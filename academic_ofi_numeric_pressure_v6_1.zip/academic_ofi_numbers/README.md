# Academic OFI Pro 6.1 - numeric pressure widgets

This is a display-only change to the supplied v6 MBO indicator. It requests
three current-value widgets and disables chart lines by default:

- OFI Pressure - 1m
- OFI Pressure - 3m
- OFI Pressure - 5m

These are signed, raw Cont-Kukanov-Stoikov OFI sums over trailing 60, 180 and
300 seconds. Positive means net buy-side pressure; negative means net sell-side
pressure. They are not probabilities, percentages, forecasts or trade delta.
For ES with correct instrument metadata, displayed units are contracts of OFI,
not a count of executed contracts. Bookmap controls numeric formatting and layout.

## Installation

1. Disable the previous OFI add-on; do not run both versions on the same archive.
2. Replace C:\BookmapScripts\academic_ofi.py with this package's academic_ofi.py.
3. Keep these two lines in Bookmap's Python API editor:

```python
import runpy
runpy.run_path(r"C:\BookmapScripts\academic_ofi.py", run_name="__main__")
```

4. Rebuild/reload using the controls that worked for your existing script, then
   enable it on the instrument. The banner says 6.1-numeric-pressure.
5. In Bookmap's Widget Settings, set the three OFI Pressure entries to the
   Widget Panel, not the Indicator Panel. The Widget Panel is the current-value
   display on the right; the Indicator Panel shows time-series curves.
   The code requests this choice by default. Saved UI settings can override it.
   Older API versions that cannot accept the flags require this UI selection.

The same Widget Settings change also works with v6's existing Academic OFI Pro
entries; a code replacement is not required just to change their visibility.

## What changed

Registration requests now use show_line_by_default=False and
show_widget_by_default=True. New names separate these displays from old curve
settings. There are no diagnostic chart series. Bookmap's add_point is still
used to update current widget values; it does not imply that lines must be visible.
The initial registration value 0.0 is a placeholder before collection begins.

The formula, event processing, Bookmap MBO reconstruction, rolling windows,
value scaling, archive schema/path, and history-retention behavior are unchanged.
The original v6 core labels within archive records are intentionally retained.
No orders are placed. No model is trained. No percentage normalization is added.

## Data quality and history

Existing files under ~/Bookmap_OFI_History are reused and never automatically
cleared. Do not delete that directory. Older events expire from current rolling
sums but remain in the archive. No historical values are repaired by this patch.

The input is still individual MBO callbacks. This patch does not establish that
the feed is live rather than replay, and does not repair a locked/crossed book,
a missing callback stream, or an incomplete initial snapshot. Existing warnings
remain. During a gap, displayed sums are observed contributions, not complete
recovered flow. An unchanged or initial zero is not proof of balanced pressure.

The initial five-second guard is heuristic, not a snapshot-completion signal.
Recorded timestamps use the local receipt clock rather than exchange time.
Use for live display, not accelerated replay. Archive writes are batched; forced
termination or disk failure can lose uncommitted tail records.

## Verification

76 offline tests passed, including widget-only registration frames, signed raw
numeric values, distinct 1/3/5-minute sums, the prior formula/book/history cases,
and generated MBO event sequences. See test_results.txt. Tests use a local API
reference/harness, not a running Bookmap/Rithmic session.

An AST comparison against the supplied v6 source confirmed that the only changed
function bodies are display registration, subscription display setup/messages,
registration-response messages, and warning wording. See core_unchanged.txt.

On-screen rendering and your live connection have NOT been tested here. A
successful registration acknowledgement means the API returned an ID; it does
not establish that your saved Widget Settings make it visible.

To run the tests from this folder:

```text
python -m unittest discover -s tests -v
```

## Primary references verified for this patch

- Bookmap Python implementation: https://raw.githubusercontent.com/BookmapAPI/python-api/master/client-rpc/src/bookmap/bookmap.py
  register_indicator exposes show_line_by_default and show_widget_by_default.
- Bookmap Widget Panel documentation: https://bookmap.com/knowledgebase/docs/KB-SettingUpAndOperating-HeatmapIndicatorPanel
  The Widget Panel shows current values; visibility is selected in Widget Settings.
- Academic OFI: https://arxiv.org/html/1011.6402 , section 2.1.

This add-on is not Bookmap-certified. Existing permissions/entitlement requirements
for your Bookmap/Rithmic configuration still apply.
