"""Test-only Bookmap public helper/serialization excerpts, with harness additions.

Source checked 2026-10-03:
https://raw.githubusercontent.com/BookmapAPI/python-api/master/client-rpc/src/bookmap/bookmap.py
MIT License, Copyright (c) 2023 Bookmap; see BOOKMAP_REFERENCE_LICENSE.txt.
This is not a complete Bookmap runtime and is not used by the indicator.
The test environment uses PyPI sortedcontainers instead of Bookmap's vendor copy.
"""
from sortedcontainers import SortedDict

FIELD_SEPARATOR = "\uE000"


def create_order_book():
    return {"asks": SortedDict(), "bids": SortedDict(lambda x: -x)}


def on_depth(order_book, is_bid, price, size):
    if not isinstance(price, int) or not isinstance(size, int):
        raise ValueError("Order book is supposed to be filled in by values in Ticks")
    side_dicts = order_book["bids" if is_bid else "asks"]
    if size == 0:
        if price in side_dicts:
            del side_dicts[price]
    else:
        side_dicts[price] = size


def get_bbo(order_book):
    bid_dict, ask_dict = order_book["bids"], order_book["asks"]
    return ((bid_dict.keys()[0], bid_dict.values()[0]) if len(bid_dict) > 0 else None,
            (ask_dict.keys()[0], ask_dict.values()[0]) if len(ask_dict) > 0 else None)


def create_mbo_book():
    return {"orders": SortedDict(), "mbp_book": create_order_book()}


def on_new_order(mbo_order_book, order_id, is_bid, price, size):
    orders = mbo_order_book["orders"]
    if order_id in orders:
        raise ValueError("Order already has order:" + order_id)
    if size == 0:
        raise ValueError("Size can't be zero")
    orders[order_id] = (is_bid, price, size)
    order_book = mbo_order_book["mbp_book"]
    side_dicts = order_book["bids" if is_bid else "asks"]
    current_size = side_dicts[price] if price in side_dicts else 0
    on_depth(order_book, is_bid, price, current_size + size)


def on_replace_order(mbo_order_book, order_id, new_price, new_size):
    """Published implementation, including its same-price overcount, for regression."""
    orders = mbo_order_book["orders"]
    if order_id not in orders:
        raise ValueError("Order book does not have order: " + order_id)
    if new_size == 0:
        raise ValueError("Size is zero")
    is_order_bid, old_price, old_size = orders[order_id]
    orders[order_id] = (is_order_bid, new_price, new_size)
    mbp_book = mbo_order_book["mbp_book"]
    side_dicts = mbp_book["bids" if is_order_bid else "asks"]
    orders[order_id] = (is_order_bid, new_price, new_size)
    old_price_level_size = side_dicts[old_price] - old_size
    new_price_level_size = (side_dicts[new_price] if new_price in side_dicts else 0) + new_size
    on_depth(mbp_book, is_order_bid, old_price, old_price_level_size)
    on_depth(mbp_book, is_order_bid, new_price, new_price_level_size)


def on_remove_order(mbo_order_book, order_id):
    orders = mbo_order_book["orders"]
    if order_id not in orders:
        raise ValueError("Order book does not have order: " + order_id)
    removed_order = orders[order_id]
    del orders[order_id]
    is_bid, price, size = removed_order
    mbp_order_book = mbo_order_book["mbp_book"]
    side_dicts = mbp_order_book["bids" if is_bid else "asks"]
    new_size = side_dicts[price] - size
    on_depth(mbp_order_book, is_bid, price, new_size)


def get_order(mbo_order_book, order_id):
    return mbo_order_book["orders"].get(order_id)


def register_indicator(addon, alias, req_id, indicator_name, graph_type,
                       color=(0, 255, 0), line_style="SOLID", initial_value=0.0,
                       show_line_by_default=True, show_widget_by_default=True, is_modifiable=False):
    msg = FIELD_SEPARATOR.join(("9", alias, str(req_id), indicator_name, graph_type,
                               str(initial_value), str(1 if show_line_by_default else 0),
                               str(1 if show_widget_by_default else 0), ",".join(map(str, color)),
                               line_style, str(1 if is_modifiable else 0)))
    addon["wire"].append(msg)


def add_point(addon, alias, indicator_id, point):
    addon["wire"].append(FIELD_SEPARATOR.join(("11", alias, str(indicator_id), str(point))))


def subscribe_to_mbo(addon, alias, req_id):
    addon["wire"].append(FIELD_SEPARATOR.join(("3", alias, str(req_id), "18", "")))


def send_user_message(addon, alias, message):
    addon["messages"].append((alias, message))


def add_label_to_settings(addon, alias, label):
    pass


def add_boolean_settings_parameter(addon, alias, name, default, reload_if_change=True):
    pass


def receive(addon, msg):
    """Harness dispatch matching the published _get_parameters_from_msg conversions."""
    t = msg.split(FIELD_SEPARATOR)
    if t[0] == "10":
        addon["indicator_response"](addon, int(t[1]), int(t[2]))
    elif t[0] == "18":
        addon["mbo"](addon, t[1], t[2], t[3], int(t[4]), int(t[5]))
    elif t[0] == "12":
        addon["interval"](addon, t[1])
    elif t[0] == "4":
        addon["response"](addon, int(t[1]))
    else:
        raise ValueError("Unsupported harness frame")
