"""Offline core regression tests, retained unchanged core and archive regression cases for v5. No live Bookmap/Rithmic connection is used."""
import ast
import math
import random
import sqlite3
import tempfile
import time
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

import academic_ofi as ofi

class FormulaTests(unittest.TestCase):
    def setUp(self):
        self.old = (100, 10, 102, 12)

    def test_unchanged_book(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, self.old), 0)

    def test_bid_add(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 15, 102, 12)), 5)

    def test_bid_size_reduction(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 7, 102, 12)), -3)

    def test_ask_add(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 102, 20)), -8)

    def test_ask_size_reduction(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 102, 8)), 4)

    def test_bid_price_improves(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (101, 3, 102, 12)), 3)

    def test_bid_price_worsens(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (99, 999, 102, 12)), -10)

    def test_ask_price_improves(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 101, 7)), -7)

    def test_ask_price_worsens(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 103, 999)), 12)

    def test_both_sides_change(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (101, 5, 103, 90)), 17)

    def test_randomized_against_piecewise_definition(self):
        rng = random.Random(7)
        for _ in range(10000):
            old = (100, rng.randrange(1, 100), 105, rng.randrange(1, 100))
            new = (100 + rng.randrange(-1, 2), rng.randrange(1, 100),
                   105 + rng.randrange(-1, 2), rng.randrange(1, 100))
            bid = new[1] if new[0] > old[0] else (-old[1] if new[0] < old[0] else new[1] - old[1])
            ask = -new[3] if new[2] < old[2] else (old[3] if new[2] > old[2] else old[3] - new[3])
            self.assertEqual(ofi.academic_ofi_event(old, new), bid + ask)


class RollingTests(unittest.TestCase):
    def test_empty_is_zero(self):
        self.assertEqual(ofi.RollingOFI().values(0), {60: 0, 180: 0, 300: 0})

    def test_exact_horizon_boundaries(self):
        r = ofi.RollingOFI()
        r.add(10.0, 5)
        self.assertEqual(r.values(69.999)[60], 5)
        self.assertEqual(r.values(70.0)[60], 0)
        self.assertEqual(r.values(190.0)[180], 0)
        self.assertEqual(r.values(310.0)[300], 0)

    def test_same_timestamp_multiple_events(self):
        r = ofi.RollingOFI()
        r.add(1.0, 10)
        r.add(1.0, -3)
        self.assertEqual(r.values(1.0)[60], 7)

    def test_no_events_still_expires_flow(self):
        r = ofi.RollingOFI()
        r.add(1, 17)
        self.assertEqual(r.values(1000), {60: 0, 180: 0, 300: 0})
        r.add(1001, -2)
        self.assertEqual(r.values(1001), {60: -2, 180: -2, 300: -2})

    def test_non_monotonic_time_rejected(self):
        r = ofi.RollingOFI()
        r.add(10, 1)
        with self.assertRaises(ValueError):
            r.add(9, 2)

    def test_nan_time_rejected(self):
        with self.assertRaises(ValueError):
            ofi.RollingOFI().values(math.nan)

    def test_randomized_against_direct_event_sums_and_compaction(self):
        rng = random.Random(91)
        r = ofi.RollingOFI()
        r.COMPACT_THRESHOLD = 32
        history, now = [], 0.0
        for index in range(12000):
            now += rng.random() * 0.5
            delta = rng.randrange(-100, 101)
            r.add(now, delta)
            history.append((now, delta))
            if index % 37 == 0:
                actual = r.values(now)
                for h in ofi.WINDOWS_SECONDS:
                    self.assertEqual(actual[h], sum(d for ts, d in history if ts > now - h))
        r.values(now + 1000)
        self.assertLess(len(r.timestamps), 32)


class MemoryArchive:
    def __init__(self, rows=(), total=0, first_started=None, last_at=-math.inf):
        self.recent = list(rows)
        self.restored_total = total
        self.first_started = first_started
        self.last_at = last_at
        self.error = None
        self.rows = []
        self.path = Path('test-memory-archive')

    def submit(self, row):
        if self.error:
            raise ofi.ArchiveError(self.error)
        self.rows.append(row)


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'test.sqlite3'
        self.identity = ofi._identity('ES_TEST', 'ES_TEST', .25, 1, 50)
        self.archives = []

    def open_archive(self, now=0, identity=None):
        a = ofi.SQLiteArchive(self.path, identity or self.identity, now)
        self.archives.append(a)
        return a

    def tearDown(self):
        for archive in self.archives:
            archive.close()
        self.temp.cleanup()

    def rows(self):
        with closing(sqlite3.connect(str(self.path))) as c:
            return c.execute('SELECT received_at_utc, kind, ofi_raw, cumulative_raw FROM records ORDER BY seq').fetchall()

    def seed(self, a):
        h = ofi.OFIHistory(a)
        h.note(1, 'BASELINE', bbo=(100, 10, 102, 12))
        h.add(2, (100, 10, 102, 12), (100, 15, 102, 12))
        h.add(150, (100, 15, 102, 12), (100, 18, 102, 12))
        h.note(151, 'GAP_START', 'test gap')
        h.note(153, 'GAP_END', bbo=(110, 10, 112, 12))
        return h

    def test_close_reopen_preserves_total_and_recent_windows(self):
        a = self.open_archive()
        self.seed(a)
        a.close()
        original_rows = self.rows()
        b = self.open_archive(200)
        h = ofi.OFIHistory(b)
        self.assertEqual(h.total, 8)
        self.assertEqual(h.started_at, 1)
        self.assertEqual(h.rolling.values(200), {60: 3, 180: 3, 300: 8})
        self.assertEqual(self.rows(), original_rows)

    def test_old_rows_survive_cache_expiration_and_reopening(self):
        a = self.open_archive()
        h = self.seed(a)
        h.rolling.COMPACT_THRESHOLD = 1
        self.assertEqual(h.rolling.values(1000), {60: 0, 180: 0, 300: 0})
        a.close()
        self.assertEqual(len(self.rows()), 5)
        b = self.open_archive(1000)
        restored = ofi.OFIHistory(b)
        self.assertEqual(restored.total, 8)
        self.assertEqual(len(restored.rolling.timestamps), 0)
        self.assertEqual(len(self.rows()), 5)

    def test_gaps_are_retained_with_before_after_bbo(self):
        a = self.open_archive()
        self.seed(a)
        a.flush()
        with closing(sqlite3.connect(str(self.path))) as c:
            row = c.execute("SELECT old_bid, old_bid_size, bid, bid_size, ofi_raw FROM records WHERE kind='OFI' LIMIT 1").fetchone()
            self.assertEqual(row, (100, 10, 100, 15, 5))
            self.assertEqual(c.execute("SELECT count(*) FROM records WHERE kind LIKE 'GAP_%'").fetchone()[0], 2)

    def test_automatic_timed_flush(self):
        with patch.object(ofi, 'ARCHIVE_FLUSH_SECONDS', 0.01):
            a = self.open_archive()
            h = ofi.OFIHistory(a)
            h.note(1, 'BASELINE')
            deadline = time.monotonic() + 2
            while not self.rows() and time.monotonic() < deadline:
                time.sleep(.01)
            self.assertEqual(len(self.rows()), 1)

    def test_identity_mismatch_does_not_reset_archive(self):
        a = self.open_archive()
        self.seed(a)
        a.close()
        rows = self.rows()
        bad = dict(self.identity, size_multiplier=10)
        with self.assertRaises(ofi.ArchiveError):
            self.open_archive(200, bad)
        self.assertEqual(self.rows(), rows)

    def test_duplicate_writer_is_rejected(self):
        a = self.open_archive()
        self.seed(a)
        a.flush()
        with self.assertRaises(ofi.ArchiveError):
            self.open_archive(200)
        self.assertEqual(len(self.rows()), 5)

    def test_backward_computer_clock_does_not_erase_history(self):
        a = self.open_archive()
        self.seed(a)
        a.close()
        with self.assertRaises(ofi.ArchiveError):
            self.open_archive(100)
        self.assertEqual(len(self.rows()), 5)

    def test_batch_order_and_integrity_after_many_events(self):
        a = self.open_archive()
        h = ofi.OFIHistory(a)
        h.note(0, 'BASELINE')
        h.rolling.COMPACT_THRESHOLD = 16
        previous = (100, 10, 102, 12)
        for i in range(1, 10001):
            current = (100, 10 + i, 102, 12)
            h.add(i * .1, previous, current)
            previous = current
        a.close()
        rows = self.rows()
        self.assertEqual(len(rows), 10001)
        self.assertEqual(rows[-1][3], 10000)
        self.assertEqual(sum(row[2] for row in rows), 10000)
        with closing(sqlite3.connect(str(self.path))) as c:
            self.assertEqual(c.execute('PRAGMA integrity_check').fetchone()[0], 'ok')

    def test_existing_committed_rows_survive_write_failure(self):
        a = self.open_archive()
        self.seed(a)
        a.flush()
        good = self.rows()
        a.submit((1,))  # Intentionally malformed record: exercise writer failure.
        with self.assertRaises(ofi.ArchiveError):
            a.flush()
        self.assertIsNotNone(a.error)
        self.assertEqual(self.rows(), good)

    def test_no_history_delete_statements_exist(self):
        tree = ast.parse(Path(ofi.__file__).read_text())
        sql = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                if node.func.attr in ('execute', 'executemany') and node.args:
                    if isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                        sql.append(node.args[0].value.strip().upper())
        self.assertFalse(any(s.startswith(('DELETE', 'DROP', 'TRUNCATE', 'REPLACE')) for s in sql))

