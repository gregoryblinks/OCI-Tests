"""Offline checks for current-value widgets, not on-screen Bookmap validation."""
import inspect
import itertools
import math
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import academic_ofi as ofi
import bookmap_reference as api


class NumericDisplayTests(unittest.TestCase):
    def test_published_signature_requests_widget_not_line(self):
        opts = ofi._registration_kwargs(api, (1, 2, 3))
        self.assertIs(opts['show_line_by_default'], False)
        self.assertIs(opts['show_widget_by_default'], True)
        self.assertEqual(opts['initial_value'], 0.0)

    def test_kwargs_wrappers_receive_visibility_flags(self):
        def register(addon, alias, req_id, name, graph, **kwargs):
            return kwargs
        opts = ofi._registration_kwargs(SimpleNamespace(register_indicator=register), (1, 2, 3))
        self.assertIs(opts['show_line_by_default'], False)
        self.assertIs(opts['show_widget_by_default'], True)

    def test_older_signature_does_not_receive_unsupported_keywords(self):
        def register(addon, alias, req_id, name, graph, color=None, line_style=None, initial_value=0.0):
            return None
        opts = ofi._registration_kwargs(SimpleNamespace(register_indicator=register), (1, 2, 3))
        self.assertNotIn('show_line_by_default', opts)
        self.assertNotIn('show_widget_by_default', opts)
        register(None, 'TEST', 1, 'OFI', 'BOTTOM', **opts)

    def test_wire_flags_are_line_zero_widget_one(self):
        addon = {'wire': []}
        api.register_indicator(addon, 'TEST', 1, 'OFI Pressure - 1m', 'BOTTOM',
                               **ofi._registration_kwargs(api, (1, 2, 3)))
        fields = addon['wire'][0].split(api.FIELD_SEPARATOR)
        self.assertEqual(fields[5:8], ['0.0', '0', '1'])

    def test_widgets_receive_different_exact_window_values(self):
        rolling = ofi.RollingOFI()
        rolling.add(120, 20)
        rolling.add(240, 145)
        rolling.add(360, 245)
        state = SimpleNamespace(indicators={60: 10, 180: 11, 300: 12},
                                last_plot=-math.inf, values=rolling.values,
                                points_submitted=0, warned={})
        addon = {'wire': []}
        with patch.object(ofi, 'bm', api):
            ofi._publish(addon, 'TEST', state, 400)
        values = [float(f.split(api.FIELD_SEPARATOR)[-1]) for f in addon['wire']]
        self.assertEqual(values, [245.0, 390.0, 410.0])
        self.assertEqual(state.points_submitted, 3)

    def test_negative_and_large_values_not_clipped_or_normalized(self):
        state = SimpleNamespace(indicators={60: 1, 180: 2, 300: 3},
                                last_plot=-math.inf,
                                values=lambda now: {60: -125.0, 180: 45000.0, 300: 0.0},
                                points_submitted=0, warned={})
        addon = {'wire': []}
        with patch.object(ofi, 'bm', api):
            ofi._publish(addon, 'TEST', state, 0)
        values = [float(f.split(api.FIELD_SEPARATOR)[-1]) for f in addon['wire']]
        self.assertEqual(values, [-125.0, 45000.0, 0.0])


if __name__ == '__main__':
    unittest.main()
