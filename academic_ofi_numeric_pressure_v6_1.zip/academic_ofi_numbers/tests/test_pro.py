"""Offline tests: helper excerpts, adapter wire frames and generated order streams.

These tests do not start Bookmap and do not connect to Rithmic.
"""
import ast
import contextlib
import io
import itertools
import math
import random
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import academic_ofi as ofi
import bookmap_reference as api


class MemoryArchive:
    def __init__(self):
        self.recent = []
        self.restored_total = 0
        self.first_started = None
        self.last_at = -math.inf
        self.error = None
        self.rows = []
        self.path = "memory-test-only"
    def submit(self, row):
        if self.error:
            raise ofi.ArchiveError(self.error)
        self.rows.append(row)


class BookTests(unittest.TestCase):
    def test_installed_helper_probe(self):
        ofi._probe_helpers(api)

    def test_published_same_price_bug_is_avoided(self):
        raw = api.create_mbo_book()
        api.on_new_order(raw, "b1", True, 100, 10)
        api.on_new_order(raw, "b2", True, 100, 7)
        api.on_replace_order(raw, "b1", 100, 4)
        self.assertEqual(api.get_bbo(raw["mbp_book"])[0][1], 21)  # published bug
        fixed = ofi.MBOBook(api)
        fixed.apply("BID_NEW", "b1", 100, 10)
        fixed.apply("BID_NEW", "b2", 100, 7)
        fixed.apply("ASK_NEW", "a1", 102, 9)
        fixed.apply("REPLACE", "b1", 100, 4)
        self.assertEqual(fixed.top(), ("VALID", (100, 11, 102, 9)))

    def test_ask_replacement(self):
        b = ofi.MBOBook(api)
        b.apply("BID_NEW", "b", 100, 2)
        b.apply("ASK_NEW", "a", 101, 8)
        b.apply("REPLACE", "a", 101, 3)
        self.assertEqual(b.top(), ("VALID", (100, 2, 101, 3)))

    def test_zero_replacement_removes(self):
        b = ofi.MBOBook(api)
        b.apply("BID_NEW", "b", 100, 2)
        b.apply("REPLACE", "b", 100, 0)
        self.assertEqual(b.top(), ("EMPTY", None))

    def test_cancel_ignores_payload(self):
        b = ofi.MBOBook(api)
        b.apply("BID_NEW", "b", 100, 2)
        b.apply("CANCEL", "b", None, "not-used")
        self.assertEqual(b.top(), ("EMPTY", None))

    def test_duplicate_rejected_before_mutation(self):
        b = ofi.MBOBook(api)
        b.apply("BID_NEW", "b", 100, 2)
        with self.assertRaises(ofi.InputError):
            b.apply("ASK_NEW", "b", 101, 4)
        self.assertEqual(api.get_order(b.book, "b"), (True, 100, 2))

    def test_unknown_replace_cancel_rejected(self):
        b = ofi.MBOBook(api)
        for event in ("REPLACE", "CANCEL"):
            with self.subTest(event=event), self.assertRaises(ofi.InputError):
                b.apply(event, "missing", 100, 3)

    def test_malformed_replacement_preserves_book(self):
        b = ofi.MBOBook(api)
        b.apply("BID_NEW", "b", 100, 2)
        for price, size in ((True, 3), (100, -1), (100.0, 2), (100, False)):
            with self.subTest(price=price, size=size), self.assertRaises(ofi.InputError):
                b.apply("REPLACE", "b", price, size)
        self.assertEqual(api.get_order(b.book, "b"), (True, 100, 2))

    def test_locked_not_reported_valid(self):
        b = ofi.MBOBook(api)
        b.apply("BID_NEW", "b", 100, 2)
        b.apply("ASK_NEW", "a", 100, 4)
        self.assertEqual(b.top()[0], "LOCKED")
        b.apply("REPLACE", "b", 101, 2)
        self.assertEqual(b.top()[0], "CROSSED")

    def test_negative_prices(self):
        b = ofi.MBOBook(api)
        b.apply("BID_NEW", "b", -100, 2)
        b.apply("ASK_NEW", "a", -99, 4)
        self.assertEqual(b.top(), ("VALID", (-100, 2, -99, 4)))

    def test_50000_random_events_against_fresh_rebuild(self):
        rng = random.Random(6026)
        b = ofi.MBOBook(api)
        oracle = {}
        last_id = 0
        for n in range(50000):
            choice = rng.random()
            if not oracle or choice < .43:
                last_id += 1
                oid = str(last_id)
                side = rng.choice((False, True))
                price = rng.randrange(80, 101) if side else rng.randrange(101, 123)
                size = rng.randrange(1, 70)
                b.apply("BID_NEW" if side else "ASK_NEW", oid, price, size)
                oracle[oid] = (side, price, size)
            else:
                oid = rng.choice(list(oracle))
                side, old_price, old_size = oracle[oid]
                if choice < .76:
                    price = old_price if rng.random() < .7 else (rng.randrange(80, 101) if side else rng.randrange(101, 123))
                    size = rng.randrange(0, 70)
                    b.apply("REPLACE", oid, price, size)
                    if size:
                        oracle[oid] = side, price, size
                    else:
                        del oracle[oid]
                else:
                    b.apply("CANCEL", oid, 0, 0)
                    del oracle[oid]
            if n % 100 == 0 or n == 49999:
                levels = {True: {}, False: {}}
                for side, p, s in oracle.values():
                    levels[side][p] = levels[side].get(p, 0) + s
                self.assertEqual(dict(b.book['orders']), oracle)
                self.assertEqual(dict(b.book['mbp_book']['bids']), levels[True])
                self.assertEqual(dict(b.book['mbp_book']['asks']), levels[False])
                bid = (max(levels[True]), levels[True][max(levels[True])]) if levels[True] else None
                ask = (min(levels[False]), levels[False][min(levels[False])]) if levels[False] else None
                self.assertEqual(api.get_bbo(b.book['mbp_book']), (bid, ask))


class StateTests(unittest.TestCase):
    def setUp(self):
        self.archive = MemoryArchive()
        self.history = ofi.OFIHistory(self.archive)
        self.s = ofi.InstrumentState(api, self.history, 0, .25, 1)

    def event(self, t, typ, oid, p, s):
        self.s.record_receipt(t, typ)
        return self.s.consume(t, typ, oid, p, s)

    def baseline(self):
        self.event(0, "BID_NEW", "b", 100, 10)
        self.event(.1, "ASK_NEW", "a", 102, 12)
        self.event(5.1, "REPLACE", "a", 102, 12)
        self.assertTrue(self.s.started)

    def test_start_on_callback_without_interval(self):
        self.baseline()
        self.assertEqual(self.history.total, 0)
        self.assertEqual(self.event(5.2, "REPLACE", "b", 100, 15), None)
        self.assertEqual(self.s.values(5.2)[60], 5)

    def test_startup_snapshot_is_not_flow(self):
        self.event(0, "BID_NEW", "b", 100, 10)
        self.event(.1, "ASK_NEW", "a", 102, 12)
        self.event(1, "BID_NEW", "b2", 100, 500)
        self.assertEqual(self.s.values(1), {60: 0, 180: 0, 300: 0})
        self.assertFalse(self.s.started)

    def test_timer_can_establish_baseline_without_new_events(self):
        self.event(0, "BID_NEW", "b", 100, 10)
        self.event(.1, "ASK_NEW", "a", 102, 12)
        self.assertTrue(self.s._start_ready(5.2))
        self.assertEqual(self.history.total, 0)

    def test_replacement_atomic_no_empty_intermediate_gap(self):
        self.baseline()
        self.event(5.2, "REPLACE", "b", 101, 4)
        self.assertEqual(self.history.total, 4)
        self.assertFalse(self.s.gap_open)
        self.assertNotIn("GAP_START", [row[1] for row in self.archive.rows])

    def test_same_price_change_exact(self):
        self.baseline()
        self.event(5.2, "REPLACE", "b", 100, 20)
        self.event(5.3, "REPLACE", "a", 102, 7)
        self.assertEqual(self.history.total, 15)

    def test_no_double_count_from_price_sampling(self):
        self.baseline()
        self.event(5.2, "BID_NEW", "improved", 101, 8)  # +8
        self.event(5.3, "REPLACE", "b", 100, 20)      # deeper, no BBO change
        self.event(5.4, "CANCEL", "improved", 0, 0)   # -8
        self.assertEqual(self.history.total, 0)
        self.assertEqual(ofi.academic_ofi_event((100, 10, 102, 12), (100, 20, 102, 12)), 10)
        # An endpoint-only/sampled replacement would wrongly produce +10 here.

    def test_locked_history_retained_and_recovery_not_bridged(self):
        self.baseline()
        self.event(5.2, "REPLACE", "b", 100, 15)  # +5
        before = list(self.archive.rows)
        self.event(6, "BID_NEW", "lock", 102, 3)
        self.assertEqual(self.s.reason, "LOCKED")
        self.assertEqual(self.s.values(6)[60], 5)
        self.event(6.1, "REPLACE", "a", 103, 9)
        self.assertFalse(self.s.gap_open)
        self.assertEqual(self.history.total, 5)
        self.assertEqual(self.archive.rows[:len(before)], before)
        self.event(6.2, "REPLACE", "a", 103, 7)
        self.assertEqual(self.history.total, 7)
        self.assertEqual(self.s.full_windows(7), [])

    def test_missing_side_history_retained(self):
        self.baseline()
        self.event(5.2, "REPLACE", "b", 100, 15)
        self.event(6, "CANCEL", "a", 0, 0)
        self.assertEqual(self.s.values(6)[60], 5)
        self.assertTrue(self.s.gap_open)
        self.event(7, "ASK_NEW", "a2", 105, 9)
        self.assertEqual(self.history.total, 5)

    def test_non_bbo_orders_have_no_ofi(self):
        self.baseline()
        self.event(6, "BID_NEW", "deep", 90, 900)
        self.assertEqual(self.history.total, 0)
        self.assertEqual(self.s.changes, 0)

    def test_history_ages_out_not_reset(self):
        self.baseline()
        self.event(6, "REPLACE", "b", 100, 15)
        count = len(self.archive.rows)
        self.assertEqual(self.s.values(66)[60], 0)
        self.assertEqual(self.s.values(66)[180], 5)
        self.assertEqual(self.s.values(306), {60: 0, 180: 0, 300: 0})
        self.assertEqual(self.history.total, 5)
        self.assertEqual(len(self.archive.rows), count)

    def test_size_multiplier(self):
        self.s.size_multiplier = 10
        self.baseline()
        self.event(6, "REPLACE", "b", 100, 15)
        self.assertEqual(self.s.values(6)[60], .5)

    def test_no_unconditional_pausing_after_warmup(self):
        self.baseline()
        self.event(6, "REPLACE", "b", 100, 15)
        self.assertEqual(self.s.mode(), "ACTIVE")
        self.assertEqual(self.s.full_windows(310), [60, 180, 300])


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.now = 1_800_000_000.0
        self.stdout = io.StringIO()
        self.stack = contextlib.ExitStack()
        self.stack.enter_context(contextlib.redirect_stdout(self.stdout))
        for key, value in [('bm', api), ('HISTORY_DIRECTORY', Path(self.tmp.name)),
                           ('_states', {}), ('_histories', {}), ('_pending_indicators', {}),
                           ('_pending_data', {}), ('_request_ids', itertools.count(1)),
                           ('_clock', SimpleNamespace(now=lambda: self.now))]:
            self.stack.enter_context(patch.object(ofi, key, value))
        self.addon = dict(wire=[], messages=[], indicator_response=ofi.handle_indicator_response,
                          mbo=ofi.handle_mbo_event, interval=ofi.on_interval, response=ofi.handle_data_response)
        self.alias = 'ES.TEST@RITHMIC'

    def tearDown(self):
        ofi._close_histories()
        self.stack.close()
        self.tmp.cleanup()

    def subscribe(self, alias=None, supported=True):
        ofi.handle_subscribe_instrument(self.addon, alias or self.alias, 'ES Test', False,
                                        .25, 1, 50, {'mbo': supported})

    def ack(self, alias=None):
        alias = alias or self.alias
        frames = [s.split(api.FIELD_SEPARATOR) for s in self.addon['wire'] if s.startswith('9' + api.FIELD_SEPARATOR)]
        for n, t in enumerate(frames):
            if t[1] == alias:
                api.receive(self.addon, api.FIELD_SEPARATOR.join(('10', t[2], str(n))))

    def event(self, dt, typ, oid, price, size, alias=None):
        self.now += dt
        api.receive(self.addon, api.FIELD_SEPARATOR.join(('18', alias or self.alias, typ, oid, str(price), str(size))))

    def start(self):
        self.subscribe()
        self.ack()
        self.event(.1, 'BID_NEW', 'b', 100, 10)
        self.event(.1, 'ASK_NEW', 'a', 102, 12)
        self.event(5.1, 'REPLACE', 'a', 102, 12)

    def test_three_widget_only_zero_initialized_registration_frames(self):
        self.subscribe()
        frames = [s.split(api.FIELD_SEPARATOR) for s in self.addon['wire'] if s.startswith('9' + api.FIELD_SEPARATOR)]
        self.assertEqual(len(frames), 3)
        self.assertEqual([f[3] for f in frames], ['OFI Pressure - 1m', 'OFI Pressure - 3m', 'OFI Pressure - 5m'])
        for t in frames:
            self.assertEqual(t[4], 'BOTTOM')
            self.assertEqual(t[5:8], ['0.0', '0', '1'])
            self.assertEqual(t[-1], '1')

    def test_id_zero_is_stored_and_immediately_plotted(self):
        self.subscribe()
        self.ack()
        self.assertEqual(ofi._states[self.alias].indicators, {60: 0, 180: 1, 300: 2})
        points = [s.split(api.FIELD_SEPARATOR) for s in self.addon['wire'] if s.startswith('11' + api.FIELD_SEPARATOR)]
        self.assertTrue(any(t[2] == '0' for t in points))
        self.assertIn('3/3 OFI indicators acknowledged', self.stdout.getvalue())

    def test_e2e_numeric_wire_points_from_mbo(self):
        self.start()
        self.event(.3, 'REPLACE', 'b', 100, 15)
        self.event(.3, 'REPLACE', 'a', 102, 8)
        points = [s.split(api.FIELD_SEPARATOR) for s in self.addon['wire'] if s.startswith('11' + api.FIELD_SEPARATOR)]
        self.assertEqual([float(t[-1]) for t in points[-3:]], [9, 9, 9])
        self.assertNotIn('NaN', '\n'.join(self.addon['wire']))
        self.assertEqual(ofi._states[self.alias].changes, 2)

    def test_missing_registration_is_reported_even_with_working_feed(self):
        self.subscribe()
        self.event(.1, 'BID_NEW', 'b', 100, 10)
        self.event(.1, 'ASK_NEW', 'a', 102, 12)
        self.event(5.1, 'REPLACE', 'b', 100, 10)
        self.event(6, 'REPLACE', 'b', 100, 14)
        self.assertIn('DISPLAY NOT READY: 0/3', self.stdout.getvalue())
        self.assertEqual(ofi._states[self.alias].history.total, 4)

    def test_mbo_only_no_depth_subscription(self):
        self.subscribe()
        frames = [s.split(api.FIELD_SEPARATOR) for s in self.addon['wire'] if s.startswith('3' + api.FIELD_SEPARATOR)]
        self.assertEqual(len(frames), 1)
        self.assertEqual(frames[0][3], '18')

    def test_interval_decay_publishes_after_silence(self):
        self.start()
        self.event(.3, 'REPLACE', 'b', 100, 15)
        self.now += 61
        api.receive(self.addon, '12' + api.FIELD_SEPARATOR + self.alias)
        points = [s.split(api.FIELD_SEPARATOR) for s in self.addon['wire'] if s.startswith('11' + api.FIELD_SEPARATOR)]
        self.assertEqual([float(t[-1]) for t in points[-3:]], [0, 5, 5])
        self.assertIn('past observations only', self.stdout.getvalue())

    def test_legacy_setting_cannot_hide_or_reset(self):
        self.start()
        self.event(.3, 'REPLACE', 'b', 100, 15)
        for name in ('Show partial windows during startup', 'Reset OFI counter (increase to reset)',
                     'Show MBO diagnostic lines'):
            ofi.on_settings_change(self.addon, self.alias, name, 'BOOLEAN', False)
        self.assertEqual(ofi._states[self.alias].values(self.now)[60], 5)

    def test_no_periodic_diagnostics_by_default(self):
        self.start()
        self.now += 31
        ofi.on_interval(self.addon, self.alias)
        self.assertNotIn('DETAILS ', self.stdout.getvalue())

    def test_opt_in_diagnostics_include_real_receipt_counts(self):
        self.start()
        ofi.on_settings_change(self.addon, self.alias, ofi.DIAGNOSTIC_SETTING, 'BOOLEAN', True)
        self.event(31, 'REPLACE', 'a', 102, 10)
        self.assertIn('DETAILS ', self.stdout.getvalue())
        self.assertIn('"received": 4', self.stdout.getvalue())
        self.assertIn('"source": "MBO"', self.stdout.getvalue())

    def test_unknown_order_fails_but_keeps_counting_receipts_and_history(self):
        self.start()
        self.event(.3, 'REPLACE', 'b', 100, 15)
        s = ofi._states[self.alias]
        value = s.history.total
        self.event(.3, 'CANCEL', 'missing', 0, 0)
        self.assertTrue(s.failed)
        self.event(.3, 'BID_NEW', 'still-arrives', 98, 50)
        self.assertEqual(s.total, 6)
        self.assertEqual(s.history.total, value)
        self.assertEqual(s.values(self.now)[60], value)

    def test_resubscribe_retains_archive(self):
        self.start()
        self.event(.3, 'REPLACE', 'b', 100, 15)
        history = ofi._states[self.alias].history
        self.now += 1
        ofi.handle_unsubscribe_instrument(self.addon, self.alias)
        self.subscribe()
        self.assertIs(ofi._states[self.alias].history, history)
        self.assertEqual(history.total, 5)
        self.assertFalse(ofi._states[self.alias].started)

    def test_late_registration_ack_ignored_after_unsubscribe(self):
        self.subscribe()
        requests = list(ofi._pending_indicators)
        ofi.handle_unsubscribe_instrument(self.addon, self.alias)
        for req in requests:
            ofi.handle_indicator_response(self.addon, req, 42)
        self.assertNotIn(self.alias, ofi._states)

    def test_multiple_instruments_ids_and_books_are_separate(self):
        self.subscribe()
        other = 'NQ.TEST@RITHMIC'
        self.subscribe(other)
        self.ack(self.alias)
        self.ack(other)
        self.event(.1, 'BID_NEW', 'shared-id', 100, 2)
        self.event(.1, 'ASK_NEW', 'shared-id', 110, 9, alias=other)
        self.assertIsNot(ofi._states[self.alias].book, ofi._states[other].book)
        all_ids = [i for s in ofi._states.values() for i in s.indicators.values()]
        self.assertEqual(len(all_ids), len(set(all_ids)))

    def test_permission_no_mbo_is_error_not_fake_flow(self):
        self.subscribe(supported=False)
        self.assertIn('no MBO capability', ofi._states[self.alias].failed)
        self.assertFalse(any(w.startswith('3' + api.FIELD_SEPARATOR) for w in self.addon['wire']))

    def test_registration_error_keeps_other_requests_and_data(self):
        original = api.register_indicator
        def partial(addon, alias, req_id, name, graph, **kwargs):
            if name.endswith('3m'):
                raise RuntimeError('test registration failure')
            return original(addon, alias, req_id, name, graph, **kwargs)
        with patch.object(api, 'register_indicator', partial):
            self.subscribe()
        self.assertIn(180, ofi._states[self.alias].indicator_errors)
        self.assertEqual(len(ofi._pending_indicators), 2)
        self.assertTrue(ofi._pending_data)

    def test_no_callback_warning(self):
        self.subscribe()
        self.ack()
        self.now += 16
        ofi.on_interval(self.addon, self.alias)
        self.assertIn('NO MBO CALLBACKS', self.stdout.getvalue())

    def test_locked_warning_does_not_masquerade_as_live_zero(self):
        self.start()
        self.event(.3, 'BID_NEW', 'lock', 102, 5)
        self.now += 3
        ofi.on_interval(self.addon, self.alias)
        self.assertIn('book=LOCKED', self.stdout.getvalue())
        self.assertIn('Do not interpret an unchanging number as balanced flow', self.stdout.getvalue())


class ArchitectureTests(unittest.TestCase):
    def test_no_order_placement_or_depth_fallback_or_get_bbos_requirement(self):
        source = Path(ofi.__file__).read_text()
        tree = ast.parse(source)
        attrs = {n.attr for n in ast.walk(tree) if isinstance(n, ast.Attribute)}
        self.assertFalse(attrs & {'send_order', 'subscribe_to_depth', 'subscribe_to_trades', 'on_replace_order'})
        self.assertNotIn('initial_value=NAN', source)

    def test_formula_is_unchanged_from_prior_version(self):
        oldpath = Path('/mnt/data/bookmap_academic_ofi_v5_1/academic_ofi.py')
        if not oldpath.exists():
            self.skipTest('prior source is only available in build environment')
        def fn(text):
            tree = ast.parse(text)
            return ast.dump(next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'academic_ofi_event'))
        self.assertEqual(fn(oldpath.read_text()), fn(Path(ofi.__file__).read_text()))


if __name__ == '__main__':
    unittest.main()
