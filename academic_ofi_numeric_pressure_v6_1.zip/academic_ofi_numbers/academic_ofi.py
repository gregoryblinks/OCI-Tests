"""Academic OFI Pro 6.1 -- Bookmap Python add-on; numeric widgets only.

Source: individual MBO callbacks -> Bookmap MBO helper -> best quotes -> CKS OFI.
No predictions, training, trades, trade-volume substitution, or depth fallback.

Each received order event is applied before evaluating the four-term OFI
formula. Only chart redraws are throttled. REPLACE uses remove + add followed
by ONE observation, avoiding the published same-price replacement helper bug.

Only three current-value widgets are requested; chart lines default to OFF.
The 1m / 3m / 5m readings are raw signed OFI, not percentages or forecasts.
Bookmap Widget Settings can override registration defaults.
Numeric zero at registration is
an initialization placeholder, not proof of reception. Registration acks and
plot submissions are tracked separately from calculation. Local reception is
not proof of live-vs-replay provenance or exchange-time freshness.

Existing v2-v5.1 SQLite archives are retained under ~/Bookmap_OFI_History.
All accepted BBO changes, baselines and gaps are appended, never deleted.
A missing/locked/crossed book does not erase history or hide previously
recorded sums. Missing flow is NOT inferred across a gap. Such sums are
incomplete until the gap leaves each rolling window. Persistent invalid data
remains an error, not something this script can turn into valid market data.

Initial five-second snapshot guard is a heuristic, NOT a snapshot-end flag.
A valid book after the guard establishes the initial baseline; this may be
observed in an MBO callback or timer. Quote-to-quote OFI remains event-driven.
Receipt-time clock is local UTC anchored to monotonic time; live use only.
No automatic daily reset; orderly shutdown flushes; a crash, full disk or
power loss can lose the uncommitted tail. No read-only archive is overwritten.

API: https://github.com/BookmapAPI/python-api
Formula: https://arxiv.org/abs/1011.6402 (section 2.1)
This add-on is not Bookmap-certified and has not been tested on a live feed.
"""
import hashlib
import inspect
import itertools
import json
import math
import os
import queue
import sqlite3
import threading
import time
from array import array
from bisect import bisect_right
from pathlib import Path
from typing import Dict, Tuple

VERSION = "6.1-numeric-pressure"
WINDOWS_SECONDS = (60, 180, 300)
STARTUP_GUARD_SECONDS = 5.0
PLOT_EVERY_SECONDS = 0.25
HISTORY_DIRECTORY = Path.home() / "Bookmap_OFI_History"
ARCHIVE_FLUSH_SECONDS = 1.0
ARCHIVE_BATCH_SIZE = 4096
ARCHIVE_QUEUE_LIMIT = 100000
REGISTRATION_WARNING_SECONDS = 10.0
DATA_WARNING_SECONDS = 15.0
PERSISTENT_INVALID_SECONDS = 2.0
WARNING_REPEAT_SECONDS = 60.0
DIAGNOSTIC_SECONDS = 30.0
DIAGNOSTIC_SETTING = "OFI Pro: detailed console diagnostics"
BBO = Tuple[int, int, int, int]
MBO_TYPES = ("BID_NEW", "ASK_NEW", "REPLACE", "CANCEL")
bm = None
_STOP = object()
_states = {}
_histories = {}
_pending_indicators = {}
_pending_data = {}
_request_ids = itertools.count(1)

class ReceiptClock:
    """UTC-labelled, monotonic receipt clock for this Python process."""
    def __init__(self):
        self.utc_anchor = time.time()
        self.monotonic_anchor = time.monotonic()

    def now(self):
        return self.utc_anchor + time.monotonic() - self.monotonic_anchor

def academic_ofi_event(previous: BBO, current: BBO) -> int:
    """Exact CKS event contribution, in integer Bookmap size units.

    The four conditions are INDEPENDENT. Equality activates both terms
    on that side, which gives the change in queue size at unchanged price.
    """
    old_bid, old_bid_size, old_ask, old_ask_size = previous
    bid, bid_size, ask, ask_size = current
    return (
        (bid_size if bid >= old_bid else 0)
        - (old_bid_size if bid <= old_bid else 0)
        - (ask_size if ask <= old_ask else 0)
        + (old_ask_size if ask >= old_ask else 0)
    )

class RollingOFI:
    """Exact trailing sums on (now - horizon, now], without time bucketing.

    Compact arrays store timestamps and cumulative integer OFI. Three rolling
    sums share one history. Non-BBO events and zero contributions use no history.
    This is only an expendable working cache. The separate append-only SQLite
    archive retains the complete recorded OFI history; cache trimming never
    deletes archived events or changes the recorded cumulative OFI.
    """

    COMPACT_THRESHOLD = 65536

    def __init__(self, windows=WINDOWS_SECONDS):
        if not windows or any(w <= 0 for w in windows):
            raise ValueError("OFI windows must be positive")
        self.windows = tuple(windows)
        self.timestamps = array("d")
        self.prefixes = array("q")
        self.total = 0
        self.base_total = 0
        self.head = 0
        self.last_time = -math.inf
        self._since_trim = 0

    def _check_time(self, now: float) -> None:
        if not math.isfinite(now) or now < self.last_time:
            raise ValueError("RollingOFI requires finite, nondecreasing timestamps")
        self.last_time = now

    def add(self, now: float, contribution: int) -> None:
        self._check_time(now)
        if not contribution:
            return
        self.total += contribution
        self.timestamps.append(now)
        self.prefixes.append(self.total)
        self._since_trim += 1
        if self._since_trim >= self.COMPACT_THRESHOLD:
            self._trim(now)
            self._since_trim = 0

    def values(self, now: float) -> Dict[int, int]:
        self._check_time(now)
        result = {}
        for horizon in self.windows:
            boundary = bisect_right(self.timestamps, now - horizon, lo=self.head)
            before = self.prefixes[boundary - 1] if boundary > self.head else self.base_total
            result[horizon] = self.total - before
        self._trim(now)
        return result

    def _trim(self, now: float) -> None:
        new_head = bisect_right(self.timestamps, now - max(self.windows), lo=self.head)
        if new_head > self.head:
            self.base_total = self.prefixes[new_head - 1]
            self.head = new_head
        if self.head >= self.COMPACT_THRESHOLD and self.head * 2 >= len(self.timestamps):
            del self.timestamps[:self.head]
            del self.prefixes[:self.head]
            self.head = 0

class ArchiveError(RuntimeError):
    """History cannot be safely appended; no automatic reset is allowed."""

class _FileLock:
    """One live writer per instrument archive, including across processes."""
    def __init__(self, path):
        self.file = open(str(path), "a+b")
        try:
            self.file.seek(0, os.SEEK_END)
            if self.file.tell() == 0:
                self.file.write(b"0")
                self.file.flush()
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, ImportError) as exc:
            self.file.close()
            raise ArchiveError(
                "Archive is already in use or could not be locked. "
                "Run only ONE copy of this indicator per instrument: %s" % path
            ) from exc

    def close(self):
        if not self.file.closed:
            self.file.close()

class _Barrier:
    def __init__(self):
        self.done = threading.Event()

class SQLiteArchive:
    """Append-only event journal with a bounded, nonblocking writer queue.

    Reads/schema checks happen once at subscription. Only the writer thread
    performs subsequent database I/O. No DELETE, REPLACE, TRUNCATE or cleanup
    path exists for recorded history. Identity mismatches fail closed.
    """
    INSERT = """INSERT INTO records
        (received_at_utc, kind, ofi_raw, cumulative_raw,
         old_bid, old_bid_size, old_ask, old_ask_size,
         bid, bid_size, ask, ask_size, note)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""

    def __init__(self, path, identity, now):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = _FileLock(str(self.path) + ".lock")
        self.error = None
        self._closed = False
        self._queue = queue.Queue(maxsize=ARCHIVE_QUEUE_LIMIT)
        self._thread = None
        try:
            connection = sqlite3.connect(str(self.path), timeout=5)
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute("PRAGMA synchronous=FULL")
                connection.execute("""CREATE TABLE IF NOT EXISTS metadata
                    (key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
                connection.execute("""CREATE TABLE IF NOT EXISTS records (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT,
                    received_at_utc REAL NOT NULL,
                    kind TEXT NOT NULL,
                    ofi_raw INTEGER NOT NULL,
                    cumulative_raw INTEGER NOT NULL,
                    old_bid INTEGER, old_bid_size INTEGER,
                    old_ask INTEGER, old_ask_size INTEGER,
                    bid INTEGER, bid_size INTEGER, ask INTEGER, ask_size INTEGER,
                    note TEXT NOT NULL
                )""")
                connection.execute("CREATE INDEX IF NOT EXISTS records_time ON records(received_at_utc)")
                expected = json.dumps(identity, sort_keys=True, separators=(",", ":"))
                stored = connection.execute("SELECT value FROM metadata WHERE key='identity'").fetchone()
                if stored is None:
                    if connection.execute("SELECT 1 FROM records LIMIT 1").fetchone():
                        raise ArchiveError("Archive identity is missing; existing records were NOT changed.")
                    connection.execute("INSERT INTO metadata VALUES ('identity', ?)", (expected,))
                    connection.execute("INSERT INTO metadata VALUES ('schema', '2')")
                elif stored[0] != expected:
                    raise ArchiveError("Instrument metadata does not match the existing archive; nothing was reset.")
                schema = connection.execute("SELECT value FROM metadata WHERE key='schema'").fetchone()
                if schema != ('2',):
                    raise ArchiveError("Unsupported history schema; existing records were NOT changed.")
                connection.commit()
                last = connection.execute(
                    "SELECT received_at_utc, cumulative_raw FROM records ORDER BY seq DESC LIMIT 1"
                ).fetchone()
                self.last_at = last[0] if last else -math.inf
                self.restored_total = int(last[1]) if last else 0
                if self.last_at > now:
                    raise ArchiveError(
                        "Archive timestamp is ahead of this computer's clock. "
                        "Correct the clock before resuming; history was NOT reset."
                    )
                first = connection.execute(
                    "SELECT received_at_utc FROM records WHERE kind='BASELINE' ORDER BY seq LIMIT 1"
                ).fetchone()
                self.first_started = first[0] if first else None
                # Load only the working-window cache. All earlier rows stay on disk.
                self.recent = list(connection.execute(
                    "SELECT received_at_utc, ofi_raw FROM records "
                    "WHERE received_at_utc > ? AND kind='OFI' ORDER BY seq",
                    (now - max(WINDOWS_SECONDS),)
                ))
            finally:
                connection.close()
            self._thread = threading.Thread(target=self._writer,
                                            name="OFI-history-writer", daemon=True)
            self._thread.start()
        except Exception:
            self._lock.close()
            raise

    def submit(self, row):
        if self.error is not None:
            raise ArchiveError(self.error)
        if self._closed:
            raise ArchiveError("Archive is closed; no history was reset.")
        try:
            self._queue.put_nowait(row)
        except queue.Full as exc:
            raise ArchiveError(
                "History writer queue is full. Accumulation stopped; already queued/committed history is retained."
            ) from exc

    def _writer(self):
        connection = None
        try:
            connection = sqlite3.connect(str(self.path), timeout=5)
            connection.execute("PRAGMA synchronous=FULL")
            stopping = False
            while not stopping:
                item = self._queue.get()
                batch = []
                barrier = None
                deadline = time.monotonic() + ARCHIVE_FLUSH_SECONDS
                while True:
                    if item is _STOP:
                        stopping = True
                        break
                    if isinstance(item, _Barrier):
                        barrier = item
                        break
                    batch.append(item)
                    if len(batch) >= ARCHIVE_BATCH_SIZE:
                        break
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    try:
                        item = self._queue.get(timeout=remaining)
                    except queue.Empty:
                        break
                if batch:
                    with connection:
                        connection.executemany(self.INSERT, batch)
                if barrier is not None:
                    barrier.done.set()
        except Exception as exc:
            self.error = "History archive write failed: %s. Previously committed rows remain intact." % exc
        finally:
            if connection is not None:
                connection.close()

    def flush(self, timeout=10):
        if self._closed:
            if self.error:
                raise ArchiveError(self.error)
            return
        barrier = _Barrier()
        self.submit(barrier)
        deadline = time.monotonic() + timeout
        while not barrier.done.wait(0.05):
            if self.error:
                raise ArchiveError(self.error)
            if time.monotonic() >= deadline:
                raise ArchiveError("History flush timed out; do not delete the archive.")

    def close(self):
        if self._closed:
            return
        try:
            if self.error is None:
                self.flush()
        finally:
            self._closed = True
            if self._thread is not None and self._thread.is_alive():
                try:
                    self._queue.put(_STOP, timeout=10)
                except queue.Full:
                    self.error = self.error or "Could not stop history writer: queue remains full."
                self._thread.join(timeout=10)
            if self._thread is None or not self._thread.is_alive():
                self._lock.close()
            else:
                # Keep the file locked while the writer is still alive.
                raise ArchiveError("History writer is still busy; archive was not deleted.")

class OFIHistory:
    """Permanent archive + cumulative total, independent of the live book."""
    def __init__(self, archive):
        self.archive = archive
        self.rolling = RollingOFI()
        for timestamp, contribution in archive.recent:
            self.rolling.add(timestamp, contribution)
        self.total = archive.restored_total
        self.started_at = archive.first_started
        self.last_at = archive.last_at

    def _record(self, now, kind, contribution=0, before=None, after=None, note=""):
        if not math.isfinite(now) or now < self.last_at:
            raise ArchiveError("History requires nondecreasing receipt times; history was not reset.")
        total = self.total + contribution
        if not -(2 ** 63) <= total < 2 ** 63:
            raise ArchiveError("Cumulative OFI exceeds archive integer range; history was not reset.")
        if not -(2 ** 63) <= contribution < 2 ** 63:
            raise ArchiveError("OFI contribution exceeds archive integer range.")
        old = before or (None,) * 4
        new = after or (None,) * 4
        row = (now, kind, contribution, total) + tuple(old) + tuple(new) + (note,)
        self.archive.submit(row)  # Fail before changing the in-memory cumulative.
        self.total = total
        self.last_at = now
        if kind == "BASELINE" and self.started_at is None:
            self.started_at = now

    def note(self, now, kind, message="", bbo=None):
        self._record(now, kind, after=bbo, note=message)

    def add(self, now, previous, current, note=""):
        contribution = academic_ofi_event(previous, current)
        # Persist BBO changes even when the four terms net to zero.
        if current != previous:
            if now < self.rolling.last_time:
                raise ArchiveError("OFI event arrived behind the rolling clock.")
            self._record(now, "OFI", contribution, previous, current, note=note)
            self.rolling.add(now, contribution)

def _identity(alias, full_name, pips, size_multiplier, instrument_multiplier):
    numbers = (float(pips), float(size_multiplier), float(instrument_multiplier))
    if any(not math.isfinite(x) or x <= 0 for x in numbers):
        raise ValueError("Instrument price/size multipliers must be finite and positive")
    return dict(alias=str(alias), full_name=str(full_name), pips=numbers[0],
                size_multiplier=numbers[1], instrument_multiplier=numbers[2])

def _get_history(alias, full_name, pips, size_multiplier, instrument_multiplier, now):
    identity = _identity(alias, full_name, pips, size_multiplier, instrument_multiplier)
    key = json.dumps(identity, sort_keys=True, separators=(",", ":"))
    if key not in _histories:
        readable = "".join(c if ord(c) < 128 and c.isalnum() else "_" for c in str(alias))[:48]
        digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]
        path = HISTORY_DIRECTORY / (readable + "_" + digest + ".sqlite3")
        _histories[key] = OFIHistory(SQLiteArchive(path, identity, now))
    return _histories[key]

_clock = ReceiptClock()

class InputError(ValueError):
    pass


def _bbo_reader(api):
    for name in ("get_bbo", "get_bbos"):
        fn = getattr(api, name, None)
        if callable(fn):
            return fn
    raise InputError("Installed bookmap module has no get_bbo helper")


class MBOBook:
    """Use public Bookmap book helpers; do not invoke on_replace_order.

    The two REPLACE legs are one callback transaction: never evaluate BBO
    between remove and add. CANCEL price/size payloads are unused by design.
    Validation is done BEFORE mutation. An unexpected order ID is not guessed.
    """
    def __init__(self, api):
        self.api = api
        self.read = _bbo_reader(api)
        self.book = api.create_mbo_book()
        if not isinstance(self.book, dict) or "mbp_book" not in self.book:
            raise InputError("Installed create_mbo_book has an unsupported structure")

    def apply(self, event_type, order_id, price, size):
        if not isinstance(order_id, str) or not order_id:
            raise InputError("MBO order ID must be a nonempty string")
        if event_type not in MBO_TYPES:
            raise InputError("Unknown MBO event type: %r" % event_type)
        old = self.api.get_order(self.book, order_id)
        if event_type in ("BID_NEW", "ASK_NEW"):
            if old is not None:
                raise InputError("Duplicate NEW order ID: %s" % order_id)
            if type(price) is not int or type(size) is not int or size <= 0:
                raise InputError("NEW requires integer price and positive integer size")
            self.api.on_new_order(self.book, order_id, event_type == "BID_NEW", price, size)
        elif event_type == "CANCEL":
            if old is None:
                raise InputError("CANCEL for unknown order ID: %s" % order_id)
            self.api.on_remove_order(self.book, order_id)
        else:
            if old is None:
                raise InputError("REPLACE for unknown order ID: %s" % order_id)
            if type(price) is not int or type(size) is not int or size < 0:
                raise InputError("REPLACE requires integer price and nonnegative integer size")
            is_bid = old[0]
            self.api.on_remove_order(self.book, order_id)
            if size > 0:
                self.api.on_new_order(self.book, order_id, is_bid, price, size)

    def top(self):
        bid, ask = self.read(self.book["mbp_book"])
        if bid is None or ask is None:
            reason = "EMPTY" if bid is None and ask is None else ("NO_BID" if bid is None else "NO_ASK")
            return reason, None
        if (len(bid) != 2 or len(ask) != 2 or
                any(type(x) is not int for x in tuple(bid) + tuple(ask))):
            raise InputError("BBO helper did not return integer (price, size) pairs")
        current = (bid[0], bid[1], ask[0], ask[1])
        if bid[1] <= 0 or ask[1] <= 0:
            return "NONPOSITIVE_SIZE", current
        if bid[0] >= ask[0]:
            return ("LOCKED" if bid[0] == ask[0] else "CROSSED"), current
        return "VALID", current


def _probe_helpers(api):
    """Local dictionary-only probe. Sends NO subscriptions, orders or market data."""
    book = MBOBook(api)
    book.apply("BID_NEW", "probe-b1", 100, 10)
    book.apply("BID_NEW", "probe-b2", 100, 7)
    book.apply("ASK_NEW", "probe-a1", 102, 11)
    if book.top() != ("VALID", (100, 17, 102, 11)):
        raise InputError("Bookmap helper self-check: bid/ask or aggregation mismatch")
    book.apply("REPLACE", "probe-b1", 100, 4)
    if book.top() != ("VALID", (100, 11, 102, 11)):
        raise InputError("Bookmap helper self-check: same-price replacement mismatch")
    book.apply("REPLACE", "probe-b1", 101, 5)
    if book.top() != ("VALID", (101, 5, 102, 11)):
        raise InputError("Bookmap helper self-check: price replacement mismatch")
    book.apply("CANCEL", "probe-b1", 0, 0)
    if book.top() != ("VALID", (100, 7, 102, 11)):
        raise InputError("Bookmap helper self-check: cancel mismatch")
    book.apply("REPLACE", "probe-b2", 100, 0)
    if book.top()[0] != "NO_BID":
        raise InputError("Bookmap helper self-check: zero-size replacement mismatch")


class InstrumentState:
    def __init__(self, api, history, now, pips, size_multiplier):
        self.book = MBOBook(api)
        self.history = history
        self.pips = float(pips)
        self.size_multiplier = float(size_multiplier)
        self.created_at = now
        self.first_event_at = None
        self.last_event_at = None
        self.previous = None
        self.started = False
        self.clean_since = None
        self.invalid_since = None
        self.gap_open = False
        self.failed = None
        self.reason = "EMPTY"
        self.current = None
        self.total = 0
        self.applied = 0
        self.changes = 0
        self.counts = dict.fromkeys(MBO_TYPES, 0)
        self.other_count = 0
        self.indicators = {}
        self.expected = {}
        self.indicator_errors = {}
        self.registration_reported = False
        self.points_submitted = 0
        self.last_plot = -math.inf
        self.last_health = -math.inf
        self.last_diagnostic = now
        self.last_rate_time = now
        self.last_rate_total = 0
        self.rate = 0.0
        self.diagnostics = False
        self.warned = {}
        self.acknowledged = False
        self.history.note(now, "SUBSCRIBE", "PRO6 SOURCE=MBO; existing history retained; book rebuilt.")

    def record_receipt(self, now, event_type):
        self.total += 1
        if event_type in self.counts:
            self.counts[event_type] += 1
        else:
            self.other_count += 1
        if self.first_event_at is None:
            self.first_event_at = now
        self.last_event_at = now

    def _start_ready(self, now):
        if self.started or self.failed or self.first_event_at is None:
            return False
        if now - max(self.created_at, self.first_event_at) < STARTUP_GUARD_SECONDS:
            return False
        if self.reason != "VALID":
            return False
        self.history.note(now, "BASELINE", "PRO6 MBO baseline; snapshot guard heuristic.", self.current)
        self.previous = self.current
        self.started = True
        self.clean_since = now
        return True

    def consume(self, now, event_type, order_id, price, size):
        if self.failed:
            return None
        self.book.apply(event_type, order_id, price, size)
        self.applied += 1
        self.reason, self.current = self.book.top()
        if self.reason == "VALID":
            self.invalid_since = None
        elif self.invalid_since is None:
            self.invalid_since = now
        if not self.started:
            return "STARTED" if self._start_ready(now) else None
        if self.reason != "VALID":
            if not self.gap_open:
                self.history.note(now, "GAP_START", "PRO6 MBO BBO=" + self.reason + "; history retained.")
                self.gap_open = True
                self.previous = None
                self.clean_since = None
            return None
        if self.previous is None:
            self.history.note(now, "BASELINE", "PRO6 MBO recovery; unknown gap flow NOT counted.", self.current)
            self.previous = self.current
            self.gap_open = False
            self.clean_since = now
            return None
        # The CKS sum is updated on EVERY usable callback, never on the plot timer.
        if self.current != self.previous:
            self.history.add(now, self.previous, self.current, note="PRO6 MBO CKS event")
            self.changes += 1
        self.previous = self.current
        return None

    def values(self, now):
        # Never replace retained observations with NaN or wipe them on a data gap.
        # A zero before first baseline is a labelled initialization placeholder.
        return {h: v / self.size_multiplier for h, v in self.history.rolling.values(now).items()}

    def mode(self):
        if self.failed:
            return "ERROR"
        if self.total == 0:
            return "WAIT_MBO"
        if not self.started:
            return "WARMUP" if self.reason == "VALID" else "WAIT_" + self.reason
        return "ACTIVE" if self.reason == "VALID" else "INCOMPLETE_" + self.reason

    def sample_rate(self, now):
        elapsed = now - self.last_rate_time
        if elapsed >= 1.0:
            self.rate = (self.total - self.last_rate_total) / elapsed
            self.last_rate_total = self.total
            self.last_rate_time = now

    def full_windows(self, now):
        if self.failed or not self.started or self.clean_since is None:
            return []
        return [h for h in WINDOWS_SECONDS if now - self.clean_since >= h]


def _notice(addon, alias, message):
    text = "Academic OFI Pro [%s]: %s" % (alias, message)
    print(text, flush=True)
    notify = getattr(bm, "send_user_message", None)
    if callable(notify):
        try:
            notify(addon, alias, text)
        except Exception as exc:
            print("OFI Pro: message-log delivery failed: %s" % exc, flush=True)


def _warn(addon, alias, state, now, key, message):
    last = state.warned.get(key, -math.inf)
    if now - last >= WARNING_REPEAT_SECONDS:
        state.warned[key] = now
        _notice(addon, alias, message)


def _fail(addon, alias, state, now, error):
    if state.failed:
        return
    state.failed = "%s: %s" % (type(error).__name__, error)
    state.previous = None
    state.clean_since = None
    try:
        state.history.note(now, "STOP", "PRO6 " + state.failed)
    except Exception:
        pass
    _notice(addon, alias, "INPUT/ARCHIVE ERROR: %s. Old history retained; new OFI is not valid. "
            "Resolve the error and re-enable. Do not delete history." % state.failed)


def _registration_kwargs(api, color):
    """Request current-value widgets, with no historical chart curves."""
    options = dict(color=color, line_style="SOLID", initial_value=0.0)
    desired = {
        "show_line_by_default": False,
        "show_widget_by_default": True,
        "is_modifiable": True,
    }
    try:
        params = inspect.signature(api.register_indicator).parameters
    except (TypeError, ValueError):
        params = {}
    accepts_kwargs = any(p.kind == inspect.Parameter.VAR_KEYWORD
                         for p in params.values())
    for name, value in desired.items():
        if name in params or accepts_kwargs:
            options[name] = value
    return options


def handle_subscribe_instrument(addon, alias, full_name, is_crypto, pips,
                                size_multiplier, instrument_multiplier, supported_features=None):
    if alias in _states:
        handle_unsubscribe_instrument(addon, alias)
    now = _clock.now()
    try:
        history = _get_history(alias, full_name, pips, size_multiplier, instrument_multiplier, now)
        state = InstrumentState(bm, history, now, pips, size_multiplier)
    except Exception as exc:
        _notice(addon, alias, "Cannot initialize: %s. No history was deleted." % exc)
        return
    _states[alias] = state
    # Three current-value widgets; new names avoid reusing old line visibility settings.
    specs = ((60, "OFI Pressure - 1m", (0, 200, 255)),
             (180, "OFI Pressure - 3m", (255, 180, 0)),
             (300, "OFI Pressure - 5m", (215, 120, 255)))
    for horizon, name, color in specs:
        req = next(_request_ids)
        state.expected[horizon] = name
        _pending_indicators[req] = (alias, state, horizon)
        try:
            bm.register_indicator(addon, alias, req, name, "BOTTOM", **_registration_kwargs(bm, color))
        except Exception as exc:
            _pending_indicators.pop(req, None)
            state.indicator_errors[horizon] = str(exc)
            _notice(addon, alias, "Cannot register %s: %s" % (name, exc))
    label = getattr(bm, "add_label_to_settings", None)
    if callable(label):
        label(addon, alias, "OFI Pro 6.1: numeric widgets only; line display OFF by default. "
              "Raw CKS 1/3/5-minute OFI; MBO source; positive=buy pressure, negative=sell pressure. "
              "Partial observed sums always shown. History never reset. No forecasts.")
    setting = getattr(bm, "add_boolean_settings_parameter", None)
    if callable(setting):
        try:
            setting(addon, alias, DIAGNOSTIC_SETTING, False, reload_if_change=False)
        except TypeError:
            setting(addon, alias, DIAGNOSTIC_SETTING, False)
    _notice(addon, alias, "v%s; 3 NUMERIC WIDGETS requested; chart lines OFF by default; SOURCE=MBO. Archive: %s. "
            "Initial zero is a placeholder until collection begins." % (VERSION, history.archive.path))
    if not all(k in _registration_kwargs(bm, (0, 200, 255))
               for k in ("show_line_by_default", "show_widget_by_default")):
        _notice(addon, alias, "This API does not expose widget visibility flags. In Bookmap "
                "Widget Settings, enable Widget Panel and disable Indicator Panel for the "
                "three OFI Pressure entries. Calculation and history are unchanged.")
    if isinstance(supported_features, dict) and supported_features.get("mbo") is False:
        _fail(addon, alias, state, now, InputError("This instrument reports no MBO capability"))
        return
    req = next(_request_ids)
    _pending_data[req] = (alias, state)
    try:
        bm.subscribe_to_mbo(addon, alias, req)
    except Exception as exc:
        _pending_data.pop(req, None)
        _fail(addon, alias, state, now, exc)


def handle_indicator_response(addon, request_id, indicator_id):
    try:
        request_id, indicator_id = int(request_id), int(indicator_id)
    except (TypeError, ValueError):
        print("OFI Pro: unusable indicator registration response", request_id, indicator_id, flush=True)
        return
    record = _pending_indicators.pop(request_id, None)
    if record is None:
        return
    alias, state, horizon = record
    if _states.get(alias) is not state:
        return
    state.indicators[horizon] = indicator_id  # Indicator ID zero is valid.
    _notice(addon, alias, "REGISTERED: %s (id=%s)" % (state.expected[horizon], indicator_id))
    # Submit the numeric value as soon as the widget acknowledgement arrives.
    _publish(addon, alias, state, _clock.now(), force=True)
    if len(state.indicators) == 3 and not state.registration_reported:
        state.registration_reported = True
        _notice(addon, alias, "3/3 OFI indicators acknowledged; current values sent to the Widget Panel. "
                "This confirms API registration, not on-screen visibility.")


def handle_data_response(addon, request_id):
    try:
        record = _pending_data.pop(int(request_id), None)
    except (TypeError, ValueError):
        return
    if record is not None:
        alias, state = record
        if _states.get(alias) is state:
            state.acknowledged = True


def _publish(addon, alias, state, now, force=False):
    if not state.indicators or (not force and now - state.last_plot < PLOT_EVERY_SECONDS):
        return
    state.last_plot = now
    try:
        values = state.values(now)
    except Exception as exc:
        _warn(addon, alias, state, now, "values", "Cannot produce rolling display values: %s" % exc)
        return
    for horizon, indicator_id in list(state.indicators.items()):
        value = values[horizon]
        if not math.isfinite(value):
            _warn(addon, alias, state, now, "nonfinite", "Nonfinite OFI value refused; history retained.")
            continue
        try:
            bm.add_point(addon, alias, indicator_id, float(value))
            state.points_submitted += 1
        except Exception as exc:
            _warn(addon, alias, state, now, "plot", "Indicator point submission failed: %s" % exc)


def handle_mbo_event(addon, alias, event_type, order_id, price_level, size_level):
    state = _states.get(alias)
    if state is None:
        return
    now = _clock.now()
    state.record_receipt(now, event_type)
    if state.total == 1:
        _notice(addon, alias, "MBO callback received. Building book; snapshot/live provenance is not exposed.")
    try:
        if state.history.archive.error:
            raise ArchiveError(state.history.archive.error)
        result = state.consume(now, event_type, order_id, price_level, size_level)
        if result == "STARTED":
            _notice(addon, alias, "OFI collection started from MBO. 1m/3m/5m show observed "
                    "partial sums immediately; full windows need 60/180/300 seconds without detected gaps.")
    except Exception as exc:
        _fail(addon, alias, state, now, exc)
    # Event-side publish fallback; computation is NOT throttled by this timer.
    _publish(addon, alias, state, now)
    _health(addon, alias, state, now)


def _health(addon, alias, state, now):
    if now - state.last_health < 1.0:
        return
    state.last_health = now
    state.sample_rate(now)
    if state.history.archive.error and not state.failed:
        _fail(addon, alias, state, now, ArchiveError(state.history.archive.error))
    missing = [h for h in WINDOWS_SECONDS if h not in state.indicators]
    if missing and now - state.created_at >= REGISTRATION_WARNING_SECONDS:
        _warn(addon, alias, state, now, "register", "DISPLAY NOT READY: %d/3 registration "
              "acknowledgements; missing horizons=%s. OFI values do not prove chart registration. "
              "Check the Python API/Bookmap log. Errors=%s" %
              (len(state.indicators), missing, state.indicator_errors))
    if state.total == 0 and now - state.created_at >= DATA_WARNING_SECONDS:
        _warn(addon, alias, state, now, "no_data", "NO MBO CALLBACKS. Initial zero is not a market "
              "reading. Check MBO permission, selected live connection and instrument.")
    elif state.last_event_at is not None and now - state.last_event_at >= DATA_WARNING_SECONDS:
        _warn(addon, alias, state, now, "silent", "No MBO callback for %.1fs. Quiet/closed market "
              "or connection issue cannot be distinguished here; displayed sums contain past observations only. "
              "Re-enable after a known disconnect to rebuild the book." % (now - state.last_event_at))
    if (not state.failed and state.invalid_since is not None and
            now - state.invalid_since >= PERSISTENT_INVALID_SECONDS and
            state.first_event_at is not None and
            now - state.first_event_at >= STARTUP_GUARD_SECONDS):
        quote = "NONE" if state.current is None else str(state.current)
        _warn(addon, alias, state, now, "invalid", "MBO book=%s for %.1fs; raw BBO=%s. "
              "History retained, but new OFI is incomplete. Do not interpret an unchanging number as balanced flow. "
              "Waiting for a 5-minute lookback does not repair this input." %
              (state.reason, now - state.invalid_since, quote))
    if state.diagnostics and now - state.last_diagnostic >= DIAGNOSTIC_SECONDS:
        state.last_diagnostic = now
        data = dict(mode=state.mode(), source="MBO", received=state.total, applied=state.applied,
                    events_per_second=round(state.rate, 1), counts=state.counts, other=state.other_count,
                    last_age=(None if state.last_event_at is None else now - state.last_event_at),
                    book=state.reason, raw_bbo=state.current, ofi_changes=state.changes,
                    values=state.values(now), full_windows=state.full_windows(now),
                    indicators=len(state.indicators), points_submitted=state.points_submitted,
                    error=state.failed, live_source="UNVERIFIED_BY_CALLBACK")
        _notice(addon, alias, "DETAILS " + json.dumps(data, sort_keys=True, allow_nan=False))


def on_interval(addon, alias):
    state = _states.get(alias)
    if state is None:
        return
    now = _clock.now()
    try:
        if state.history.archive.error:
            raise ArchiveError(state.history.archive.error)
        # Timer may establish the initial baseline, but NEVER computes a quote-to-quote OFI.
        if state._start_ready(now):
            _notice(addon, alias, "OFI collection started from MBO; partial observed sums are displayed.")
    except Exception as exc:
        _fail(addon, alias, state, now, exc)
    _publish(addon, alias, state, now)
    _health(addon, alias, state, now)


def on_settings_change(addon, alias, name, field_type, new_value):
    state = _states.get(alias)
    if state is None:
        return
    if name == DIAGNOSTIC_SETTING:
        state.diagnostics = (new_value.lower() == "true" if isinstance(new_value, str) else bool(new_value))
    # Legacy reset, partial-window hiding and diagnostic-plot settings are ignored.
    # They cannot erase history or switch all three OFI series to NaN.


def handle_unsubscribe_instrument(addon, alias):
    state = _states.pop(alias, None)
    if state is not None:
        try:
            state.history.note(_clock.now(), "UNSUBSCRIBE", "PRO6 disabled; recorded history retained.")
        except Exception as exc:
            print("OFI Pro: unsubscribe archive warning: %s" % exc, flush=True)
    for pending in (_pending_indicators, _pending_data):
        for req, record in list(pending.items()):
            if record[0] == alias and record[1] is state:
                del pending[req]


def _close_histories():
    for history in _histories.values():
        try:
            history.archive.close()
        except Exception as exc:
            print("OFI Pro: archive close warning: %s" % exc, flush=True)


def main():
    global bm
    try:
        import bookmap as bm
    except ImportError as exc:
        raise SystemExit("Run this file through the Bookmap Python API loader, not a standalone terminal.") from exc
    required = ("create_addon", "start_addon", "wait_until_addon_is_turned_off",
                "add_mbo_handler", "subscribe_to_mbo", "add_on_interval_handler",
                "register_indicator", "add_indicator_response_handler", "add_point",
                "create_mbo_book", "on_new_order", "on_remove_order", "get_order")
    missing = [name for name in required if not callable(getattr(bm, name, None))]
    if missing:
        raise SystemExit("Bookmap API is missing required methods: " + ", ".join(missing))
    try:
        _probe_helpers(bm)
    except Exception as exc:
        raise SystemExit("OFI Pro local helper self-check failed: %s. No history deleted." % exc)
    print("Academic OFI Pro v%s: local book-helper self-check PASSED. This is not a live-feed test." % VERSION, flush=True)
    addon = bm.create_addon()
    bm.add_indicator_response_handler(addon, handle_indicator_response)
    bm.add_mbo_handler(addon, handle_mbo_event)
    bm.add_on_interval_handler(addon, on_interval)
    response = getattr(bm, "add_response_data_handler", None)
    if callable(response):
        response(addon, handle_data_response)
    for name in ("add_on_setting_change_handler", "add_on_settings_change_handler"):
        handler = getattr(bm, name, None)
        if callable(handler):
            handler(addon, on_settings_change)
            break
    try:
        bm.start_addon(addon, handle_subscribe_instrument, handle_unsubscribe_instrument)
        bm.wait_until_addon_is_turned_off(addon)
    finally:
        _close_histories()


if __name__ == "__main__":
    main()
