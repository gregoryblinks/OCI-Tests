# OFI Pressure: one-minute Bookmap bubbles

**Version 1.0.0 — research prototype, read-only.**

This project implements the requested one-minute, multi-level OFI pressure indicator and automatic Excel/CSV export. It never sends, modifies or cancels trading orders.

## Delivery and validation status — read first

The independent Java calculation engine, bubble image renderer and export writer have been compiled and tested. **36 automated Java tests pass.** A deterministic, explicitly synthetic 120-minute feed produced 120 Excel/CSV records; the first 60 are warm-up and the following 60 are scored. Python/openpyxl validation checked the Excel files and the offline label tools.

**The Bookmap adapter has not been compiled against the actual Bookmap SDK or run inside Bookmap in this environment.** Network access to download the SDK JARs failed. Accordingly, this delivery contains source and local build scripts, **not a prebuilt Bookmap-loadable JAR**. The local build downloads the real SDK, compiles the adapter and produces the JAR. Do not treat this as a certified or production-validated add-on. Actual replay/feed acceptance tests remain mandatory.

The target is the **Bookmap Java API 7.6.0.20**, with **Java 17-compatible bytecode**. Compatibility with older Bookmap versions is not claimed. You need a Bookmap connection and entitlement that expose genuine MBO data to add-ons. A heatmap or visible volume bubbles do not by themselves establish that this MBO API is available.

## What is implemented

At every MBO add, replace or remove, the engine reconstructs the order book and computes the specified before/after OFI formula at each current rank. The top ten levels move with the book; they are not fixed at the minute's opening prices.

At the close of each UTC minute, it freezes one observation, calculates its pressure relative to previous valid minutes, submits that same observation to the export writer and draws one labelled bubble at the minute's last trade price. If there were no non-OTC trades, it uses the closing midpoint and records that fallback.

The bubble is emitted at the **first Bookmap timestamp callback at or after the minute boundary**, not backdated. In an active feed this will normally be near the candle close, but there is no guarantee of an exact zero-latency timestamp. Both `end_ns` and `available_ns`, plus `close_latency_ms`, are saved. If your research requires an exact visual anchor at the historical boundary regardless of callback time, a custom Core-API painter is a separate extension; this version uses Simplified-API icons.

Default appearance:

- `Z+2.8`: positive standardized pressure, green/teal; `Z-2.1`: negative standardized pressure, red.
- Bubble diameter increases with absolute Z, capped at 4 standard deviations for visual size only. The recorded Z is not clipped.
- Absolute Z below 0.5 is neutral grey. `WARM`, `FLAT`, `DATA!` and `SAVE!` are nonnumeric state markers, never invented zero scores.

**A centered Z-score is a deviation from its historical mean, not necessarily the sign of net order flow.** The export therefore distinguishes `flow_direction` (sign of normalized OFI) from `deviation_direction` (sign of Z). A positive Z is not a probability of an upward move. The display deliberately says `Z`, not `BUY` or `SELL`.

There is no lower-panel line, absorption classifier, predictive probability, order execution logic, tooltip drill-down, automatic historical MBO backfill or fitted PCA in this version.

## Build and install

Install a JDK 17 or later and Python 3.10 or later. Check that `java`, `javac`, `jar` and `python`/`python3` are available in your terminal. Python is a **build/research requirement**, not a Bookmap runtime requirement. The running add-on and its Excel writer need no Python process.

Extract the ZIP and open a terminal in the extracted `ofi-pressure-bookmap` directory.

### Windows

```bat
build.cmd
```

### macOS / Linux

```sh
sh build.sh
```

The script downloads `api-core` and `api-simplified` from Bookmap's official Maven repository, runs the core tests, compiles all production sources against the real SDK, excludes the SDK from the add-on and creates:

```text
dist/ofi-pressure-bookmap-1.0.0.jar
```

SDK and output SHA-256 hashes are recorded in `dist/build-info.json`. If the SDK cannot be downloaded automatically, put the exact official `api-core-7.6.0.20.jar` and `api-simplified-7.6.0.20.jar` in `lib/`, then run:

```sh
python tools/build.py --offline
```

Do not substitute dummy API classes. As an alternative, an installed Gradle can build the supplied `build.gradle` with `gradle jar`; its output is under `build/libs/`.

In Bookmap, open **Settings → API plugins configuration → Add**, select the compiled JAR and enable **OFI Pressure - 1 Minute Bubbles (Research v1)** for the instrument. Menu naming can vary with the Bookmap build. Use Replay first and inspect the add-on's settings/status panel.

The first full minute is collected from a completed MBO snapshot. With the default calibration, the **61st consecutive valid complete minute is the first eligible numeric score**. Initial partial minutes, data faults and insufficient depth do not count. A constant baseline can remain unscored even after warm-up. Invalid minutes reset calibration, so bad feeds can prevent warm-up from finishing.

## Files and settings

On first initialization the add-on creates:

```text
<your user home>/Bookmap/OFI-Pressure/config.properties
<your user home>/Bookmap/OFI-Pressure/data/<instrument>_<alias-hash>/<unique-run-id>/
```

Each run writes one pair of files per UTC date:

```text
2026-01-05_pressure.csv
2026-01-05_pressure.xlsx
metadata.txt
```

The date above is an example, not a fixed filename. Live filenames use the observed market/replay date. Separate instruments and separate activations use separate run directories. The add-on does not silently merge duplicate observations from repeated replays.

The settings panel has **Open output folder**, **Open configuration file**, engine status and writer status. Edit the configuration, then disable/re-enable the add-on to apply changes. This intentionally starts a new run, reconstructs the book and restarts calibration rather than mixing incompatible settings. The configuration is global to this prototype; separately configured per-instrument profiles are not implemented.

Core defaults:

| Setting | Default | Meaning |
|---|---:|---|
| `levels` | 10 | Current best 10 distinct prices on each side; 1–50 allowed |
| `weights.mode` | EXPONENTIAL | Fixed positive weights, not PCA |
| `weights.decay` | 0.25 | Weight decreases by distance in rank |
| `depth.mode` | EVENT | Shared event-average depth across both sides/ranks |
| `rolling.window.minutes` | 240 | Maximum number of prior valid minute observations |
| `rolling.minimum.minutes` | 60 | Minimum prior observations to score |
| `quality.stale.seconds` | 30 | Conservative threshold for no MBO updates |
| `quality.clock.gap.seconds` | 120 | Large clock jump clears calibration and flags data |
| `quality.minimum.coverage` | 0.99 | Required valid, non-stale time coverage |
| `display.minimum.abs.z` | 0 | Keep every scored minute visible |
| `display.show.warmup` | true | Show nonnumeric status bubbles |
| `run.label` | UNSPECIFIED | Set e.g. LIVE_ES or REPLAY_TEST; not automatically inferred |

These are transparent starting parameters, **not statistically optimized parameters for your instrument**. The stale threshold and ten-level requirement may be inappropriate for illiquid instruments or limited-depth feeds. Do not reduce quality requirements merely to force scores to appear.

Alternative weights: `UNIFORM`, or `MANUAL` with exactly `levels` comma-separated values in `weights.manual`. Manual weights are divided by their sum of absolute values. A PCA vector estimated entirely before the evaluated period can be supplied manually, but this project does not fit it or enforce the provenance of user-supplied weights. Use a new run and fresh calibration after changing weights.

## Method

For level/rank `l`, the before and after bid price/quantity are `(b0,qb0)` and `(b1,qb1)`; ask values are `(a0,qa0)` and `(a1,qa1)`:

```text
e[l] = I(b1 >= b0)*qb1 - I(b1 <= b0)*qb0
       - I(a1 <= a0)*qa1 + I(a1 >= a0)*qa0
OFI[l, minute] = sum of e[l] across MBO changes in that minute
w[l] = exp(-0.25*(l-1)) / sum_j exp(-0.25*(j-1))  [default]
Q_event = average post-event quantity over both sides and all selected ranks
normalized_OFI = sum_l w[l] * OFI[l, minute] / Q_event
Z = (normalized_OFI - mean_of_prior_valid_minutes) / sample_SD_of_prior_valid_minutes
```

The price-decrease bid term and price-increase ask term use the **old queue size**, as in the indicator formula discussed in the conversation. Rank changes are included by comparing each current ranked book state with the previous ranked state. This is **rank-based multi-level OFI**, not a footprint assigning independent signed trades to absolute prices. The same event can change several ranked components; their sum is not a count of unique contracts.

`TIME` depth mode substitutes the time-weighted average of the same depth over valid, non-stale coverage. Both event- and time-weighted depth estimates are saved for audit. With incomplete/missing book ranks, no score is admitted; the code does not assign arbitrary prices to empty queues or silently substitute another depth level.

The primary OFI is driven exclusively by MBO state transitions. A trade callback contributes OHLC and aggressor-volume diagnostics only. The trade's book reduction must arrive through the MBO stream; otherwise the feed contract is unsuitable. This prevents double counting executions. Generic remove callbacks are **not labelled as true cancellations versus executions**, because that decomposition is not reliably supplied by these generic callbacks.

This is a measurement/research implementation based on the specified OFI formula and multi-level idea, **not an exact replication of Cont/Cucuringu/Zhang's PCA/forecasting models**. No out-of-sample predictive edge has been demonstrated. The earlier conversation's suggestions about absorption and illustrative predictive percentages are not implemented empirical findings.

## Export reliability and limitations

The market callback submits an immutable record to a bounded queue. A separate writer appends and flushes CSV, requests a file-channel flush, and writes a real two-sheet `.xlsx` snapshot. Export has a small asynchronous delay; a displayed bubble is not proof that a power-loss-durable disk commit has already completed.

CSV is the recovery log; Excel is the convenient daily research view. If Excel locks the workbook, CSV continues, the panel reports a warning and a valid `.xlsx.pending.xlsx` snapshot is retained. Close Excel to allow replacement at the next completed minute. After stopping, the pending snapshot can be opened or CSV can be recovered offline.

A full queue or CSV write failure is visible in the panel/log; subsequent bubbles receive `SAVE!` rather than silently implying healthy recording. Check recording status before and after each session. Application crashes can still lose queued, not-yet-written rows. There is no raw MBO archive, remote backup or automatic CSV replay recovery on restart.

`*_ns` timestamps are stored as strings in the generated XLSX to preserve all digits. Do not open the raw CSV directly in Excel with automatic numeric conversion: use the XLSX or import nanosecond columns explicitly as text. UTC timestamps, configuration hash, run ID, data validity, baseline statistics, each level's raw/normalized OFI and weights are included. Blank scores mean unavailable, not zero. The feature log is immutable with respect to calibration: old rows are not rescored using future data.

The rolling baseline is specific to this instrument and activation, but is **not conditioned on time of day or volatility regime**. It is not persisted across restarts. The engine detects some faults (unknown/duplicate order IDs, missing levels, stale data, backward time), but it does not have exchange sequence numbers and cannot prove the feed has no packet loss or coalescing. On a reconstruction fault or replay seek, disable/re-enable; resubscribe the instrument if a fresh snapshot is not supplied.

## Research utilities

All example observations are generated, not exchange data. The included `examples/synthetic_pressure.xlsx` shows the actual exporter schema: 120 minutes, 97 columns, `minute_pressure` and `metadata` sheets. Sixty minutes are warm-up. Do not use its values as evidence of predictive performance.

Run the independent Java tests without downloading Bookmap:

```sh
python tools/test_core.py
```

Build a separate forward-label CSV from your exported features:

```sh
python tools/forward_labels.py path/to/2026-01-05_pressure.csv --output labels.csv
```

Multiple CSV paths can be supplied, including adjacent dates of the same run. The script uses exact timestamps, refuses duplicate minutes within a run, requires all intermediate future minutes to be valid, and leaves incomplete horizons blank. It produces 1-, 5- and 15-minute midpoint log returns, midpoint tick changes and long-side MFE/MAE diagnostics in a separate file. Nanosecond timestamps never pass through floating-point conversion.

These are **close-to-close analytical labels, not executable P&L**. A marker may only be available after the closing midpoint; returns do not include spread, fees, queue position, fill probability, slippage or latency. `signal_within_latency_limit` is a screening flag, not a fill model. Use chronological train/validation/test splits, purge overlapping forward horizons and avoid pooling repeated replay runs as independent samples.

Recover a workbook from CSV if needed:

```sh
python -m pip install -r tools/requirements-research.txt
python tools/recover_excel.py path/to/2026-01-05_pressure.csv
```

Full acceptance checklist: `docs/ACCEPTANCE_TESTS.md`. Audit and field definitions: `docs/SCHEMA.md`.

## Primary references

- Bookmap official Java examples, build/load instructions and API compatibility: https://github.com/BookmapAPI/DemoStrategies
- Current official demo build dependency: https://github.com/BookmapAPI/DemoStrategies/blob/master/Strategies/build.gradle
- MBO callback semantics: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0.10/velox/api/layer1/simplified/MarketByOrderDepthDataListener.html
- Icon API: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0.10/velox/api/layer1/simplified/Indicator.html
- Clock callback semantics: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/TimeListener.html
- Price-unit conventions: https://github.com/BookmapAPI/ai-skills/blob/main/references/simplified-api.md
- Cont, Kukanov and Stoikov, *The Price Impact of Order Book Events*: https://arxiv.org/abs/1011.6402
- Cont, Cucuringu and Zhang, *Cross-Impact of Order Flow Imbalance in Equity Markets*: https://arxiv.org/abs/2112.13213

The cited paper is the one discussed, not an assertion that it is the latest Cont paper as of today.
