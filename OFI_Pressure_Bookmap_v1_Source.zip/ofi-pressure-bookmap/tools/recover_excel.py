#!/usr/bin/env python3
"""Rebuild a formatted Excel workbook from a saved feature CSV; requires openpyxl."""
from __future__ import annotations
import argparse
import csv
import math
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


def typed(name: str, value: str):
    if value == '':
        return None
    if name.endswith(('_ns', '_utc')) or name in {'alias', 'run_id', 'config_sha256', 'run_label'}:
        return value
    if value.lower() in {'true', 'false'}:
        return value.lower() == 'true'
    try:
        number = float(value)
        if math.isfinite(number):
            return int(value) if '.' not in value and 'e' not in value.lower() and len(value.lstrip('-')) < 15 else number
    except ValueError:
        pass
    return value


def recover(source: Path, target: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = 'minute_pressure'
    with source.open(newline='', encoding='utf-8-sig') as stream:
        reader = csv.DictReader(stream)
        headers = reader.fieldnames
        if not headers:
            raise ValueError('CSV has no header')
        ws.append(headers)
        for row in reader:
            ws.append([typed(h, row[h]) for h in headers])
    ws.freeze_panes = 'D2'
    ws.auto_filter.ref = ws.dimensions
    ws.sheet_view.showGridLines = False
    for cell in ws[1]:
        cell.font = Font(name='Calibri', bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor='183B4E')
        cell.alignment = Alignment(wrap_text=True, vertical='center')
    ws.row_dimensions[1].height = 34
    for j, name in enumerate(headers, 1):
        ws.column_dimensions[get_column_letter(j)].width = 27 if name.endswith(('_utc', '_ns')) else min(36, max(16, len(name) + 2))
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, str):
                cell.data_type = 's'  # Input strings must never become formulas.
            cell.font = Font(name='Calibri', size=11, color='008000')
            if isinstance(cell.value, float):
                cell.number_format = '0.0000;[Red]-0.0000'
            if headers[cell.column - 1] in {'prior_empirical_percentile', 'valid_book_coverage', 'direction_persistence'}:
                cell.number_format = '0.0%'
            if headers[cell.column - 1] == 'score_status' and cell.value != 'READY':
                cell.fill = PatternFill('solid', fgColor='FFF0DA')
    meta = wb.create_sheet('metadata')
    entries = [
        ('Item', 'Value'),
        ('Source', str(source.resolve())),
        ('Purpose', 'Recovered immutable minute feature snapshots. No live fields were recomputed.'),
        ('Time', 'UTC [start,end). Nanosecond timestamps are stored as text.'),
        ('Caution', 'Pressure is a standardized anomaly, not a probability or a guarantee of return.'),
        ('Caution', 'No profit, spread, fees, fill model or slippage is represented.'),
        ('Method reference', 'https://arxiv.org/abs/1011.6402'),
        ('Multi-level reference', 'https://arxiv.org/abs/2112.13213'),
    ]
    for row in entries:
        meta.append(row)
    meta.column_dimensions['A'].width = 28
    meta.column_dimensions['B'].width = 100
    meta.freeze_panes = 'A2'
    meta.sheet_view.showGridLines = False
    for cell in meta[1]:
        cell.fill = PatternFill('solid', fgColor='183B4E')
        cell.font = Font(bold=True, color='FFFFFF')
    for row in meta.iter_rows(min_row=2):
        for cell in row:
            cell.font = Font(color='666666')
            cell.alignment = Alignment(wrap_text=True, vertical='top')
        meta.row_dimensions[row[0].row].height = 32
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.stem + '.tmp.xlsx')
    wb.save(temporary)
    temporary.replace(target)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('csv', type=Path)
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    target = a.output or a.csv.with_suffix('.recovered.xlsx')
    if target.resolve() == a.csv.resolve():
        p.error('Output must not overwrite the CSV.')
    recover(a.csv, target)
    print(target)


if __name__ == '__main__':
    main()
