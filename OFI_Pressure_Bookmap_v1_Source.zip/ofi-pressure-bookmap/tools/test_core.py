#!/usr/bin/env python3
"""Compile and test only our independent Java engine/exporter, NOT the Bookmap adapter."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
out = ROOT / 'build' / 'core-classes'
out.mkdir(parents=True, exist_ok=True)
sources = sorted((ROOT / 'src/main/java/com/ofipressure/core').glob('*.java'))
sources += sorted((ROOT / 'src/main/java/com/ofipressure/io').glob('*.java'))
sources += [ROOT / 'src/main/java/com/ofipressure/bookmap/BubbleImage.java']
sources += sorted((ROOT / 'src/test/java').rglob('*.java'))
try:
    subprocess.run(['javac', '--release', '17', '-encoding', 'UTF-8', '-d', str(out), *map(str, sources)], check=True, cwd=ROOT)
    subprocess.run(['java', '-Djava.awt.headless=true', '-cp', str(out), 'com.ofipressure.EngineTests'], check=True, cwd=ROOT)
except (FileNotFoundError, subprocess.CalledProcessError) as exc:
    print('TEST FAILED. Install JDK 17+ and inspect the error above.', file=sys.stderr)
    raise SystemExit(1) from exc
