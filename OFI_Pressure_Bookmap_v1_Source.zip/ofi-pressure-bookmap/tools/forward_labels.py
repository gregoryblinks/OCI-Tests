#!/usr/bin/env python3
"""Create separate, strictly time-aligned research labels. These are NOT executable trade returns."""
from __future__ import annotations
import argparse
import csv
import math
from pathlib import Path

MINUTE_NS = 60_000_000_000


def truth(value: str) -> bool:
    return value.strip().lower() in {'true', '1'}


def finite(value: str) -> float | None:
    try:
        n = float(value)
        return n if math.isfinite(n) else None
    except (TypeError, ValueError):
        return None


def make_labels(paths: list[Path], horizons: list[int], max_latency_ms: float = 1000) -> list[dict]:
    groups: dict[tuple[str, str, str], dict[int, dict]] = {}
    for path in paths:
        with path.open(newline='', encoding='utf-8-sig') as stream:
            for row in csv.DictReader(stream):
                key = (row['alias'], row['run_id'], row['config_sha256'])
                end = int(row['end_ns'])  # Never cast nanoseconds through float.
                target = groups.setdefault(key, {})
                if end in target:
                    raise ValueError(f'Duplicate minute for {key[0]}, run {key[1]}, end_ns={end}. Deduplicate inputs explicitly.')
                target[end] = row
    result = []
    for key, rows in sorted(groups.items()):
        for end, row in sorted(rows.items()):
            ready = truth(row['data_valid']) and row['score_status'] == 'READY'
            base = finite(row['mid_close'])
            tick = finite(row['tick_size'])
            latency = finite(row['close_latency_ms'])
            out = {
                'alias': key[0], 'run_id': key[1], 'config_sha256': key[2],
                'signal_end_utc': row['end_utc'], 'signal_end_ns': str(end),
                'signal_available_ns': row['available_ns'], 'pressure_z': row['pressure_z'],
                'signal_ready': ready,
                'signal_within_latency_limit': latency is not None and 0 <= latency <= max_latency_ms,
                'label_type': 'MIDPRICE_DIAGNOSTIC_NOT_EXECUTABLE_PNL',
            }
            for horizon in horizons:
                future = [rows.get(end + j * MINUTE_NS) for j in range(1, horizon + 1)]
                complete = ready and all(r is not None and truth(r['data_valid']) for r in future)
                values = [finite(r['mid_close']) if r else None for r in future]
                highs = [finite(r['mid_high']) if r else None for r in future]
                lows = [finite(r['mid_low']) if r else None for r in future]
                complete = bool(complete and base is not None and tick is not None and tick > 0 and all(v is not None for v in values + highs + lows))
                out[f'complete_{horizon}m'] = complete
                out[f'target_end_ns_{horizon}m'] = str(end + horizon * MINUTE_NS)
                out[f'forward_log_return_{horizon}m'] = math.log(values[-1] / base) if complete and base > 0 and values[-1] > 0 else ''
                out[f'forward_mid_ticks_{horizon}m'] = (values[-1] - base) / tick if complete else ''
                out[f'future_long_mfe_ticks_{horizon}m'] = max(0, (max(highs) - base) / tick) if complete else ''
                out[f'future_long_mae_ticks_{horizon}m'] = min(0, (min(lows) - base) / tick) if complete else ''
            result.append(out)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('csv', type=Path, nargs='+')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--horizons', default='1,5,15')
    parser.add_argument('--max-latency-ms', type=float, default=1000)
    args = parser.parse_args()
    horizons = sorted(set(int(x) for x in args.horizons.split(',')))
    if not horizons or any(h < 1 or h > 1440 for h in horizons):
        parser.error('Horizons must be positive minute counts <= 1440.')
    if args.max_latency_ms < 0:
        parser.error('Latency limit must be nonnegative.')
    if args.output.resolve() in {p.resolve() for p in args.csv}:
        parser.error('Output must not overwrite a live feature file.')
    labels = make_labels(args.csv, horizons, args.max_latency_ms)
    if not labels:
        parser.error('No rows found.')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(labels[0]))
        writer.writeheader()
        writer.writerows(labels)
    print(f'Wrote {len(labels)} rows to {args.output}. Labels are diagnostic; model spread, fees and execution latency separately.')


if __name__ == '__main__':
    main()
