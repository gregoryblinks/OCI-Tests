@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    py -3 tools\build.py %*
) else (
    python tools\build.py %*
)
exit /b %ERRORLEVEL%
