package com.ofipressure.io;

import com.ofipressure.core.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Small, dependency-free OOXML writer for immutable minute observations; not an event database. */
public final class XlsxSnapshot {
    private XlsxSnapshot() {}
    private static final String NS="http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    public static void write(Path target,List<BarRecord> records,Map<String,String> metadata) throws IOException {
        if(records.isEmpty())return;
        Path temp=target.resolveSibling(target.getFileName()+".pending.xlsx");
        try(ZipOutputStream z=new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)))) {
            part(z,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
            part(z,"_rels/.rels","<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            part(z,"xl/workbook.xml","<?xml version=\"1.0\"?><workbook xmlns=\""+NS+"\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"minute_pressure\" sheetId=\"1\" r:id=\"rId1\"/><sheet name=\"metadata\" sheetId=\"2\" r:id=\"rId2\"/></sheets></workbook>");
            part(z,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/><Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
            part(z,"xl/styles.xml",styles());
            List<List<Object>> rows=new ArrayList<>();rows.add(new ArrayList<>(records.get(0).headers()));for(BarRecord r:records)rows.add(r.values());
            sheet(z,"xl/worksheets/sheet1.xml",rows,false);
            List<List<Object>> meta=new ArrayList<>();meta.add(Arrays.asList("Setting / definition","Value"));
            metadata.forEach((k,v)->meta.add(Arrays.asList(k,v)));
            sheet(z,"xl/worksheets/sheet2.xml",meta,true);
        }
        try {Files.move(temp,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
        catch(AtomicMoveNotSupportedException e){Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING);}
        // If Excel has locked target, move throws and the valid .pending.xlsx is intentionally retained.
    }
    private static void part(ZipOutputStream z,String path,String xml)throws IOException{z.putNextEntry(new ZipEntry(path));z.write(xml.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private static String styles(){return "<?xml version=\"1.0\"?><styleSheet xmlns=\""+NS+"\">"
        +"<numFmts count=\"2\"><numFmt numFmtId=\"164\" formatCode=\"0.0000;[Red]-0.0000\"/><numFmt numFmtId=\"165\" formatCode=\"0.0%\"/></numFmts>"
        +"<fonts count=\"4\"><font><sz val=\"11\"/><name val=\"Calibri\"/><color rgb=\"FF008000\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/><color rgb=\"FFFFFFFF\"/></font><font><sz val=\"11\"/><name val=\"Calibri\"/><color rgb=\"FF666666\"/></font><font><sz val=\"11\"/><name val=\"Calibri\"/><color rgb=\"FF111111\"/></font></fonts>"
        +"<fills count=\"4\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF183B4E\"/><bgColor indexed=\"64\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFFFF0DA\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>"
        +"<borders count=\"1\"><border/></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
        +"<cellXfs count=\"7\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyAlignment=\"1\"><alignment wrapText=\"1\" vertical=\"center\"/></xf><xf numFmtId=\"164\" fontId=\"3\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/><xf numFmtId=\"165\" fontId=\"3\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/><xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyAlignment=\"1\"><alignment wrapText=\"1\" vertical=\"top\"/></xf><xf numFmtId=\"0\" fontId=\"3\" fillId=\"3\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"3\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/></cellXfs>"
        +"<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>";}
    private static void sheet(ZipOutputStream z,String path,List<List<Object>> rows,boolean metadata)throws IOException{
        z.putNextEntry(new ZipEntry(path));
        Writer w=new OutputStreamWriter(z,StandardCharsets.UTF_8);
        int cols=rows.get(0).size();
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\""+NS+"\"><dimension ref=\"A1:"+col(cols-1)+rows.size()+"\"/><sheetViews><sheetView workbookViewId=\"0\" showGridLines=\"0\"><pane xSplit=\""+(metadata?0:3)+"\" ySplit=\"1\" topLeftCell=\""+(metadata?"A2":"D2")+"\" activePane=\"bottomRight\" state=\"frozen\"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight=\"18\"/><cols>");
        for(int j=0;j<cols;j++) {
            String name=String.valueOf(rows.get(0).get(j));
            int width=metadata?(j==0?35:108):(name.equals("alias")?38:name.endsWith("_utc")?27:name.endsWith("_ns")?24:name.contains("sha256")?68:name.contains("run_id")?48:name.equals("quality_flags")?34:Math.max(15,Math.min(26,name.length()+2)));
            w.write("<col min=\""+(j+1)+"\" max=\""+(j+1)+"\" width=\""+width+"\" customWidth=\"1\"/>");
        }
        w.write("</cols><sheetData>");
        for(int i=0;i<rows.size();i++){
            w.write("<row r=\""+(i+1)+"\""+(i==0?" ht=\"34\" customHeight=\"1\"":metadata?" ht=\"34\" customHeight=\"1\"":"")+">");
            List<Object> row=rows.get(i);
            for(int j=0;j<row.size();j++){
                Object v=row.get(j);if(v==null)continue;
                String ref=col(j)+(i+1),name=String.valueOf(rows.get(0).get(j));
                if(v instanceof Number && !Double.isFinite(((Number)v).doubleValue()))continue;
                int style=i==0?1:metadata?4:v instanceof Number?(name.contains("percentile")||name.equals("valid_book_coverage")||name.equals("direction_persistence")?3:v instanceof Double||v instanceof Float?2:6):0;
                if(i>0&&(name.equals("score_status")&&!v.equals("READY")||name.equals("quality_flags")&&!v.toString().isEmpty()))style=5;
                w.write("<c r=\""+ref+"\" s=\""+style+"\"");
                if(v instanceof Number)w.write("><v>"+v+"</v></c>");
                else if(v instanceof Boolean)w.write(" t=\"b\"><v>"+((Boolean)v?"1":"0")+"</v></c>");
                else w.write(" t=\"inlineStr\"><is><t xml:space=\"preserve\">"+xml(v.toString())+"</t></is></c>");
            }
            w.write("</row>");
        }
        w.write("</sheetData><autoFilter ref=\"A1:"+col(cols-1)+rows.size()+"\"/></worksheet>");w.flush();z.closeEntry();
    }
    private static String col(int n){StringBuilder s=new StringBuilder();do{s.insert(0,(char)('A'+n%26));n=n/26-1;}while(n>=0);return s.toString();}
    private static String xml(String s){
        StringBuilder b=new StringBuilder();
        s.codePoints().filter(x->x==9||x==10||x==13||x>=32&&x<=0xD7FF||x>=0xE000&&x<=0xFFFD||x>=0x10000&&x<=0x10FFFF).forEach(b::appendCodePoint);
        return b.toString().replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");
    }
}
