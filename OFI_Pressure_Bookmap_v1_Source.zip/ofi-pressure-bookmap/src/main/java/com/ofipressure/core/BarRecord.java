package com.ofipressure.core;

import java.time.Instant;
import java.util.*;

/** Immutable research snapshot. String timestamps deliberately preserve nanoseconds in Excel. */
public final class BarRecord {
    private final LinkedHashMap<String,Object> fields;
    public final long startNs,endNs,availableNs;
    public final double anchorTicks,z;
    public final String scoreStatus;
    public final boolean valid;
    public BarRecord(LinkedHashMap<String,Object> fields,long startNs,long endNs,long availableNs,double anchorTicks,double z,String status,boolean valid){
        this.fields=new LinkedHashMap<>(fields);this.startNs=startNs;this.endNs=endNs;this.availableNs=availableNs;
        this.anchorTicks=anchorTicks;this.z=z;this.scoreStatus=status;this.valid=valid;
    }
    public Map<String,Object> fields(){return Collections.unmodifiableMap(fields);}
    public Object get(String key){return fields.get(key);}
    public List<String> headers(){return new ArrayList<>(fields.keySet());}
    public List<Object> values(){return new ArrayList<>(fields.values());}
    public static String iso(long ns){return Instant.ofEpochSecond(Math.floorDiv(ns,1000000000L),Math.floorMod(ns,1000000000L)).toString();}
}
