package com.ofipressure.core;

import java.util.*;

/** Prior observations only; caller must score BEFORE observe. Recompute Welford moments per minute. */
public final class RollingCalibration {
    private final ArrayDeque<Double> data=new ArrayDeque<>();
    private final int capacity,minimum;
    private final double floor;
    public RollingCalibration(int capacity,int minimum,double floor){this.capacity=capacity;this.minimum=minimum;this.floor=floor;}
    public static final class Score {
        public final int count; public final double mean,sd,z,percentile; public final String status;
        Score(int n,double m,double s,double z,double p,String status){count=n;mean=m;sd=s;this.z=z;percentile=p;this.status=status;}
    }
    public Score score(double value) {
        int n=0,less=0,equal=0; double mean=0,m2=0;
        for(double x:data){n++;double d=x-mean;mean+=d/n;m2+=d*(x-mean);if(x<value)less++;else if(x==value)equal++;}
        double sd=n>1?Math.sqrt(Math.max(0,m2/(n-1))):Double.NaN;
        double pct=n>0?(less+0.5*equal)/n:Double.NaN;
        String status=n<minimum?"WARMUP":(!Double.isFinite(sd)||sd<=floor?"FLAT_BASELINE":"READY");
        return new Score(n,n>0?mean:Double.NaN,sd,status.equals("READY")?(value-mean)/sd:Double.NaN,pct,status);
    }
    public void observe(double x){if(!Double.isFinite(x))throw new IllegalArgumentException("Nonfinite sample");data.addLast(x);if(data.size()>capacity)data.removeFirst();}
    public void clear(){data.clear();}
    public int size(){return data.size();}
}
