package com.ofipressure.core;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Explicit, immutable parameters. No parameters are fitted on the current bar. */
public final class EngineConfig {
    public static final String MODEL_VERSION = "mlofi-before-after-1.0.0";
    public final int levels, window, warmup, maxOrders;
    public final double decay, varianceFloor, minCoverage, minBubbleZ;
    public final long staleNanos, gapResetNanos;
    public final String depthMode, weightMode, runLabel;
    public final Path outputRoot;
    public final double[] weights;
    public final boolean showWarmup;

    public EngineConfig(Properties p) {
        levels = integer(p, "levels", 10, 1, 50);
        window = integer(p, "rolling.window.minutes", 240, 2, 10080);
        warmup = integer(p, "rolling.minimum.minutes", 60, 2, window);
        maxOrders = integer(p, "book.max.orders", 2000000, 1000, 10000000);
        decay = number(p, "weights.decay", 0.25, 0, 5);
        varianceFloor = number(p, "rolling.sd.floor", 1e-9, 1e-15, 1e3);
        minCoverage = number(p, "quality.minimum.coverage", 0.99, 0.5, 1.0);
        minBubbleZ = number(p, "display.minimum.abs.z", 0, 0, 20);
        staleNanos = (long)(number(p, "quality.stale.seconds", 30, 1, 3600) * 1e9);
        gapResetNanos = (long)(number(p, "quality.clock.gap.seconds", 120, 60, 86400) * 1e9);
        depthMode = p.getProperty("depth.mode", "EVENT").trim().toUpperCase(Locale.ROOT);
        if (!depthMode.equals("EVENT") && !depthMode.equals("TIME")) throw new IllegalArgumentException("depth.mode must be EVENT or TIME");
        weightMode = p.getProperty("weights.mode", "EXPONENTIAL").trim().toUpperCase(Locale.ROOT);
        weights = new double[levels];
        if (weightMode.equals("MANUAL")) {
            String[] a = p.getProperty("weights.manual", "").split(",");
            if (a.length != levels) throw new IllegalArgumentException("weights.manual must have exactly levels entries");
            for (int i=0; i<levels; i++) { weights[i] = Double.parseDouble(a[i].trim()); if (!Double.isFinite(weights[i])) throw new IllegalArgumentException("Nonfinite weight"); }
        } else if (weightMode.equals("UNIFORM") || weightMode.equals("EXPONENTIAL")) {
            for (int i=0; i<levels; i++) weights[i] = weightMode.equals("UNIFORM") ? 1.0 : Math.exp(-decay*i);
        } else throw new IllegalArgumentException("weights.mode must be EXPONENTIAL, UNIFORM or MANUAL");
        double l1=0; for(double w:weights) l1+=Math.abs(w);
        if (!(l1 > 0)) throw new IllegalArgumentException("Weights cannot all be zero");
        for (int i=0; i<levels; i++) weights[i] /= l1;
        showWarmup = Boolean.parseBoolean(p.getProperty("display.show.warmup", "true"));
        runLabel = p.getProperty("run.label", "UNSPECIFIED").trim();
        outputRoot = Paths.get(p.getProperty("output.directory", Paths.get(System.getProperty("user.home"), "Bookmap", "OFI-Pressure", "data").toString()));
    }
    private static int integer(Properties p,String k,int d,int lo,int hi) {
        int v=Integer.parseInt(p.getProperty(k,""+d).trim());
        if(v<lo || v>hi) throw new IllegalArgumentException(k+" must be "+lo+".."+hi); return v;
    }
    private static double number(Properties p,String k,double d,double lo,double hi) {
        double v=Double.parseDouble(p.getProperty(k,""+d).trim());
        if(!Double.isFinite(v) || v<lo || v>hi) throw new IllegalArgumentException(k+" outside allowed range"); return v;
    }
    public Properties asProperties() {
        Properties p=new Properties();
        p.setProperty("levels",""+levels); p.setProperty("rolling.window.minutes",""+window); p.setProperty("rolling.minimum.minutes",""+warmup);
        p.setProperty("weights.mode",weightMode); p.setProperty("weights.decay",""+decay);
        StringJoiner w=new StringJoiner(","); for(double v:weights)w.add(Double.toString(v)); p.setProperty("weights.manual",w.toString());
        p.setProperty("depth.mode",depthMode); p.setProperty("rolling.sd.floor",""+varianceFloor);
        p.setProperty("quality.minimum.coverage",""+minCoverage); p.setProperty("quality.stale.seconds",""+(staleNanos/1e9));
        p.setProperty("quality.clock.gap.seconds",""+(gapResetNanos/1e9)); p.setProperty("book.max.orders",""+maxOrders);
        p.setProperty("display.minimum.abs.z",""+minBubbleZ); p.setProperty("display.show.warmup",""+showWarmup);
        p.setProperty("run.label",runLabel); p.setProperty("output.directory",outputRoot.toString()); return p;
    }
    public String fingerprint() {
        try {
            StringBuilder b=new StringBuilder(MODEL_VERSION+"\n"); Properties p=asProperties();
            for(String k:new TreeSet<>(p.stringPropertyNames())) b.append(k).append('=').append(p.getProperty(k)).append('\n');
            byte[] hash=MessageDigest.getInstance("SHA-256").digest(b.toString().getBytes(StandardCharsets.UTF_8));
            StringBuilder h=new StringBuilder(); for(byte x:hash)h.append(String.format(Locale.ROOT,"%02x",x&255)); return h.toString();
        } catch(Exception e) { throw new IllegalStateException(e); }
    }
    public static Path configPath() { return Paths.get(System.getProperty("user.home"),"Bookmap","OFI-Pressure","config.properties"); }
    public static EngineConfig loadOrCreate(Path file) throws IOException {
        Files.createDirectories(file.toAbsolutePath().getParent());
        if(!Files.exists(file)) {
            try(OutputStream out=Files.newOutputStream(file,StandardOpenOption.CREATE_NEW)) {
                new EngineConfig(new Properties()).asProperties().store(out,"OFI Pressure: disable/re-enable add-on after editing. All time buckets are UTC.");
            } catch(FileAlreadyExistsException ignore) { /* another instrument initialized simultaneously */ }
        }
        Properties p=new Properties(); try(InputStream in=Files.newInputStream(file)){p.load(in);} return new EngineConfig(p);
    }
}
