package com.ofipressure.bookmap;

import com.ofipressure.core.*;
import com.ofipressure.io.*;
import java.awt.Desktop;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.*;
import velox.api.layer1.annotations.Layer1ApiVersion;
import velox.api.layer1.annotations.Layer1ApiVersionValue;
import velox.api.layer1.annotations.Layer1SimpleAttachable;
import velox.api.layer1.annotations.Layer1StrategyName;
import velox.api.layer1.data.InstrumentInfo;
import velox.api.layer1.data.TradeInfo;
import velox.api.layer1.messages.indicators.Layer1ApiUserMessageModifyIndicator.GraphType;
import velox.api.layer1.simplified.*;
import velox.gui.StrategyPanel;

/** Read-only Bookmap adapter. No order submission/modification/cancellation API is called. */
@Layer1SimpleAttachable
@Layer1StrategyName("OFI Pressure - 1 Minute Bubbles (Research v1)")
@Layer1ApiVersion(Layer1ApiVersionValue.VERSION2)
public final class OfiPressureAddon implements CustomModule, MarketByOrderDepthDataListener,
        TimeListener, SnapshotEndListener, TradeDataListener, IntervalListener, CustomSettingsPanelProvider {
    private EngineConfig config;
    private PressureEngine engine;
    private ResearchWriter writer;
    private Indicator bubbles;
    private volatile JLabel engineStatus,writerStatus;
    private final AtomicBoolean updatePending=new AtomicBoolean();
    private volatile String startupError="";
    private volatile boolean stopped=false;

    @Override public void initialize(String alias,InstrumentInfo info,Api api,InitialState initialState){
        stopped=false;startupError="";
        try{
            config=EngineConfig.loadOrCreate(EngineConfig.configPath());
            String runId=Instant.now().toString().replace(':','-')+"_"+UUID.randomUUID().toString().substring(0,8);
            writer=new ResearchWriter(config,alias,runId,info.pips);
            bubbles=api.registerIndicator("OFI Pressure 1m bubbles",GraphType.PRIMARY);
            // Never add line points: this is a bubble-only primary-chart indicator.
            engine=new PressureEngine(config,alias,runId,info.pips,this::onClosedMinute);
            if(initialState!=null)engine.onTime(initialState.getCurrentTime());
            System.out.println("OFI Pressure output: "+writer.directory());
        }catch(Exception e){startupError="Initialization failed: "+e.getMessage();System.err.println(startupError);if(writer!=null)writer.close();}
    }
    private void onClosedMinute(BarRecord record){
        boolean saved=writer.submit(record);
        if(!saved)System.err.println("OFI RECORDING FAILURE for "+record.get("alias")+" "+record.get("end_utc"));
        if(!Double.isFinite(record.anchorTicks))return;
        if(!Double.isFinite(record.z)&&!config.showWarmup&&saved)return;
        if(Double.isFinite(record.z)&&Math.abs(record.z)<config.minBubbleZ&&saved)return;
        BufferedImage icon=BubbleImage.render(record.z,record.scoreStatus,!saved||writer.failed());
        // addIcon is timestamped by the current Bookmap callback. Never pretend it was available earlier.
        bubbles.addIcon(record.anchorTicks,icon,icon.getWidth()/2,icon.getHeight()/2);
    }
    @Override public void send(String orderId,boolean isBid,int price,int size){if(engine!=null&&!stopped)engine.send(orderId,isBid,price,size);}
    @Override public void replace(String orderId,int price,int size){if(engine!=null&&!stopped)engine.replace(orderId,price,size);}
    @Override public void cancel(String orderId){if(engine!=null&&!stopped)engine.cancel(orderId);}
    @Override public void onTimestamp(long t){if(engine!=null&&!stopped)engine.onTime(t);}
    @Override public void onSnapshotEnd(){if(engine!=null&&!stopped)engine.snapshotEnd();}
    @Override public void onTrade(double price,int size,TradeInfo tradeInfo){
        if(engine!=null&&!stopped)engine.trade(price,size,tradeInfo==null?0:tradeInfo.isBidAggressor?1:-1,tradeInfo!=null&&tradeInfo.isOtc);
    }
    @Override public long getInterval(){return 1000000000L;}
    @Override public void onInterval(){
        // Market clock comes only from onTimestamp. Never synthesize timestamps from System.currentTimeMillis.
        if(engineStatus==null||!updatePending.compareAndSet(false,true))return;
        String e=!startupError.isEmpty()?startupError:engine==null?"Initializing":engine.status();
        String w=writer==null?"No writer":writer.status();
        SwingUtilities.invokeLater(()->{try{if(engineStatus!=null)engineStatus.setText(e);if(writerStatus!=null)writerStatus.setText(w);}finally{updatePending.set(false);}});
    }
    @Override public StrategyPanel[] getCustomSettingsPanels(){
        SimpleStrategyPanel p=new SimpleStrategyPanel("OFI Pressure - research settings");
        engineStatus=new JLabel(engine==null?startupError:engine.status());writerStatus=new JLabel(writer==null?"No writer":writer.status());
        p.addItem("Engine",engineStatus);p.addItem("Export",writerStatus);
        p.addItem("Configuration",new JLabel(EngineConfig.configPath().toString()));
        p.addItem("Parameters",new JLabel(config==null?"Unavailable":config.levels+" levels; "+config.weightMode+"; depth "+config.depthMode+"; prior "+config.window+" / warmup "+config.warmup));
        JButton folder=new JButton("Open output folder");folder.addActionListener(e->open(writer==null?EngineConfig.configPath().getParent():writer.directory(),false));p.addItems(folder);
        JButton edit=new JButton("Open configuration file");edit.addActionListener(e->open(EngineConfig.configPath(),true));p.addItems(edit);
        p.addItems(new JLabel("After editing: disable/re-enable. A new run and warm-up start; MBO snapshot is required."));
        p.addItems(new JLabel("Z is a baseline deviation, not a probability. Replay-test before relying on it."));
        return new StrategyPanel[]{p};
    }
    private void open(Path path,boolean file){
        try{if(!Desktop.isDesktopSupported())throw new UnsupportedOperationException("Desktop integration unavailable");Desktop d=Desktop.getDesktop();if(file&&d.isSupported(Desktop.Action.EDIT))d.edit(path.toFile());else d.open(path.toFile());}
        catch(Exception e){JOptionPane.showMessageDialog(null,path+"\n"+e.getMessage(),"Open this path manually",JOptionPane.INFORMATION_MESSAGE);}
    }
    @Override public void stop(){stopped=true;if(writer!=null)writer.close();/* Incomplete last minute is intentionally not exported/scored. */}
}
