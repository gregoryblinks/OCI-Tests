package com.ofipressure.bookmap;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Locale;

/** Pure Java renderer; zero is neutral. "Z" explicitly denotes a centered anomaly, not buy probability. */
public final class BubbleImage {
    private BubbleImage(){}
    public static BufferedImage render(double z,String status,boolean recordingError){
        boolean scored=Double.isFinite(z)&&!recordingError;
        int diameter=scored?(int)(32+8*Math.min(4,Math.abs(z))):34;
        String label=recordingError?"SAVE!":scored?String.format(Locale.ROOT,"Z%+.1f",z):status.equals("WARMUP")?"WARM":status.equals("FLAT_BASELINE")?"FLAT":"DATA!";
        int width=Math.max(diameter+4,78),height=diameter+4;
        BufferedImage image=new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=image.createGraphics();
        try{
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            Color color=recordingError?new Color(230,165,35,235):!scored||Math.abs(z)<0.5?new Color(108,119,132,220):z>0?new Color(0,150,118,235):new Color(205,62,72,235);
            int x=(width-diameter)/2;g.setColor(new Color(12,18,26,230));g.fillOval(x-1,1,diameter+2,diameter+2);
            g.setColor(color);g.fillOval(x,2,diameter,diameter);g.setStroke(new BasicStroke(1.5f));g.setColor(Color.WHITE);g.drawOval(x,2,diameter,diameter);
            g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,12));FontMetrics fm=g.getFontMetrics();int textX=(width-fm.stringWidth(label))/2,textY=(height-fm.getHeight())/2+fm.getAscent();
            // Small dark strip preserves labels at minimum bubble size.
            g.setColor(new Color(12,18,26,185));g.fillRoundRect(textX-2,textY-fm.getAscent(),fm.stringWidth(label)+4,fm.getHeight(),5,5);
            g.setColor(Color.WHITE);g.drawString(label,textX,textY);
        }finally{g.dispose();}return image;
    }
}
