package com.ofipressure;

import com.ofipressure.core.*;
import com.ofipressure.io.*;
import com.ofipressure.bookmap.BubbleImage;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import javax.imageio.ImageIO;

/** No network, Bookmap runtime, credentials or test framework required. */
public final class EngineTests {
    private static int passed=0;
    private static final long T=Instant.parse("2026-01-05T09:00:00Z").getEpochSecond()*PressureEngine.SECOND;
    private static final long S=PressureEngine.SECOND,M=PressureEngine.MINUTE;
    private static void eq(double expected,double actual){if(!(Math.abs(expected-actual)<1e-8*Math.max(1,Math.abs(expected))))throw new AssertionError("expected "+expected+", got "+actual);}
    private static void yes(boolean b,String why){if(!b)throw new AssertionError(why);}
    private static void test(String name,Throwing action)throws Exception{action.run();passed++;System.out.println("PASS "+name);}
    private interface Throwing{void run()throws Exception;}
    private static double num(BarRecord r,String field){return ((Number)r.get(field)).doubleValue();}
    private static EngineConfig cfg(String... pairs){Properties p=new Properties();p.setProperty("levels","1");p.setProperty("rolling.window.minutes","4");p.setProperty("rolling.minimum.minutes","2");for(int i=0;i<pairs.length;i+=2)p.setProperty(pairs[i],pairs[i+1]);return new EngineConfig(p);}
    private static PressureEngine engine(EngineConfig c,List<BarRecord> out,long t){PressureEngine e=new PressureEngine(c,"TEST","test-run",0.25,out::add);e.onTime(t);for(int i=0;i<c.levels;i++){e.send("B"+i,true,100-i,10);e.send("A"+i,false,102+i,10);}e.snapshotEnd();return e;}
    private static void constantMinute(PressureEngine e,long start,int bidSize){for(int s:new int[]{10,25,40,55}){e.onTime(start+s*S);e.replace("B0",100,bidSize);}e.onTime(start+M);}
    public static void main(String[] args)throws Exception{
        test("unchanged book gives zero",()->eq(0,OrderBook.eventOfi(100,10,102,20,100,10,102,20)));
        test("same-price bid addition is positive",()->eq(7,OrderBook.eventOfi(100,10,102,20,100,17,102,20)));
        test("same-price bid removal is negative",()->eq(-7,OrderBook.eventOfi(100,10,102,20,100,3,102,20)));
        test("same-price ask addition is negative",()->eq(-7,OrderBook.eventOfi(100,10,102,20,100,10,102,27)));
        test("same-price ask removal is positive",()->eq(7,OrderBook.eventOfi(100,10,102,20,100,10,102,13)));
        test("bid improvement uses NEW queue",()->eq(13,OrderBook.eventOfi(100,10,102,20,101,13,102,20)));
        test("bid retreat uses OLD queue",()->eq(-10,OrderBook.eventOfi(100,10,102,20,99,99,102,20)));
        test("ask improvement uses NEW queue",()->eq(-13,OrderBook.eventOfi(100,10,102,20,100,10,101,13)));
        test("ask retreat uses OLD queue",()->eq(20,OrderBook.eventOfi(100,10,102,20,100,10,103,99)));
        test("aggregate order sizes at the same price",()->{OrderBook b=new OrderBook(1000);b.send("a",true,100,10);b.send("b",true,100,20);b.send("c",false,102,5);OrderBook.Top top=new OrderBook.Top(1);b.top(top);eq(30,top.bidSize[0]);});
        test("replace is an absolute size, zero deletes",()->{OrderBook b=new OrderBook(1000);b.send("a",true,100,10);b.send("c",false,102,5);b.replace("a",100,7);OrderBook.Top top=new OrderBook.Top(1);b.top(top);eq(7,top.bidSize[0]);b.replace("a",100,0);b.top(top);yes(!top.valid(),"empty bid");});
        test("large aggregate quantities do not overflow int",()->{OrderBook b=new OrderBook(1000);b.send("a",true,-10,Integer.MAX_VALUE);b.send("b",true,-10,Integer.MAX_VALUE);b.send("c",false,-9,1);OrderBook.Top top=new OrderBook.Top(1);b.top(top);eq(4294967294.0,top.bidSize[0]);yes(top.valid(),"negative prices are valid");});
        test("dynamic ranks follow improving quote",()->{OrderBook b=new OrderBook(1000);b.send("b0",true,100,10);b.send("b1",true,99,20);b.send("a0",false,103,30);b.send("a1",false,104,40);OrderBook.Top t0=new OrderBook.Top(2),t1=new OrderBook.Top(2);b.top(t0);b.send("better",true,101,50);b.top(t1);eq(101,t1.bidPrice[0]);eq(100,t1.bidPrice[1]);eq(50,OrderBook.eventOfi(t0.bidPrice[0],t0.bidSize[0],t0.askPrice[0],t0.askSize[0],t1.bidPrice[0],t1.bidSize[0],t1.askPrice[0],t1.askSize[0]));eq(10,OrderBook.eventOfi(t0.bidPrice[1],t0.bidSize[1],t0.askPrice[1],t0.askSize[1],t1.bidPrice[1],t1.bidSize[1],t1.askPrice[1],t1.askSize[1]));});
        test("snapshot is not counted as flow",()->{List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,T);constantMinute(e,T,10);eq(0,num(r.get(0),"L1_ofi"));eq(4,num(r.get(0),"mbo_events"));yes(r.get(0).valid,"first complete minute valid");});
        test("partial first minute is unscored",()->{List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,T+5*S);constantMinute(e,T,15);yes(!r.get(0).valid,"partial");yes(r.get(0).get("quality_flags").toString().contains("PARTIAL_START"),"partial flag");});
        test("half-open minute boundary allocates event to next bar",()->{List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,T);constantMinute(e,T,10);e.replace("B0",100,20);constantMinute(e,T+M,20);eq(0,num(r.get(0),"L1_ofi"));eq(10,num(r.get(1),"L1_ofi"));});
        test("trade callback does not double count book consumption",()->{List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,T);e.onTime(T+10*S);e.trade(102,4,1,false);e.replace("A0",102,6);constantMinute(e,T+10*S,10);eq(4,num(r.get(0),"L1_ofi"));eq(4,num(r.get(0),"aggressive_buy_size"));eq(25.5,num(r.get(0),"trade_close"));});
        test("OTC trade excluded from candle and volume",()->{List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,T);e.trade(1000,100,1,true);constantMinute(e,T,10);eq(0,num(r.get(0),"trade_count"));eq(1,num(r.get(0),"otc_trades_excluded"));yes(Double.isNaN(num(r.get(0),"trade_close")),"no synthetic close");});
        test("time-weighted depth uses old state before update",()->{List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg("depth.mode","TIME"),r,T);e.onTime(T+20*S);e.replace("B0",100,20);e.onTime(T+40*S);e.replace("B0",100,20);e.onTime(T+M);eq(40.0/3,num(r.get(0),"shared_depth_time"));eq(15,num(r.get(0),"shared_depth_event"));eq(0.75,num(r.get(0),"normalized_ofi"));});
        test("prior-only calibration and sample standard deviation",()->{RollingCalibration cal=new RollingCalibration(3,2,1e-9);cal.observe(1);cal.observe(3);RollingCalibration.Score s=cal.score(5);eq(2,s.count);eq(2,s.mean);eq(Math.sqrt(2),s.sd);eq(3/Math.sqrt(2),s.z);yes(cal.size()==2,"scoring cannot observe itself");cal.observe(5);cal.observe(7);eq(5,cal.score(9).mean);});
        test("empirical percentile handles ties without normal assumption",()->{RollingCalibration c=new RollingCalibration(10,2,1e-9);c.observe(1);c.observe(2);c.observe(2);c.observe(4);eq(.5,c.score(2).percentile);});
        test("flat baseline remains unscored",()->{RollingCalibration c=new RollingCalibration(3,2,1e-9);c.observe(1);c.observe(1);yes(c.score(100).status.equals("FLAT_BASELINE"),"flat status");yes(Double.isNaN(c.score(100).z),"not infinite z");});
        test("Z sign and underlying flow sign can differ",()->{RollingCalibration c=new RollingCalibration(4,2,1e-9);c.observe(-3);c.observe(-2);c.observe(-1);yes(c.score(-0.5).z>0,"positive deviation despite negative raw flow");});
        test("engine freezes score before inserting current minute",()->{List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,T);constantMinute(e,T,15);constantMinute(e,T+M,12);constantMinute(e,T+2*M,25);eq(2,num(r.get(2),"prior_sample_count"));double a=num(r.get(0),"normalized_ofi"),b=num(r.get(1),"normalized_ofi"),x=num(r.get(2),"normalized_ofi");eq((x-(a+b)/2)/(Math.abs(a-b)/Math.sqrt(2)),r.get(2).z);});
        test("missing depth cannot yield a numeric score",()->{List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,T);e.onTime(T+S);e.cancel("A0");constantMinute(e,T+S,10);yes(!r.get(0).valid,"missing book invalid");yes(Double.isNaN(r.get(0).z),"no numeric pressure");});
        test("stale data invalidates minute",()->{List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,T);e.onTime(T+59*S);e.replace("B0",100,20);e.onTime(T+M);yes(r.get(0).get("quality_flags").toString().contains("STALE_BOOK"),"stale flag");yes(!r.get(0).valid,"stale invalid");});
        test("large clock gaps are flagged, not padded with fake bars",()->{List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,T);e.onTime(T+5*M);yes(r.size()==1,"only observed old bar emitted");yes(r.get(0).get("quality_flags").toString().contains("CLOCK_GAP"),"gap flag");});
        test("duplicate order ID fails closed",()->{PressureEngine e=engine(cfg(),new ArrayList<>(),T);e.send("B0",true,100,9);yes(e.failed(),"duplicate must fail");});
        test("unknown replacement fails closed",()->{PressureEngine e=engine(cfg(),new ArrayList<>(),T);e.replace("absent",100,9);yes(e.failed(),"unknown replace must fail");});
        test("unknown cancellation fails closed",()->{PressureEngine e=engine(cfg(),new ArrayList<>(),T);e.cancel("absent");yes(e.failed(),"unknown cancel must fail");});
        test("backward replay seek requires fresh snapshot",()->{PressureEngine e=engine(cfg(),new ArrayList<>(),T);e.onTime(T-S);yes(e.failed(),"rewind must fail");});
        test("weight normalization and invalid config",()->{EngineConfig c=cfg("levels","3","weights.mode","MANUAL","weights.manual","1,2,1");eq(.5,c.weights[1]);try{cfg("weights.mode","MANUAL","weights.manual","0");throw new AssertionError("zero accepted");}catch(IllegalArgumentException good){}});
        test("configuration fingerprint is deterministic",()->yes(cfg().fingerprint().equals(cfg().fingerprint()),"deterministic config hash"));
        test("writer drains CSV and genuine XLSX on close",()->{Path dir=Files.createTempDirectory("ofi-writer-test-");EngineConfig c=cfg("output.directory",dir.toString());List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(c,r,T);constantMinute(e,T,15);ResearchWriter w=new ResearchWriter(c,"TEST","run",.25);yes(w.submit(r.get(0)),"accept record");w.close();yes(!w.failed(),w.status());yes(Files.size(w.directory().resolve("2026-01-05_pressure.csv"))>100,"csv exists");yes(Files.size(w.directory().resolve("2026-01-05_pressure.xlsx"))>100,"xlsx exists");});
        test("locked-style XLSX failure preserves CSV and pending workbook",()->{Path dir=Files.createTempDirectory("ofi-lock-test-");EngineConfig c=cfg("output.directory",dir.toString());List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(c,r,T);constantMinute(e,T,15);ResearchWriter w=new ResearchWriter(c,"TEST","run",.25);Path blocked=w.directory().resolve("2026-01-05_pressure.xlsx");Files.createDirectory(blocked);Files.writeString(blocked.resolve("lock"),"prevent directory replacement");w.submit(r.get(0));w.close();yes(!w.failed(),"CSV stays operational");yes(w.status().contains("blocked"),"visible XLSX warning");yes(Files.exists(w.directory().resolve("2026-01-05_pressure.xlsx.pending.xlsx")),"pending workbook retained");});
        test("bubble renderer produces labels without Bookmap",()->{Path out=Paths.get("build","bubble-render-test.png");Files.createDirectories(out.getParent());ImageIO.write(BubbleImage.render(2.8,"READY",false),"png",out.toFile());yes(Files.size(out)>100,"rendered PNG");});
        System.out.println("\nRESULT: "+passed+" tests passed.");
    }
}
