package com.ofipressure;

import com.ofipressure.core.*;
import com.ofipressure.io.*;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;

/** Deterministic artificial order flow; never interpret its statistics as a market backtest. */
public final class SyntheticDemo {
    public static void main(String[] args)throws Exception{
        Path root=Paths.get(args.length>0?args[0]:"examples/generated").toAbsolutePath();
        Properties p=new Properties();p.setProperty("output.directory",root.toString());p.setProperty("run.label","SYNTHETIC_NOT_MARKET_DATA");
        EngineConfig c=new EngineConfig(p);
        String run="synthetic-demo";
        ResearchWriter writer=new ResearchWriter(c,"SYNTHETIC_NOT_MARKET_DATA",run,0.25);
        List<BarRecord> rows=new ArrayList<>();
        PressureEngine engine=new PressureEngine(c,"SYNTHETIC_NOT_MARKET_DATA",run,0.25,r->{rows.add(r);if(!writer.submit(r))throw new IllegalStateException(writer.status());});
        long t=Instant.parse("2026-01-05T09:00:00Z").getEpochSecond()*PressureEngine.SECOND;
        int n=20;int[] bp=new int[n],ap=new int[n],bq=new int[n],aq=new int[n];
        engine.onTime(t);
        for(int i=0;i<n;i++){bp[i]=20000-i;ap[i]=20002+i;bq[i]=100+5*i;aq[i]=100+5*i;engine.send("B"+i,true,bp[i],bq[i]);engine.send("A"+i,false,ap[i],aq[i]);}
        engine.snapshotEnd();Random random=new Random(825271);
        for(int minute=0;minute<120;minute++){
            for(int second=0;second<60;second++){
                engine.onTime(t+minute*PressureEngine.MINUTE+second*PressureEngine.SECOND);
                int j=random.nextInt(12);
                int drift=(int)Math.round(4*Math.sin(minute*0.53));
                bq[j]=Math.max(15,Math.min(350,bq[j]+random.nextInt(17)-8+drift));
                aq[j]=Math.max(15,Math.min(350,aq[j]+random.nextInt(17)-8-drift));
                engine.replace("B"+j,bp[j],bq[j]);engine.replace("A"+j,ap[j],aq[j]);
                if(second%3==0){boolean buy=random.nextBoolean();int size=1+random.nextInt(3);engine.trade(buy?ap[0]:bp[0],size,buy?1:-1,false);if(buy){aq[0]=Math.max(5,aq[0]-size);engine.replace("A0",ap[0],aq[0]);}else{bq[0]=Math.max(5,bq[0]-size);engine.replace("B0",bp[0],bq[0]);}}
                if(second==30&&minute%7==3){
                    boolean up=minute%14==3;
                    if(up){for(int i=n-1;i>=0;i--){ap[i]++;engine.replace("A"+i,ap[i],aq[i]);}for(int i=0;i<n;i++){bp[i]++;engine.replace("B"+i,bp[i],bq[i]);}}
                    else {for(int i=n-1;i>=0;i--){bp[i]--;engine.replace("B"+i,bp[i],bq[i]);}for(int i=0;i<n;i++){ap[i]--;engine.replace("A"+i,ap[i],aq[i]);}}
                }
            }
            engine.onTime(t+(minute+1)*PressureEngine.MINUTE);
        }
        writer.close();if(writer.failed())throw new IllegalStateException(writer.status());
        long ready=rows.stream().filter(r->r.scoreStatus.equals("READY")).count();
        System.out.println("SYNTHETIC DEMO: "+rows.size()+" minutes, "+ready+" scored, "+(rows.size()-ready)+" warmup/invalid");
        System.out.println("OUTPUT: "+writer.directory());
    }
}
