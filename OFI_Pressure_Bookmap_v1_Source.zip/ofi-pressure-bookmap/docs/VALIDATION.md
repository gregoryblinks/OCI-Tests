# Validation report

Generated for source version 1.0.0.

## Completed in the development environment

- Compiled the independent Java engine, Java2D bubble renderer, CSV writer and XLSX snapshot writer with OpenJDK 21, targeting Java 17 bytecode (`--release 17`).
- Ran **36 automated Java tests**, all passed. Exact console log: `core-test-log.txt`.
- Covered event-level signs and old/new queue selection, aggregate quantities above 32-bit limits, atomic replace semantics, dynamic price ranks, snapshot exclusion, partial bars, minute boundaries, trade double-count prevention, OTC exclusion, time-weighted depth, prior-only calibration, empirical percentiles, degenerate variance, sign interpretation, data faults, stale clocks, rewind handling, writer drain and blocked XLSX replacement.
- Rendered a pressure bubble using the production renderer in a headless JVM. This verifies image generation only, not Bookmap placement.
- Drove the production engine/writer with a deterministic **synthetic** 120-minute, 10-level measurement example. The export contained 120 records, 97 columns and two Excel sheets. Sixty records were warm-up, followed by sixty scored records.
- Opened generated XLSX with openpyxl and verified exact nanosecond strings, expected blank warm-up scores, valid numeric ready scores, row count, sheet names, and absence of spreadsheet error/formula cells. Snapshot values are deliberately fixed research observations, not formulas that could recalculate history.
- Visually inspected rendered portions of both workbook sheets and the scored section. Adjusted instrument-column width to prevent clipping.
- Verified CSV-to-XLSX recovery with openpyxl.
- Verified offline label counts: 59 complete one-minute labels, 55 five-minute labels, and 45 fifteen-minute labels among the 60 READY synthetic observations. Confirmed incomplete horizons remain blank.
- Removed an intermediate minute and confirmed labels do not bridge the gap. Duplicate input rows are rejected.

## Not completed / not claimed

- Downloading the official Bookmap SDK JARs into this environment failed. Consequently the **Bookmap adapter has not been compiled against those SDK JARs here**. The build script is provided to do that locally. No fake SDK binaries or precompiled adapter are shipped.
- No actual Bookmap process, installation, market-data provider, MBO entitlement or user recording was available for runtime integration tests.
- No real-feed snapshot lifecycle, provider-specific execution/remove semantics, replay-seek lifecycle, chart position, display scaling, multi-day memory usage or peak feed throughput is certified.
- File-lock handling was tested by making the target workbook path nonreplaceable, not by running desktop Excel on Windows.
- The example is artificial data and is not evidence of prediction accuracy, market edge, absorption detection, execution performance or profitability.

Complete `ACCEPTANCE_TESTS.md` against your Bookmap build and MBO connection before relying on the output.
