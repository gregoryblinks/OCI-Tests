# Feature schema, v1

One immutable row per observed completed minute, including unscored warm-up and invalid initial partial minutes. An incomplete final minute at shutdown is not promoted to a complete observation. A hard reconstruction failure stops further output until reload. Daily XLSX/CSV files share values; `metadata.txt` and the XLSX metadata sheet record method and settings.

## Time and identity

| Field | Type / meaning |
|---|---|
| `start_utc`, `end_utc` | ISO-8601 UTC minute boundaries; interval is [start,end) |
| `start_ns`, `end_ns` | Exact epoch nanoseconds stored as **text**, not floating-point numbers |
| `available_ns`, `available_utc` | First API clock callback on which this completed observation was produced |
| `close_latency_ms` | (available_ns - end_ns) / 1e6; not an estimate of exchange-to-machine latency |
| `last_mbo_age_ms` | Age of most recent MBO update at the minute boundary, in milliseconds |
| `alias` | Bookmap instrument alias; separate engine per alias |
| `run_id` | Unique activation ID; do not pool repeated replay runs as independent observations |
| `run_label` | User-specified provenance label; default UNSPECIFIED |
| `model_version`, `schema_version` | Algorithm/schema version identifiers |
| `config_sha256` | SHA-256 of model version and canonical configuration; includes output path and run label |

## Main pressure and statistical context

| Field | Meaning |
|---|---|
| `pressure_z` | Centered standardized anomaly; blank until READY |
| `normalized_ofi` | Fixed weighted raw OFI divided by selected shared depth; may be present in an invalid row for audit, but do **not** use it as valid data |
| `integrated_raw_ofi` | Sum of w_l times each ranked OFI; not a sum of unique traded contracts |
| `normalization_depth` | Shared depth actually used; EVENT or TIME |
| `flow_direction` | POSITIVE / NEGATIVE / ZERO / NA from normalized OFI |
| `deviation_direction` | POSITIVE / NEGATIVE / ZERO / NA from centered Z |
| `pressure_strength` | NEUTRAL (<0.5), MILD (<1), ELEVATED (<2), STRONG (<3), EXTREME (>=3), based on absolute Z; UNSCORED if unavailable |
| `prior_sample_count` | Number of prior valid complete minutes used in the current baseline |
| `prior_mean` | Mean of those prior normalized values |
| `prior_sample_sd` | Sample SD with n-1 denominator; blank with fewer than two observations |
| `prior_empirical_percentile` | (number less than current + half the number equal) / prior count. Fraction from 0 to 1; not Gaussian CDF or a prediction probability |
| `score_status` | READY, WARMUP, FLAT_BASELINE or INVALID |

The numerical baseline can be nonzero. A positive centered Z is therefore not necessarily positive actual flow. Formula evaluation always precedes insertion of the current observation into the rolling baseline. Baseline is reset after invalid minutes and is not restored across activations.

## Data quality

| Field | Meaning |
|---|---|
| `data_valid` | True only if the whole measurement passes the engine's quality checks; separate from calibration readiness |
| `bar_complete` | Observation started at the minute boundary; not proof of data validity |
| `valid_book_coverage` | Valid non-stale book time divided by 60 seconds |
| `quality_flags` | Pipe-separated reasons; blank is necessary for a valid minute |
| `mbo_events` | MBO mutations observed after snapshot initialization |
| `valid_mbo_events` | Mutations with sufficient, uncrossed ranked books before and after |

Flags currently include PARTIAL_START, INCOMPLETE_BOOK, STALE_BOOK, CLOCK_GAP, NO_MBO_EVENTS, LOW_COVERAGE, ZERO_DEPTH and BAD_TRADE. Any flag invalidates the minute. Some fatal faults such as DUPLICATE_ORDER_ID, UNKNOWN_REPLACE, UNKNOWN_CANCEL or TIME_REWIND stop the engine instead of emitting additional untrustworthy bars. The panel/log reports those failures. This does not constitute exchange sequence-number or packet-loss verification.

## Prices and trades

| Fields | Units / meaning |
|---|---|
| `trade_open`, `trade_high`, `trade_low`, `trade_close` | Non-OTC trade prices during this minute, in displayed price units; blank with no qualifying trade |
| `mid_open`, `mid_high`, `mid_low`, `mid_close` | Observed valid best-quote midpoints, in displayed price units |
| `bubble_price` | Trade close if present, otherwise midpoint close |
| `bubble_price_source` | LAST_TRADE or MIDPOINT |
| `trade_count` | Number of qualifying trade callbacks, not total volume |
| `aggressive_buy_size`, `aggressive_sell_size` | Sizes classified from Bookmap TradeInfo.isBidAggressor |
| `unknown_aggressor_size` | Trade size when TradeInfo is absent |
| `trade_delta` | Aggressive buy size minus aggressive sell size; **not added again to OFI** |
| `otc_trades_excluded` | Number of OTC callbacks deliberately omitted from candle/volume data |
| `tick_size` | InstrumentInfo.pips used to convert price levels to displayed price |
| `size_unit` | BOOKMAP_RAW_SIZE; the add-on does not infer contracts/shares or apply an unverified size multiplier |

Midpoint OHLC is based on reconstructed book states, not a candle downloaded independently from the exchange. When no valid midpoint exists, relevant values are blank; forward labels require valid data and prices.

## Depth, level components and settings

| Fields | Meaning |
|---|---|
| `shared_depth_event` | Average of post-update queue quantities over all valid MBO callbacks, both sides and all configured ranks |
| `shared_depth_time` | Same shared average, weighted by valid non-stale elapsed time |
| `levels`, `depth_mode`, `weight_mode` | Configuration used for this observation |
| `L1_ofi` ... `LN_ofi` | Raw accumulated ranked OFI at each selected level |
| `L1_normalized_ofi` ... `LN_normalized_ofi` | Each ranked OFI divided by the same selected shared depth |
| `L1_depth_event` ... `LN_depth_event` | Per-rank mean of bid+ask size divided by two, sampled after valid MBO updates |
| `L1_weight` ... `LN_weight` | Exact fixed normalized aggregation weights |
| `active_seconds` | One-second bins containing nonzero integrated raw OFI |
| `direction_persistence` | Fraction of active one-second bins with sign matching the integrated raw minute OFI; blank when no directional total exists |

Persistence is only a diagnostic. It is not volume-weighted, it excludes zero-flow seconds from its denominator and it does not affect the primary Z-score.

## Offline forward labels

The `forward_labels.py` output is a **different file** joined by instrument, run, configuration and exact minute timestamp. For h in {1,5,15} by default:

- `complete_hm`: current signal is READY and every required future minute exists with valid data and prices.
- `forward_log_return_hm`: log(midpoint at t+h / midpoint at t), when both prices are positive.
- `forward_mid_ticks_hm`: (future midpoint - current midpoint) / tick size.
- `future_long_mfe_ticks_hm`: max(0, greatest subsequent minute mid-high - current midpoint) / tick.
- `future_long_mae_ticks_hm`: min(0, lowest subsequent minute mid-low - current midpoint) / tick; negative denotes adverse excursion for a hypothetical long.
- `target_end_ns_hm`: exact desired future timestamp, including when data are absent.
- `signal_within_latency_limit`: whether close latency is within the configured screening limit, default 1000 ms. It does not alter the diagnostic label calculations or establish a fill.

No spreads, commissions, slippage, quote-side execution, queue model or position sizing are included. These values are **not executable strategy P&L**. Do not fill missing outcomes with zero or use data from a different activation to bridge a gap.
