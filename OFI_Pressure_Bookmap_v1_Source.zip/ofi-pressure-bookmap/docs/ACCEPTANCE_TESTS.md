# Bookmap / feed acceptance checklist

These tests are **not yet performed in a real Bookmap process**. Core unit-test success does not substitute for them.

## 1. Build and load

Run the build with the real official SDK. Confirm the JAR contains `com/ofipressure/...` classes and **no `velox/` classes**. Record the SDK version, add-on hash and Bookmap build. Load the JAR through API plugins configuration. Confirm it appears and does not produce exceptions. Enable only on an MBO-entitled test instrument.

## 2. Initial snapshot and quantities

Open the status panel. Verify that a full MBO snapshot is received and the status leaves `WAITING_FOR_SNAPSHOT`. Inspect raw order counts and compare reconstructed best quotes with Bookmap. Confirm `InstrumentInfo.pips` converts prices correctly. Confirm what the connection's raw size unit represents. Do not assume shares/contracts merely from the chart. Require at least the configured number of distinct visible prices on each side.

If no snapshot completion is provided, do not force-enable scoring. The adapter must be adjusted and tested for that provider/version. Do not replace MBO data with ordinary depth callbacks while leaving the same label.

## 3. One-minute timing and plotting

Use a recording with more than 65 consecutive valid minutes; 120 is preferable. Check UTC half-open [start,end) boundaries against Bookmap's chart timezone. Events exactly at 10:01 belong to the 10:01–10:02 minute, not 10:00–10:01. Measure `close_latency_ms` and reject excessive delays for your use case.

Compare each eligible bubble's Z with its CSV/XLSX row, allowing the deliberate one-decimal display rounding. Confirm price is the minute's last non-OTC trade, or labelled midpoint fallback. Confirm no connecting line is visible. Check visibility at typical zoom and display-scaling settings; bubble overlap at coarse zoom is expected, and collision avoidance is not implemented.

## 4. Determinism

Start replay from the **same beginning**, with identical configuration and a full snapshot, twice. Each activation has a different run ID; ignoring run identifiers and system-created folder timestamps, all market-derived feature values must match. Do not include both runs as independent observations in research.

Pause and resume replay; market-time calculations must not advance based on wall-clock time alone. Seek backward: expect reload-required, not continuation using future-trained baseline state. Disable/re-enable and provide a fresh snapshot.

## 5. Faults and feed semantics

Verify MBO replace sizes are absolute new sizes. Compare an execution's MBO size reduction and the separate trade diagnostic: it must change OFI only once. Do not assume MBO `cancel` means a true discretionary cancellation rather than an execution-related removal.

Test feed disconnect/reconnect, missing depth, absent MBO entitlement and a limited-depth recording. No valid pressure should emerge from partial initialization or a desynchronized order book. The generic API has no packet-sequence verification here; unexplained discrepancies need provider-specific investigation.

## 6. Export behaviour

Check one row per completed observed minute, correct run/date filenames and exact 19-digit timestamp strings. An initial partial bar is marked invalid; the uncompleted final minute on shutdown is not written as a complete minute.

Open the XLSX in Excel during replay. On a locking platform, confirm CSV continues, the panel shows the XLSX warning, and `.pending.xlsx` remains readable. Close Excel and verify the next completed minute refreshes the workbook. Test a read-only/full output location. Confirm errors are visible, not silently swallowed.

The writer has a bounded 4,096-record queue; stress-test replay speed and your disk. Shutdown allows up to ten seconds for draining. Check for warnings and final file row count before terminating Bookmap. Peak real-feed throughput, memory usage over multi-day sessions, rendering retention and fast-replay export performance have not been benchmarked here.

## 7. Research validity

Manually recompute several minute OFI vectors from an independently decoded MBO sample. Recompute event-average depth and the fixed weighted aggregate. Recompute each score using only preceding valid full minutes, not the minute itself. Inspect positive Z with negative raw flow to confirm sign semantics are understood.

Check future labels at session/day gaps: absent future minutes must produce blanks, never a positional shift to the next available row. Do not use midpoint forward returns as a trading fill model. Validate chronological out-of-sample predictability after all costs before assigning economic meaning to the pressure score.
