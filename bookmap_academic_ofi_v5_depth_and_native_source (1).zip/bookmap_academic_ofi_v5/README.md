# Academic OFI v5: separate the OFI input from MBO receipt counters

## Important correction to the earlier advice

The public Bookmap Python API does not document a native `onBbo` subscription.
Its `get_bbos(order_book)` helper reads a **locally maintained aggregated depth
book**. It does not read Bookmap's internal BBO directly. Some providers expose
MBO only to Python, even while the chart shows depth.

Accordingly this package contains TWO DISTINCT implementations. Use one, not both:

1. `academic_ofi.py`: a drop-in **aggregated-depth** Python patch. It eliminates
   individual-order MBO reconstruction. Requires actual Python depth callbacks.
2. `native-java/`: the **actual native-BBO implementation**, using the documented
   Java `BboListener.onBbo(bidPrice, bidSize, askPrice, askSize)` callback. This is
   source plus a local build script, **not a compiled or signed Bookmap JAR**.

Neither changes the Cont-Kukanov-Stoikov four-term equation. These are 60/180/300
second rolling lookbacks, not predictions. No training or order placement.

## Python drop-in installation

Disable the old indicator. Back up its script (do not delete its history).
Replace `C:\BookmapScripts\academic_ofi.py` with this package's `academic_ofi.py`.
Keep the same two-line loader in Bookmap's Python editor:

```python
import runpy
runpy.run_path(r"C:\BookmapScripts\academic_ofi.py", run_name="__main__")
```

Build/reload the script using the operation already working in your installation,
then enable it for the ES chart. The log must say `v5.0-bookmap-depth`.

OFI is calculated after each delivered depth update. The official Bookmap helpers
handle price levels with **absolute queue size**, not a volume delta. MBO callbacks
update counters only: unknown IDs, duplicate IDs, or crossing MBO orders cannot
modify the depth-derived OFI state.

The log distinguishes:

- `DEPTH CALLBACK RECEIVED`: aggregated input actually arrived.
- `OFI ACTIVE from BOOKMAP_DEPTH`: a baseline was established after the initial
  five-second depth-snapshot guard. That guard is a heuristic, not a snapshot-end
  detector. Partial windows are enabled by default, so numerical OFI can appear now.
- `OFI=WAIT_DEPTH`, `depth_total=0`, with increasing `MBO_total`: MBO is received,
  but the required depth stream is missing. **Five minutes of waiting will not fix
  this. Use the native Java route below; there is no fabricated MBO fallback.**
- `WAIT_VALID_DEPTH_BBO`: depth arrived but its two-sided state is currently invalid.
- `STOPPED_ERROR`: the log includes the exact processing/archive failure.

Every five seconds `OFI DIAG` reports both stream counts, age since the last local
callback, BBO, registered indicator count, and actual 1m/3m/5m values.
`MBO_REPORT_SECONDS` controls this log interval; `MBO_RATE_SAMPLE_SECONDS` controls
rate sampling. An ACK or capability flag is not proof of event delivery.

Diagnostic lines are off by default because their large event-rate scale can make
OFI look flat. They remain selectable through `Show diagnostic lines (may flatten
OFI scale)`. The log and counters continue while the diagnostic lines are hidden.
The cumulative line is also off by default. Turn on partial windows to show values
without a full 1/3/5-minute uninterrupted segment.

## History: Python

The exact same identity, filename, SQLite schema and archive directory are used:

`%USERPROFILE%\Bookmap_OFI_History`

No existing rows are deleted or rewritten. Cumulative and recent rolling values
are restored; new rows are tagged `SOURCE=BOOKMAP_DEPTH`. Source changes, invalid
states and recoveries are recorded as markers, with no invented OFI across a gap.
An invalid state clears only the *comparison baseline*, not recorded observations.
Old observations still leave their rolling lookbacks when they age, but remain
in the archive and cumulative total.

**Old erroneous values/estimated bridges are preserved, not repaired.** A source
change cannot reconstruct missed history. For up to five minutes the rolling
values may include older-source data; cumulative recorded OFI includes all sources.
This is why the source switch is explicitly marked. Old chart points are not
redrawn after recreating an indicator.

Both MBO and depth counters are local callback counts, include the initial
snapshot, and reset per activation. They do not independently verify live/replay
mode, Rithmic origin, exchange latency or completeness. Use the live Rithmic chart.
Times are local monotonic elapsed time anchored to UTC. Not for accelerated replay.

## Native Java: genuine BboListener input

See `native-java/README.md`. This route does not need Python depth callbacks,
`get_bbos()`, or any local order-book reconstruction. Native MBO listener callbacks
are counted independently. A native `SnapshotEndListener` marks initialization;
the first valid BBO establishes a baseline. No arbitrary five-minute wait.

The Java route requires a JDK and local Bookmap API JARs to build. These are not
included. Network access to Bookmap's API binary repository was unavailable during
this task, so no ready-to-load native JAR was built here. The provided builder uses
your installed API files and packages only our own classes, not Bookmap's libraries.

Bookmap's current guide says custom add-ons on paid live exchange data require
Bookmap verification/signing. It also restricts market-data export. This code is
not approved or signed; confirm whether your intended *derived-OFI* local logging
and any legacy stored quote data are allowed by your agreements before live use.
No signing, licence or data-export controls are bypassed.

## Verification actually performed

- 63 Python unit/integration-mock tests passed, including formula, rolling expiry,
  depth-only and MBO-only streams, absolute size updates, no double counting,
  invalid-state recovery, drawing callbacks, and archive preservation.
- Native Java core and append-only journal were compiled with a real JDK and
  exercised by the bundled `NativeCoreTests` (including randomized formula checks).
- An actual v4 SQLite archive was created, reopened by v5 unchanged, and appended.
- A copied derived-history journal was loaded by the real Java NativeHistory
  class, continued and reopened with the expected cumulative total.
- **The Bookmap-dependent Java adapter was not compiled against real Bookmap API
  binaries here and neither route was tested inside live Bookmap/Rithmic.**
- Bookmap Python helper behavior was mocked to the documented interface for local
  tests; tests do not prove your provider supplies depth or validate its event stream.

Files: `test_results_v5.txt`, `upgrade_results_v5.txt`, and
`native-java/test_results_native_core.txt` contain the executed results.

Run Python tests:

```text
python -m unittest -v test_retained_core test_depth_patch
```

## Persistence limitations

Writes are queued and periodically flushed. Orderly shutdown flushes; forced
termination, power loss, full disks or write failures can lose pending tail records.
No claim of lossless collection across a disconnect, hidden upstream gap, process
crash or archival error is made. Back up your history normally. A corrupted/truncated
archive is rejected, not silently wiped. Do not delete it as troubleshooting.

## Primary references checked

- Python API and helpers: https://github.com/BookmapAPI/python-api
- Native BBO: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/BboListener.html
- Snapshot end: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/SnapshotEndListener.html
- Native MBO callbacks: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/MarketByOrderDepthDataListener.html
- Current installation/signing guidance: https://bookmap.com/knowledgebase/docs/KB-Bookmap-Vibe-Coding-Starter-Guide
- CKS paper: https://arxiv.org/abs/1011.6402
