"""Academic L1 OFI -- v5.0-bookmap-depth.

IMPORTANT: the public Bookmap Python API has no direct native onBbo callback.
OFI uses Bookmap's AGGREGATED DEPTH callbacks with the documented helpers
create_order_book / on_depth / get_bbos. This is still a local price-level
book, NOT direct access to Bookmap's internal BBO. Individual MBO orders are
never reconstructed and MBO callbacks can never change the OFI baseline.

Some MBO providers do not deliver depth callbacks to Python. In that case
this version reports WAIT_DEPTH, retains history and does NOT fabricate OFI.
The bundled native Java source implements the actual BboListener route.

All existing SQLite rows and cumulative history are retained. New OFI rows
are tagged BOOKMAP_DEPTH. Legacy estimates are not erased or corrected by
changing source. Invalid depth states create marked gaps; the next valid
state starts a baseline, never a fabricated endpoint bridge.

60/180/300 seconds are trailing lookbacks, NOT forecasts. No training, orders
or network requests. Local receipt-time clock, not exchange-time; LIVE use
only, not accelerated replay. The five-second initial depth-snapshot guard
is a heuristic because snapshot completion is not exposed by the callback.

Disk writes use the same v4 append-only journal and bounded writer queue.
Forced termination or disk errors can lose uncommitted tail data. Archives
are never automatically deleted, including on closing Bookmap.

API: https://github.com/BookmapAPI/python-api
Formula: https://arxiv.org/abs/1011.6402
"""
import hashlib
import itertools
import json
import math
import os
import queue
import sqlite3
import threading
import time
import uuid
from array import array
from bisect import bisect_right
from pathlib import Path
from typing import Dict, Optional, Tuple

VERSION = "5.0-bookmap-depth"
WINDOWS_SECONDS = (60, 180, 300)
STARTUP_GUARD_SECONDS = 5.0
PLOT_EVERY_SECONDS = 0.25
SHOW_PARTIAL_WINDOWS_DEFAULT = True
SHOW_CUMULATIVE_DEFAULT = False  # Optional: cumulative scale can dwarf rolling OFI.
HISTORY_DIRECTORY = Path.home() / "Bookmap_OFI_History"
ARCHIVE_FLUSH_SECONDS = 1.0
ARCHIVE_BATCH_SIZE = 4096
ARCHIVE_QUEUE_LIMIT = 100000
PARTIAL_SETTING = "Show partial windows (startup or data gaps)"
CUMULATIVE_SETTING = "Show cumulative recorded OFI"
LEGACY_PARTIAL_SETTING = "Show partial windows during startup"
LEGACY_RESET_SETTING = "Reset OFI counter (increase to reset)"
CUMULATIVE_KEY = -1
STATUS_KEY = -2
MBO_RATE_KEY = -10
MBO_AGE_KEY = -11
DEPTH_RATE_KEY = -12
DEPTH_VALID_KEY = -13
MBO_PLOTS_SETTING = "Show diagnostic lines (may flatten OFI scale)"
LEGACY_MBO_PLOTS_SETTING = "Show MBO diagnostic lines"
MBO_LOG_SETTING = "OFI and MBO diagnostics in message log"
LEGACY_MBO_LOG_SETTING = "MBO diagnostics in message log (every 5s)"
MBO_REPORT_SECONDS = 5.0
MBO_RATE_SAMPLE_SECONDS = 1.0
MBO_NO_RECENT_SECONDS = 5.0  # A silence warning, NOT a disconnect detector.
MBO_EVENT_TYPES = ("BID_NEW", "ASK_NEW", "REPLACE", "CANCEL", "OTHER")
BBO = Tuple[int, int, int, int]


class _WireNaN(float):
    """Bookmap's Java-side numeric parser needs 'NaN', not Python's 'nan'."""
    def __new__(cls):
        return super().__new__(cls, "nan")

    def __str__(self):
        return "NaN"


NAN = _WireNaN()
bm = None


class ReceiptClock:
    """UTC-labelled, monotonic receipt clock for this Python process."""
    def __init__(self):
        self.utc_anchor = time.time()
        self.monotonic_anchor = time.monotonic()

    def now(self):
        return self.utc_anchor + time.monotonic() - self.monotonic_anchor


_clock = ReceiptClock()


def academic_ofi_event(previous: BBO, current: BBO) -> int:
    """Exact CKS event contribution, in integer Bookmap size units.

    The four conditions are INDEPENDENT. Equality activates both terms
    on that side, which gives the change in queue size at unchanged price.
    """
    old_bid, old_bid_size, old_ask, old_ask_size = previous
    bid, bid_size, ask, ask_size = current
    return (
        (bid_size if bid >= old_bid else 0)
        - (old_bid_size if bid <= old_bid else 0)
        - (ask_size if ask <= old_ask else 0)
        + (old_ask_size if ask >= old_ask else 0)
    )


class RollingOFI:
    """Exact trailing sums on (now - horizon, now], without time bucketing.

    Compact arrays store timestamps and cumulative integer OFI. Three rolling
    sums share one history. Non-BBO events and zero contributions use no history.
    This is only an expendable working cache. The separate append-only SQLite
    archive retains the complete recorded OFI history; cache trimming never
    deletes archived events or changes the recorded cumulative OFI.
    """

    COMPACT_THRESHOLD = 65536

    def __init__(self, windows=WINDOWS_SECONDS):
        if not windows or any(w <= 0 for w in windows):
            raise ValueError("OFI windows must be positive")
        self.windows = tuple(windows)
        self.timestamps = array("d")
        self.prefixes = array("q")
        self.total = 0
        self.base_total = 0
        self.head = 0
        self.last_time = -math.inf
        self._since_trim = 0

    def _check_time(self, now: float) -> None:
        if not math.isfinite(now) or now < self.last_time:
            raise ValueError("RollingOFI requires finite, nondecreasing timestamps")
        self.last_time = now

    def add(self, now: float, contribution: int) -> None:
        self._check_time(now)
        if not contribution:
            return
        self.total += contribution
        self.timestamps.append(now)
        self.prefixes.append(self.total)
        self._since_trim += 1
        if self._since_trim >= self.COMPACT_THRESHOLD:
            self._trim(now)
            self._since_trim = 0

    def values(self, now: float) -> Dict[int, int]:
        self._check_time(now)
        result = {}
        for horizon in self.windows:
            boundary = bisect_right(self.timestamps, now - horizon, lo=self.head)
            before = self.prefixes[boundary - 1] if boundary > self.head else self.base_total
            result[horizon] = self.total - before
        self._trim(now)
        return result

    def _trim(self, now: float) -> None:
        new_head = bisect_right(self.timestamps, now - max(self.windows), lo=self.head)
        if new_head > self.head:
            self.base_total = self.prefixes[new_head - 1]
            self.head = new_head
        if self.head >= self.COMPACT_THRESHOLD and self.head * 2 >= len(self.timestamps):
            del self.timestamps[:self.head]
            del self.prefixes[:self.head]
            self.head = 0



class ArchiveError(RuntimeError):
    """History cannot be safely appended; no automatic reset is allowed."""


class _FileLock:
    """One live writer per instrument archive, including across processes."""
    def __init__(self, path):
        self.file = open(str(path), "a+b")
        try:
            self.file.seek(0, os.SEEK_END)
            if self.file.tell() == 0:
                self.file.write(b"0")
                self.file.flush()
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, ImportError) as exc:
            self.file.close()
            raise ArchiveError(
                "Archive is already in use or could not be locked. "
                "Run only ONE copy of this indicator per instrument: %s" % path
            ) from exc

    def close(self):
        if not self.file.closed:
            self.file.close()  # OS releases the lock; do not delete the lock file.


class _Barrier:
    def __init__(self):
        self.done = threading.Event()


_STOP = object()


class SQLiteArchive:
    """Append-only event journal with a bounded, nonblocking writer queue.

    Reads/schema checks happen once at subscription. Only the writer thread
    performs subsequent database I/O. No DELETE, REPLACE, TRUNCATE or cleanup
    path exists for recorded history. Identity mismatches fail closed.
    """
    INSERT = """INSERT INTO records
        (received_at_utc, kind, ofi_raw, cumulative_raw,
         old_bid, old_bid_size, old_ask, old_ask_size,
         bid, bid_size, ask, ask_size, note)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""

    def __init__(self, path, identity, now):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = _FileLock(str(self.path) + ".lock")
        self.error = None
        self._closed = False
        self._queue = queue.Queue(maxsize=ARCHIVE_QUEUE_LIMIT)
        self._thread = None
        try:
            connection = sqlite3.connect(str(self.path), timeout=5)
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute("PRAGMA synchronous=FULL")
                connection.execute("""CREATE TABLE IF NOT EXISTS metadata
                    (key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
                connection.execute("""CREATE TABLE IF NOT EXISTS records (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT,
                    received_at_utc REAL NOT NULL,
                    kind TEXT NOT NULL,
                    ofi_raw INTEGER NOT NULL,
                    cumulative_raw INTEGER NOT NULL,
                    old_bid INTEGER, old_bid_size INTEGER,
                    old_ask INTEGER, old_ask_size INTEGER,
                    bid INTEGER, bid_size INTEGER, ask INTEGER, ask_size INTEGER,
                    note TEXT NOT NULL
                )""")
                connection.execute("CREATE INDEX IF NOT EXISTS records_time ON records(received_at_utc)")
                expected = json.dumps(identity, sort_keys=True, separators=(",", ":"))
                stored = connection.execute("SELECT value FROM metadata WHERE key='identity'").fetchone()
                if stored is None:
                    if connection.execute("SELECT 1 FROM records LIMIT 1").fetchone():
                        raise ArchiveError("Archive identity is missing; existing records were NOT changed.")
                    connection.execute("INSERT INTO metadata VALUES ('identity', ?)", (expected,))
                    connection.execute("INSERT INTO metadata VALUES ('schema', '2')")
                elif stored[0] != expected:
                    raise ArchiveError("Instrument metadata does not match the existing archive; nothing was reset.")
                schema = connection.execute("SELECT value FROM metadata WHERE key='schema'").fetchone()
                if schema != ('2',):
                    raise ArchiveError("Unsupported history schema; existing records were NOT changed.")
                connection.commit()
                last = connection.execute(
                    "SELECT received_at_utc, cumulative_raw FROM records ORDER BY seq DESC LIMIT 1"
                ).fetchone()
                self.last_at = last[0] if last else -math.inf
                self.restored_total = int(last[1]) if last else 0
                if self.last_at > now:
                    raise ArchiveError(
                        "Archive timestamp is ahead of this computer's clock. "
                        "Correct the clock before resuming; history was NOT reset."
                    )
                first = connection.execute(
                    "SELECT received_at_utc FROM records WHERE kind='BASELINE' ORDER BY seq LIMIT 1"
                ).fetchone()
                self.first_started = first[0] if first else None
                # Load only the working-window cache. All earlier rows stay on disk.
                self.recent = list(connection.execute(
                    "SELECT received_at_utc, ofi_raw FROM records "
                    "WHERE received_at_utc > ? AND kind='OFI' ORDER BY seq",
                    (now - max(WINDOWS_SECONDS),)
                ))
            finally:
                connection.close()
            self._thread = threading.Thread(target=self._writer,
                                            name="OFI-history-writer", daemon=True)
            self._thread.start()
        except Exception:
            self._lock.close()
            raise

    def submit(self, row):
        if self.error is not None:
            raise ArchiveError(self.error)
        if self._closed:
            raise ArchiveError("Archive is closed; no history was reset.")
        try:
            self._queue.put_nowait(row)
        except queue.Full as exc:
            raise ArchiveError(
                "History writer queue is full. Accumulation stopped; already queued/committed history is retained."
            ) from exc

    def _writer(self):
        connection = None
        try:
            connection = sqlite3.connect(str(self.path), timeout=5)
            connection.execute("PRAGMA synchronous=FULL")
            stopping = False
            while not stopping:
                item = self._queue.get()
                batch = []
                barrier = None
                deadline = time.monotonic() + ARCHIVE_FLUSH_SECONDS
                while True:
                    if item is _STOP:
                        stopping = True
                        break
                    if isinstance(item, _Barrier):
                        barrier = item
                        break
                    batch.append(item)
                    if len(batch) >= ARCHIVE_BATCH_SIZE:
                        break
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    try:
                        item = self._queue.get(timeout=remaining)
                    except queue.Empty:
                        break
                if batch:
                    with connection:
                        connection.executemany(self.INSERT, batch)
                if barrier is not None:
                    barrier.done.set()
        except Exception as exc:
            self.error = "History archive write failed: %s. Previously committed rows remain intact." % exc
        finally:
            if connection is not None:
                connection.close()

    def flush(self, timeout=10):
        if self._closed:
            if self.error:
                raise ArchiveError(self.error)
            return
        barrier = _Barrier()
        self.submit(barrier)
        deadline = time.monotonic() + timeout
        while not barrier.done.wait(0.05):
            if self.error:
                raise ArchiveError(self.error)
            if time.monotonic() >= deadline:
                raise ArchiveError("History flush timed out; do not delete the archive.")

    def close(self):
        if self._closed:
            return
        try:
            if self.error is None:
                self.flush()
        finally:
            self._closed = True
            if self._thread is not None and self._thread.is_alive():
                try:
                    self._queue.put(_STOP, timeout=10)
                except queue.Full:
                    self.error = self.error or "Could not stop history writer: queue remains full."
                self._thread.join(timeout=10)
            if self._thread is None or not self._thread.is_alive():
                self._lock.close()
            else:
                # Keep the file locked while the writer is still alive.
                raise ArchiveError("History writer is still busy; archive was not deleted.")


class OFIHistory:
    """Permanent archive + cumulative total, independent of the live book."""
    def __init__(self, archive):
        self.archive = archive
        self.rolling = RollingOFI()
        for timestamp, contribution in archive.recent:
            self.rolling.add(timestamp, contribution)
        self.total = archive.restored_total
        self.started_at = archive.first_started
        self.last_at = archive.last_at

    def _record(self, now, kind, contribution=0, before=None, after=None, note=""):
        if not math.isfinite(now) or now < self.last_at:
            raise ArchiveError("History requires nondecreasing receipt times; history was not reset.")
        total = self.total + contribution
        if not -(2 ** 63) <= total < 2 ** 63:
            raise ArchiveError("Cumulative OFI exceeds archive integer range; history was not reset.")
        if not -(2 ** 63) <= contribution < 2 ** 63:
            raise ArchiveError("OFI contribution exceeds archive integer range.")
        old = before or (None,) * 4
        new = after or (None,) * 4
        row = (now, kind, contribution, total) + tuple(old) + tuple(new) + (note,)
        self.archive.submit(row)  # Fail before changing the in-memory cumulative.
        self.total = total
        self.last_at = now
        if kind == "BASELINE" and self.started_at is None:
            self.started_at = now

    def note(self, now, kind, message="", bbo=None):
        self._record(now, kind, after=bbo, note=message)

    def add(self, now, previous, current, note=""):
        contribution = academic_ofi_event(previous, current)
        # Persist BBO changes even when the four terms net to zero.
        if current != previous:
            if now < self.rolling.last_time:
                raise ArchiveError("OFI event arrived behind the rolling clock.")
            self._record(now, "OFI", contribution, previous, current, note=note)
            self.rolling.add(now, contribution)


def _feature_flag(features, name):
    """Do not treat an absent flag or a string as a verified capability."""
    value = features.get(name) if isinstance(features, dict) else None
    return "YES" if value is True else ("NO" if value is False else "UNKNOWN")


class MBOStatistics:
    """O(1) callback counters, independent of book/OFI success.

    Counts reset per instrument activation, NOT per book invalidity. Periodic
    counter snapshots are appended to the existing permanent history archive.
    Rates are counts / measured sampling interval (normally about one second),
    not exchange event rates, not trade volume and not estimated market totals.
    """
    def __init__(self, now, features=None):
        self.session_id = uuid.uuid4().hex[:12]
        self.created_at = now
        self.mbo_supported = _feature_flag(features, "mbo")
        self.delayed_reported = _feature_flag(features, "isDelayed")
        self.request_id = None
        self.request_sent = False
        self.request_error = None
        self.ack_at = None
        self.ack_handler_available = False
        self.counts = dict.fromkeys(MBO_EVENT_TYPES, 0)
        self.total = 0
        self.payloads = 0
        self.bad_payloads = 0
        self.after_5s = 0
        self.updates_after_5s = 0
        self.first_at = None
        self.last_at = None
        self.last_payload_at = None
        self.last_event = None
        self.applied = 0
        self.processing_errors = 0
        self.invalid_applied = 0
        self.invalid_after_warmup = 0
        self.invalid_since = None
        self.last_reason = "EMPTY"
        self.bridges = 0
        self.ofi_bbo_changes = 0
        self.last_sample_at = now
        self.sampled_counts = dict(self.counts)
        self.sample_seconds = 0.0
        self.sample_count = 0
        self.rate = 0.0
        self.type_rates = dict.fromkeys(MBO_EVENT_TYPES, 0.0)
        self.last_report_at = now

    def record(self, now, event_type, order_id, price, size):
        category = event_type if isinstance(event_type, str) and event_type in self.counts else "OTHER"
        self.counts[category] += 1
        self.total += 1
        self.last_at = now
        if self.first_at is None:
            self.first_at = now
        if now - self.created_at >= STARTUP_GUARD_SECONDS:
            self.after_5s += 1
            if category in ("REPLACE", "CANCEL"):
                self.updates_after_5s += 1
        # CANCEL carries no useful price/size; validate its type and ID only.
        numeric_ok = (category == "CANCEL" or
                      (type(price) is int and type(size) is int and
                       size >= (1 if category in ("BID_NEW", "ASK_NEW") else 0)))
        good = (category != "OTHER" and isinstance(order_id, str) and
                bool(order_id) and numeric_ok)
        first_proof = good and self.payloads == 0
        if good:
            self.payloads += 1
            self.last_payload_at = now
        else:
            self.bad_payloads += 1
        # Keep one bounded raw sample, not an unbounded set of order IDs.
        self.last_event = dict(event_type=str(event_type)[:40],
                               order_id=str(order_id)[:96],
                               price_level=price if type(price) is int else str(price)[:40],
                               size_level=size if type(size) is int else str(size)[:40])
        return first_proof

    def sample(self, now, force=False):
        elapsed = now - self.last_sample_at
        if elapsed <= 0 or (not force and elapsed < MBO_RATE_SAMPLE_SECONDS):
            return False
        changes = {key: self.counts[key] - self.sampled_counts[key] for key in self.counts}
        self.sample_count = sum(changes.values())
        self.sample_seconds = elapsed
        self.rate = self.sample_count / elapsed
        self.type_rates = {key: count / elapsed for key, count in changes.items()}
        self.sampled_counts = dict(self.counts)
        self.last_sample_at = now
        return True

    def age(self, now):
        return None if self.last_at is None else max(0.0, now - self.last_at)

    def receipt_state(self, now):
        if self.total == 0:
            return "NO_CALLBACKS"
        if self.payloads == 0:
            return "NO_VALID_MBO_PAYLOAD"
        if now - self.last_payload_at > MBO_NO_RECENT_SECONDS:
            return "NO_RECENT_MBO_CALLBACKS"
        if now - self.created_at < STARTUP_GUARD_SECONDS:
            return "MBO_RECEIVED_STARTUP"
        return "RECENT_MBO_CALLBACKS"



def _identity(alias, full_name, pips, size_multiplier, instrument_multiplier):
    numbers = (float(pips), float(size_multiplier), float(instrument_multiplier))
    if any(not math.isfinite(x) or x <= 0 for x in numbers):
        raise ValueError("Instrument price/size multipliers must be finite and positive")
    return dict(alias=str(alias), full_name=str(full_name), pips=numbers[0],
                size_multiplier=numbers[1], instrument_multiplier=numbers[2])


def _get_history(alias, full_name, pips, size_multiplier, instrument_multiplier, now):
    identity = _identity(alias, full_name, pips, size_multiplier, instrument_multiplier)
    key = json.dumps(identity, sort_keys=True, separators=(",", ":"))
    if key not in _histories:
        readable = "".join(c if ord(c) < 128 and c.isalnum() else "_" for c in str(alias))[:48]
        digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]
        path = HISTORY_DIRECTORY / (readable + "_" + digest + ".sqlite3")
        _histories[key] = OFIHistory(SQLiteArchive(path, identity, now))
    return _histories[key]



class DepthInputError(ValueError):
    pass


class DepthBook:
    """Bookmap helper updated with absolute aggregated depth sizes, NOT MBO."""
    def __init__(self):
        self.book = bm.create_order_book()

    def apply(self, is_bid, price, size):
        if type(is_bid) is not bool or type(price) is not int or type(size) is not int or size < 0:
            raise DepthInputError("Depth requires bool side, integer price and nonnegative absolute size")
        bm.on_depth(self.book, is_bid, price, size)

    def top_state(self):
        bid, ask = bm.get_bbos(self.book)
        if bid is None and ask is None:
            reason = "EMPTY"
        elif bid is None:
            reason = "NO_BID"
        elif ask is None:
            reason = "NO_ASK"
        elif bid[1] <= 0 or ask[1] <= 0:
            reason = "NONPOSITIVE_SIZE"
        elif bid[0] == ask[0]:
            reason = "LOCKED"
        elif bid[0] > ask[0]:
            reason = "CROSSED"
        else:
            reason = "VALID"
        return reason, bid, ask

    def bbo(self):
        reason, bid, ask = self.top_state()
        return (bid[0], bid[1], ask[0], ask[1]) if reason == "VALID" else None


class InstrumentState:
    def __init__(self, size_multiplier, now, history, pips=1.0, supported_features=None):
        if not math.isfinite(size_multiplier) or size_multiplier <= 0:
            raise ValueError("size_multiplier must be finite and positive")
        self.size_multiplier = size_multiplier
        self.pips = pips
        self.history = history
        self.book = DepthBook()
        self.stats = MBOStatistics(now, supported_features)
        self.depth_supported = _feature_flag(supported_features, "depth")
        self.depth_total = 0
        self.depth_applied = 0
        self.depth_first_at = None
        self.depth_last_at = None
        self.depth_request_sent = False
        self.depth_request_error = None
        self.depth_ack = False
        self.depth_rate = 0.0
        self.depth_sample_at = now
        self.depth_sampled_total = 0
        self.depth_last_event = None
        self.ofi_changes = 0
        self.indicators = {}
        self.previous = None
        self.created_at = now
        self.first_interval_at = None
        self.warming_up = True
        self.gap_open = False
        self.clean_since = None
        self.last_plot = -math.inf
        self.last_gap_notice = -math.inf
        self.failed = None
        self.show_partial = SHOW_PARTIAL_WINDOWS_DEFAULT
        self.show_cumulative = SHOW_CUMULATIVE_DEFAULT
        self.show_mbo_plots = False
        self.show_mbo_log = True
        self.no_depth_reported = False
        self.history.note(now, "SOURCE_CHANGE", "v5 BOOKMAP_DEPTH helper input; MBO is diagnostics only. "
                          "All legacy rows/totals retained; source-switch interval not bridged.")

    def record_depth(self, now, is_bid, price, size):
        self.depth_total += 1
        self.depth_last_at = now
        if self.depth_first_at is None:
            self.depth_first_at = now
        self.depth_last_event = dict(side=str(is_bid), price=str(price), size=str(size))

    def sample_depth(self, now):
        elapsed = now - self.depth_sample_at
        if elapsed >= MBO_RATE_SAMPLE_SECONDS:
            self.depth_rate = (self.depth_total - self.depth_sampled_total) / elapsed
            self.depth_sample_at = now
            self.depth_sampled_total = self.depth_total

    def consume_depth(self, now, is_bid, price, size):
        if self.failed:
            return None
        self.book.apply(is_bid, price, size)
        self.depth_applied += 1
        if self.warming_up:
            return None
        reason, bid, ask = self.book.top_state()
        if reason != "VALID":
            if not self.gap_open:
                self.history.note(now, "GAP_START", "BOOKMAP_DEPTH BBO " + reason + "; history retained.")
                self.gap_open = True
                self.previous = None
                self.clean_since = None
            if now - self.last_gap_notice >= 10:
                self.last_gap_notice = now
                return "Depth-derived BBO=%s. History RETAINED; no synthetic gap OFI." % reason
            return None
        current = (bid[0], bid[1], ask[0], ask[1])
        if self.previous is None:
            self.history.note(now, "BASELINE", "BOOKMAP_DEPTH recovery; unknown gap flow NOT counted.", current)
            self.previous = current
            self.gap_open = False
            self.clean_since = now
            return "OFI ACTIVE from aggregated depth; valid baseline restored. History retained."
        self.history.add(now, self.previous, current, note="SOURCE=BOOKMAP_DEPTH")
        if current != self.previous:
            self.ofi_changes += 1
        self.previous = current
        return None

    def start_if_ready(self, now):
        if self.first_interval_at is None:
            self.first_interval_at = now
        if self.failed or not self.warming_up or self.depth_first_at is None:
            return False
        guard_start = max(self.depth_first_at, self.first_interval_at, self.created_at)
        current = self.book.bbo()
        if now - guard_start < STARTUP_GUARD_SECONDS or current is None:
            return False
        self.history.note(now, "BASELINE", "BOOKMAP_DEPTH initial snapshot guard completed (heuristic).", current)
        self.previous = current
        self.warming_up = False
        self.clean_since = now
        return True

    def complete(self, now, horizon):
        return (not self.failed and not self.warming_up and not self.gap_open and
                self.clean_since is not None and now - self.clean_since >= horizon)

    def displayed_values(self, now):
        if self.history.started_at is None:
            return {h: NAN for h in WINDOWS_SECONDS}
        values = self.history.rolling.values(now)
        return {h: (values[h] / self.size_multiplier
                    if self.show_partial or self.complete(now, h) else NAN) for h in WINDOWS_SECONDS}

    def mode(self):
        if self.failed:
            return "STOPPED_ERROR"
        if self.depth_total == 0:
            return "WAIT_DEPTH"
        if self.book.bbo() is None:
            return "WAIT_VALID_DEPTH_BBO"
        if self.warming_up:
            return "WARMUP_DEPTH_SNAPSHOT"
        return "ACTIVE"

    def status(self, now):
        if self.failed or self.gap_open:
            return -1.0
        return 1.0 if self.complete(now, max(WINDOWS_SECONDS)) else 0.0


_states = {}
_histories = {}
_pending_indicators = {}
_pending_data = {}
_ack_handler_available = False
_request_ids = itertools.count(1)


def _notice(addon, alias, message):
    text = "Academic OFI [%s]: %s" % (alias, message)
    print(text, flush=True)
    bm.send_user_message(addon, alias, text)


def _stop(addon, alias, state, now, error):
    if state.failed:
        return
    state.failed = str(error)
    state.previous = None
    state.clean_since = None
    try:
        state.history.note(now, "STOP", state.failed)
    except (ArchiveError, OSError, sqlite3.Error):
        pass
    _notice(addon, alias, "OFI STOPPED: %s. History retained. Receipt counters still run. "
            "Fix the error then re-enable; do NOT delete the archive." % error)


def _add_bool(addon, alias, name, default):
    # API distributions differ on the optional reload keyword.
    try:
        bm.add_boolean_settings_parameter(addon, alias, name, default, reload_if_change=False)
    except TypeError:
        bm.add_boolean_settings_parameter(addon, alias, name, default)


def handle_subscribe_instrument(addon, alias, full_name, is_crypto, pips,
                                size_multiplier, instrument_multiplier, supported_features=None):
    if alias in _states:
        handle_unsubscribe_instrument(addon, alias)
    now = _clock.now()
    try:
        history = _get_history(alias, full_name, pips, size_multiplier, instrument_multiplier, now)
        state = InstrumentState(float(size_multiplier), now, history, float(pips), supported_features)
    except (ArchiveError, ValueError, TypeError, OSError, sqlite3.Error) as exc:
        _notice(addon, alias, "Cannot start: %s. History was NOT deleted." % exc)
        return
    _states[alias] = state
    specifications = (
        (60, "Academic OFI - 1m", (0, 200, 255), "SOLID"),
        (180, "Academic OFI - 3m", (255, 180, 0), "SOLID"),
        (300, "Academic OFI - 5m", (215, 120, 255), "SOLID"),
        (0, "Academic OFI - Zero", (140, 140, 140), "SHORT_DASH"),
        (CUMULATIVE_KEY, "Academic OFI - Cumulative (all recorded sources)", (70, 200, 140), "SOLID"),
        (STATUS_KEY, "Academic OFI - Data status", (210, 210, 210), "SOLID"),
        (MBO_RATE_KEY, "MBO - Received events per second", (100, 200, 180), "SOLID"),
        (MBO_AGE_KEY, "MBO - Last callback age (seconds)", (230, 210, 90), "SOLID"),
        (DEPTH_RATE_KEY, "Depth - Received events per second", (130, 170, 250), "SOLID"),
        (DEPTH_VALID_KEY, "Depth - BBO valid (1 yes, 0 no)", (170, 170, 230), "SOLID"),
    )
    for key, name, color, style in specifications:
        req = next(_request_ids)
        _pending_indicators[req] = (alias, state, key)
        bm.register_indicator(addon, alias, req, name, "BOTTOM", color=color,
                              line_style=style, initial_value=NAN)
    for name, default in ((PARTIAL_SETTING, True), (CUMULATIVE_SETTING, False),
                           (MBO_PLOTS_SETTING, False), (MBO_LOG_SETTING, True)):
        _add_bool(addon, alias, name, default)
    bm.add_label_to_settings(addon, alias, "v5: OFI source = aggregated DEPTH, not raw MBO. "
        "MBO callbacks only counted. WAIT_DEPTH means no OFI input. History never deleted. "
        "Use native Java BboListener if this connection supplies MBO only to Python.")
    _notice(addon, alias, "v%s; SOURCE=BOOKMAP_DEPTH; MBO=DIAGNOSTICS_ONLY; history=%s; "
            "legacy cumulative=%g retained. Native BBO is NOT exposed directly by Python. "
            "Depth supported=%s, MBO supported=%s (flags do not prove delivery)." %
            (VERSION, history.archive.path, history.total / state.size_multiplier,
             state.depth_supported, state.stats.mbo_supported))
    state.stats.ack_handler_available = _ack_handler_available
    # Separate subscriptions: failure of optional MBO must not stop usable depth OFI.
    for kind, method in (("DEPTH", "subscribe_to_depth"), ("MBO", "subscribe_to_mbo")):
        if kind == "MBO" and state.stats.mbo_supported == "NO":
            continue
        req = next(_request_ids)
        _pending_data[req] = (alias, state, kind)
        if kind == "MBO":
            state.stats.request_id = req
        try:
            getattr(bm, method)(addon, alias, req)
            if kind == "DEPTH":
                state.depth_request_sent = True
            else:
                state.stats.request_sent = True
        except Exception as exc:
            _pending_data.pop(req, None)
            if kind == "DEPTH":
                state.depth_request_error = str(exc)
            else:
                state.stats.request_error = str(exc)
            _notice(addon, alias, "%s subscription failed: %s. History retained." % (kind, exc))


def handle_unsubscribe_instrument(addon, alias):
    state = _states.pop(alias, None)
    if state is not None:
        _emit_diagnostics(addon, alias, state, _clock.now(), force=True)
        try:
            state.history.note(_clock.now(), "UNSUBSCRIBE", "Disabled; all recorded history retained.")
        except (ArchiveError, OSError, sqlite3.Error) as exc:
            print("OFI archive warning: %s" % exc, flush=True)
    for pending in (_pending_data, _pending_indicators):
        for req, record in list(pending.items()):
            if record[0] == alias and record[1] is state:
                del pending[req]


def handle_indicator_response(addon, request_id, indicator_id):
    record = _pending_indicators.pop(request_id, None)
    if record is not None:
        alias, state, key = record
        if _states.get(alias) is state:
            state.indicators[key] = indicator_id
            if key == 60:
                _notice(addon, alias, "1m OFI line REGISTERED (id=%s). Numerical values require DEPTH input." % indicator_id)


def handle_mbo_event(addon, alias, event_type, order_id, price_level, size_level):
    state = _states.get(alias)
    if state is None:
        return
    # Deliberately no book.apply(), no size aggregation and no OFI update here.
    first = state.stats.record(_clock.now(), event_type, order_id, price_level, size_level)
    if first:
        _notice(addon, alias, "MBO CALLBACK RECEIVED; per-order payload received. "
                "Counters only; not OFI input. Snapshot/replay are not independently excluded.")


def handle_depth_event(addon, alias, is_bid, price_level, size_level):
    state = _states.get(alias)
    if state is None:
        return
    now = _clock.now()
    state.record_depth(now, is_bid, price_level, size_level)
    if state.depth_total == 1:
        _notice(addon, alias, "DEPTH CALLBACK RECEIVED; aggregated OFI input detected. "
                "Building price-level snapshot (5-second heuristic guard).")
    if state.failed:
        return
    try:
        if state.history.archive.error:
            raise ArchiveError(state.history.archive.error)
        message = state.consume_depth(now, is_bid, price_level, size_level)
        if message:
            _notice(addon, alias, message)
    except (ArchiveError, DepthInputError, ValueError, TypeError, OverflowError) as exc:
        _stop(addon, alias, state, now, exc)


def handle_data_response(addon, request_id):
    record = _pending_data.pop(request_id, None)
    if record is None:
        return
    alias, state, kind = record
    if _states.get(alias) is not state:
        return
    if kind == "DEPTH":
        state.depth_ack = True
    else:
        state.stats.ack_at = _clock.now()
    _notice(addon, alias, "%s subscription ACK; this does not prove callback delivery or snapshot completion." % kind)


def _register_data_response_handler(addon):
    for name in ("add_response_data_handler", "on_response_data_handler"):
        register = getattr(bm, name, None)
        if callable(register):
            register(addon, handle_data_response)
            return True
    return False


def _diagnostic_snapshot(alias, state, now):
    stats = state.stats
    reason, bid, ask = state.book.top_state()
    def quote(x):
        return None if x is None else {"price": x[0] * state.pips,
                                      "size": x[1] / state.size_multiplier}
    # Read rolling values here, then plot at the same or later receipt time.
    values = state.displayed_values(now)
    finite_values = {str(k): (v if math.isfinite(v) else None) for k, v in values.items()}
    return dict(version=VERSION, alias=str(alias), session_id=stats.session_id,
                source="BOOKMAP_DEPTH", native_bbo=False, mbo_role="COUNTERS_ONLY",
                ofi_mode=state.mode(), ofi_error=state.failed,
                mbo_supported=stats.mbo_supported, depth_supported=state.depth_supported,
                mbo_received=stats.payloads > 0, mbo_total=stats.total, mbo_rate=stats.rate,
                mbo_counts=dict(stats.counts), mbo_bad_payloads=stats.bad_payloads,
                mbo_last_age=stats.age(now), depth_total=state.depth_total,
                depth_applied=state.depth_applied, depth_rate=state.depth_rate,
                depth_last_age=(None if state.depth_last_at is None else now - state.depth_last_at),
                depth_ack=state.depth_ack, mbo_ack=stats.ack_at is not None,
                depth_request_error=state.depth_request_error, mbo_request_error=stats.request_error,
                depth_bbo=reason, bid=quote(bid), ask=quote(ask),
                spread_ticks=(ask[0] - bid[0] if bid is not None and ask is not None else None),
                ofi_changes=state.ofi_changes, ofi_values=finite_values,
                registered_indicators=len(state.indicators),
                cumulative_recorded=state.history.total / state.size_multiplier,
                delayed_reported=stats.delayed_reported, live_source="UNVERIFIED",
                archive_path=str(state.history.archive.path), archive_error=state.history.archive.error)


def _diagnostic_message(d):
    def age(x):
        return "NEVER" if x is None else "%.3fs" % x
    def quote(x):
        return "NONE" if x is None else "%g x %g" % (x["price"], x["size"])
    counts = d["mbo_counts"]
    return ("OFI DIAG source=BOOKMAP_DEPTH; OFI=%s; depth_total=%d depth/s=%.1f depth_age=%s; "
            "depth_BBO=%s bid=%s ask=%s spread_ticks=%s; MBO_received=%s MBO_total=%d "
            "MBO/s=%.1f MBO_age=%s BID_NEW=%d ASK_NEW=%d REPLACE=%d CANCEL=%d OTHER=%d; "
            "OFI_changes=%d values=%s indicators=%d; live_source=UNVERIFIED%s%s" %
            (d["ofi_mode"], d["depth_total"], d["depth_rate"], age(d["depth_last_age"]),
             d["depth_bbo"], quote(d["bid"]), quote(d["ask"]), d["spread_ticks"],
             "YES" if d["mbo_received"] else "NO", d["mbo_total"], d["mbo_rate"], age(d["mbo_last_age"]),
             counts["BID_NEW"], counts["ASK_NEW"], counts["REPLACE"], counts["CANCEL"], counts["OTHER"],
             d["ofi_changes"], d["ofi_values"], d["registered_indicators"],
             "; error=" + d["ofi_error"] if d["ofi_error"] else "",
             "; depth_request_error=" + d["depth_request_error"] if d["depth_request_error"] else ""))


def _emit_diagnostics(addon, alias, state, now, force=False):
    if not force and now - state.stats.last_report_at < MBO_REPORT_SECONDS:
        return
    state.stats.last_report_at = now
    state.stats.sample(now, force=force)
    state.sample_depth(now)
    snapshot = _diagnostic_snapshot(alias, state, now)
    if state.show_mbo_log:
        _notice(addon, alias, _diagnostic_message(snapshot))
    if not state.history.archive.error:
        try:
            state.history.note(now, "OFI_DEPTH_DIAGNOSTIC", json.dumps(snapshot, sort_keys=True, allow_nan=False))
        except (ArchiveError, ValueError, TypeError, OSError, sqlite3.Error) as exc:
            _stop(addon, alias, state, now, exc)


def on_interval(addon, alias):
    state = _states.get(alias)
    if state is None:
        return
    now = _clock.now()
    state.stats.sample(now)
    state.sample_depth(now)
    try:
        if state.history.archive.error:
            raise ArchiveError(state.history.archive.error)
        if state.start_if_ready(now):
            _notice(addon, alias, "OFI ACTIVE from BOOKMAP_DEPTH. 1m/3m/5m values now available "
                    "with partial windows enabled; history retained.")
    except (ArchiveError, ValueError, TypeError) as exc:
        _stop(addon, alias, state, now, exc)
    _emit_diagnostics(addon, alias, state, now)
    if state.depth_total == 0 and not state.no_depth_reported and now - state.created_at >= 15:
        state.no_depth_reported = True
        _notice(addon, alias, "WAIT_DEPTH: no aggregated depth callbacks. MBO callbacks=%d. "
                "Waiting five minutes will NOT solve missing depth. This provider/API may expose "
                "MBO only. Use the native Java BboListener route; history retained." % state.stats.total)
    if now - state.last_plot < PLOT_EVERY_SECONDS:
        return
    state.last_plot = now
    values = state.displayed_values(now)
    values[0] = 0.0
    values[CUMULATIVE_KEY] = state.history.total / state.size_multiplier if state.show_cumulative else NAN
    # Diagnostic scales are hidden by default so event rates do not obscure OFI.
    values[STATUS_KEY] = state.status(now) if state.show_mbo_plots else NAN
    values[MBO_RATE_KEY] = state.stats.rate if state.show_mbo_plots else NAN
    age = state.stats.age(now)
    values[MBO_AGE_KEY] = age if state.show_mbo_plots and age is not None else NAN
    values[DEPTH_RATE_KEY] = state.depth_rate if state.show_mbo_plots else NAN
    values[DEPTH_VALID_KEY] = float(state.book.bbo() is not None and not state.failed) if state.show_mbo_plots else NAN
    for key, indicator_id in state.indicators.items():
        bm.add_point(addon, alias, indicator_id, values[key])


def on_settings_change(addon, alias, setting_name, field_type, new_value):
    state = _states.get(alias)
    if state is None:
        return
    flag = new_value.lower() == "true" if isinstance(new_value, str) else bool(new_value)
    if setting_name in (PARTIAL_SETTING, LEGACY_PARTIAL_SETTING):
        state.show_partial = flag
    elif setting_name == CUMULATIVE_SETTING:
        state.show_cumulative = flag
    elif setting_name == MBO_PLOTS_SETTING:
        state.show_mbo_plots = flag
    elif setting_name in (MBO_LOG_SETTING, LEGACY_MBO_LOG_SETTING):
        state.show_mbo_log = flag
    elif setting_name == LEGACY_RESET_SETTING:
        _notice(addon, alias, "History reset DISABLED. No rows deleted.")
    # Old diagnostic-plot setting intentionally ignored to default to visible OFI.


def _register_settings_handler(addon):
    for name in ("add_on_settings_change_handler", "add_on_setting_change_handler"):
        register = getattr(bm, name, None)
        if callable(register):
            register(addon, on_settings_change)
            return
    raise RuntimeError("Bookmap API has no settings-change handler")


def _close_histories():
    for history in _histories.values():
        try:
            history.archive.close()
        except (ArchiveError, OSError, sqlite3.Error) as exc:
            print("Academic OFI: archive close warning: %s" % exc, flush=True)


def main():
    global bm, _ack_handler_available
    try:
        import bookmap as bm
    except ImportError as exc:
        raise SystemExit("Run in Bookmap Python API using the two-line loader.") from exc
    required = ("add_depth_handler", "subscribe_to_depth", "create_order_book", "on_depth", "get_bbos",
                "add_mbo_handler", "subscribe_to_mbo")
    missing = [name for name in required if not callable(getattr(bm, name, None))]
    if missing:
        raise SystemExit("Bookmap Python API is missing required methods: " + ", ".join(missing))
    addon = bm.create_addon()
    bm.add_depth_handler(addon, handle_depth_event)
    bm.add_mbo_handler(addon, handle_mbo_event)
    _ack_handler_available = _register_data_response_handler(addon)
    bm.add_on_interval_handler(addon, on_interval)
    bm.add_indicator_response_handler(addon, handle_indicator_response)
    _register_settings_handler(addon)
    try:
        bm.start_addon(addon, handle_subscribe_instrument, handle_unsubscribe_instrument)
        bm.wait_until_addon_is_turned_off(addon)
    finally:
        _close_histories()


if __name__ == "__main__":
    main()
