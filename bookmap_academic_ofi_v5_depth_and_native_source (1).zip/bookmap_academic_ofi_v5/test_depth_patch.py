"""Synthetic callbacks only. No live Bookmap/Rithmic connection in these tests."""
import ast
import contextlib
import importlib.util
import io
import json
import math
import random
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import academic_ofi as ofi
from test_retained_core import MemoryArchive

class FakeAPI:
    """Model only the documented absolute-depth/helper interface, not Bookmap internals."""
    def __init__(self):
        self.notices=[]; self.points=[]; self.registered=[]; self.subscriptions=[]
        self.fail_mbo=False; self.fail_depth=False
    def create_order_book(self):
        return {True: {}, False: {}}
    def on_depth(self, book, side, price, size):
        if size: book[side][price]=size
        else: book[side].pop(price, None)
    def get_bbos(self, book):
        bid=max(book[True]) if book[True] else None
        ask=min(book[False]) if book[False] else None
        return ((bid,book[True][bid]) if bid is not None else None,
                (ask,book[False][ask]) if ask is not None else None)
    def register_indicator(self, addon, alias, req, name, graph, **kw):
        self.registered.append((alias,req,name,graph))
    def add_boolean_settings_parameter(self, addon, alias, name, default):
        pass
    def add_label_to_settings(self, *args): pass
    def subscribe_to_depth(self, addon, alias, req):
        if self.fail_depth: raise RuntimeError('test depth subscribe failure')
        self.subscriptions.append(('DEPTH',alias,req))
    def subscribe_to_mbo(self, addon, alias, req):
        if self.fail_mbo: raise RuntimeError('test mbo subscribe failure')
        self.subscriptions.append(('MBO',alias,req))
    def send_user_message(self, addon, alias, text): self.notices.append(text)
    def add_point(self, addon, alias, key, value): self.points.append((alias,key,value))

class DepthTests(unittest.TestCase):
    def setUp(self):
        self.api=FakeAPI(); self.p=patch.object(ofi,'bm',self.api); self.p.start()
        self.h=ofi.OFIHistory(MemoryArchive())
        self.s=ofi.InstrumentState(1.0,0,self.h,.25,{'mbo':True,'depth':True})
        ofi._states.clear(); ofi._states['ES']=self.s
        self.output=contextlib.redirect_stdout(io.StringIO()); self.output.__enter__()
    def tearDown(self):
        self.output.__exit__(None,None,None); ofi._states.clear(); self.p.stop()
    def depth(self,t,side,p,q):
        self.s.record_depth(t,side,p,q)
        self.s.consume_depth(t,side,p,q)
    def activate(self):
        self.s.start_if_ready(0)
        self.depth(.1,True,100,10); self.depth(.2,False,102,12)
        self.assertTrue(self.s.start_if_ready(6))
    def test_depth_only_starts_without_any_mbo(self):
        self.activate(); self.assertEqual(self.s.stats.total,0); self.assertEqual(self.s.mode(),'ACTIVE')
    def test_mbo_only_never_starts_ofi(self):
        for t in range(1,20):
            with patch.object(ofi._clock,'now',return_value=t):
                ofi.handle_mbo_event(None,'ES','BID_NEW','id'+str(t),100,5)
        self.assertFalse(self.s.start_if_ready(30)); self.assertEqual(self.s.mode(),'WAIT_DEPTH')
        self.assertEqual(self.s.stats.total,19); self.assertTrue(math.isnan(self.s.displayed_values(30)[60]))
    def test_absolute_size_not_delta(self):
        self.activate(); self.depth(7,True,100,15)
        self.assertEqual(self.s.book.bbo(),(100,15,102,12)); self.assertEqual(self.h.total,5)
    def test_repeated_depth_is_zero_flow(self):
        self.activate(); self.depth(7,True,100,10); self.assertEqual(self.h.total,0)
    def test_bid_depletion_promotes_next_price(self):
        self.activate(); self.depth(7,True,99,100); self.depth(8,True,100,0)
        self.assertEqual(self.h.total,-10); self.assertEqual(self.s.book.bbo()[0],99)
    def test_ask_depletion_promotes_next_price(self):
        self.activate(); self.depth(7,False,103,100); self.depth(8,False,102,0)
        self.assertEqual(self.h.total,12)
    def test_deep_updates_no_ofi(self):
        self.activate(); self.depth(7,True,90,10000); self.assertEqual(self.h.total,0)
    def test_mbo_unknown_cancel_cannot_stop_depth_ofi(self):
        self.activate()
        with patch.object(ofi._clock,'now',return_value=7):
            ofi.handle_mbo_event(None,'ES','CANCEL','never_seen',0,0)
        self.depth(8,True,100,15)
        self.assertIsNone(self.s.failed); self.assertEqual(self.h.total,5)
    def test_crossing_mbo_orders_cannot_change_depth_book(self):
        self.activate(); before=self.s.book.bbo()
        with patch.object(ofi._clock,'now',return_value=7):
            ofi.handle_mbo_event(None,'ES','ASK_NEW','locked',100,900)
            ofi.handle_mbo_event(None,'ES','BID_NEW','cross',999,999)
        self.assertEqual(self.s.book.bbo(),before); self.assertEqual(self.h.total,0)
    def test_no_double_count_when_both_streams_update(self):
        self.activate(); self.depth(7,True,100,15)
        with patch.object(ofi._clock,'now',return_value=7):
            ofi.handle_mbo_event(None,'ES','BID_NEW','x',100,5)
        self.assertEqual(self.h.total,5)
    def test_lock_retains_archive_and_recovers_without_bridge(self):
        self.activate(); self.depth(7,True,100,15)
        original=list(self.h.archive.rows)
        self.depth(8,False,100,20)
        self.assertEqual(self.h.total,5); self.assertEqual(self.s.mode(),'WAIT_VALID_DEPTH_BBO')
        self.assertEqual(self.h.archive.rows[:len(original)],original)
        self.depth(9,False,100,0)
        self.assertEqual(self.h.total,5)
        self.depth(10,False,102,10); self.assertEqual(self.h.total,7)
        self.assertFalse(any('ESTIMATED_BRIDGE' in row[1] for row in self.h.archive.rows))
    def test_empty_side_keeps_prior_history(self):
        self.activate(); self.depth(7,True,100,15); self.depth(8,True,100,0)
        self.assertEqual(self.h.total,5); self.assertTrue(self.s.gap_open)
    def test_startup_snapshot_is_not_counted(self):
        self.depth(0,True,100,100); self.depth(1,True,100,500); self.depth(2,False,102,999)
        self.s.start_if_ready(2); self.assertTrue(self.s.start_if_ready(8)); self.assertEqual(self.h.total,0)
    def test_both_sides_required(self):
        self.depth(0,True,100,10); self.s.start_if_ready(0)
        self.assertFalse(self.s.start_if_ready(999)); self.assertEqual(self.s.mode(),'WAIT_VALID_DEPTH_BBO')
    def test_partial_values_draw_immediately_after_guard(self):
        self.activate(); self.depth(7,True,100,15)
        self.assertEqual(self.s.displayed_values(7),{60:5,180:5,300:5})
    def test_full_window_setting(self):
        self.activate(); self.s.show_partial=False; self.depth(7,True,100,15)
        self.assertTrue(math.isnan(self.s.displayed_values(8)[60]))
        self.assertEqual(self.s.displayed_values(66)[60],5)
        self.assertTrue(math.isnan(self.s.displayed_values(66)[180]))
    def test_diagnostics_default_hidden(self): self.assertFalse(self.s.show_mbo_plots)
    def test_data_status_fills_no_exchange_completeness_claim(self):
        self.activate(); self.assertEqual(self.s.status(65),0); self.assertEqual(self.s.status(306),1)
    def test_divide_by_size_multiplier(self):
        self.s.size_multiplier=10; self.activate(); self.depth(7,True,100,15)
        self.assertEqual(self.s.displayed_values(7)[60],.5)
    def test_legacy_reset_setting_does_nothing(self):
        self.activate(); self.depth(7,True,100,15)
        ofi.on_settings_change(None,'ES',ofi.LEGACY_RESET_SETTING,'NUMBER','1')
        self.assertEqual(self.h.total,5)
    def test_reactivation_retains_total_and_history(self):
        self.activate(); self.depth(7,True,100,15); before=list(self.h.archive.rows)
        other=ofi.InstrumentState(1,8,self.h,.25)
        self.assertEqual(other.history.total,5); self.assertEqual(self.h.archive.rows[:len(before)],before)
    def test_rate_measures_receipts_independent_of_archive_error(self):
        self.h.archive.error='disk test'
        with patch.object(ofi._clock,'now',return_value=1):
            ofi.handle_depth_event(None,'ES',True,100,10)
            ofi.handle_mbo_event(None,'ES','CANCEL','x',0,0)
        self.assertEqual(self.s.depth_total,1); self.assertEqual(self.s.stats.total,1)
        self.assertIsNotNone(self.s.failed)
    def test_malformed_mbo_is_counted_not_used_for_ofi(self):
        with patch.object(ofi._clock,'now',return_value=1):
            ofi.handle_mbo_event(None,'ES','UNRECOGNIZED',None,None,None)
        self.assertEqual(self.s.stats.bad_payloads,1); self.assertIsNone(self.s.failed)
    def test_depth_bad_type_stops_but_does_not_reset(self):
        with patch.object(ofi._clock,'now',return_value=1):
            ofi.handle_depth_event(None,'ES','True',100,10)
        self.assertIsNotNone(self.s.failed); self.assertEqual(self.h.total,0)
    def test_no_depth_message_is_not_wait_five_minutes(self):
        with patch.object(ofi._clock,'now',return_value=16): ofi.on_interval(None,'ES')
        self.assertTrue(any('WAIT_DEPTH' in x and 'five minutes will NOT' in x for x in self.api.notices))
    def test_diagnostic_contains_actual_values(self):
        self.activate(); self.depth(7,True,100,15)
        d=ofi._diagnostic_snapshot('ES',self.s,7)
        self.assertEqual(d['ofi_values']['60'],5); self.assertFalse(d['native_bbo'])
        self.assertEqual(d['mbo_role'],'COUNTERS_ONLY'); json.dumps(d,allow_nan=False)
    def test_plot_callback_receives_numeric_value(self):
        self.activate(); self.depth(7,True,100,15); self.s.indicators[60]=123
        with patch.object(ofi._clock,'now',return_value=8): ofi.on_interval(None,'ES')
        self.assertIn(('ES',123,5),self.api.points)
    def test_no_mbo_book_class_or_estimated_bridge_runtime(self):
        self.assertFalse(hasattr(ofi,'MBOBook'))
        text=Path(ofi.__file__).read_text()
        handler=text[text.index('def handle_mbo_event'):text.index('def handle_depth_event')]
        self.assertNotIn('consume_depth(',handler); self.assertNotIn('history.add(',handler)

class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory(); self.api=FakeAPI()
        self.p1=patch.object(ofi,'bm',self.api); self.p1.start()
        self.p2=patch.object(ofi,'HISTORY_DIRECTORY',Path(self.t.name)); self.p2.start()
        ofi._states.clear(); ofi._histories.clear(); ofi._pending_indicators.clear(); ofi._pending_data.clear()
        self.output=contextlib.redirect_stdout(io.StringIO()); self.output.__enter__()
    def tearDown(self):
        ofi._close_histories(); ofi._states.clear(); ofi._histories.clear()
        self.output.__exit__(None,None,None); self.p1.stop(); self.p2.stop(); self.t.cleanup()
    def subscribe(self,features=None):
        with patch.object(ofi._clock,'now',return_value=1000):
            ofi.handle_subscribe_instrument(None,'ES','ES TEST',False,.25,1,50,features or {'mbo':True})
        return ofi._states['ES']
    def test_both_subscribed(self):
        self.subscribe(); self.assertEqual([x[0] for x in self.api.subscriptions],['DEPTH','MBO'])
    def test_mbo_failure_does_not_stop_depth(self):
        self.api.fail_mbo=True; s=self.subscribe()
        self.assertIsNone(s.failed); self.assertTrue(s.depth_request_sent); self.assertTrue(s.stats.request_error)
    def test_depth_failure_is_reported(self):
        self.api.fail_depth=True; s=self.subscribe(); self.assertTrue(s.depth_request_error)
        self.assertEqual(s.mode(),'WAIT_DEPTH')
    def test_explicit_no_mbo_does_not_stop_depth(self):
        s=self.subscribe({'mbo':False}); self.assertEqual(len(self.api.subscriptions),1)
        self.assertIsNone(s.failed)
    def test_indicator_registration(self):
        s=self.subscribe(); self.assertEqual(len(self.api.registered),10)
        for i,(_,req,_,_) in enumerate(self.api.registered): ofi.handle_indicator_response(None,req,i)
        self.assertEqual(len(s.indicators),10)
    def test_separate_acknowledgements(self):
        s=self.subscribe()
        for _,_,req in self.api.subscriptions: ofi.handle_data_response(None,req)
        self.assertTrue(s.depth_ack); self.assertIsNotNone(s.stats.ack_at)
    def test_identity_filename_unchanged_from_v4_algorithm(self):
        s=self.subscribe(); ident=ofi._identity('ES','ES TEST',.25,1,50)
        import hashlib
        digest=hashlib.sha256(json.dumps(ident,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:16]
        self.assertEqual(s.history.archive.path.name,'ES_'+digest+'.sqlite3')

if __name__=='__main__': unittest.main(verbosity=2)
