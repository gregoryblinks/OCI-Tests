"""Build against YOUR installed Bookmap API jars. No network downloads or bundled fake API."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bookmap-dir', required=True, type=Path,
                        help='Actual Bookmap installation folder containing its API jars')
    parser.add_argument('--javac', type=Path, help='Full path to a JDK 11+ javac executable')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    if not args.bookmap_dir.is_dir():
        parser.error('Bookmap directory does not exist: '+str(args.bookmap_dir))
    candidates=[args.javac] if args.javac else []
    if os.environ.get('JAVA_HOME'):
        candidates.append(Path(os.environ['JAVA_HOME'])/'bin'/('javac.exe' if os.name=='nt' else 'javac'))
    system=shutil.which('javac')
    if system: candidates.append(Path(system))
    candidates += list(args.bookmap_dir.glob('**/bin/javac.exe')) if os.name=='nt' else []
    javac=next((p for p in candidates if p and p.is_file()),None)
    if javac is None:
        parser.error('A Java DEVELOPMENT KIT is required (a Java runtime is not enough). '
                     'Install a JDK 17 or 21, then pass --javac ".../bin/javac.exe". No file was changed in Bookmap.')
    required={
        'velox/api/layer1/simplified/Api.class',
        'velox/api/layer1/simplified/SnapshotEndListener.class',
        'velox/api/layer1/simplified/BboListener.class',
        'velox/api/layer1/annotations/Layer1SimpleAttachable.class',
        'velox/api/layer1/annotations/Layer1ApiVersion.class',
        'velox/api/layer1/data/InstrumentInfo.class',
    }
    jars=sorted(args.bookmap_dir.resolve().rglob('*.jar'))
    found=set()
    for jar in jars:
        try:
            with zipfile.ZipFile(jar) as z: found.update(required.intersection(z.namelist()))
        except (OSError,zipfile.BadZipFile): pass
    missing=required-found
    if missing:
        parser.error('Could not locate required API classes in this installation: '+', '.join(sorted(missing))+
                     '. Point --bookmap-dir at the installation/API library folder, not your scripts folder.')
    build=root/'build'; classes=build/'classes'; classes.mkdir(parents=True,exist_ok=True)
    # Only our own source is compiled/packaged. Bookmap API jars are compile-time dependencies only.
    sources=sorted((root/'src').rglob('*.java'))
    def quoted(value):
        return '"'+str(value).replace('\\','/').replace('"','\\"')+'"'
    arguments=['--release','8','-encoding','UTF-8','-classpath',os.pathsep.join(str(p) for p in jars),
               '-d',str(classes)]+[str(p) for p in sources]
    argfile=build/'javac-args.txt'
    argfile.write_text('\n'.join(quoted(x) for x in arguments),encoding='utf-8')
    result=subprocess.run([str(javac),'@'+str(argfile)],check=False)
    if result.returncode:
        raise SystemExit('Compilation failed against your installed API. Keep the compiler output; no add-on was installed.')
    destination=build/'academic-ofi-native-v5.jar'
    if destination.exists():
        raise SystemExit('Output JAR already exists. Move it to a backup name before rebuilding; it was not overwritten.')
    with zipfile.ZipFile(destination,'x',zipfile.ZIP_DEFLATED) as z:
        z.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\r\n\r\n')
        for p in sorted((classes/'local'/'ofi').rglob('*.class')):
            z.write(p,p.relative_to(classes).as_posix())
    print('Built:',destination)
    print('This JAR is UNSIGNED. Bookmap approval may be required for paid live CME data.')
    print('No files were installed and no existing history was modified.')

if __name__=='__main__': main()
