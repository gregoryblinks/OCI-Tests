package local.ofi;

import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Append-only DERIVED OFI journal. Never edits or deletes the existing Python SQLite archive. */
public final class NativeHistory implements AutoCloseable {
    public final Path path;
    public final OfiCore.Rolling rolling = new OfiCore.Rolling();
    public long total;
    public boolean hasBaseline;
    public volatile String error;
    private double lastTime = Double.NEGATIVE_INFINITY;
    private final ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<String>(100000);
    private final RandomAccessFile lockFile;
    private final FileLock lock;
    private Thread writer;
    private volatile boolean closing;

    public NativeHistory(Path folder, String alias, double pips, double sizes, double multiplier, double now) throws Exception {
        Files.createDirectories(folder);
        path = folder.resolve(stem(alias) + ".ofi.tsv");
        lockFile = new RandomAccessFile(path.toString() + ".lock", "rw");
        FileLock acquired;
        try { acquired = lockFile.getChannel().tryLock(); }
        catch (Exception exc) { lockFile.close(); throw exc; }
        if (acquired == null) { lockFile.close(); throw new IOException("Another native OFI writer is active"); }
        lock = acquired;
        try {
            String header = "#NATIVE_OFI_V1\t" + Base64.getEncoder().encodeToString(alias.getBytes(StandardCharsets.UTF_8))
                + "\t" + pips + "\t" + sizes + "\t" + multiplier;
            if (!Files.exists(path)) {
                try (BufferedWriter out = Files.newBufferedWriter(path, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW)) {
                    out.write(header); out.newLine();
                }
            }
            // A truncated final record is not silently dropped or overwritten.
            try (RandomAccessFile check = new RandomAccessFile(path.toFile(), "r")) {
                if (check.length() == 0) throw new IOException("Empty journal; history preserved for inspection");
                check.seek(check.length() - 1);
                if (check.read() != 10) throw new IOException("Journal tail is incomplete; history preserved, not truncated");
            }
            try (BufferedReader in = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                String first = in.readLine();
                String[] h = first.split("\t", -1);
                if (h.length != 5 || !h[0].equals("#NATIVE_OFI_V1") ||
                    !h[1].equals(Base64.getEncoder().encodeToString(alias.getBytes(StandardCharsets.UTF_8))) ||
                    Double.parseDouble(h[2]) != pips || Double.parseDouble(h[3]) != sizes || Double.parseDouble(h[4]) != multiplier)
                    throw new IOException("Native archive identity mismatch; history not reset");
                String line;
                while ((line = in.readLine()) != null) {
                    String[] row = line.split("\t", 5);
                    if (row.length != 5) throw new IOException("Malformed journal row; history retained");
                    double ts = Double.parseDouble(row[0]);
                    long delta = Long.parseLong(row[1]), cumulative = Long.parseLong(row[2]);
                    if (!Double.isFinite(ts) || ts < lastTime || cumulative != Math.addExact(total, delta))
                        throw new IOException("Journal chronology/total mismatch; history retained");
                    total = cumulative; lastTime = ts;
                    if (row[3].contains("BASELINE")) hasBaseline = true;
                    if (ts > now - 300 && delta != 0) rolling.add(ts, delta);
                }
            }
            if (lastTime > now) throw new IOException("Archive ahead of local clock; correct clock, do not delete history");
            writer = new Thread(new Runnable() { public void run() { writeLoop(); } }, "Academic-OFI-journal");
            writer.setDaemon(true); writer.start();
        } catch (Exception exc) { lock.release(); lockFile.close(); throw exc; }
    }
    public static String stem(String alias) throws Exception {
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(alias.getBytes(StandardCharsets.UTF_8));
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 12; i++) s.append(String.format("%02x", hash[i] & 255));
        return s.toString();
    }
    public void record(double now, long delta, String kind, String note) throws IOException {
        if (error != null) throw new IOException(error);
        if (closing) throw new IOException("Journal already closing");
        if (!Double.isFinite(now) || now < lastTime) throw new IOException("Nonmonotonic journal time");
        long next = Math.addExact(total, delta);
        String safe = note.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
        String row = now + "\t" + delta + "\t" + next + "\t" + kind + "\t" + safe + "\n";
        if (!queue.offer(row)) throw new IOException("Journal queue full; history retained, OFI stopped");
        total = next; lastTime = now;
        if (kind.contains("BASELINE")) hasBaseline = true;
        rolling.add(now, delta);
    }
    private void writeLoop() {
        try (FileOutputStream out = new FileOutputStream(path.toFile(), true);
             BufferedWriter text = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8), 65536)) {
            long forced = System.nanoTime();
            while (!closing || !queue.isEmpty()) {
                String item = queue.poll(100, TimeUnit.MILLISECONDS);
                if (item != null) {
                    text.write(item);
                    for (int i = 0; i < 4095 && (item = queue.poll()) != null; i++) text.write(item);
                }
                text.flush();
                if (System.nanoTime() - forced >= 1000000000L) {
                    out.getChannel().force(true); forced = System.nanoTime();
                }
            }
            text.flush(); out.getChannel().force(true);
        } catch (Exception exc) { error = exc.toString(); System.err.println("Academic OFI journal error: " + error); }
    }
    @Override public void close() throws Exception {
        if (closing) return;
        closing = true;
        if (writer != null) {
            writer.join(10000);
            if (writer.isAlive()) throw new IOException("Journal writer still active; history untouched");
        }
        lock.release(); lockFile.close();
        if (error != null) throw new IOException(error);
    }
}
