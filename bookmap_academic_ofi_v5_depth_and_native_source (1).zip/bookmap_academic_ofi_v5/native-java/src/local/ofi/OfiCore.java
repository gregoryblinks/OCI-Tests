package local.ofi;

import java.util.ArrayList;

/** No Bookmap dependencies: CKS formula and exact trailing sums on a supplied clock. */
public final class OfiCore {
    private OfiCore() { }
    public static long contribution(int[] old, int[] cur) {
        return (cur[0] >= old[0] ? (long)cur[1] : 0L)
             - (cur[0] <= old[0] ? (long)old[1] : 0L)
             - (cur[2] <= old[2] ? (long)cur[3] : 0L)
             + (cur[2] >= old[2] ? (long)old[3] : 0L);
    }
    public static boolean valid(int[] bbo) {
        return bbo != null && bbo.length == 4 && bbo[1] > 0 && bbo[3] > 0 && bbo[0] < bbo[2];
    }
    public static final class Rolling {
        private final ArrayList<Double> times = new ArrayList<Double>();
        private final ArrayList<Long> prefixes = new ArrayList<Long>();
        private long total = 0, base = 0;
        private int head = 0;
        private double last = Double.NEGATIVE_INFINITY;
        private void check(double now) {
            if (!Double.isFinite(now) || now < last) throw new IllegalArgumentException("Nonmonotonic OFI time");
            last = now;
        }
        public void add(double now, long contribution) {
            check(now);
            if (contribution == 0) return;
            total = Math.addExact(total, contribution);
            times.add(now); prefixes.add(total);
        }
        public long[] values(double now) {
            check(now);
            long[] result = new long[3];
            int[] horizons = {60, 180, 300};
            for (int k = 0; k < horizons.length; k++) {
                int index = upper(now - horizons[k]);
                long before = index > head ? prefixes.get(index - 1) : base;
                result[k] = Math.subtractExact(total, before);
            }
            int expired = upper(now - 300);
            if (expired > head) { base = prefixes.get(expired - 1); head = expired; }
            if (head >= 65536) {
                times.subList(0, head).clear(); prefixes.subList(0, head).clear(); head = 0;
            }
            return result;
        }
        private int upper(double cutoff) {
            int lo = head, hi = times.size();
            while (lo < hi) {
                int mid = (lo + hi) >>> 1;
                if (times.get(mid) <= cutoff) lo = mid + 1; else hi = mid;
            }
            return lo;
        }
    }
}
