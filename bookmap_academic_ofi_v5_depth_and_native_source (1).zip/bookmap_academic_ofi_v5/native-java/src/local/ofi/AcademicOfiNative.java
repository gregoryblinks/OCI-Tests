package local.ofi;

import java.awt.Color;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Locale;
import velox.api.layer1.annotations.Layer1ApiVersion;
import velox.api.layer1.annotations.Layer1ApiVersionValue;
import velox.api.layer1.annotations.Layer1SimpleAttachable;
import velox.api.layer1.annotations.Layer1StrategyName;
import velox.api.layer1.data.InstrumentInfo;
import velox.api.layer1.messages.indicators.Layer1ApiUserMessageModifyIndicator.GraphType;
import velox.api.layer1.simplified.*;

/** Native BBO input. NO individual-order reconstruction, no order placement, no network. */
@Layer1SimpleAttachable
@Layer1StrategyName("Academic OFI Native BBO v5")
@Layer1ApiVersion(Layer1ApiVersionValue.VERSION2)
public class AcademicOfiNative implements CustomModule, BboListener,
        MarketByOrderDepthDataListener, IntervalListener, SnapshotEndListener {
    private String alias = "";
    private InstrumentInfo info;
    private NativeHistory history;
    private int[] previous, latest;
    private boolean snapshotEnded, gap, stopped;
    private String error;
    private double cleanSince = Double.NaN;
    private final double utcAnchor = System.currentTimeMillis() / 1000.0;
    private final long nanoAnchor = System.nanoTime();
    private double lastReport = Double.NEGATIVE_INFINITY, sampleAt, lastMbo = Double.NaN;
    private long mboBidNew, mboAskNew, mboReplace, mboCancel, bboCount, ofiCount, sampledMbo;
    private double mboRate;
    private Indicator[] lines;
    private Indicator zero, cumulative, mboRateLine, mboCountLine, statusLine, bboCountLine;

    private double now() { return utcAnchor + (System.nanoTime() - nanoAnchor) / 1e9; }
    @Override public void initialize(String alias, InstrumentInfo info, Api api, InitialState initialState) {
        this.alias = alias; this.info = info; sampleAt = now();
        try {
            if (!Double.isFinite(info.pips) || info.pips <= 0 || !Double.isFinite(info.sizeMultiplier) || info.sizeMultiplier <= 0)
                throw new IllegalArgumentException("Invalid instrument multipliers");
            Path folder = Paths.get(System.getProperty("user.home"), "Bookmap_OFI_History", "native_v5");
            history = new NativeHistory(folder, alias, info.pips, info.sizeMultiplier, info.multiplier, now());
            history.record(now(), 0, "SOURCE_NATIVE_BBO", "New activation; previous journal retained; no bridge from last activation");
            lines = new Indicator[3];
            String[] labels = {"1m", "3m", "5m"};
            Color[] colors = {Color.CYAN, Color.ORANGE, new Color(215,120,255)};
            AxisGroup group = new AxisGroup();
            for (int i=0;i<3;i++) {
                lines[i] = api.registerIndicator("Academic OFI Native - " + labels[i], GraphType.BOTTOM, Double.NaN, true, true);
                lines[i].setColor(colors[i]); group.add(lines[i]);
            }
            zero = api.registerIndicator("Academic OFI Native - Zero", GraphType.BOTTOM, 0, true, false);
            zero.setColor(Color.GRAY); group.add(zero);
            // Separate axes; diagnostic lines hidden by default but widgets available.
            cumulative = api.registerIndicator("OFI Native - Cumulative recorded", GraphType.BOTTOM, Double.NaN, false, true);
            mboRateLine = api.registerIndicator("MBO Native - Received callbacks per second", GraphType.BOTTOM, 0, false, true);
            mboCountLine = api.registerIndicator("MBO Native - Callbacks this activation", GraphType.BOTTOM, 0, false, true);
            bboCountLine = api.registerIndicator("BBO Native - Callbacks this activation", GraphType.BOTTOM, 0, false, true);
            statusLine = api.registerIndicator("OFI Native - Status (-1 error, 0 partial, 1 full)", GraphType.BOTTOM, 0, false, true);
            log("v5 NATIVE_BBO; journal=" + history.path + "; cumulative retained=" + history.total
                + "; waiting for onSnapshotEnd; MBO is counters only. No Python loader needed.");
        } catch (Exception exc) { fail(exc); }
    }
    @Override public void onBbo(int bidPrice, int bidSize, int askPrice, int askSize) {
        bboCount++;
        latest = new int[]{bidPrice,bidSize,askPrice,askSize};
        if (stopped || error != null || history == null || !snapshotEnded) return;
        double t = now();
        try {
            if (!OfiCore.valid(latest)) {
                if (!gap) history.record(t, 0, "GAP_NATIVE_BBO", "Invalid BBO supplied by API; no manufactured flow");
                previous = null; cleanSince = Double.NaN; gap = true;
                return;
            }
            if (previous == null) { baseline(t); return; }
            if (!Arrays.equals(previous, latest)) {
                long delta = OfiCore.contribution(previous, latest);
                history.record(t, delta, "OFI", "SOURCE=NATIVE_BBO");
                ofiCount++;
            }
            previous = latest.clone();
        } catch (Exception exc) { fail(exc); }
    }
    private void baseline(double t) throws Exception {
        if (!OfiCore.valid(latest)) return;
        history.record(t,0,"BASELINE","SOURCE=NATIVE_BBO; preceding snapshot/gap not counted");
        previous = latest.clone(); gap = false; cleanSince = t;
        log("OFI ACTIVE: native BBO baseline received. Partial 1m/3m/5m values available now.");
    }
    @Override public void onSnapshotEnd() {
        if (snapshotEnded || stopped || error != null || history == null) return;
        snapshotEnded = true;
        try { baseline(now()); } catch (Exception exc) { fail(exc); }
        log("Native snapshot-end callback received. MBO counts include the snapshot.");
    }
    // These are MBO listener callbacks, NOT trading commands.
    @Override public void send(String orderId, boolean isBid, int price, int size) {
        if (isBid) mboBidNew++; else mboAskNew++;
        lastMbo = now();
    }
    @Override public void replace(String orderId, int price, int size) { mboReplace++; lastMbo = now(); }
    @Override public void cancel(String orderId) { mboCancel++; lastMbo = now(); }
    private long mboTotal() { return mboBidNew + mboAskNew + mboReplace + mboCancel; }
    @Override public long getInterval() { return 250000000L; }
    @Override public void onInterval() {
        if (stopped || lines == null) return;
        double t = now();
        if (t - sampleAt >= 1) {
            mboRate = (mboTotal() - sampledMbo) / (t - sampleAt);
            sampledMbo = mboTotal(); sampleAt = t;
        }
        if (history != null && history.error != null && error == null) fail(new IllegalStateException(history.error));
        try {
            if (history != null) {
                long[] values = history.rolling.values(t);
                for (int i=0;i<3;i++) lines[i].addPoint(history.hasBaseline ? values[i]/info.sizeMultiplier : Double.NaN);
                cumulative.addPoint(history.total/info.sizeMultiplier);
            }
            mboRateLine.addPoint(mboRate); mboCountLine.addPoint(mboTotal()); bboCountLine.addPoint(bboCount);
            statusLine.addPoint(error != null || gap ? -1 :
                (snapshotEnded && Double.isFinite(cleanSince) && t-cleanSince>=300 ? 1 : 0));
            if (t-lastReport>=5) {
                lastReport=t;
                String mode = error!=null ? "ERROR" : !snapshotEnded ? "WAIT_SNAPSHOT_END" :
                    !OfiCore.valid(latest) ? "WAIT_VALID_NATIVE_BBO" : previous==null ? "WAIT_BASELINE" : "ACTIVE";
                String message = String.format(Locale.ROOT,
                    "NATIVE DIAG OFI=%s BBO_callbacks=%d OFI_changes=%d MBO_total=%d MBO/s=%.1f "
                    + "BID_NEW=%d ASK_NEW=%d REPLACE=%d CANCEL=%d lastMBO_age=%s live_source=UNVERIFIED%s",
                    mode,bboCount,ofiCount,mboTotal(),mboRate,mboBidNew,mboAskNew,mboReplace,mboCancel,
                    Double.isFinite(lastMbo) ? String.format(Locale.ROOT,"%.3fs",t-lastMbo) : "NEVER",
                    error!=null ? " error="+error : "");
                log(message);
                if (error==null && history!=null) history.record(t,0,"DIAGNOSTIC",message);
            }
        } catch (Exception exc) { fail(exc); }
    }
    private void log(String message) { System.out.println("Academic OFI Native ["+alias+"]: "+message); }
    private void fail(Exception exc) {
        if (error!=null) return;
        error=exc.toString(); previous=null; cleanSince=Double.NaN;
        log("STOPPED: "+error+". History retained. MBO counters remain independent.");
    }
    @Override public void stop() {
        stopped=true;
        if (history!=null) {
            try {
                if (history.error==null && error==null) history.record(now(),0,"UNSUBSCRIBE","History retained");
                history.close();
            } catch (Exception exc) { log("Archive close warning: "+exc); }
        }
    }
}
