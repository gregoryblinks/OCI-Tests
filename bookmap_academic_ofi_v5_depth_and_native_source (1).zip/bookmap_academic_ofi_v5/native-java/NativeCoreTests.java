package local.ofi;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Tests only our Java core/journal. No Bookmap classes or simulated live-connection claims. */
public class NativeCoreTests {
    static int checks=0;
    static void check(boolean value, String label) { checks++; if(!value) throw new AssertionError(label); }
    public static void main(String[] args) throws Exception {
        int[] old={100,10,102,12};
        check(OfiCore.contribution(old,new int[]{100,15,102,12})==5,"bid add");
        check(OfiCore.contribution(old,new int[]{100,10,102,8})==4,"ask removal");
        check(OfiCore.contribution(old,new int[]{101,3,102,12})==3,"bid price improves");
        check(OfiCore.contribution(old,new int[]{99,900,102,12})==-10,"bid price falls");
        check(OfiCore.contribution(old,new int[]{100,10,101,7})==-7,"ask improves");
        check(OfiCore.contribution(old,new int[]{100,10,103,900})==12,"ask worsens");
        check(OfiCore.contribution(old,old)==0,"unchanged");
        check(!OfiCore.valid(new int[]{100,1,100,1}),"lock invalid");
        check(!OfiCore.valid(new int[]{100,0,102,1}),"zero size invalid");
        OfiCore.Rolling r=new OfiCore.Rolling(); r.add(10,5);
        check(r.values(69.999)[0]==5,"inside boundary");
        check(r.values(70)[0]==0,"exclusive 60-second boundary");
        r.add(71,2);r.add(71,-1);
        check(r.values(71)[0]==1,"same timestamp");
        check(r.values(1000)[2]==0,"cache expiration");
        Path dir=Files.createTempDirectory("ofi-native-test-");
        NativeHistory h=new NativeHistory(dir,"ES_TEST",.25,1,50,1000);
        h.record(1000,0,"BASELINE","test"); h.record(1001,5,"OFI","test");
        h.record(1002,0,"GAP","keep prior flow"); Path p=h.path; h.close();
        byte[] before=Files.readAllBytes(p);
        NativeHistory restored=new NativeHistory(dir,"ES_TEST",.25,1,50,1003);
        check(restored.total==5,"journal cumulative restored");
        check(restored.rolling.values(1003)[0]==5,"journal rolling restored");
        check(Arrays.equals(before,Files.readAllBytes(p)),"restore no rewrite");
        restored.record(1004,2,"OFI","append");restored.close();
        byte[] after=Files.readAllBytes(p);
        check(Arrays.equals(before,Arrays.copyOf(after,before.length)),"append preserves byte prefix");
        NativeHistory late=new NativeHistory(dir,"ES_TEST",.25,1,50,2000);
        check(late.total==7,"cumulative survives old windows");
        check(late.rolling.values(2000)[0]==0,"old events only leave cache");late.close();
        boolean rejected=false;
        try {new NativeHistory(dir,"ES_TEST",.25,10,50,2001);} catch(Exception exc) {rejected=true;}
        check(rejected,"identity mismatch rejected");
        check(Arrays.equals(after,Files.readAllBytes(p)),"mismatch preserves journal");
        // Stress the formula against its piecewise definition, including near-int limits.
        Random random=new Random(9);
        for(int i=0;i<10000;i++) {
            int[] a={100,1+random.nextInt(1000),105,1+random.nextInt(1000)};
            int[] b={99+random.nextInt(3),1+random.nextInt(1000),104+random.nextInt(3),1+random.nextInt(1000)};
            long bid=b[0]>a[0]?b[1]:b[0]<a[0]?-a[1]:b[1]-a[1];
            long ask=b[2]<a[2]?-b[3]:b[2]>a[2]?a[3]:a[3]-b[3];
            check(OfiCore.contribution(a,b)==bid+ask,"random formula "+i);
        }
        check(OfiCore.contribution(new int[]{100,Integer.MAX_VALUE,102,Integer.MAX_VALUE},
                    new int[]{101,Integer.MAX_VALUE,103,Integer.MAX_VALUE})==2L*Integer.MAX_VALUE,"long arithmetic");
        // Only temporary test files are removed. Production journals have no deletion path.
        try(java.util.stream.Stream<Path> stream=Files.walk(dir)) {
            stream.sorted(Comparator.reverseOrder()).forEach(x->{try {Files.delete(x);}catch(Exception ex){throw new RuntimeException(ex);}});
        }
        System.out.println("PASS: "+checks+" Java core/journal assertions. Native Bookmap adapter NOT exercised.");
    }
}
