"""Copy legacy SQLite derived OFI into a native journal, without changing/deleting SQLite.
Stop the old Python indicator and flush it first. Run BEFORE enabling native OFI.
New native destination files are created exclusively; existing destinations are skipped.
"""
import argparse
import base64
from contextlib import closing
import hashlib
import json
import math
import os
from pathlib import Path
import sqlite3
import tempfile


def migrate_one(source: Path, target_folder: Path):
    # Read-only connection and transaction create a consistent, committed snapshot.
    with closing(sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True)) as con:
        con.execute('BEGIN')
        identity_row=con.execute("SELECT value FROM metadata WHERE key='identity'").fetchone()
        if identity_row is None: raise ValueError('Missing identity in '+str(source))
        identity=json.loads(identity_row[0]); alias=identity['alias']
        header=['#NATIVE_OFI_V1',base64.b64encode(alias.encode()).decode(),
                str(float(identity['pips'])),str(float(identity['size_multiplier'])),
                str(float(identity['instrument_multiplier']))]
        stem=hashlib.sha256(alias.encode()).hexdigest()[:24]
        destination=target_folder/(stem+'.ofi.tsv')
        if destination.exists():
            return 'SKIPPED existing native journal: '+str(destination)
        target_folder.mkdir(parents=True,exist_ok=True)
        fd,temporary=tempfile.mkstemp(prefix=stem+'.migration-',suffix='.staging',dir=target_folder)
        temp=Path(temporary)
        try:
            with os.fdopen(fd,'w',encoding='utf-8',newline='\n') as out:
                out.write('\t'.join(header)+'\n')
                total=0; last=-math.inf; count=0
                for ts,kind,delta,cumulative in con.execute(
                    'SELECT received_at_utc,kind,ofi_raw,cumulative_raw FROM records ORDER BY seq'):
                    if not math.isfinite(ts) or ts<last or total+delta!=cumulative:
                        raise ValueError('Nonmonotonic or inconsistent legacy history; original not modified')
                    if not -(2**63)<=cumulative<2**63: raise OverflowError('Cumulative exceeds Java long')
                    total=cumulative; last=ts; count+=1
                    safe_kind='LEGACY_'+str(kind).replace('\t',' ').replace('\n',' ').replace('\r',' ')
                    out.write(f'{ts!r}\t{delta}\t{cumulative}\t{safe_kind}\tIMPORTED_FROM_SQLITE_NO_RECOMPUTATION\n')
                out.flush(); os.fsync(out.fileno())
            # Atomic, exclusive publication: cannot replace an existing destination.
            # Supported on local NTFS and standard Unix filesystems. Fail safely otherwise.
            os.link(str(temp),str(destination))
            # Remove only our redundant staging link, never source or historical destination.
            temp.unlink()
            return f'CREATED {destination}: {count} rows, cumulative_raw={total}. Original SQLite untouched.'
        except Exception as exc:
            raise RuntimeError(f'{exc}. Original SQLite untouched; staging retained at {temp}') from exc


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--history-dir',type=Path,default=Path.home()/'Bookmap_OFI_History')
    args=parser.parse_args()
    sources=sorted(args.history_dir.glob('*.sqlite3'))
    if not sources: raise SystemExit('No legacy SQLite histories found at '+str(args.history_dir))
    # Detect ambiguous same-alias archives before creating any destination.
    aliases={}
    for source in sources:
        with closing(sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True)) as con:
            row=con.execute("SELECT value FROM metadata WHERE key='identity'").fetchone()
            if row is None: raise SystemExit('Missing identity: '+str(source))
            alias=json.loads(row[0])['alias']
        if alias in aliases: raise SystemExit('Multiple legacy archives share alias '+alias+
                                              '; reconcile them first. No destination created.')
        aliases[alias]=source
    for source in sources: print(migrate_one(source,args.history_dir/'native_v5'))
    print('Native uses a NEW journal. Original SQLite (including all old BBO fields) remains unchanged.')
    print('Legacy estimates are preserved, not repaired. Do not resume the old Python writer after migration.')

if __name__=='__main__': main()
