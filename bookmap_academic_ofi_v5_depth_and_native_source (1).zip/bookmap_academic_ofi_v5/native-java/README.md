# Academic OFI Native BBO v5 -- source project

This is the **actual native-BBO** route. It implements Bookmap's documented Java
BboListener and never constructs a book from individual MBO messages. The separate
MarketByOrderDepthDataListener callbacks count actual received per-order events.
They do not participate in the OFI equation.

## Status

Source and local builder supplied. **No compiled/signed native Bookmap JAR is
included.** The computational core and history journal were compiled/tested here;
the Bookmap adapter still needs compilation against your installed API and an
in-Bookmap test. Do not rename a `.java` or `.py` file to `.jar`.

## Build on Windows

A JDK (not just the Bookmap Java runtime) and the actual Bookmap API JARs are needed.
The builder performs no downloads. Extract this folder, then open Command Prompt
in it. For an installation actually located at `C:\Bookmap`, run:

```bat
py build_native.py --bookmap-dir "C:\Bookmap"
```

Use your real installation path. It is NOT the `C:\BookmapScripts` folder.
If `py` is not available, use the same Python executable you selected in Bookmap:

```bat
"C:\actual\path\python.exe" build_native.py --bookmap-dir "C:\actual\Bookmap"
```

When a JDK is not on PATH, add its actual compiler path:

```bat
py build_native.py --bookmap-dir "C:\Bookmap" --javac "C:\actual\jdk-21\bin\javac.exe"
```

Successful output is `build\academic-ofi-native-v5.jar`. The script does not
install anything in Bookmap or overwrite an existing JAR. Missing API classes or
compiler errors are reported explicitly, rather than replaced with mock libraries.

## Preserve and import existing history before first native activation

Stop the old Python OFI script and let it close/flush. Keep all original files.
Run, from this folder:

```bat
py migrate_history.py
```

It opens SQLite read-only, copies all *derived OFI contributions* and marker kinds
into the native journal and leaves original SQLite rows/BBO fields untouched. It
validates chronological and cumulative consistency. Destinations are exclusive:
existing native journals are skipped, never overwritten. Conflicting legacy
archives with the same alias are rejected before creating destinations.

New native journals live in:

`%USERPROFILE%\Bookmap_OFI_History\native_v5`

The history copy preserves legacy estimated/erroneous values. It does NOT turn them
into exact OFI or infer missed events. Do not continue writing the old Python stream
after migration and expect those later observations to magically reach the native
journal. Use only one calculation route. Previously committed legacy data is copied;
uncommitted data cannot be recovered by this tool.

## Load in Bookmap

Use `Settings -> Configure add-ons -> Add`, select the actual built JAR, choose
`Academic OFI Native BBO v5`, and enable it on your ES chart. This does NOT go in
the Python editor and does not use the Python loader. Keep the old Python OFI off.

Bookmap's current published guide requires verification/signing for custom add-ons
on paid live data such as CME. This source/JAR is not signed or approved. Confirm
with Bookmap that this add-on and its local derived-OFI journal are permitted; do
not assume your Python API permissions transfer to a custom Java add-on. No licence,
permission, signing or market-data export restrictions are bypassed.

## What appears

Three rolling native OFI lines (1m, 3m, 5m) and zero share an OFI scale.
Diagnostic lines have separate axes and are hidden by default; their widgets are
registered for selection. They show MBO callbacks per second, total MBO callbacks,
native BBO callback count, cumulative recorded OFI, and data status.

The log uses `Academic OFI Native` and prints `NATIVE DIAG` about every five seconds:

- `WAIT_SNAPSHOT_END`: no native snapshot-end notification yet. Snapshot additions
  are not counted as flow. No heuristic completion claim is made.
- `WAIT_VALID_NATIVE_BBO`: no usable two-sided quote from Bookmap's native callback.
- `ACTIVE`: snapshot-end notification received and a valid BBO baseline exists.
- `ERROR`: processing/storage failure, with the cause shown. Existing history kept.

The native code can still detect an invalid BBO *supplied by the API*. It does not
hide it or claim native input cannot be invalid. Such intervals create gap markers;
recovery uses a new baseline without manufacturing intervening OFI. Past history
is never cleared. Optional partial values continue to represent observed history.

Snapshot MBO callbacks count toward reception totals. Local arrival age/rates do
not prove live provenance, freshness at the exchange, or completeness. Use an
appropriate live connection. This version uses receipt-time lookbacks and is **not
for accelerated replay**. The journal is not a raw market-data recorder; it stores
derived OFI, cumulative values and marker/diagnostic records. Existing legacy
SQLite may contain raw BBO fields; it remains untouched.

## Native history guarantees and boundaries

On orderly shutdown, the asynchronous writer flushes its queue and forces the file.
An invalid BBO, reactivation or app restart never deletes previous journal rows.
Only the five-minute in-memory *working cache* expires old observations. The full
journal and cumulative remain. Gaps and subscription changes are explicitly marked.
A corrupt/truncated final row is rejected, not silently truncated.

Disk failures, forced termination or power loss can lose the pending tail. Full
queues stop accumulation instead of silently dropping an event. Very large archives
are scanned at initialization, which can make startup slower. This source is a
starting implementation pending real Bookmap integration/performance testing.

## Local tests

These core tests do not require Bookmap:

```bat
javac -d test-classes src\local\ofi\OfiCore.java src\local\ofi\NativeHistory.java NativeCoreTests.java
java -cp test-classes local.ofi.NativeCoreTests
```

They test formula/rolling behavior and retention in temporary journals. The tests
remove only their own temporary test files, never user history.
