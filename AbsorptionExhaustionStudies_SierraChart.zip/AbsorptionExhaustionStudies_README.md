# Sierra Chart Absorption and Exhaustion Studies

This package contains one ACSIL source file with two custom studies:

1. **VAP Absorption Candidates**
2. **VAP Exhaustion Candidates**

The studies use Sierra Chart's per-bar Volume-at-Price data (`sc.VolumeAtPriceForBars`). They mark configurable candidates; absorption and exhaustion remain context-dependent order-flow concepts and are not objectively knowable from one footprint rule.

## Data requirements

- Use an **Intraday chart** with accurate historical Bid Volume and Ask Volume.
- Configure Sierra Chart for **1 Tick Intraday Data Storage Time Unit**.
- Keep **Volume at Price Multiplier** at 1 unless you intentionally aggregate price levels.
- A centralized futures feed such as YM or MYM is more suitable than a cash index or CFD whose volume may be synthetic or broker-specific.

## Build and install

1. Copy `AbsorptionExhaustionStudies.cpp` into the Sierra Chart `ACS_Source` folder.
2. In Sierra Chart, select **Analysis > Build Custom Studies DLL**.
3. Select the source file.
4. Select **Build > Remote Build** or **Build with Visual C++ - Release**.
5. Add either study through **Analysis > Studies > Add Custom Study** under **Absorption and Exhaustion Order Flow Studies**.

## Absorption logic

### Bullish candidate

- Evaluates the lowest configurable number of price levels.
- Looks for aggressive Bid Volume dominance, optionally using diagonal comparison.
- Requires a configurable number of dominant edge levels.
- Requires edge Bid Volume to exceed an adaptive multiple of average Bid Volume per price level.
- Requires the close to reject away from the low.
- Can optionally require negative or zero total bar delta.

### Bearish candidate

The inverse logic is used at the bar high with aggressive Ask Volume.

### Suggested starting values for YM/MYM

The defaults are deliberately relative rather than fixed-volume based:

- Edge levels: 3
- Minimum dominant levels: 2
- Dominance ratio: 3.0
- Edge volume multiple: 1.5
- Rejection: 35%
- Closed bars only: Yes

For a slower chart or regular trading hours, increase the dominance and volume thresholds. For MYM or overnight trading, fixed volume filters should usually be lower or disabled.

## Exhaustion logic

### Bullish candidate / seller exhaustion

- Compares Bid Volume at the lowest traded price with Bid Volume one level above.
- Also compares the lowest Bid Volume with average Bid Volume per price level in the bar.
- Optionally requires a finished auction and a close away from the low.

### Bearish candidate / buyer exhaustion

The inverse logic is used at the bar high with Ask Volume.

### Suggested starting values

- Extreme-to-adjacent ratio: 0.25
- Extreme-to-average ratio: 0.35
- Minimum adjacent volume: tune for instrument and session
- Require finished auction: No initially
- Require rejection: Yes
- Closed bars only: Yes

## Important interpretation notes

- These are **candidate markers**, not automatic trade entries.
- Absorption detection from completed bar VAP data does not preserve the exact sequence of trades inside the bar. A more advanced real-time version can incorporate Time and Sales, pullback VAP, repeated testing of the same price, and market-depth behavior.
- Calibrate separately for YM and MYM, chart type, session, and volatility regime.
- Validate with replay and out-of-sample data before using alerts operationally.
