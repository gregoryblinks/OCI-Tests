# Validation status and Bookmap replay checklist

## Performed in this environment

OpenJDK 21 compiler with `--release 17`, compiling the dependency-free core and renderer. `sh build.sh --test-only` passed **62** test groups. Output: [test-results.txt](test-results.txt).

The adapter was compiled against small, explicitly labeled test doubles and executed in **8** mocked callback scenarios. Output: [contract-preflight-results.txt](contract-preflight-results.txt). This checks Java syntax and the tested callback logic, not the actual SDK ABI, threading behavior, settings persistence, chart integration or feed.

The native-size production renderer preview was inspected. Both arrows point toward the candle, all four rows are vertical, and no background box or status heading remains. Image transparency, edges, placement and the absence of reserved hidden-arrow space are also tested.

Not performed: real Bookmap SDK compilation (download unavailable), Windows PowerShell execution, Bookmap replay/runtime testing, live Rithmic observation, audio-device testing, or exchange-volume reconciliation. The original live warning's trigger remains unconfirmed without its log.

## Covered by regression tests

Inclusive four-way gates, no mixed-direction signals, warm-up, reference exclusion of current candle, FIFO history, zero-volume minutes, zero MAD, unknown side, bad price, retained invalid reference slots, and exact quarantine expiry. Minute timing tests cover exact boundaries, repeated callbacks, partial start, intraminute reordering, stale data, accepted buffer-late prints, late-after-publication quarantine, clock regressions, missing timestamp, zero-size noise, negative corrections and bounded long gaps. A 100-minute randomized stream conserves delivered volume. Published results remain immutable.

Renderer tests cover four rows in order, no heading/threshold column, dashes, centered text, bullish/bearish high/low anchoring, labels without arrows, independent visibility switches, placement overrides, transparent edges and compact dimensions.

Mocked adapter checks cover bullish/bearish output, labels with hidden arrows, default 200 ms buffering, zero-size noise, buffered prints, callback timestamp handling and missing metadata.

## Required in your Bookmap installation

1. **Upgrade identification.** Build the new JAR against the real SDK. Remove the old add-on, restart Bookmap, load the 3.2.0 JAR and verify the displayed name is `ES Expansion V3.2 - compact arrows + metrics`. Confirm `version=3.2.0` in the log. No old boxed layer should remain enabled.
2. **Input and timestamp checks.** Use the same ES contract, feed and trade filters when comparing volumes. Enable per-candle logging. Compare total buy/sell/unknown and total volume against Bookmap's trade data for matching one-minute intervals. Compare open/high/low/close to a one-minute trade-based OHLC view, not quote-derived extremes. Check exact minute boundary prints.
3. **Warm-up and formulas.** Confirm the initial partial minute is excluded and that exactly 15 prior complete minute slots enter each calculation. Independently recompute median/MAD and all four readings from the received trade records. Confirm zero MAD is unavailable rather than zero or infinity.
4. **Timing.** Log both candle end and notification. With buffer 200 ms, no output should be published earlier than end + 200 ms. Do not assume fixed latency; callback and feed delays vary. Verify only one output per minute and no use of next-minute trades. Compare buffer 0 and 200 using the same arrival sequence.
5. **Data problems.** Inspect the new reason codes. Zero-size callbacks must not restart warm-up. A print received after publication must not change the old chart arrow; its retained minute is marked unreliable for future results, and the log must flag prior signals for audit. A bad-price minute should preserve volume readings where possible. Unknown aggressor data must not silently become a sell. A genuinely bad-volume slot can block calculations until it leaves the window.
6. **Presentation and settings.** Verify bullish arrows below lows, bearish arrows above highs, and text extending away from price. Check label-only output on a near-miss candle, independent toggles, font size, zoom/scroll behavior, latest-chart-edge clipping and high-DPI scaling. Thresholds belong in settings, not in repeated labels.
7. **Lifecycle.** Check attach after subscription history, parameter reload, replay rewind, pause/resume, disconnect/reconnect and stop mid-minute. No incomplete final candle should be emitted on stop. Large historical gaps must not create stacks of stale icons at one reconnect time. Audio must be silent during catch-up and optional in realtime/replay.

Keep the new default `labelMode=0` for every-candle readings while validating. A dash means a required value is unavailable, not a zero reading or a trading instruction. Treat a signal based on later-discovered incomplete data as an audit issue; this build intentionally does not repaint historical signals.

## Research integrity

Record indicator version, parameters, contract, provider, data filters, close buffer and notification timestamps. Preserve raw trade-event arrival order in replay/backtesting. Signals become available at notification time, not retroactively at the earlier candle-close price. Add spread, slippage, fees and latency to any later performance study. No profit expectancy or optimality of the 2x/2z parameters has been established.
