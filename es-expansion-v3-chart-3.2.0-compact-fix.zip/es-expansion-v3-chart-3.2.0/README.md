# ES Expansion V3.2 - compact arrows + metrics

**Version 3.2.0 | Java 17 | Bookmap Simplified Layer 1 API**

Trade-only, completed-one-minute expansion research indicator for the ES contract already subscribed in Bookmap through Rithmic. No extra data connection, MBO dependency, order-book analysis, or order submission.

Start with [QUICKSTART.md](QUICKSTART.md). Changes are listed in [CHANGELOG.md](CHANGELOG.md). Replay checks and honest test status are in [docs/VALIDATION.md](docs/VALIDATION.md).

## Build status

The source is tested locally with dependency-free Java tests and mocked API callback scenarios. It has **not** been compiled against the actual Bookmap SDK in this environment, nor run in Bookmap or on a live Rithmic feed. Attempts to download the SDK failed. No precompiled add-on JAR is included. The user build scripts compile against the official `api-core` and `api-simplified` libraries, version `7.6.0.20`, and do not bundle those libraries into the resulting add-on.

This version keeps the same SDK target as the previous package. Bookmap's official DemoStrategies build declares Java 17 and those SDK coordinates [1]. Compatibility with your particular installed Bookmap build still requires a real SDK build and replay test. Published API documentation cited below is for 7.2; it verifies the relevant contracts but is not a substitute for that test.

## Display

Only four vertical rows, centered on the annotation's arrow/time anchor:

```text
RVOL 2.60x
ACC  +2.40z
SV   +2.70z
SI   +2.20z
```

The actual rendered RVOL suffix is the multiplication symbol. Undefined values are em dashes. Values are shown to two decimals; magnitudes at least 1000 use scientific notation to avoid an excessively wide label. Formatting never changes the calculation.

A bullish green up arrow sits below the completed candle's low and the text sits below it. A bearish red down arrow sits above the completed candle's high and the text sits above it. No expansion means no arrow; readings still appear by default. In no-signal mode, labels follow candle direction (up/flat below; down above), with an override for always above/below.

There is no painted box, background, border, status heading, title, time, or threshold column. A thin dark outline around the glyphs helps readability. Default font: 11 pixels. Arrows and labels can be toggled independently. Hidden arrows leave no reserved space. Threshold controls remain available in Bookmap's parameter settings [2].

RVOL/ACC are non-directional: threshold passes are amber. SV/SI are green at their positive threshold, red at their negative threshold, and neutral gray otherwise. A mixed SV/SI direction does not qualify for an arrow.

[Actual renderer preview](docs/render-samples/annotation-preview.png): synthetic readings, not a live Bookmap screenshot. On the authoring machine the example signal icons are 83 by 83 pixels, no-signal labels 83 by 65, and all-dash labels 48 by 65. Font metrics may vary by OS. Only glyphs and the arrow are opaque; these dimensions do not describe visible boxes.

The API accepts `BufferedImage` icons at an event time and price [3]. It does not accept an explicit historical timestamp through `Indicator.addIcon`. This implementation therefore anchors to the notification time, not the midpoint of the prior candle. Vertical anchors use the finished candle's high/low plus an adjustable tick offset. Default label centering can clip at the live chart edge; maintain adequate visible chart space. There is no automatic collision avoidance when zoomed out.

## Inputs and formulas (unchanged)

Each minute is the half-open event-time interval `[start, start + 60 seconds)`. Its open/close are the earliest/latest valid execution prices by event time (arrival order breaks equal-time close ties); its high/low are execution extremes. Prices are Bookmap price levels. Multiplying a price difference by `InstrumentInfo.pips` yields a price-unit difference. The official API example uses the same trade-price conversion and identifies `isBidAggressor` as buyer-initiated [4,5].

Volume is the sum of positive executed trade sizes received for this instrument. For the intended ES feed it is contract volume, not event count or resting liquidity. The log records API quantity units directly. No order IDs, depth, OFI, VPIN, Fibonacci, VWAP, or additional indicators enter the model. OTC trades are excluded by default, as in the prior build.

For the current completed minute `t`, the reference is exactly the prior `N` consecutive completed minutes, initially `N = 15`. It never includes `t`. Zero-volume and unreliable complete minutes occupy their proper time slots; they are not replaced by older active candles.

For an observed quantity `X`,

```text
center = median(X[t-N], ..., X[t-1])
MAD    = median(abs(X[i] - center)) over the same reference
z(X[t]) = (X[t] - center) / (1.4826 * MAD)
```

A zero or unavailable scale returns unavailable, not infinity. No epsilon, standard-deviation fallback, winsorization, or hidden alternative lookback is used. "z" here is a robust standardized score, not evidence of Gaussian market tails or a confidence guarantee.

| Component | Definition | Required threshold |
|---|---|---|
| RVOL | Current traded volume / prior-N median traded volume | >= 2.0 for both directions |
| ACC | Robust z-score of current **volume level** against prior-N volume levels | >= +2.0 for both directions |
| SV | Raw `(buy volume - sell volume) / (buy + sell)`; then robust z of that ratio | >= +2.0 bullish; <= -2.0 bearish |
| SI | Raw `(close - open) * pips / traded volume`; then robust z of that ratio | >= +2.0 bullish; <= -2.0 bearish |

ACC retains the distribution-relative volume-level definition from the previous version. It is not a derivative or volume growth rate, so it overlaps substantially with RVOL. SI is an open-to-close research proxy, not a causal market-impact estimate. Positive/negative z is relative to the historical median; no extra raw-sign or candle-color gate is imposed.

The signal gate is exactly:

```java
bullish = rvol >= rvolThreshold && accZ >= accelerationThreshold
        && svZ >= svThreshold && siZ >= siThreshold;
bearish = rvol >= rvolThreshold && accZ >= accelerationThreshold
        && svZ <= -svThreshold && siZ <= -siThreshold;
```

All four values must be finite, and the model must be ready. One unavailable value blocks a full signal. All thresholds and lookback are editable parameters, initially 2x and +/-2z. No profitability claim is made.

## Data-issue repairs

The earlier version marked any nonpositive trade size as invalid and could clear the entire reference when a single late trade arrived. It also marked the unrelated current candle invalid. This version removes those paths rather than merely hiding their headings.

| Event | New treatment |
|---|---|
| Zero size, including zero size with no finite price | Ignore as zero executed contracts. Do not advance engine time from that callback, invalidate the candle, or reset the reference. Record a rate-limited diagnostic. |
| Negative size | Unsupported execution correction. Do not subtract invented contracts. Mark that minute's volume-dependent calculations unavailable, retaining its reference slot. |
| Positive size, non-finite price | Retain quantity and available aggressor side. Mark price-dependent SI unavailable. Valid volume components remain calculable. |
| Missing `TradeInfo` | Keep the volume as unknown-side volume; SV is unavailable rather than misclassifying it as a sell. RVOL, ACC and SI can remain usable. |
| Missing event timestamp | Diagnose it. Exclude the initial incomplete observation or conservatively mark the most recent open bucket unreliable; do not invent an exchange timestamp. |
| Prior-minute trade before buffered publication | Include it in its own minute. New-minute trades cannot enter that candle. |
| Trade after its minute was published, within retained history | Do not repaint. Quarantine only the affected reference minute for future evaluations. Previously published results stay immutable and are explicitly flagged for audit in the diagnostic. |
| Old trade outside the retained reference | Ignore and log; do not contaminate unrelated current data. |
| Zero volume or zero MAD | Show unavailable directional/standardized readings as applicable; no fabricated score or arrow. |

An actually unreliable volume minute can still block all four calculations while present in the reference. It ages out naturally after `N` subsequent evaluations. The update deliberately does not force signals on incomplete data. Price-only or side-only problems preserve other valid readings; each metric's baseline must still contain all `N` usable entries for that metric.

The actual original live failure was not confirmed: no diagnostic from that session was supplied. These are verified code-path fixes, not proof that Rithmic itself was at fault or that your feed cannot contain other issues. Missing/duplicated executions that are not flagged in the delivered stream cannot automatically be detected or recovered by this indicator.

## Event timing and buffering

Bookmap supplies the timestamp for subsequent updates through `TimeListener`; interval callbacks follow its indicator/replay clock, not an independent OS timer [6,7]. The adapter retains the actual callback timestamp. The engine maintains a monotonic observed clock and ignores regressing timer calls rather than moving buckets backwards.

Default close buffer: **200 ms**, adjustable from 0 to 2000. The first clock callback at/after `minute end + buffer` publishes that minute once. A Bookmap interval callback is requested every 100 ms. Live notification timing also depends on feed delivery and processing; neither 100 ms nor 200 ms is an end-to-end execution guarantee.

The buffer intentionally lets trades timestamped inside the finished minute arrive before publication. Trades timestamped in a later minute are stored separately and are excluded from its formulas and reference. The completed candle is inserted into history only after evaluation. Historical `Result` objects are immutable. No unfinished/buffer-pending candle is flushed into a signal at stop.

This is causal as of **notification time**, not an assertion that all included late prints had already arrived at the exact candle boundary. Backtesting must replay arrival/callback order and use actual notification time plus trading latency for hypothetical fills. Do not backdate a buffered decision to the earlier candle-close price.

A first partially observed minute is excluded. The module does not initialize historical time from a live `InitialState` frontier. Bookmap's historical-mode listener requests subscription history and signals the transition to the realtime/replay frontier [8]. Optional audio stays silent during historical catch-up and is off by default.

For long gaps, the engine bounds empty-minute processing, retains the last N consecutive minute slots, and suppresses stale annotations that would otherwise pile up at a reconnect timestamp. The maximum annotation/alert delay is 2 seconds by default and is kept at least the buffer plus one interval. Suppressed stale results remain available in detailed logs. No silent session-time compression occurs.

## Diagnostics

Adapter messages use `velox.api.layer1.common.Log`, Bookmap's native log API [9], instead of relying on stdout redirection. Open **File -> Show log file** [4].

`ES_EXPANSION_DIAG` includes version, alias, reason, running count, event/clock times, affected minute start/end, next unpublished minute, price, quantity, side and action. To bound logging load, the first three occurrences and then powers of two are logged for each issue type. Totals appear on stop. `Log every completed candle` adds all component values, raw quantities, thresholds, status and explanation. Otherwise signals and status transitions are logged.

Useful log keys:

```text
ZERO_SIZE_IGNORED
BUFFERED_LATE_ACCEPTED
LATE_RETAINED_MINUTE_QUARANTINED
STALE_OUTSIDE_REFERENCE
NONFINITE_PRICE
NEGATIVE_SIZE_UNSUPPORTED
MISSING_TIMESTAMP
CURRENT_UNKNOWN_SIDE
BAD_VOLUME_REFERENCE
UNAVAILABLE_SV_REFERENCE
UNAVAILABLE_SI_REFERENCE
ACC_ZERO_MAD / SV_ZERO_MAD / SI_ZERO_MAD
```

No such heading is painted on the chart. Dashes communicate unavailable values without covering the heatmap.

## Build and source layout

```powershell
.\build.ps1
.\build.ps1 -SdkDir "C:\path\to\existing-sdk-jars"
.\build.ps1 -TestOnly
```

```bash
sh build.sh
sh build.sh --sdk-dir /path/to/existing-sdk-jars
sh build.sh --test-only
```

A real SDK build produces `build/libs/es-expansion-v3-chart-3.2.0.jar`. A test-only run does not. The existing quoted PowerShell JVM-option fix is retained. A Gradle build is also provided; no wrapper or downloaded SDK binaries are distributed.

`ExpansionModel` implements the immutable candles, robust statistics and four-way gate. `MinuteEngine` handles event-time buckets, buffering, completion and per-minute reliability. `AnnotationRenderer` draws the transparent image. `EsExpansionV3` is the Bookmap adapter and parameter UI. `AudioAlert` handles optional audio off the data thread. `CoreSelfTest` contains the 62 test groups. `RenderSamples` makes the production-renderer preview.

`tools/contract_preflight.py` is an optional Python/JDK developer check that generates **test doubles, not SDK classes** in a separate build directory. It compiles and runs eight mocked callback scenarios but creates no add-on JAR. Those doubles are never used by `build.ps1`, `build.sh` or Gradle and must not be deployed.

## Primary API references

Accessed during this update; links document contracts, not a claim of installed-runtime validation.

1. Official demo build: https://raw.githubusercontent.com/BookmapAPI/DemoStrategies/master/Strategies/build.gradle
2. Parameter UI/reload contract: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/Parameter.html
3. Indicator icon anchoring: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/Indicator.html
4. Add-on guide, trade conversion, loading and logs: https://bookmap.com/knowledgebase/docs/API-Tutorial
5. Trade metadata: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-core/7.2.0/velox/api/layer1/data/TradeInfo.html
6. TimeListener: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/TimeListener.html
7. IntervalListener: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/IntervalListener.html
8. HistoricalModeListener: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/HistoricalModeListener.html
9. Native logger: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-core/7.2.0/velox/api/layer1/common/Log.html
