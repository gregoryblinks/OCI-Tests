#!/usr/bin/env python3
"""Offline Java syntax/callback preflight using SMALL TEST DOUBLES, NOT the Bookmap SDK.

No JAR is created. Do not use these doubles as SDK dependencies or deploy them.
Actual compatibility still requires build.sh/build.ps1 against Bookmap's official jars.
Python 3.9+ and JDK 17+ are required only for this optional developer check.
"""
from pathlib import Path
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "build" / "contract-preflight"
S = "velox.api.layer1.simplified"
A = "velox.api.layer1.annotations"
D = "velox.api.layer1.data"
G = "velox.api.layer1.messages.indicators.Layer1ApiUserMessageModifyIndicator.GraphType"


def write(full_name: str, body: str) -> None:
    package, name = full_name.rsplit(".", 1)
    target = DEST / "src" / Path(*package.split(".")) / (name + ".java")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("package " + package + ";\n" + body + "\n", encoding="utf-8")


def main() -> None:
    if DEST.exists():
        shutil.rmtree(DEST)
    javac = shutil.which("javac")
    java = shutil.which("java")
    if not javac or not java:
        raise SystemExit("JDK 17+ must be on PATH")
    annotation = "@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME) "
    write(A + ".Layer1SimpleAttachable", annotation + "public @interface Layer1SimpleAttachable {}")
    write(A + ".Layer1StrategyName", annotation + "public @interface Layer1StrategyName { String value(); }")
    write(A + ".Layer1ApiVersionValue", "public enum Layer1ApiVersionValue { VERSION2 }")
    write(A + ".Layer1ApiVersion", annotation + "public @interface Layer1ApiVersion { Layer1ApiVersionValue value(); }")
    write(S + ".Parameter", annotation + "public @interface Parameter { String name(); double minimum() default 0; double maximum() default 1e9; double step() default 1; boolean reloadOnChange() default true; }")
    write(D + ".InstrumentInfo", "public class InstrumentInfo { public final double pips; public InstrumentInfo(double pips) { this.pips=pips; } }")
    write(D + ".TradeInfo", "public class TradeInfo { public final boolean isOtc, isBidAggressor; public TradeInfo(boolean otc, boolean buy) { isOtc=otc; isBidAggressor=buy; } }")
    write("velox.api.layer1.messages.indicators.Layer1ApiUserMessageModifyIndicator", "public class Layer1ApiUserMessageModifyIndicator { public enum GraphType { PRIMARY, BOTTOM } }")
    write("velox.api.layer1.common.Log", "public final class Log { public static void info(String s) { System.out.println(s); } public static void warn(String s) { System.err.println(s); } }")
    write(S + ".InitialState", "public class InitialState {}")
    write(S + ".Api", f"public interface Api {{ Indicator registerIndicator(String name, {G} graphType, double value, boolean line, boolean widget); }}")
    write(S + ".Indicator", "public interface Indicator { void setColor(java.awt.Color color); void addIcon(double value, java.awt.image.BufferedImage icon, int x, int y); }")
    write(S + ".CustomModule", f"public interface CustomModule {{ void initialize(String alias, {D}.InstrumentInfo info, Api api, InitialState state); void stop(); }}")
    write(S + ".TradeDataListener", f"public interface TradeDataListener {{ void onTrade(double price, int size, {D}.TradeInfo tradeInfo); }}")
    write(S + ".TimeListener", "public interface TimeListener { void onTimestamp(long t); }")
    write(S + ".IntervalListener", "public interface IntervalListener { long getInterval(); void onInterval(); }")
    write(S + ".HistoricalModeListener", "public interface HistoricalModeListener { void onRealtimeStart(); }")
    write("preflight.AdapterCheck", r'''
import java.awt.Color;
import java.awt.image.BufferedImage;
import com.example.bookmap.expansion.*;
import velox.api.layer1.data.*;
import velox.api.layer1.simplified.*;
public final class AdapterCheck {
  static final long M=60_000_000_000L;
  static final class MemoryIndicator implements Indicator {
    int count, y; double price; BufferedImage image;
    public void setColor(Color c) { }
    public void addIcon(double p, BufferedImage i, int x, int y) {
      count++; this.y=y; this.price=p; this.image=i;
    }
  }
  static void check(boolean condition) { if(!condition) throw new AssertionError(); }
  static void at(EsExpansionV3 a,long t) { a.onTimestamp(t); }
  static void trade(EsExpansionV3 a,long t,double p,int n,boolean buy) {
    at(a,t); a.onTrade(p,n,new TradeInfo(false,buy));
  }
  static void test(boolean bullish,boolean arrows) {
    EsExpansionV3 a=new EsExpansionV3(); a.closeBufferMilliseconds=0; a.showArrows=arrows;
    MemoryIndicator i=new MemoryIndicator();
    a.initialize("ES-test@RITHMIC",new InstrumentInfo(0.25),(name,type,value,line,widget)->i,new InitialState());
    at(a,0); a.onInterval();
    for(int m=0;m<15;m++) {
      ExpansionModel.Candle c=CoreSelfTest.baseline(m);
      trade(a,m*M+1,c.open,(int)c.buyVolume,true);
      trade(a,(m+1)*M-1,c.close,(int)c.sellVolume,false);
      at(a,(m+1)*M); a.onInterval();
    }
    check(i.count==15);
    a.onRealtimeStart();
    trade(a,15*M+1,24000,bullish?1140:60,true);
    trade(a,16*M-1,24000+(bullish?80:-80),bullish?60:1140,false);
    check(i.count==15); at(a,16*M); a.onInterval(); check(i.count==16);
    check(i.y==(bullish?0:i.image.getHeight()-1));
    check(i.price==(bullish?23998:24002));
    a.onInterval(); check(i.count==16);
    a.stop(); at(a,17*M); a.onInterval(); check(i.count==16);
  }
  static MinuteEngine engine(EsExpansionV3 a) {
    try { var f=EsExpansionV3.class.getDeclaredField("engine"); f.setAccessible(true); return (MinuteEngine)f.get(a); }
    catch(ReflectiveOperationException ex) { throw new AssertionError(ex); }
  }
  static EsExpansionV3 initialized(MemoryIndicator i) {
    EsExpansionV3 a=new EsExpansionV3();
    a.initialize("ES-mock@RITHMIC",new InstrumentInfo(0.25),(name,type,value,line,widget)->i,new InitialState());
    at(a,0); a.onInterval(); return a;
  }
  static void defaultBuffer() {
    MemoryIndicator i=new MemoryIndicator(); EsExpansionV3 a=initialized(i); long g=200_000_000L;
    for(int m=0;m<16;m++) {
      ExpansionModel.Candle c=m<15?CoreSelfTest.baseline(m):CoreSelfTest.candle(m,1200,1140,80,true,false);
      trade(a,m*M+g+1,c.open,(int)c.buyVolume,true);
      trade(a,(m+1)*M-1,c.close,(int)c.sellVolume,false);
      at(a,(m+1)*M); a.onInterval(); check(i.count==m);
      at(a,(m+1)*M+g); a.onInterval(); check(i.count==m+1);
    }
    check(i.y==0&&i.price==23998); a.stop();
  }
  static void zeroNoise() {
    MemoryIndicator i=new MemoryIndicator(); EsExpansionV3 a=initialized(i);
    trade(a,1,100,5,true); at(a,2); a.onTrade(Double.NaN,0,null);
    at(a,M+200_000_000L); a.onInterval();
    check(engine(a).ignoredZeroSizeTrades()==1&&engine(a).invalidTrades()==0&&engine(a).historySize()==1);
    a.stop();
  }
  static void bufferedPrint() {
    MemoryIndicator i=new MemoryIndicator(); EsExpansionV3 a=initialized(i);
    trade(a,1,100,5,true); at(a,M); a.onInterval();
    trade(a,M+100_000_000L,200,900,true); trade(a,M-1,101,7,false);
    check(i.count==0); at(a,M+200_000_000L); a.onInterval();
    check(i.count==1&&engine(a).bufferedLateTrades()==1&&engine(a).droppedLateTrades()==0); a.stop();
  }
  static void trueCallbackTime() {
    MemoryIndicator i=new MemoryIndicator(); EsExpansionV3 a=initialized(i);
    at(a,10*M); at(a,1); a.onInterval();
    check(engine(a).clockNs()==1&&i.count==0); a.stop();
  }
  static void missingMetadata() {
    MemoryIndicator i=new MemoryIndicator(); EsExpansionV3 a=initialized(i);
    for(int m=0;m<16;m++) {
      ExpansionModel.Candle c=m<15?CoreSelfTest.baseline(m):CoreSelfTest.candle(m,1200,1140,80,true,false);
      at(a,m*M+200_000_001L);
      a.onTrade(c.open,(int)c.buyVolume,m==15?null:new TradeInfo(false,true));
      trade(a,(m+1)*M-1,c.close,(int)c.sellVolume,false);
      at(a,(m+1)*M+200_000_000L); a.onInterval();
    }
    check(i.count==16&&i.image.getHeight()<75); a.stop();
  }
  public static void main(String[] args) {
    test(true,true); test(false,true); test(true,false);
    defaultBuffer(); zeroNoise(); bufferedPrint(); trueCallbackTime(); missingMetadata();
    System.out.println("PASS: adapter syntax and 8 mocked callback scenarios; NOT an SDK/runtime compatibility test.");
  }
}
''')
    sources = [str(p) for p in (DEST / "src").rglob("*.java")]
    sources += [str(p) for p in (ROOT / "src/main/java").rglob("*.java")]
    sources += [str(p) for p in (ROOT / "src/test/java").rglob("*.java")]
    classes = DEST / "classes"
    classes.mkdir(parents=True)
    subprocess.run([javac, "--release", "17", "-encoding", "UTF-8", "-Xlint:all", "-d", str(classes), *sources], check=True)
    subprocess.run([java, "-Djava.awt.headless=true", "-cp", str(classes), "preflight.AdapterCheck"], check=True)
    print("TEST DOUBLES ONLY. Use the real SDK build before loading into Bookmap.")


if __name__ == "__main__":
    main()
