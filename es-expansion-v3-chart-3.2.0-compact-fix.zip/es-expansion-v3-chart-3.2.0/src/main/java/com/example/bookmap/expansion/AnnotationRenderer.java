package com.example.bookmap.expansion;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import static com.example.bookmap.expansion.ExpansionModel.*;

/** Transparent glyphs ONLY: four vertical readings and an optional directional arrow. */
public final class AnnotationRenderer {
    public static final Color BULL = new Color(55, 222, 132);
    public static final Color BEAR = new Color(255, 102, 116);
    public static final Color COMMON_PASS = new Color(247, 202, 91);
    public static final Color NEUTRAL = new Color(210, 215, 223);
    private static final Color OUTLINE = new Color(0, 0, 0, 190);
    private static final String[] NAMES = {"RVOL", "ACC", "SV", "SI"};
    private static final int PAD = 3, ARROW_HEIGHT = 15, ARROW_HALF_WIDTH = 5, SEPARATION = 3;

    public static final class Settings {
        public final boolean showArrows, showLabels;
        public final int labelMode, fontSize, gapPixels, noSignalPlacement;
        public final double priceOffsetTicks;
        public Settings(boolean showArrows, boolean showLabels, int labelMode, int fontSize,
                int gapPixels, int noSignalPlacement, double priceOffsetTicks) {
            if (labelMode < 0 || labelMode > 2 || fontSize < 9 || fontSize > 20
                    || gapPixels < 0 || gapPixels > 40 || noSignalPlacement < 0 || noSignalPlacement > 2
                    || !Double.isFinite(priceOffsetTicks) || priceOffsetTicks < 0 || priceOffsetTicks > 50) {
                throw new IllegalArgumentException("Invalid annotation settings");
            }
            this.showArrows = showArrows;
            this.showLabels = showLabels;
            this.labelMode = labelMode;
            this.fontSize = fontSize;
            this.gapPixels = gapPixels;
            this.noSignalPlacement = noSignalPlacement;
            this.priceOffsetTicks = priceOffsetTicks;
        }
    }
    public static final class Annotation {
        public final BufferedImage image;
        public final int anchorX, anchorY, textTop, rowHeight, arrowTipY;
        public final double priceLevel;
        public final boolean below, arrowVisible, labelVisible;
        public final List<String> rows;
        Annotation(BufferedImage image, int anchorX, int anchorY, double priceLevel,
                boolean below, boolean arrowVisible, boolean labelVisible,
                List<String> rows, int textTop, int rowHeight, int arrowTipY) {
            this.image = image;
            this.anchorX = anchorX;
            this.anchorY = anchorY;
            this.priceLevel = priceLevel;
            this.below = below;
            this.arrowVisible = arrowVisible;
            this.labelVisible = labelVisible;
            this.rows = List.copyOf(rows);
            this.textTop = textTop;
            this.rowHeight = rowHeight;
            this.arrowTipY = arrowTipY;
        }
    }
    private final Settings settings;
    public AnnotationRenderer(Settings settings) { this.settings = Objects.requireNonNull(settings); }

    /** No box, heading, time, status text, threshold column, or reserved space for a hidden arrow. */
    public Annotation render(Result result) {
        boolean signal = result.signal != Signal.NONE;
        boolean arrow = signal && settings.showArrows;
        boolean label = settings.showLabels && (settings.labelMode == 0
                || settings.labelMode == 1 && result.anyPass() || settings.labelMode == 2 && signal);
        if (!arrow && !label) return null;
        boolean below = result.signal == Signal.BULLISH || result.signal != Signal.BEARISH
                && (settings.noSignalPlacement == 1 || settings.noSignalPlacement == 0
                        && result.candle.close >= result.candle.open);
        double price = below ? result.candle.low - settings.priceOffsetTicks
                : result.candle.high + settings.priceOffsetTicks;
        if (!Double.isFinite(price)) return null;

        Font font = new Font(Font.MONOSPACED, Font.BOLD, settings.fontSize);
        BufferedImage measuring = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics2D measure = measuring.createGraphics();
        measure.setFont(font);
        FontMetrics fm = measure.getFontMetrics();
        int rowHeight = fm.getHeight(), ascent = fm.getAscent();
        int nameWidth = fm.stringWidth("RVOL"), columnGap = fm.charWidth(' ');
        String[] values = {format(result.rvol, false), format(result.accelerationZ, true),
                format(result.signedVolumeZ, true), format(result.signedImpactZ, true)};
        String[] rows = new String[4];
        int valueWidth = 0;
        for (int i = 0; i < 4; i++) {
            valueWidth = Math.max(valueWidth, fm.stringWidth(values[i]));
            rows[i] = String.format(Locale.ROOT, "%-4s %s", NAMES[i], values[i]);
        }
        measure.dispose();
        int textWidth = nameWidth + columnGap + valueWidth;
        int labelHeight = label ? 4 * rowHeight : 0;
        int arrowHeight = arrow ? ARROW_HEIGHT : 0;
        int separator = arrow && label ? SEPARATION : 0;
        int width = 2 * PAD + Math.max(label ? textWidth : 0, arrow ? 2 * ARROW_HALF_WIDTH : 0);
        int height = 2 * PAD + settings.gapPixels + labelHeight + arrowHeight + separator;
        int anchorX = width / 2, anchorY = below ? 0 : height - 1;
        int textTop = below ? PAD + settings.gapPixels + arrowHeight + separator : PAD;
        int tipY = arrow ? (below ? PAD + settings.gapPixels : height - PAD - settings.gapPixels - 1) : -1;

        // TYPE_INT_ARGB starts fully transparent. NEVER fill a rectangle or background.
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setFont(font);
        if (label) {
            Color[] colors = {result.rvolPass() ? COMMON_PASS : NEUTRAL,
                    result.accelerationPass() ? COMMON_PASS : NEUTRAL,
                    directionalColor(result.signedVolumeZ, result.parameters.svThreshold),
                    directionalColor(result.signedImpactZ, result.parameters.siThreshold)};
            int x = (width - textWidth) / 2;
            for (int i = 0; i < 4; i++) {
                int y = textTop + ascent + i * rowHeight;
                outlinedText(g, NAMES[i], x, y, NEUTRAL);
                outlinedText(g, values[i], x + nameWidth + columnGap, y, colors[i]);
            }
        }
        if (arrow) {
            int direction = below ? 1 : -1;
            Polygon shape = new Polygon(new int[] {anchorX, anchorX - 5, anchorX - 2, anchorX - 2,
                        anchorX + 2, anchorX + 2, anchorX + 5},
                    new int[] {tipY, tipY + direction * 6, tipY + direction * 6,
                        tipY + direction * ARROW_HEIGHT, tipY + direction * ARROW_HEIGHT,
                        tipY + direction * 6, tipY + direction * 6}, 7);
            g.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(OUTLINE); g.draw(shape);
            g.setColor(result.signal == Signal.BULLISH ? BULL : BEAR); g.fill(shape);
        }
        g.dispose();
        return new Annotation(image, anchorX, anchorY, price, below, arrow, label,
                label ? List.of(rows) : List.of(), textTop, rowHeight, tipY);
    }
    private static void outlinedText(Graphics2D g, String text, int x, int y, Color color) {
        Shape glyphs = g.getFont().createGlyphVector(g.getFontRenderContext(), text).getOutline(x, y);
        g.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(OUTLINE); g.draw(glyphs);
        g.setColor(color); g.fill(glyphs);
    }
    private static Color directionalColor(double value, double threshold) {
        if (Double.isFinite(value) && value >= threshold) return BULL;
        if (Double.isFinite(value) && value <= -threshold) return BEAR;
        return NEUTRAL;
    }
    private static String format(double value, boolean signed) {
        if (!Double.isFinite(value)) return "\u2014";
        // Avoid unbounded-width labels for unusually large z-scores; calculations are NOT clipped.
        if (Math.abs(value) >= 1000) return String.format(Locale.ROOT, signed ? "%+.1e" : "%.1e", value)
                + (signed ? "z" : "\u00d7");
        return String.format(Locale.ROOT, signed ? "%+.2fz" : "%.2f\u00d7", value);
    }
}
