package com.example.bookmap.expansion;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.Objects;

/** Pure, deterministic research model. No Bookmap classes, wall clock, or order book. */
public final class ExpansionModel {
    private ExpansionModel() { }
    public static final long MINUTE_NS = 60_000_000_000L;
    public static final double MAD_NORMALIZATION = 1.4826;

    public enum Side { BUY, SELL, UNKNOWN }
    public enum Signal { NONE, BULLISH, BEARISH }
    public enum Status { WARMUP, PARTIAL, NO_TRADES, INVALID_DATA, UNDEFINED, READY }

    public static final class Parameters {
        public final int lookback;
        public final double rvolThreshold, accelerationThreshold, svThreshold, siThreshold;
        public final double priceIncrement;

        public Parameters(int lookback, double rvolThreshold, double accelerationThreshold,
                double svThreshold, double siThreshold, double priceIncrement) {
            if (lookback < 2 || lookback > 240) {
                throw new IllegalArgumentException("Lookback must be between 2 and 240 minutes");
            }
            for (double x : new double[] {rvolThreshold, accelerationThreshold,
                    svThreshold, siThreshold, priceIncrement}) {
                if (!Double.isFinite(x) || x <= 0) {
                    throw new IllegalArgumentException("Thresholds and price increment must be finite and positive");
                }
            }
            this.lookback = lookback;
            this.rvolThreshold = rvolThreshold;
            this.accelerationThreshold = accelerationThreshold;
            this.svThreshold = svThreshold;
            this.siThreshold = siThreshold;
            this.priceIncrement = priceIncrement;
        }
    }

    /** Immutable candle. Prices are Bookmap price levels; quantities are raw trade-size units. */
    public static final class Candle {
        public final long startNs, endNs, volume, buyVolume, sellVolume, unknownVolume;
        public final double open, high, low, close;
        public final boolean complete, tainted, priceTainted;

        public Candle(long startNs, double open, double high, double low, double close,
                long buyVolume, long sellVolume, long unknownVolume,
                boolean complete, boolean tainted) {
            this(startNs, open, high, low, close, buyVolume, sellVolume, unknownVolume, complete, tainted, false);
        }
        public Candle(long startNs, double open, double high, double low, double close,
                long buyVolume, long sellVolume, long unknownVolume,
                boolean complete, boolean tainted, boolean priceTainted) {
            if (startNs < 0 || startNs % MINUTE_NS != 0) {
                throw new IllegalArgumentException("Candle start must be a nonnegative UTC minute boundary");
            }
            if (buyVolume < 0 || sellVolume < 0 || unknownVolume < 0) {
                throw new IllegalArgumentException("Negative volume is not an ordinary trade");
            }
            this.startNs = startNs;
            this.endNs = Math.addExact(startNs, MINUTE_NS);
            this.open = open;
            this.high = high;
            this.low = low;
            this.close = close;
            this.buyVolume = buyVolume;
            this.sellVolume = sellVolume;
            this.unknownVolume = unknownVolume;
            this.volume = Math.addExact(Math.addExact(buyVolume, sellVolume), unknownVolume);
            this.complete = complete;
            this.tainted = tainted;
            this.priceTainted = priceTainted;
        }
        public Candle withUnreliableVolume() {
            return new Candle(startNs, open, high, low, close, buyVolume, sellVolume, unknownVolume,
                    complete, true, priceTainted);
        }
        public boolean reliableVolume() { return complete && !tainted; }
        public boolean hasTrades() { return volume > 0; }
        public boolean validPrices() {
            return Double.isFinite(open) && Double.isFinite(high) && Double.isFinite(low)
                    && Double.isFinite(close) && high >= Math.max(open, close)
                    && low <= Math.min(open, close) && high >= low;
        }
        public double signedVolume() {
            // Never silently classify UNKNOWN executions as sell orders or omit them from the denominator.
            if (!complete || !hasTrades() || unknownVolume != 0 || tainted) return Double.NaN;
            return ((double) buyVolume - (double) sellVolume) / volume;
        }
        public double signedImpact(double priceIncrement) {
            if (!complete || !hasTrades() || tainted || priceTainted || !validPrices()) return Double.NaN;
            return (close - open) * priceIncrement / volume;
        }
    }

    public static final class Result {
        public final Candle candle;
        public final Parameters parameters;
        public final int historyCount;
        public final double rvol, accelerationZ, signedVolumeZ, signedImpactZ;
        public final double medianVolume, volumeMad, signedVolumeRaw, signedImpactRaw;
        public final Status status;
        public final Signal signal;
        /** Log-only explanation; never rendered as a chart heading or a data box. */
        public final String detail;

        Result(Candle candle, Parameters parameters, int historyCount, double rvol,
                double accelerationZ, double signedVolumeZ, double signedImpactZ,
                double medianVolume, double volumeMad, Status status, String detail) {
            this.candle = candle;
            this.parameters = parameters;
            this.historyCount = historyCount;
            this.rvol = rvol;
            this.accelerationZ = accelerationZ;
            this.signedVolumeZ = signedVolumeZ;
            this.signedImpactZ = signedImpactZ;
            this.medianVolume = medianVolume;
            this.volumeMad = volumeMad;
            this.signedVolumeRaw = candle.signedVolume();
            this.signedImpactRaw = candle.signedImpact(parameters.priceIncrement);
            this.status = status;
            this.detail = detail;
            this.signal = status == Status.READY
                    ? decide(rvol, accelerationZ, signedVolumeZ, signedImpactZ, parameters) : Signal.NONE;
        }
        public boolean rvolPass() { return Double.isFinite(rvol) && rvol >= parameters.rvolThreshold; }
        public boolean accelerationPass() {
            return Double.isFinite(accelerationZ) && accelerationZ >= parameters.accelerationThreshold;
        }
        public boolean anyPass() {
            return rvolPass() || accelerationPass()
                || (Double.isFinite(signedVolumeZ) && Math.abs(signedVolumeZ) >= parameters.svThreshold)
                || (Double.isFinite(signedImpactZ) && Math.abs(signedImpactZ) >= parameters.siThreshold);
        }
    }

    /** Exact requested four-way gate. Positive/negative z is relative to its own prior median. */
    public static Signal decide(double rvol, double accelerationZ, double svZ, double siZ, Parameters p) {
        if (!Double.isFinite(rvol) || !Double.isFinite(accelerationZ)
                || !Double.isFinite(svZ) || !Double.isFinite(siZ)
                || rvol < p.rvolThreshold || accelerationZ < p.accelerationThreshold) return Signal.NONE;
        if (svZ >= p.svThreshold && siZ >= p.siThreshold) return Signal.BULLISH;
        if (svZ <= -p.svThreshold && siZ <= -p.siThreshold) return Signal.BEARISH;
        return Signal.NONE;
    }

    public static double median(double[] values) {
        if (values.length == 0) return Double.NaN;
        double[] sorted = values.clone();
        for (double v : sorted) if (!Double.isFinite(v)) return Double.NaN;
        Arrays.sort(sorted);
        int m = sorted.length / 2;
        return (sorted.length & 1) == 1 ? sorted[m] : sorted[m - 1] / 2.0 + sorted[m] / 2.0;
    }
    public static double mad(double[] values, double center) {
        if (!Double.isFinite(center)) return Double.NaN;
        double[] deviations = new double[values.length];
        for (int i = 0; i < values.length; i++) deviations[i] = Math.abs(values[i] - center);
        return median(deviations);
    }
    public static double robustZ(double value, double[] reference) {
        if (!Double.isFinite(value)) return Double.NaN;
        double center = median(reference);
        double scale = MAD_NORMALIZATION * mad(reference, center);
        // Deliberately no epsilon denominator, infinite scores, or undisclosed SD fallback.
        if (!Double.isFinite(scale) || scale <= 0) return Double.NaN;
        double z = (value - center) / scale;
        return Double.isFinite(z) ? z : Double.NaN;
    }

    /** Previous N consecutive COMPLETED minutes. Bad minutes occupy a slot, never compress time. */
    public static final class Window {
        private final Parameters parameters;
        private final Deque<Candle> history = new ArrayDeque<>();
        private long lastEndNs = -1;
        public Window(Parameters parameters) { this.parameters = Objects.requireNonNull(parameters); }
        public int size() { return history.size(); }
        public void reset() { history.clear(); lastEndNs = -1; }

        /** Quarantine ONLY the affected retained minute. Already emitted Result objects stay immutable. */
        public boolean invalidateMinute(long startNs) {
            boolean found = false;
            Deque<Candle> replacement = new ArrayDeque<>();
            for (Candle c : history) {
                if (c.startNs == startNs) { replacement.addLast(c.withUnreliableVolume()); found = true; }
                else replacement.addLast(c);
            }
            if (found) { history.clear(); history.addAll(replacement); }
            return found;
        }
        public Result accept(Candle current) {
            Objects.requireNonNull(current);
            if (lastEndNs >= 0 && current.startNs < lastEndNs) {
                throw new IllegalArgumentException("Completed candles must be supplied once, in chronological order");
            }
            if (lastEndNs >= 0 && current.startNs != lastEndNs) history.clear();
            lastEndNs = current.endNs;
            if (!current.complete) {
                int count = history.size();
                history.clear(); // Only the initially observed partial candle is intentionally excluded.
                return unavailable(current, count, Status.PARTIAL, "INITIAL_PARTIAL_MINUTE_EXCLUDED");
            }
            Result result;
            if (history.size() < parameters.lookback) {
                boolean invalid = current.tainted || current.priceTainted
                        || current.hasTrades() && !current.validPrices();
                result = unavailable(current, history.size(), invalid ? Status.INVALID_DATA : Status.WARMUP,
                        "REFERENCE=" + history.size() + "/" + parameters.lookback
                        + (current.tainted ? ";CURRENT_VOLUME_UNRELIABLE" : "")
                        + (current.priceTainted ? ";CURRENT_PRICE_UNRELIABLE" : ""));
            } else {
                double[] volumes = new double[parameters.lookback];
                double[] signed = new double[parameters.lookback];
                double[] impacts = new double[parameters.lookback];
                int i = 0, badVolumes = 0, badSigned = 0, badImpacts = 0;
                for (Candle past : history) {
                    volumes[i] = past.reliableVolume() ? past.volume : Double.NaN;
                    signed[i] = past.signedVolume();
                    impacts[i] = past.signedImpact(parameters.priceIncrement);
                    if (!Double.isFinite(volumes[i])) badVolumes++;
                    if (!Double.isFinite(signed[i])) badSigned++;
                    if (!Double.isFinite(impacts[i])) badImpacts++;
                    i++;
                }
                double med = median(volumes);
                double currentVolume = current.reliableVolume() ? current.volume : Double.NaN;
                double rv = med > 0 ? currentVolume / med : Double.NaN;
                // ACC remains robust z(VOLUME LEVEL), NOT a volume derivative.
                double acc = robustZ(currentVolume, volumes);
                double sv = robustZ(current.signedVolume(), signed);
                double si = robustZ(current.signedImpact(parameters.priceIncrement), impacts);
                boolean allFinite = Double.isFinite(rv) && Double.isFinite(acc)
                        && Double.isFinite(sv) && Double.isFinite(si);
                Status status = current.tainted || current.priceTainted || badVolumes > 0
                        || current.hasTrades() && !current.validPrices() ? Status.INVALID_DATA
                        : !current.hasTrades() ? Status.NO_TRADES : allFinite ? Status.READY : Status.UNDEFINED;
                String detail = "OK";
                if (status != Status.READY) {
                    StringBuilder why = new StringBuilder();
                    if (current.tainted) why.append("CURRENT_VOLUME_UNRELIABLE;");
                    if (current.priceTainted || current.hasTrades() && !current.validPrices())
                        why.append("CURRENT_PRICE_UNRELIABLE;");
                    if (!current.hasTrades()) why.append("NO_TRADES;");
                    if (current.unknownVolume > 0) why.append("CURRENT_UNKNOWN_SIDE;");
                    if (badVolumes > 0) why.append("BAD_VOLUME_REFERENCE=").append(badVolumes).append(';');
                    if (badSigned > 0) why.append("UNAVAILABLE_SV_REFERENCE=").append(badSigned).append(';');
                    if (badImpacts > 0) why.append("UNAVAILABLE_SI_REFERENCE=").append(badImpacts).append(';');
                    if (!(med > 0)) why.append("RVOL_MEDIAN_NOT_POSITIVE_OR_UNAVAILABLE;");
                    if (!Double.isFinite(acc) && badVolumes == 0 && current.reliableVolume()) why.append("ACC_ZERO_MAD;");
                    if (!Double.isFinite(sv) && badSigned == 0 && Double.isFinite(current.signedVolume()))
                        why.append("SV_ZERO_MAD;");
                    if (!Double.isFinite(si) && badImpacts == 0 && Double.isFinite(current.signedImpact(parameters.priceIncrement)))
                        why.append("SI_ZERO_MAD;");
                    detail = why.toString();
                }
                result = new Result(current, parameters, history.size(), rv, acc, sv, si,
                        med, mad(volumes, med), status, detail);
            }
            // Evaluate BEFORE insert: the current candle is NEVER part of its own baseline.
            // Invalid complete bars remain explicit unavailable slots until they age out naturally.
            history.addLast(current);
            while (history.size() > parameters.lookback) history.removeFirst();
            return result;
        }
        private Result unavailable(Candle c, int count, Status status, String detail) {
            return new Result(c, parameters, count, Double.NaN, Double.NaN, Double.NaN, Double.NaN,
                    Double.NaN, Double.NaN, status, detail);
        }
    }
}
