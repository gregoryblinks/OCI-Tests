package com.example.bookmap.expansion;

import java.awt.Color;
import java.time.Instant;
import java.util.EnumMap;
import java.util.Locale;
import velox.api.layer1.annotations.Layer1ApiVersion;
import velox.api.layer1.annotations.Layer1ApiVersionValue;
import velox.api.layer1.annotations.Layer1SimpleAttachable;
import velox.api.layer1.annotations.Layer1StrategyName;
import velox.api.layer1.common.Log;
import velox.api.layer1.data.InstrumentInfo;
import velox.api.layer1.data.TradeInfo;
import velox.api.layer1.messages.indicators.Layer1ApiUserMessageModifyIndicator.GraphType;
import velox.api.layer1.simplified.Api;
import velox.api.layer1.simplified.CustomModule;
import velox.api.layer1.simplified.HistoricalModeListener;
import velox.api.layer1.simplified.Indicator;
import velox.api.layer1.simplified.InitialState;
import velox.api.layer1.simplified.IntervalListener;
import velox.api.layer1.simplified.Parameter;
import velox.api.layer1.simplified.TimeListener;
import velox.api.layer1.simplified.TradeDataListener;
import static com.example.bookmap.expansion.ExpansionModel.*;

/** Display-only executed-trade indicator. No order submission, MBO, or order-book calculations. */
@Layer1SimpleAttachable
@Layer1StrategyName("ES Expansion V3.2 - compact arrows + metrics")
@Layer1ApiVersion(Layer1ApiVersionValue.VERSION2)
public final class EsExpansionV3 implements CustomModule, TradeDataListener, TimeListener,
        IntervalListener, HistoricalModeListener {
    public static final String VERSION = "3.2.0";
    @Parameter(name = "Lookback (completed minutes)", minimum = 2, maximum = 240, step = 1)
    public Integer lookback = 15;
    @Parameter(name = "RVOL threshold (x)", minimum = 0.1, maximum = 100, step = 0.1)
    public Double rvolThreshold = 2.0;
    @Parameter(name = "ACC threshold (robust z of VOLUME LEVEL)", minimum = 0.1, maximum = 20, step = 0.1)
    public Double accelerationThreshold = 2.0;
    @Parameter(name = "SV threshold (+/- robust z)", minimum = 0.1, maximum = 20, step = 0.1)
    public Double svThreshold = 2.0;
    @Parameter(name = "SI threshold (+/- robust z)", minimum = 0.1, maximum = 20, step = 0.1)
    public Double siThreshold = 2.0;
    @Parameter(name = "Show full-signal arrows")
    public Boolean showArrows = true;
    @Parameter(name = "Show four vertical readings")
    public Boolean showLabels = true;
    @Parameter(name = "Labels: 0 every candle, 1 any pass, 2 full signals", minimum = 0, maximum = 2, step = 1)
    public Integer labelMode = 0;
    @Parameter(name = "No-signal placement: 0 candle direction, 1 below, 2 above", minimum = 0, maximum = 2, step = 1)
    public Integer noSignalPlacement = 0;
    // New field name avoids an inherited large font preference from the boxed version.
    @Parameter(name = "Compact text size (pixels)", minimum = 9, maximum = 20, step = 1)
    public Integer compactFontSize = 11;
    @Parameter(name = "Arrow distance beyond high/low (ticks)", minimum = 0, maximum = 50, step = 1)
    public Double priceOffsetTicks = 2.0;
    @Parameter(name = "Extra visual gap (pixels)", minimum = 0, maximum = 40, step = 1)
    public Integer gapPixels = 3;
    @Parameter(name = "Close buffer (ms): 0 immediate; 200 recommended default", minimum = 0, maximum = 2000, step = 50)
    public Integer closeBufferMilliseconds = 200;
    @Parameter(name = "Audio for confirmed signals (catch-up history stays silent)")
    public Boolean enableAudio = false;
    @Parameter(name = "Exclude OTC trades")
    public Boolean excludeOtc = true;
    @Parameter(name = "Log every completed candle (otherwise signals/status changes)")
    public Boolean logEveryCandle = false;
    @Parameter(name = "Maximum annotation/alert clock delay (seconds)", minimum = 0.1, maximum = 30, step = 0.1)
    public Double maximumEventDelaySeconds = 2.0;

    private String alias;
    private MinuteEngine engine;
    private Indicator annotations;
    private AnnotationRenderer renderer;
    private AudioAlert audio;
    private boolean running, caughtUp;
    private long eventTimestampNs = -1, realtimeGateNs = Long.MAX_VALUE;
    private long maximumEventDelayNs, suppressedStaleAnnotations;
    private Status lastLoggedStatus;
    private final EnumMap<MinuteEngine.Issue, Long> issueCounts = new EnumMap<>(MinuteEngine.Issue.class);

    @Override public void initialize(String alias, InstrumentInfo info, Api api, InitialState initialState) {
        this.alias = alias;
        Parameters parameters = new Parameters(lookback, rvolThreshold, accelerationThreshold,
                svThreshold, siThreshold, info.pips);
        renderer = new AnnotationRenderer(new AnnotationRenderer.Settings(showArrows, showLabels,
                labelMode, compactFontSize, gapPixels, noSignalPlacement, priceOffsetTicks));
        long graceNs = closeBufferMilliseconds * 1_000_000L;
        if (!Double.isFinite(maximumEventDelaySeconds) || maximumEventDelaySeconds < 0.1)
            throw new IllegalArgumentException("Maximum event delay must be finite and at least 0.1 seconds");
        maximumEventDelayNs = Math.max((long) (maximumEventDelaySeconds * 1_000_000_000L), graceNs + getInterval());
        annotations = api.registerIndicator("ES Expansion V3.2 compact annotations", GraphType.PRIMARY,
                Double.NaN, true, false);
        annotations.setColor(new Color(0, 0, 0, 0)); // addIcon only; no line or bottom pane
        if (audio != null) audio.close();
        audio = enableAudio ? new AudioAlert() : null;
        issueCounts.clear();
        engine = new MinuteEngine(parameters, graceNs, this::onCompletedMinute, this::onDiagnostic);
        eventTimestampNs = -1;
        realtimeGateNs = Long.MAX_VALUE;
        suppressedStaleAnnotations = 0;
        lastLoggedStatus = null;
        caughtUp = false;
        running = true;
        // Do not seed history from InitialState's live frontier before Bookmap replays older events.
        Log.info("ES Expansion " + VERSION + " initialized for " + alias
                + "; N=" + lookback + "; closeBufferMs=" + closeBufferMilliseconds
                + "; compactFont=" + compactFontSize + "; labels=" + showLabels + "; arrows=" + showArrows
                + "; ACC=robust z(volume level); trades only; research parameters, not a profitability claim");
    }
    @Override public void onTimestamp(long timestampNs) {
        if (!running) return;
        // This timestamp belongs to subsequent callbacks. Do not replace it with an unrelated max clock.
        eventTimestampNs = timestampNs;
    }
    @Override public long getInterval() { return 100_000_000L; }
    @Override public void onInterval() {
        if (running && eventTimestampNs >= 0) engine.onClock(eventTimestampNs);
    }
    @Override public void onTrade(double price, int size, TradeInfo tradeInfo) {
        if (!running) return;
        if (tradeInfo != null && excludeOtc && tradeInfo.isOtc) return;
        // A bid aggressor is the buyer initiating a trade, NOT a seller hitting the bid.
        Side side = tradeInfo == null ? Side.UNKNOWN : tradeInfo.isBidAggressor ? Side.BUY : Side.SELL;
        engine.onTrade(eventTimestampNs, price, size, side);
    }
    @Override public void onRealtimeStart() {
        if (!running) return;
        caughtUp = true;
        realtimeGateNs = Math.max(eventTimestampNs, engine.clockNs());
        // In replay this is the replay frontier, not proof that the exchange feed is live.
    }
    private void onDiagnostic(MinuteEngine.Diagnostic d) {
        long count = issueCounts.merge(d.issue, 1L, Long::sum);
        // First three and powers of two: retain exact examples without flooding the data thread.
        if (count > 3 && (count & (count - 1)) != 0) return;
        String action;
        switch (d.issue) {
            case ZERO_SIZE_IGNORED: action = "zero contracts ignored; reference unchanged"; break;
            case BUFFERED_LATE_ACCEPTED: action = "included before publication inside close buffer"; break;
            case STALE_OUTSIDE_REFERENCE: action = "ignored outside retained reference; current minute unchanged"; break;
            case LATE_RETAINED_MINUTE_QUARANTINED:
                action = "affected reference minute quarantined; published results NOT revised; audit prior signals"; break;
            case NONFINITE_PRICE: action = "quantity/side retained; affected minute SI unavailable"; break;
            default: action = "affected minute unavailable; no blanket reference reset";
        }
        Log.warn(String.format(Locale.ROOT,
                "ES_EXPANSION_DIAG version=%s alias=%s reason=%s count=%d event=%s clock=%s "
                + "affectedStart=%s affectedEnd=%s nextUnpublished=%s price=%s size=%d side=%s action=%s",
                VERSION, alias, d.issue, count, time(d.eventNs), time(d.clockNs), time(d.affectedStartNs),
                d.affectedStartNs < 0 ? "NA" : time(d.affectedStartNs + MINUTE_NS),
                time(d.nextUnpublishedStartNs), Double.toString(d.price), d.size, d.side, action));
    }
    private void onCompletedMinute(Result result, long notificationNs) {
        if (!running) return;
        boolean timely = notificationNs >= result.candle.endNs
                && notificationNs - result.candle.endNs <= maximumEventDelayNs;
        // addIcon has no timestamp argument: publish at callback time, never backdate an entry cue.
        if (timely) {
            AnnotationRenderer.Annotation annotation = renderer.render(result);
            if (annotation != null) annotations.addIcon(annotation.priceLevel, annotation.image,
                    annotation.anchorX, annotation.anchorY);
        } else suppressedStaleAnnotations++;
        if (logEveryCandle || result.signal != Signal.NONE || result.status != lastLoggedStatus) {
            Log.info(String.format(Locale.ROOT,
                    "ES_EXPANSION version=%s alias=%s end=%s notification=%s status=%s signal=%s "
                    + "V=%d B=%d S=%d UNKNOWN=%d RVOL=%.6f ACCz=%.6f SVraw=%.6f SVz=%.6f SIraw=%.9f SIz=%.6f "
                    + "reference=%d/%d thresholds=[%.3f,%.3f,%.3f,%.3f] timely=%s detail=%s",
                    VERSION, alias, time(result.candle.endNs), time(notificationNs), result.status, result.signal,
                    result.candle.volume, result.candle.buyVolume, result.candle.sellVolume, result.candle.unknownVolume,
                    result.rvol, result.accelerationZ, result.signedVolumeRaw, result.signedVolumeZ,
                    result.signedImpactRaw, result.signedImpactZ, result.historyCount, result.parameters.lookback,
                    result.parameters.rvolThreshold, result.parameters.accelerationThreshold,
                    result.parameters.svThreshold, result.parameters.siThreshold, timely, result.detail));
        }
        lastLoggedStatus = result.status;
        if (audio != null && caughtUp && timely && result.candle.endNs > realtimeGateNs
                && result.signal != Signal.NONE) audio.play(result.signal == Signal.BULLISH);
    }
    private static String time(long nanos) {
        return nanos < 0 ? "NA" : Instant.ofEpochSecond(nanos / 1_000_000_000L,
                nanos % 1_000_000_000L).toString();
    }
    @Override public void stop() {
        running = false;
        if (audio != null) { audio.close(); audio = null; }
        if (engine != null) Log.info("ES Expansion " + VERSION + " stopped for " + alias
                + "; completed=" + engine.completedCandles() + "; late=" + engine.droppedLateTrades()
                + "; acceptedInBuffer=" + engine.bufferedLateTrades() + "; quarantined=" + engine.quarantinedLateTrades()
                + "; stale=" + engine.staleTrades() + "; zeroSize=" + engine.ignoredZeroSizeTrades()
                + "; invalid=" + engine.invalidTrades() + "; skippedEmpty=" + engine.skippedEmptyMinutes()
                + "; staleAnnotations=" + suppressedStaleAnnotations + "; issues=" + issueCounts);
        // No flush: an open or not-yet-finalized minute does not become a confirmed signal on shutdown.
    }
}
