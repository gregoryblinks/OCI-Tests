package com.example.bookmap.expansion;

import java.util.Objects;
import java.util.TreeMap;
import static com.example.bookmap.expansion.ExpansionModel.*;

/** Event-time one-minute buckets. Called serially by Bookmap, never by an OS/wall-clock timer. */
public final class MinuteEngine {
    @FunctionalInterface public interface CompletionListener {
        void onComplete(Result result, long notificationTimestampNs);
    }
    @FunctionalInterface public interface DiagnosticListener {
        void onDiagnostic(Diagnostic diagnostic);
    }
    public enum Issue {
        ZERO_SIZE_IGNORED, MISSING_TIMESTAMP, NEGATIVE_SIZE_UNSUPPORTED,
        NONFINITE_PRICE, VOLUME_OVERFLOW, BUFFERED_LATE_ACCEPTED,
        LATE_RETAINED_MINUTE_QUARANTINED, STALE_OUTSIDE_REFERENCE
    }
    public static final class Diagnostic {
        public final Issue issue;
        public final long eventNs, clockNs, affectedStartNs, nextUnpublishedStartNs;
        public final double price;
        public final int size;
        public final Side side;
        Diagnostic(Issue issue, long eventNs, long clockNs, long nextNs, double price, int size, Side side) {
            this.issue = issue; this.eventNs = eventNs; this.clockNs = clockNs;
            this.affectedStartNs = eventNs < 0 ? -1 : minuteStart(eventNs);
            this.nextUnpublishedStartNs = nextNs;
            this.price = price; this.size = size; this.side = side;
        }
    }
    private final Parameters parameters;
    private final Window window;
    private final CompletionListener listener;
    private final DiagnosticListener diagnostics;
    private final long closeGraceNs;
    private final TreeMap<Long, MutableCandle> pending = new TreeMap<>();
    private long nextStartNs = -1, clockNs = -1;
    private double lastFinalizedPrice = Double.NaN;
    private boolean unknownBeforeInitialization;
    private long completedCandles, droppedLateTrades, invalidTrades, skippedEmptyMinutes;
    private long ignoredZeroSizeTrades, bufferedLateTrades, quarantinedLateTrades, staleTrades;

    /** Zero-buffer constructor for deterministic research tests and explicit immediate-close use. */
    public MinuteEngine(Parameters parameters, CompletionListener listener) {
        this(parameters, 0, listener, d -> { });
    }
    public MinuteEngine(Parameters parameters, long closeGraceNs, CompletionListener listener,
            DiagnosticListener diagnostics) {
        if (closeGraceNs < 0 || closeGraceNs > 2_000_000_000L)
            throw new IllegalArgumentException("Close buffer must be between 0 and 2000 ms");
        this.parameters = Objects.requireNonNull(parameters);
        this.window = new Window(parameters);
        this.listener = Objects.requireNonNull(listener);
        this.diagnostics = Objects.requireNonNull(diagnostics);
        this.closeGraceNs = closeGraceNs;
    }
    public long completedCandles() { return completedCandles; }
    public long droppedLateTrades() { return droppedLateTrades; }
    public long invalidTrades() { return invalidTrades; }
    public long skippedEmptyMinutes() { return skippedEmptyMinutes; }
    public long ignoredZeroSizeTrades() { return ignoredZeroSizeTrades; }
    public long bufferedLateTrades() { return bufferedLateTrades; }
    public long quarantinedLateTrades() { return quarantinedLateTrades; }
    public long staleTrades() { return staleTrades; }
    public int historySize() { return window.size(); }
    public long clockNs() { return clockNs; }
    public long closeGraceNs() { return closeGraceNs; }
    private static long minuteStart(long ns) { return ns / MINUTE_NS * MINUTE_NS; }

    private void initializeAt(long timestampNs) {
        if (nextStartNs >= 0) return;
        nextStartNs = minuteStart(timestampNs);
        pending.put(nextStartNs, new MutableCandle(nextStartNs,
                timestampNs == nextStartNs && !unknownBeforeInitialization));
    }
    /** Close [start,end) once the indicator's clock reaches end + the explicit close buffer. */
    public void onClock(long timestampNs) {
        if (timestampNs < 0) return;
        initializeAt(timestampNs);
        if (timestampNs < clockNs) return; // A timer regression never moves a candle or the clock backwards.
        clockNs = timestampNs;
        finalizeDue();
    }
    public void onTrade(long timestampNs, double price, int size, Side side) {
        if (side == null) side = Side.UNKNOWN;
        if (size == 0) {
            // Zero contracts are not an execution. Do not move time or poison a reference.
            ignoredZeroSizeTrades++;
            diagnose(Issue.ZERO_SIZE_IGNORED, timestampNs, price, size, side);
            return;
        }
        if (timestampNs < 0) {
            invalidTrades++;
            if (nextStartNs < 0) unknownBeforeInitialization = true;
            else {
                // Cannot locate the event: conservatively invalidate the most recent observed bucket.
                long bucket = Math.max(nextStartNs, minuteStart(clockNs));
                pending.computeIfAbsent(bucket, k -> new MutableCandle(k, true)).tainted = true;
            }
            diagnose(Issue.MISSING_TIMESTAMP, timestampNs, price, size, side);
            return;
        }
        initializeAt(timestampNs);
        if (timestampNs < nextStartNs) {
            droppedLateTrades++;
            // No rewriting of a published signal. Quarantine its input minute for FUTURE evaluations.
            if (window.invalidateMinute(minuteStart(timestampNs))) {
                quarantinedLateTrades++;
                diagnose(Issue.LATE_RETAINED_MINUTE_QUARANTINED, timestampNs, price, size, side);
            } else {
                staleTrades++;
                diagnose(Issue.STALE_OUTSIDE_REFERENCE, timestampNs, price, size, side);
            }
            return;
        }
        long start = minuteStart(timestampNs);
        MutableCandle bucket = pending.computeIfAbsent(start, k -> new MutableCandle(k, true));
        if (size < 0) {
            // Do not interpret unsupported trade corrections as ordinary negative contracts.
            invalidTrades++; bucket.tainted = true;
            diagnose(Issue.NEGATIVE_SIZE_UNSUPPORTED, timestampNs, price, size, side);
        } else {
            boolean finitePrice = Double.isFinite(price);
            if (!finitePrice) {
                // Quantity and side remain useful; only price-derived calculations are unavailable.
                invalidTrades++; bucket.priceTainted = true;
                diagnose(Issue.NONFINITE_PRICE, timestampNs, price, size, side);
            }
            if (!bucket.add(timestampNs, price, size, side)) {
                invalidTrades++;
                diagnose(Issue.VOLUME_OVERFLOW, timestampNs, price, size, side);
            }
            if (clockNs >= start + MINUTE_NS) {
                bufferedLateTrades++;
                diagnose(Issue.BUFFERED_LATE_ACCEPTED, timestampNs, price, size, side);
            }
        }
        // Trades in the new minute can already be stored, but are NEVER used for the prior result.
        onClock(Math.max(timestampNs, clockNs));
    }
    private void finalizeDue() {
        while (clockNs - nextStartNs >= MINUTE_NS + closeGraceNs) {
            MutableCandle mutable = pending.remove(nextStartNs);
            if (mutable == null) mutable = new MutableCandle(nextStartNs, true);
            Candle finished = mutable.freeze(lastFinalizedPrice);
            if (finished.validPrices()) lastFinalizedPrice = finished.close;
            nextStartNs = finished.endNs; // advance BEFORE notifying, to prevent duplicate completion
            Result result = window.accept(finished);
            completedCandles++;
            listener.onComplete(result, clockNs);

            // A long disconnect/replay gap does not require allocating millions of empty candles.
            // Never skip an actual pending candle; keep the last N empty slots in the reference.
            long lastDueBoundary = minuteStart(Math.max(0, clockNs - closeGraceNs));
            long remaining = (lastDueBoundary - nextStartNs) / MINUTE_NS;
            if (remaining > parameters.lookback + 1L) {
                long target = lastDueBoundary - parameters.lookback * MINUTE_NS;
                Long nextPopulated = pending.ceilingKey(nextStartNs);
                if (nextPopulated != null) target = Math.min(target, nextPopulated);
                if (target > nextStartNs) {
                    skippedEmptyMinutes += (target - nextStartNs) / MINUTE_NS;
                    nextStartNs = target;
                    window.reset(); // Only for a gap; never an unrelated malformed/late event.
                }
            }
        }
    }
    private void diagnose(Issue issue, long time, double price, int size, Side side) {
        diagnostics.onDiagnostic(new Diagnostic(issue, time, clockNs, nextStartNs, price, size, side));
    }
    private static final class MutableCandle {
        final long startNs;
        final boolean complete;
        double open = Double.NaN, high = Double.NaN, low = Double.NaN, close = Double.NaN;
        long buy, sell, unknown, firstTradeTime = Long.MAX_VALUE, lastTradeTime = Long.MIN_VALUE;
        boolean tainted, priceTainted;
        MutableCandle(long startNs, boolean complete) { this.startNs = startNs; this.complete = complete; }
        boolean add(long timestampNs, double price, int size, Side side) {
            boolean ok = true;
            try {
                long b = buy, s = sell, u = unknown;
                switch (side) {
                    case BUY: b = Math.addExact(b, size); break;
                    case SELL: s = Math.addExact(s, size); break;
                    case UNKNOWN: u = Math.addExact(u, size); break;
                    default: throw new IllegalStateException("Unexpected side");
                }
                Math.addExact(Math.addExact(b, s), u);
                buy = b; sell = s; unknown = u;
            } catch (ArithmeticException ex) { tainted = true; ok = false; }
            if (Double.isFinite(price)) {
                if (firstTradeTime == Long.MAX_VALUE) { open = high = low = close = price; }
                else { high = Math.max(high, price); low = Math.min(low, price); }
                // Open/close use event time; ties at a timestamp use arrival order for the close.
                if (timestampNs < firstTradeTime) { firstTradeTime = timestampNs; open = price; }
                if (timestampNs >= lastTradeTime) { lastTradeTime = timestampNs; close = price; }
            }
            return ok;
        }
        Candle freeze(double carryPrice) {
            if (firstTradeTime == Long.MAX_VALUE) open = high = low = close = carryPrice;
            return new Candle(startNs, open, high, low, close, buy, sell, unknown, complete, tainted, priceTainted);
        }
    }
}
