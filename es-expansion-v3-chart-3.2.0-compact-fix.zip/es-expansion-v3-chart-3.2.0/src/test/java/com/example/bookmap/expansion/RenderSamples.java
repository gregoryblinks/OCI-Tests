package com.example.bookmap.expansion;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import javax.imageio.ImageIO;
import static com.example.bookmap.expansion.ExpansionModel.*;

/** Production-renderer QA samples. Synthetic values, NOT a live Bookmap screenshot. */
public final class RenderSamples {
    public static void main(String[] args) throws Exception {
        Path directory = Path.of(args.length == 0 ? "build/render-samples" : args[0]);
        Files.createDirectories(directory);
        AnnotationRenderer renderer = new AnnotationRenderer(new AnnotationRenderer.Settings(
                true, true, 0, 11, 3, 0, 2));
        Parameters p = new Parameters(15, 2, 2, 2, 2, 0.25);
        // Fixed illustrative readings isolate the exact display request from signal mathematics.
        Result bull = new Result(CoreSelfTest.candle(15, 1200, 1140, 20, true, false), p, 15,
                2.6, 2.4, 2.7, 2.2, 1200/2.6, 160, Status.READY, "RENDER_SAMPLE");
        Result bear = new Result(CoreSelfTest.candle(15, 1200, 60, -20, true, false), p, 15,
                2.6, 2.4, -2.7, -2.2, 1200/2.6, 160, Status.READY, "RENDER_SAMPLE");
        Result none = new Result(CoreSelfTest.candle(15, 1200, 800, 20, true, false), p, 15,
                2.6, 2.4, 1.4, 2.2, 1200/2.6, 160, Status.READY, "RENDER_SAMPLE");
        Result warm = new Window(p).accept(CoreSelfTest.baseline(0));
        Result[] results = {bull, bear, none, warm};
        String[] names = {"bullish", "bearish", "no-signal", "warmup"};
        String[] captions = {"Bullish", "Bearish", "No full alignment", "Unavailable / warm-up"};
        BufferedImage sheet = new BufferedImage(960, 340, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = sheet.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new Color(19, 23, 29)); g.fillRect(0, 0, sheet.getWidth(), sheet.getHeight());
        g.setColor(new Color(230, 235, 240)); g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        g.drawString("ES Expansion 3.2 | Text and arrows only", 22, 30);
        g.setColor(new Color(158, 167, 181)); g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        g.drawString("Actual renderer at native 11 px. Illustrative values, not a live Bookmap screenshot. No boxes or headings on chart.", 22, 52);
        for (int y=90; y<290; y+=30) {
            g.setColor(new Color(32, 38, 47)); g.drawLine(20,y,940,y);
        }
        for (int i=0; i<results.length; i++) {
            AnnotationRenderer.Annotation a=renderer.render(results[i]);
            ImageIO.write(a.image,"png",directory.resolve(names[i]+".png").toFile());
            int x=120+i*240;
            int candleTop=a.below?107:202, candleBottom=candleTop+35;
            boolean up=results[i].candle.close>=results[i].candle.open;
            g.setColor(up?AnnotationRenderer.BULL:AnnotationRenderer.BEAR);
            g.drawLine(x,candleTop-12,x,candleBottom+12); g.fillRect(x-5,candleTop,10,candleBottom-candleTop);
            int anchorY=a.below?candleBottom+15:candleTop-15;
            g.drawImage(a.image,x-a.anchorX,anchorY-a.anchorY,null);
            g.setColor(new Color(215,221,230)); g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,12));
            int textWidth=g.getFontMetrics().stringWidth(captions[i]);
            g.drawString(captions[i],x-textWidth/2,302);
            System.out.println(names[i]+": "+a.image.getWidth()+"x"+a.image.getHeight()+" px; rows="+a.rows);
        }
        g.setColor(new Color(158,167,181)); g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,11));
        g.drawString("Amber: RVOL/ACC pass. Green/red: SV/SI directional threshold. Gray: below threshold or unavailable. z = robust score.",22,326);
        g.dispose(); ImageIO.write(sheet,"png",directory.resolve("annotation-preview.png").toFile());
        System.out.println("Renderer samples saved in "+directory.toAbsolutePath());
    }
}
