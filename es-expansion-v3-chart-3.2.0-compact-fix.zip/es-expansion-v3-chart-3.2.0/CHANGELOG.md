# Changes in 3.2.0

## Requested display repair

Removed the filled rectangle, rounded border, title/status, time, threshold column and left-extending layout. Only an optional arrow and four vertical metric rows remain, centered together. Bullish: below candle low, arrow then text. Bearish: above candle high, text then arrow. Non-signal readings remain visible by default, without a heading or arrow. Default text size is 11 pixels. Unavailable values are dashes; labels have no background. Existing lookback/threshold controls are unchanged.

## Data handling

Zero-size callbacks are ignored without invalidating data or moving the engine clock. The default 200 ms configurable close buffer accepts slight prior-minute reordering before publication. Timer calls use the actual latest callback timestamp rather than a separate max-timestamp variable in the adapter. Emitted values are immutable.

Late prints no longer erase the whole reference or mark an unrelated current candle invalid. Only the affected retained minute is quarantined for future evaluations; prints older than the retained reference are ignored with a diagnostic. Unreliable complete minutes retain their time slots until naturally aged out. A real bad-volume slot may still block signals for the following N evaluations; the safety condition is not bypassed.

A positive-size print with a bad price preserves actual volume and known side, while making SI unavailable. Unknown side only removes SV. Negative corrections remain unsupported and fail closed for the affected minute. Diagnostics identify the exact reason, times, price, quantity, side and action, using Bookmap's native logger with rate limiting.

## Build/tests

Retained the PowerShell quoting repair from 3.1.1. Updated the output name to `es-expansion-v3-chart-3.2.0.jar`. Added regression tests: 62 core/render/timing groups and 8 mocked adapter scenarios pass locally. Actual SDK download/compilation, Windows execution, Bookmap rendering and live Rithmic operation are not verified in this environment. No precompiled JAR is shipped.

## Deliberately unchanged

Previous 15 consecutive completed minutes; same four components and all-four directional gate; no MBO or order-book inputs; no order submission; no new trading filters. ACC remains robust z(volume level), not a derivative. Thresholds remain experimental. No claim is made that the original live error's cause was established without its log.
