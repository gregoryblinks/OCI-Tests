# Upgrade to ES Expansion 3.2.0

This update replaces the large annotation box with four compact vertical text rows and an optional arrow. It also replaces blanket data-error resets with per-minute handling.

## Package status

This is source code, not a precompiled add-on. The pure Java model/renderer passed 62 test groups, and the Bookmap adapter passed 8 callback scenarios using explicitly labeled test doubles. Those checks are not an SDK or Bookmap/Rithmic runtime test. The official SDK could not be downloaded in the authoring environment. Build locally against the official SDK, then validate in replay before relying on live signals.

## Windows: build the replacement

1. Extract this ZIP to a NEW folder and open PowerShell in the folder containing `build.ps1`.
2. The previous build downloaded SDK files into its `.deps` folder. Copy that entire `.deps` folder into this new project folder to reuse them. Otherwise the build script will download the same official Bookmap SDK dependencies automatically. Keep the previous project as a backup.
3. Run:

```powershell
.\build.ps1
```

The script requires a full JDK 17 or newer. It retains the previous PowerShell fix: both `"-Djava.awt.headless=true"` arguments are quoted.

Alternatively, point directly to the old SDK cache without copying it:

```powershell
.\build.ps1 -SdkDir "C:\path\to\your-old-project\.deps"
```

Replace only the example path with your actual old project path. A successful build creates:

```text
build\libs\es-expansion-v3-chart-3.2.0.jar
```

Do not load a `3.1.0` or `3.1.1` JAR after this rebuild: those contain the old box renderer.

## Load it in Bookmap

Disable and remove the earlier ES Expansion add-on. Restart Bookmap to avoid retaining the old loaded classes or annotations. Open **Settings -> API plugins configuration -> Add**, select the new `3.2.0.jar`, and choose:

```text
ES Expansion V3.2 - compact arrows + metrics
```

Enable it on your Rithmic-connected ES contract. Do not enable the old and new versions simultaneously. Bookmap's official add-on guide documents this loading flow: https://bookmap.com/knowledgebase/docs/API-Tutorial

## Default display

The readings are always in the order `RVOL`, `ACC`, `SV`, `SI`.

- Bullish signal: green up arrow below candle low; readings below the arrow.
- Bearish signal: red down arrow above candle high; readings above the arrow.
- No full signal: readings remain, with no arrow.

There is no background rectangle, border, heading, timestamp, or threshold column. The default font is 11 pixels, adjustable in the add-on settings. Thresholds remain editable in the settings; they are not repeated on every chart label. RVOL/ACC pass in amber; SV/SI pass in green/red according to direction. Unavailable values are shown as a dash, not zero.

Set **Labels: 0 every candle, 1 any pass, 2 full signals** to **0** for readings on every completed candle. Arrow and label visibility are independent. For non-signal candles, the default is below up/flat candles and above down candles; placement can be forced above or below.

Use a one-minute trade-based OHLC candle view when comparing candle extremes. The add-on builds its own one-minute trade candles; it does not read the chart's current candle aggregation settings.

## Timing setting: read before using

**Close buffer (ms)** defaults to **200**. A minute is published at the first Bookmap event-clock callback at or after its end plus this buffer. This intentionally adds 0.2 seconds of event-time buffering, plus whatever callback/feed/processing delay exists. It is not a guaranteed end-to-end latency.

Set the buffer to **0** to remove that intentional delay, accepting less tolerance for out-of-order prints. The buffer does not include any trade timestamped in the following minute in the candle being evaluated. Backtests must use the logged notification time, not assume entry at the earlier candle-closing time.

The simplified icon API places the image at the notification event time. Arrows use the completed candle's high/low, but are not backdated to the candle-body midpoint. Keep sufficient chart space around the newest candle for centered text.

## What to expect during start-up or data problems

The initial partially observed minute is excluded. The indicator needs the previous 15 full one-minute candles before evaluating a candidate candle with the default lookback. Available subscription history can provide that reference; otherwise it must accumulate as new minutes close. Dashes during this period are normal.

Zero-size callbacks no longer invalidate anything. A slightly late prior-minute print can be accepted before the buffered minute is published. An execution arriving after publication does not repaint old readings or arrows. If its minute is still in the reference, that minute is marked unreliable for subsequent calculations until it leaves the 15-minute window. It is not replaced with an older traded minute, and the unrelated current minute is not marked bad. A truly bad volume minute may therefore still leave required readings unavailable for the next 15 evaluations; this is deliberate protection, not a removed threshold.

Price errors and unknown aggressor side affect only the calculations that require those fields. Genuine feed problems are not hidden by changing values to zero or forcing a signal.

## Diagnose persistent dashes

Open **File -> Show log file** and look for `ES_EXPANSION_DIAG` or `ES_EXPANSION version=3.2.0`. Diagnostics now use Bookmap's native logger. They include the reason, event timestamp, affected minute, price, size, side, and action. Enable **Log every completed candle** for full numerical comparison.

Examples of reason codes: `ZERO_SIZE_IGNORED`, `BUFFERED_LATE_ACCEPTED`, `LATE_RETAINED_MINUTE_QUARANTINED`, `STALE_OUTSIDE_REFERENCE`, `NONFINITE_PRICE`, and `NEGATIVE_SIZE_UNSUPPORTED`. Reference and zero-MAD explanations appear in each logged result's `detail` field.

The source-code defects have been addressed; the exact cause of the earlier warning on your installation was not established because no live log was provided.

## macOS / Linux

```bash
sh build.sh
```

Core-only tests without the SDK (no installable JAR produced):

```powershell
.\build.ps1 -TestOnly
```

```bash
sh build.sh --test-only
```

The indicator is display-only. Its 2x RVOL and +/-2 robust-z thresholds are research parameters, not demonstrated profitable entries.
