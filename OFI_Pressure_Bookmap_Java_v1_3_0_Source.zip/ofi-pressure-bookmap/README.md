# OFI Pressure for Bookmap - Java v1.3.0

**Source release.** This package contains the Java add-on, independent engine, Swing panel, renderer, exporter, tests, and build tools. It does not contain a prebuilt Bookmap JAR or the proprietary Bookmap SDK. The independent Java tests pass; the adapter has not been compiled against the real SDK or run inside Bookmap in the delivery environment.

## Changes in this release

**LOCK/CROSS rejection is removed, not just hidden.** Equal best bid/ask and a best bid above the best ask do not exclude an MBO event, reduce depth coverage, invalidate a minute, or stop warmup/calibration. This applies to transient and persistent states alike; there is no duration threshold or hidden spread veto.

The event formula and active-rank weights are unchanged. More events can now enter that formula, depth denominators and calibration, so the resulting numbers can differ from v1.2.0. The arithmetic midpoint is available whenever both sides exist, including zero/negative spreads, for research fields and no-trade bubble anchoring. A usable last trade still takes priority for the bubble position.

No `LOCK` or `CROSS` bubbles are generated. Export-only bid/ask and quote-state diagnostics remain for research compatibility; they do not add quality flags or warnings. Each row records `quote_state_policy=NO_SPREAD_FILTER`, export schema 4 and model `mlofi-adaptive-depth-1.3.0`.

**Unchanged:** startup after 15 prior valid minutes, rolling benchmark of 60 prior valid minutes, minimum 3 and target 10 paired ranks, ignored/countable bad diagnostic trades, retained calibration across ordinary invalid minutes, XLSX/CSV export, the compact settings panel and resizable pop-out, and no order execution.

**Still checked:** missing levels/sides, stale data, insufficient coverage, no usable MBO events, partial startup minutes, unusable depth/nonfinite calculations, and actual reconstruction faults. Removing the quote filter does not make every possible minute valid or repair a misreconstructed book. A persistent erroneous book can now produce a numeric score; validate the input independently.

## Build

Requirements: JDK 17 or newer (`java`, `javac`, and `jar` on PATH); Python 3.10 or newer for the included build/research scripts. The running Java add-on does not require Python.

Extract the ZIP and open a terminal in the `ofi-pressure-bookmap` directory.

Windows:

```bat
build.cmd
```

macOS/Linux:

```sh
sh build.sh
```

The script downloads `api-core` and `api-simplified` version **7.6.0.20** from Bookmap's official Maven repository, runs the independent tests, compiles against the real SDK, and creates:

```text
dist/ofi-pressure-bookmap-1.3.0.jar
```

### Reuse SDK files from your previous successful build

Copy these two files from your previous project's `lib/` to this project's `lib/`:

```text
api-core-7.6.0.20.jar
api-simplified-7.6.0.20.jar
```

Then run:

```bat
build.cmd --offline
```

or:

```sh
sh build.sh --offline
```

Do not copy an old add-on JAR in place of the SDK. No SDK stubs or SDK classes are packaged into the add-on. Gradle users may instead run `gradle jar`; the Gradle output is under `build/libs/`.

## Replace the old add-on

Disable and remove the old add-on entry. In Bookmap, use **Settings -> API plugins configuration -> Add**, select the new JAR, and enable **OFI Pressure - 1 Minute Bubbles (Research v1.3.0)**. Do not run old and new versions simultaneously. If the host still shows the old version, restart Bookmap before retrying.

Check the compact panel's four buttons. **Open output** targets the current instrument/run folder. **Pop out** opens a resizable window with the same controls and diagnostics; Escape closes it. Changes to the configuration still require disable/re-enable.

Existing v1.1/v1.2 configurations (`config.schema.version=2`) are preserved, including your 15/60 and minimum-three-level settings. Legacy schema-1 migration remains backed up and one-time. A new instance starts a new run and calibration; old observations are not automatically loaded.

## Output directory without using the indicator window

Default Windows location (paste into Explorer or Win+R):

```text
%USERPROFILE%\Bookmap\OFI-Pressure\data
```

Default macOS/Linux location:

```text
~/Bookmap/OFI-Pressure/data
```

A custom `output.directory` in `~/Bookmap/OFI-Pressure/config.properties` overrides this. The panel and console print the actual run path.

Layout:

```text
<data root>/<sanitized instrument>_<alias hash>/<unique run>/
    YYYY-MM-DD_pressure.csv
    YYYY-MM-DD_pressure.xlsx
    metadata.txt
```

CSV is the recovery record; Excel is a replaceable daily snapshot. Close Excel when it prevents replacement. The writer continues saving CSV and reports workbook problems. No files from earlier runs are overwritten by the upgrade.

## Bid/ask ordering: no rejection filter

```text
best bid < best ask    eligible if the remaining checks pass
best bid = best ask    eligible if the remaining checks pass
best bid > best ask    eligible if the remaining checks pass
```

All eligible events enter OFI, including entry to and recovery from an equal/inverted spread. Fresh intervals contribute depth and coverage regardless of quote ordering. Completed valid observations enter the same prior-only 15/60 calibration. A positive-spread recovery is not required.

This is an acceptance-policy change, not a correction of feed sequencing or reconstruction. No quote prices are shifted, no cancellations are invented, and no callbacks are removed to create a normal-looking spread. The arithmetic midpoint of inverted quotes is not a promise of an executable price. Numeric pressure is not evidence that the reconstructed book is correct.

### Export-only diagnostics (schema 4)

The schema-3 fields are retained: `book_state_end`, `best_bid_end`, `best_ask_end`, `spread_ticks_end`, `locked_post_event_count`, `crossed_post_event_count`, `locked_observed_ms`, `crossed_observed_ms`, and `first_quote_issue_*`. The historical word `issue` in those column names does not mean the row is rejected.

Counts refer to post-update states, not distinct episodes. Durations refer to reconstructed-state residence on Bookmap's callback clock, including stale residence, not matching-engine duration. Same-timestamp states can count with zero measured milliseconds. These columns are not used by the acceptance or pressure formula. New field `quote_state_policy=NO_SPREAD_FILTER` explicitly identifies the policy. Default ten-level rows have 167 fields.

Do not mix v1.2 and v1.3 observations as if their acceptance rules were the same. Reloading starts a new run; earlier invalid observations are not recomputed or automatically loaded into warmup.

## Measurement defaults

```properties
levels=10
levels.minimum=3
rolling.minimum.minutes=15
rolling.window.minutes=60
rolling.benchmark.minutes=60
```

The first eligible Z is on the 16th valid complete minute using 15 preceding valid observations. It is marked with `*` until it uses 60 prior valid observations. A flat reference distribution produces `FLAT`, not an infinite score. Invalid minutes do not count toward calibration. The 60 observations are valid observations, not necessarily 60 consecutive wall-clock minutes.

The engine computes the before/after Cont-style formula on the current common ranks, integrates with event-wise normalized weights, normalizes by depth, and scores against **prior** observations. Default exponential weights are not fitted PCA. Z describes a deviation from a historical baseline, not a trade probability; raw-flow and deviation directions are saved separately. The engine performs no order entry.

## Testing and limitations

Run the independent tests without downloading any SDK:

```sh
python tools/test_core.py
```

**103 tests:** 36 original, 27 adaptive-depth/calibration, 29 quote-policy, 11 Swing panel regressions. These compile the production independent engine, renderer, panel, and exporter. They do not compile or execute `OfiPressureAddon` against a fake SDK.

The panel tests include 220x160, 300x220, 480x440, and 760x500 layouts, long paths/status strings, scroll behavior, and action routing. Small-panel renderings are regenerated by the tests. Host-specific layout, OS folder opening, Bookmap pop-out integration, data-provider semantics, and live performance still require local acceptance testing. See `docs/VALIDATION.md` and `docs/ACCEPTANCE_TESTS.md`.

Offline research tools remain in `tools/`. `forward_labels.py` creates a separate outcome file; `recover_excel.py` rebuilds an Excel workbook from CSV. They require the separate packages in `tools/requirements-research.txt`. Missing labels are not manufactured and none of the outputs establishes profitability.

## Primary references

- Bookmap API and build/loading examples: https://github.com/BookmapAPI/DemoStrategies
- Bookmap StrategyPanel API: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-core/7.2.0/velox/gui/StrategyPanel.html
- MBO callback contract: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0.10/velox/api/layer1/simplified/MarketByOrderDepthDataListener.html
- Cont et al., event OFI: https://arxiv.org/abs/1011.6402
- Cont et al., multilevel/cross-impact work: https://arxiv.org/abs/2112.13213

Bookmap's older public Javadoc establishes the API types used; the project explicitly builds against the 7.6.0.20 SDK. No installed Bookmap version or provider has been verified here.
