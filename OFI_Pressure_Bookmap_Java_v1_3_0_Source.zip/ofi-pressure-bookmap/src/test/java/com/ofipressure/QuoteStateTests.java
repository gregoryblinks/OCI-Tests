package com.ofipressure;

import com.ofipressure.core.*;
import com.ofipressure.bookmap.BubbleImage;
import com.ofipressure.io.ResearchWriter;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;

/** Quote ordering is diagnostic only: test event sums, coverage, calibration and remaining safeguards. */
public final class QuoteStateTests {
    private static int passed;
    private static final long S=PressureEngine.SECOND,M=PressureEngine.MINUTE;
    private static final long T=Instant.parse("2026-01-05T09:00:00Z").getEpochSecond()*S;
    private interface Action {void run()throws Exception;}
    private static void test(String name,Action action)throws Exception {action.run();passed++;System.out.println("PASS "+name);}
    private static void yes(boolean b,String message){if(!b)throw new AssertionError(message);}
    private static void eq(double want,double got){yes(Math.abs(want-got)<1e-8,"expected "+want+", got "+got);}
    private static void same(double want,double got){if(Double.isNaN(want))yes(Double.isNaN(got),"expected NaN");else eq(want,got);}
    private static double n(BarRecord r,String field){return ((Number)r.get(field)).doubleValue();}
    private static String s(BarRecord r,String field){return r.get(field).toString();}
    private static EngineConfig config(String... kv){Properties p=new Properties();for(int i=0;i<kv.length;i+=2)p.setProperty(kv[i],kv[i+1]);return new EngineConfig(p);}
    private static PressureEngine engine(List<BarRecord> rows){return engine(rows,config(),102,3,3,T);}
    private static PressureEngine engine(List<BarRecord> rows,EngineConfig c,int ask,int bids,int asks,long start){
        PressureEngine e=new PressureEngine(c,"QUOTE-TEST","test",.25,rows::add);e.onTime(start);
        for(int i=0;i<bids;i++)e.send("B"+i,true,100-i,10);
        for(int i=0;i<asks;i++)e.send("A"+i,false,ask+i,10);
        e.snapshotEnd();return e;
    }
    private static void minute(PressureEngine e,int i,int qty){
        for(int second:new int[]{10,25,40,55}){e.onTime(T+i*M+second*S);e.replace("B0",100,qty);}e.onTime(T+(i+1)*M);
    }
    private static OrderBook.Top top(int bid,int ask){
        OrderBook book=new OrderBook(1000);book.send("bid",true,bid,10);book.send("ask",false,ask,10);
        OrderBook.Top t=new OrderBook.Top(1);book.top(t);return t;
    }
    private static void accepted(BarRecord r){
        yes(r.valid,"minute rejected: "+s(r,"quality_flags"));yes(s(r,"quality_flags").isEmpty(),"no quote flags");
        eq(n(r,"mbo_events"),n(r,"valid_mbo_events"));eq(1,n(r,"valid_book_coverage"));
        yes(!s(r,"quality_warnings").contains("LOCK")&&!s(r,"quality_warnings").contains("CROSS"),"no quote warnings");
    }
    private static List<BarRecord> sequence(int ask,String mode,int count){
        List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config("depth.mode",mode),ask,3,3,T);
        for(int i=0;i<count;i++){
            int bidQty=10+(i*7)%31,askQty=10+(i*11)%29;
            e.onTime(T+i*M+10*S);e.replace("B0",100,bidQty);
            e.onTime(T+i*M+25*S);e.replace("A0",ask,askQty);
            e.onTime(T+i*M+40*S);e.replace("B0",100,bidQty+2);
            e.onTime(T+i*M+55*S);e.replace("A0",ask,askQty+4);
            e.onTime(T+(i+1)*M);
        }
        return rows;
    }
    private static void compareSpreadStates(String mode){
        List<BarRecord> normal=sequence(102,mode,80),locked=sequence(100,mode,80),crossed=sequence(99,mode,80);
        for(int i=0;i<80;i++)for(BarRecord r:List.of(locked.get(i),crossed.get(i))){
            accepted(r);BarRecord expected=normal.get(i);
            for(String field:new String[]{"integrated_raw_ofi","normalized_ofi","shared_depth_event","shared_depth_time",
                    "valid_book_coverage","valid_mbo_events","prior_sample_count","prior_mean","prior_sample_sd","pressure_z",
                    "prior_empirical_percentile","direction_persistence","levels_used_avg"})same(n(expected,field),n(r,field));
            yes(r.scoreStatus.equals(expected.scoreStatus),"score status identical");
            yes(s(r,"calibration_stage").equals(s(expected,"calibration_stage")),"stage identical");
        }
    }
    public static void main(String[] args)throws Exception {
        test("locked top is eligible in both validity overloads",()->{
            OrderBook.Top t=top(100,100);yes(t.locked()&&!t.crossed(),"diagnostic only");yes(t.valid()&&t.valid(1),"equality accepted");eq(0,t.spreadTicks());eq(100,t.midpoint);
        });
        test("crossed top is eligible in both validity overloads",()->{
            OrderBook.Top t=top(101,100);yes(t.crossed()&&!t.locked(),"diagnostic only");yes(t.valid()&&t.valid(1),"negative spread accepted");eq(-1,t.spreadTicks());eq(100.5,t.midpoint);
        });
        test("normal positive spread remains eligible",()->{OrderBook.Top t=top(100,102);yes(t.valid(1),"valid");eq(2,t.spreadTicks());eq(101,t.midpoint);});
        test("missing sides remain invalid with no fabricated midpoint",()->{
            OrderBook b=new OrderBook(1000);OrderBook.Top t=new OrderBook.Top(3);b.top(t);yes(!t.valid()&&!t.valid(1),"empty invalid");yes(Double.isNaN(t.midpoint),"no midpoint");
            b.send("ask",false,-3,10);b.top(t);yes(!t.valid(1)&&!t.crossed()&&!t.locked(),"missing bid");yes(Double.isNaN(t.midpoint),"missing bid midpoint blank");
            b.cancel("ask");b.send("bid",true,1,10);b.top(t);yes(!t.valid(1)&&!t.crossed()&&!t.locked(),"missing ask");
        });
        test("minimum depth is still enforced independently of spread",()->{
            OrderBook.Top t=top(101,100);yes(!t.valid(3),"one level cannot satisfy three");yes(!t.valid(0),"nonpositive requirement rejected");
        });
        test("negative prices and extreme integer midpoint arithmetic remain safe",()->{
            yes(top(-5,-3).valid(1),"negative prices supported");eq(4294967295.0,top(Integer.MIN_VALUE,Integer.MAX_VALUE).spreadTicks());
            OrderBook.Top t=top(Integer.MAX_VALUE,Integer.MIN_VALUE);yes(t.valid(1),"cross not filtered");eq(-0.5,t.midpoint);
        });
        test("same-timestamp lock entry and recovery both contribute to OFI",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows);e.onTime(T+10*S);e.send("L",true,102,5);e.cancel("L");minute(e,0,16);
            BarRecord r=rows.get(0);accepted(r);eq(6,n(r,"valid_mbo_events"));eq(1,n(r,"locked_post_event_count"));eq(0,n(r,"locked_observed_ms"));
            eq(25.5,n(r,"first_quote_issue_bid"));yes(s(r,"book_state_end").equals("NORMAL"),"recovered");
            yes(BubbleImage.label(r.z,r.scoreStatus,false,s(r,"quality_flags"),0,15,false).equals("W0/15"),"warmup not LOCK");
        });
        test("same-timestamp cross entry update and recovery all contribute",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows);e.onTime(T+10*S);e.send("X",true,103,5);e.replace("X",103,7);e.cancel("X");minute(e,0,16);
            BarRecord r=rows.get(0);accepted(r);eq(7,n(r,"valid_mbo_events"));eq(2,n(r,"crossed_post_event_count"));eq(0,n(r,"crossed_observed_ms"));
            eq(-1,n(r,"first_quote_issue_spread_ticks"));yes(!e.status().contains("CROSS")&&!e.status().contains("LOCK"),"no visible quote veto");
        });
        test("five seconds of mixed quote states no longer subtract coverage",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows);e.onTime(T+10*S);e.send("L",true,102,5);
            e.onTime(T+13*S);e.cancel("L");e.onTime(T+15*S);e.send("X",true,103,5);e.onTime(T+17*S);e.cancel("X");
            for(int second:new int[]{25,40,55}){e.onTime(T+second*S);e.replace("B0",100,14);}e.onTime(T+M);
            BarRecord r=rows.get(0);accepted(r);eq(3000,n(r,"locked_observed_ms"));eq(2000,n(r,"crossed_observed_ms"));
        });
        test("lock spanning a minute boundary counts both minutes",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows);e.onTime(T+20*S);e.replace("B0",100,11);e.onTime(T+40*S);e.replace("B0",100,12);
            e.onTime(T+59*S);e.send("L",true,102,5);e.onTime(T+M);e.onTime(T+M+2*S);e.cancel("L");minute(e,1,14);
            accepted(rows.get(0));accepted(rows.get(1));eq(1,n(rows.get(1),"prior_sample_count"));eq(1000,n(rows.get(0),"locked_observed_ms"));eq(2000,n(rows.get(1),"locked_observed_ms"));
        });
        test("snapshot updates are excluded even when the resulting book is locked",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config(),100,3,3,T);minute(e,0,16);
            accepted(rows.get(0));eq(4,n(rows.get(0),"mbo_events"));eq(60000,n(rows.get(0),"locked_observed_ms"));
        });
        test("full locked minute produces hand-computed three-level OFI",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config("weights.mode","UNIFORM"),100,3,3,T);minute(e,0,16);
            BarRecord r=rows.get(0);accepted(r);eq(2,n(r,"integrated_raw_ofi"));eq(11,n(r,"shared_depth_event"));eq(2.0/11,n(r,"normalized_ofi"));
        });
        test("full crossed minute produces hand-computed three-level OFI",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config("weights.mode","UNIFORM"),99,3,3,T);minute(e,0,16);
            BarRecord r=rows.get(0);accepted(r);eq(2,n(r,"integrated_raw_ofi"));eq(11,n(r,"shared_depth_event"));eq(2.0/11,n(r,"normalized_ofi"));eq(60000,n(r,"crossed_observed_ms"));
        });
        test("locked and crossed depth-time normalization includes all fresh intervals",()->{
            for(int ask:new int[]{100,99}){
                List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config("weights.mode","UNIFORM","depth.mode","TIME"),ask,3,3,T);
                e.onTime(T+20*S);e.replace("B0",100,16);e.onTime(T+40*S);e.replace("B0",100,16);e.onTime(T+M);
                accepted(rows.get(0));eq(32.0/3,n(rows.get(0),"shared_depth_time"));eq(2/(32.0/3),n(rows.get(0),"normalized_ofi"));
            }
        });
        test("EVENT-mode spread-translation invariance over 80 normal locked and crossed minutes",()->compareSpreadStates("EVENT"));
        test("TIME-mode spread-translation invariance over 80 normal locked and crossed minutes",()->compareSpreadStates("TIME"));
        test("permanently locked minutes advance warmup and reach a rolling 60-minute benchmark",()->{
            List<BarRecord> rows=sequence(100,"EVENT",80);for(int i=0;i<80;i++){accepted(rows.get(i));eq(Math.min(i,60),n(rows.get(i),"prior_sample_count"));}
            yes(rows.get(14).scoreStatus.equals("WARMUP"),"fifteenth still uses 14 prior");yes(Double.isFinite(rows.get(15).z),"sixteenth scored");
            yes(s(rows.get(15),"calibration_stage").equals("PROVISIONAL"),"provisional");yes(s(rows.get(60),"calibration_stage").equals("MATURE"),"61st mature");
        });
        test("permanently crossed minutes reach first score and roll with no current-bar leakage",()->{
            List<BarRecord> rows=sequence(99,"EVENT",80);BarRecord r=rows.get(79);eq(60,n(r,"prior_sample_count"));double mean=0;
            for(int i=19;i<79;i++)mean+=n(rows.get(i),"normalized_ofi")/60;
            double squares=0;for(int i=19;i<79;i++)squares+=Math.pow(n(rows.get(i),"normalized_ofi")-mean,2);
            double sd=Math.sqrt(squares/59);eq(mean,n(r,"prior_mean"));eq(sd,n(r,"prior_sample_sd"));eq((n(r,"normalized_ofi")-mean)/sd,r.z);
            yes(Double.isFinite(rows.get(15).z)&&Double.isFinite(rows.get(60).z),"early and mature scores");
        });
        test("midpoint fallback remains available for locked and crossed books with no trades",()->{
            for(int ask:new int[]{100,99}){
                List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config(),ask,3,3,T);minute(e,0,16);BarRecord r=rows.get(0);
                accepted(r);eq((100+ask)/2.0,r.anchorTicks);eq((100+ask)/2.0*.25,n(r,"bubble_price"));yes(s(r,"bubble_price_source").equals("MIDPOINT"),"fallback");
            }
        });
        test("valid trade price still takes priority over arithmetic midpoint",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config(),99,3,3,T);e.trade(103,7,1,false);minute(e,0,16);
            accepted(rows.get(0));eq(103,rows.get(0).anchorTicks);yes(s(rows.get(0),"bubble_price_source").equals("LAST_TRADE"),"trade anchor");
        });
        test("bad diagnostic trade cannot veto an otherwise eligible crossed minute",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config(),99,3,3,T);e.trade(Double.NaN,5,1,false);e.trade(100,0,1,false);minute(e,0,16);
            accepted(rows.get(0));eq(2,n(rows.get(0),"bad_trade_count"));yes(s(rows.get(0),"quality_warnings").contains("BAD_TRADE_IGNORED"),"diagnostic retained");
        });
        test("fewer than three levels remains invalid in either quote state",()->{
            for(int ask:new int[]{100,99}){
                List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config(),ask,2,2,T);minute(e,0,16);
                yes(!rows.get(0).valid,"depth check retained");yes(s(rows.get(0),"quality_flags").contains("INCOMPLETE_BOOK"),"depth reason");
                yes(!s(rows.get(0),"quality_flags").contains("LOCKED_BOOK")&&!s(rows.get(0),"quality_flags").contains("CROSSED_BOOK"),"no quote flags");
            }
        });
        test("stale data remains invalid even when quote filtering is disabled",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config(),99,3,3,T);e.onTime(T+59*S);e.replace("B0",100,16);e.onTime(T+M);
            yes(!rows.get(0).valid,"stale rejected");yes(s(rows.get(0),"quality_flags").contains("STALE_BOOK"),"freshness retained");
        });
        test("partial starting minute remains excluded from warmup",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config(),99,3,3,T+15*S);
            e.onTime(T+25*S);e.replace("B0",100,16);e.onTime(T+45*S);e.replace("B0",100,17);e.onTime(T+M);minute(e,1,20);
            yes(!rows.get(0).valid&&s(rows.get(0),"quality_flags").contains("PARTIAL_START"),"partial not included");eq(0,n(rows.get(1),"prior_sample_count"));accepted(rows.get(1));
        });
        test("reconstruction faults still fail closed with a crossed book",()->{
            PressureEngine e=engine(new ArrayList<>(),config(),99,3,3,T);e.cancel("UNKNOWN");yes(e.failed(),"unknown order is not quote filtering");
        });
        test("flat baseline still remains unscored rather than manufacturing pressure",()->{
            List<BarRecord> rows=new ArrayList<>();PressureEngine e=engine(rows,config(),99,3,3,T);for(int i=0;i<16;i++)minute(e,i,10);
            accepted(rows.get(15));yes(rows.get(15).scoreStatus.equals("FLAT_BASELINE"),"flat preserved");yes(Double.isNaN(rows.get(15).z),"no fake score");
        });
        test("renderer has no LOCK or CROSS labels even for legacy flag inputs",()->{
            for(String flag:List.of("LOCKED_BOOK","CROSSED_BOOK")){
                String label=BubbleImage.label(Double.NaN,"INVALID",false,flag,15,15,false);yes(!label.equals("LOCK")&&!label.equals("CROSS"),"no legacy labels");
                yes(BubbleImage.label(2.1,"READY",false,flag,15,15,false).equals("Z+2.1*"),"pressure shown");
            }
        });
        test("export schema identifies the changed acceptance policy",()->{
            List<BarRecord> rows=sequence(99,"EVENT",1);BarRecord r=rows.get(0);eq(4,n(r,"schema_version"));
            yes(s(r,"quote_state_policy").equals("NO_SPREAD_FILTER"),"policy recorded");yes(s(r,"model_version").endsWith("1.3.0"),"new model");
        });
        test("export retains quote diagnostics without marking the row invalid",()->{
            BarRecord r=sequence(99,"EVENT",1).get(0);Path dir=Files.createTempDirectory("ofi-quote-export-");
            ResearchWriter w=new ResearchWriter(config("output.directory",dir.toString()),"T","quote",.25);yes(w.submit(r),"queued");w.close();yes(!w.failed(),w.status());
            String csv=Files.readString(w.directory().resolve("2026-01-05_pressure.csv"));String metadata=Files.readString(w.directory().resolve("metadata.txt"));
            yes(csv.contains("NO_SPREAD_FILTER")&&csv.contains("crossed_observed_ms"),"diagnostic fields retained");
            yes(!csv.contains("LOCKED_BOOK")&&!csv.contains("CROSSED_BOOK"),"no invalidating flags");
            yes(metadata.contains("No spread filter")&&metadata.contains("diagnostic only"),"policy explained");
            yes(Files.size(w.directory().resolve("2026-01-05_pressure.xlsx"))>100,"workbook created");
        });
        System.out.println("\nRESULT: "+passed+" quote-state regression tests passed.");
    }
}
