package com.ofipressure;

import com.ofipressure.bookmap.SettingsView;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.concurrent.atomic.AtomicInteger;
import javax.imageio.ImageIO;
import javax.swing.*;

/** Tests the production panel directly; uses no fake Bookmap SDK classes. */
public final class SettingsViewTests {
    private static int passed;
    private static void yes(boolean b,String message){if(!b)throw new AssertionError(message);}
    private interface Action{void run()throws Exception;}
    private static void test(String name,Action action)throws Exception{action.run();passed++;System.out.println("PASS "+name);}
    private static Component named(Container root,String name){
        for(Component c:root.getComponents()){if(name.equals(c.getName()))return c;if(c instanceof Container){Component found=named((Container)c,name);if(found!=null)return found;}}
        return null;
    }
    private static void layout(Container c){c.doLayout();for(Component x:c.getComponents())if(x instanceof Container)layout((Container)x);}
    private static SettingsView view(){return new SettingsView(()->{},()->{},()->{},()->{});}
    private static void update(SettingsView v,String path,String status){v.update(status,"CSV saved; XLSX update blocked: "+path,"3-10 levels; start 15 / rolling 60",path,path+"/config.properties","");}
    private static void assertVisible(SettingsView v,String name){
        Component c=named(v,name);yes(c!=null,"component "+name);Rectangle b=SwingUtilities.convertRectangle(c.getParent(),c.getBounds(),v);
        yes(b.width>0&&b.height>0,"positive button size");yes(new Rectangle(0,0,v.getWidth(),v.getHeight()).contains(b),"clipped "+name+" at "+b);
    }
    public static void main(String[] args)throws Exception{
        final Throwable[] error={null};
        SwingUtilities.invokeAndWait(()->{
            try{
                test("long paths cannot enlarge preferred/minimum panel size",()->{
                    SettingsView v=view();Dimension min=v.getMinimumSize(),pref=v.getPreferredSize();
                    update(v,"/home/"+"a-very-long-folder/".repeat(150),"ERROR "+"details ".repeat(1000));
                    yes(v.getMinimumSize().equals(min)&&v.getPreferredSize().equals(pref),"bounds independent of contents");yes(min.width<=240&&pref.width<=380,"compact requested sizes");
                });
                test("all four action buttons stay visible at 220 x 160",()->{
                    SettingsView v=view();update(v,"/home/"+"path/".repeat(200),"READY");v.setSize(220,160);layout(v);
                    for(String name:new String[]{"openOutput","copyPath","editConfig","popOut"})assertVisible(v,name);
                });
                test("buttons stay pinned while details are scrolled to bottom",()->{
                    SettingsView v=view();update(v,"/home/user/data","READY "+"details ".repeat(200));v.setSize(300,220);layout(v);
                    JScrollPane s=(JScrollPane)named(v,"detailsScroll");s.getVerticalScrollBar().setValue(s.getVerticalScrollBar().getMaximum());layout(v);
                    assertVisible(v,"openOutput");assertVisible(v,"copyPath");yes(s.getVerticalScrollBar().isVisible(),"scrollbar visible");
                });
                test("full output path remains selectable and is not truncated in data",()->{
                    String path="/users/"+"long-name/".repeat(150)+"run";SettingsView v=view();update(v,path,"READY");
                    JTextField f=(JTextField)named(v,"outputPath");yes(f.getText().equals(path),"path exact");yes(!f.isEditable(),"read-only");f.selectAll();yes(f.getSelectedText().equals(path),"copy selection");
                });
                test("diagnostics wrap instead of forcing horizontal scrolling",()->{
                    SettingsView v=view();JTextArea a=(JTextArea)named(v,"details");JScrollPane s=(JScrollPane)named(v,"detailsScroll");
                    yes(a.getLineWrap()&&a.getWrapStyleWord(),"wrap");yes(s.getHorizontalScrollBarPolicy()==ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER,"no horizontal overflow");
                });
                test("actions dispatch independently with exact callback selection",()->{
                    AtomicInteger open=new AtomicInteger(),copy=new AtomicInteger(),edit=new AtomicInteger(),pop=new AtomicInteger();
                    SettingsView v=new SettingsView(open::incrementAndGet,copy::incrementAndGet,edit::incrementAndGet,pop::incrementAndGet);
                    for(String name:new String[]{"openOutput","copyPath","editConfig","popOut"})((JButton)named(v,name)).doClick(0);
                    yes(open.get()==1&&copy.get()==1&&edit.get()==1&&pop.get()==1,"all actions routed once");
                });
                test("popout's nested popout button is disabled",()->{SettingsView v=new SettingsView(()->{},()->{},()->{},null);yes(!named(v,"popOut").isEnabled(),"no recursive popouts");});
                test("native-looking text is plain text, not interpreted HTML",()->{
                    SettingsView v=view();update(v,"/path/<html>/&/config","<html><h1>untrusted text</h1>");
                    JTextArea a=(JTextArea)named(v,"details");yes(a.getText().contains("<html><h1>untrusted text</h1>"),"literal, not HTML layout");
                });
                test("settings describe disabled quote filtering rather than invalid quote minutes",()->{
                    SettingsView v=view();update(v,"/home/user/data","READY");
                    String text=((JTextArea)named(v,"details")).getText();
                    yes(text.contains("Quote-state filter: OFF"),"policy visible");
                    yes(!text.contains("These minutes stay invalid")&&!text.contains("LOCK:")&&!text.contains("CROSS:"),"old explanation removed");
                });
                test("panel renders at small and large dimensions",()->{
                    Path dir=Paths.get("build/ui-qa");Files.createDirectories(dir);
                    for(int[] size:new int[][]{{220,160},{300,220},{480,440},{760,500}}){
                        SettingsView v=view();update(v,"C:/Users/Researcher/Bookmap/OFI-Pressure/data/ES.CME-EXAMPLE/2026-10-05T12-00-00Z_run",
                            "READY / PROVISIONAL; prior=23/60; levels=3-10; badTrades=0; quote-state filter=OFF");
                        v.setSize(size[0],size[1]);layout(v);assertVisible(v,"openOutput");assertVisible(v,"copyPath");
                        BufferedImage image=new BufferedImage(size[0],size[1],BufferedImage.TYPE_INT_ARGB);Graphics2D g=image.createGraphics();v.printAll(g);g.dispose();
                        ImageIO.write(image,"png",dir.resolve("settings-"+size[0]+"x"+size[1]+".png").toFile());
                    }
                });
            }catch(Throwable t){error[0]=t;}
        });
        if(error[0]!=null)throw new AssertionError("EDT tests failed",error[0]);
        test("off-EDT text updates are rejected explicitly",()->{try{update(view(),"/path","bad thread");throw new AssertionError("thread misuse accepted");}catch(IllegalStateException expected){}});
        System.out.println("\nRESULT: "+passed+" settings-view regression tests passed.");
    }
}
