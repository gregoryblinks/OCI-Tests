package com.ofipressure.io;

import com.ofipressure.core.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;

/** Bounded asynchronous writer: CSV is the recovery record, XLSX is a replaceable daily snapshot. */
public final class ResearchWriter implements AutoCloseable {
    private final ArrayBlockingQueue<BarRecord> queue=new ArrayBlockingQueue<>(4096);
    private final Thread worker;
    private final Path directory;
    private final Map<String,String> metadata=new LinkedHashMap<>();
    private volatile boolean closing=false,failed=false;
    private volatile String status="Starting writer";
    private String day="";
    private FileOutputStream csvFile;
    private BufferedWriter csv;
    private List<BarRecord> daily=new ArrayList<>();
    private long rowCount=0;
    public ResearchWriter(EngineConfig config,String alias,String runId,double tickSize)throws IOException{
        String safeAlias=alias.replaceAll("[^A-Za-z0-9._-]","_");if(safeAlias.length()>60)safeAlias=safeAlias.substring(0,60);
        directory=config.outputRoot.resolve(safeAlias+"_"+Integer.toHexString(alias.hashCode())).resolve(runId);
        Files.createDirectories(directory);
        metadata.put("WARNING","Research prototype. No profitability, absorption, or next-return probability is estimated.");
        metadata.put("model_version",EngineConfig.MODEL_VERSION);metadata.put("alias",alias);metadata.put("run_id",runId);metadata.put("config_sha256",config.fingerprint());
        metadata.put("tick_size",Double.toString(tickSize));metadata.put("bucket_convention","UTC half-open [start,end); events at end belong to the next minute.");
        metadata.put("timing","Bubble emitted at available_ns (first API clock callback at/after close), not retroactively backdated. Preserve close_latency_ms in research.");
        metadata.put("pressure_z","(normalized_ofi - prior_mean) / prior_sample_sd; only PRIOR valid completed bars; sample SD (n-1).");
        metadata.put("direction","Z sign is deviation from baseline, NOT necessarily the sign of raw flow. flow_direction and deviation_direction are separate.");
        metadata.put("weights","Configured weights renormalized per event over ranks present on both sides before AND after each mutation. Default EXPONENTIAL is not fitted PCA.");
        metadata.put("depth","EVENT: average of per-event mean post-event depth over common ranks. TIME: mean available-rank depth over valid non-stale coverage. No zero-padding of unavailable ranks.");
        metadata.put("missing_data","Blank score = warm-up, flat baseline or invalid data. Ordinary invalid bars are skipped, not inserted and do NOT clear calibration. Long clock gaps, rewind and reconstruction faults still reset.");
        metadata.put("calibration", "Default first score uses 15 prior valid bars; baseline grows to 60, then rolls over the last 60 valid observations. Benchmark reached is sample count, NOT a confidence guarantee.");
        metadata.put("adaptive_depth", "Fewer than levels.minimum ranks per side is invalid. Reduced depth is a warning. Renormalization is not proof that differing level counts have identical distributions; retain level exposures for research.");
        metadata.put("bad_trades", "Invalid diagnostic trades are ignored and counted. They do not invalidate OFI; OHLC/volume diagnostics may be incomplete. quality_flags are fatal; quality_warnings are informational.");
        metadata.put("quote_state_policy", EngineConfig.QUOTE_STATE_POLICY);
        metadata.put("quote_policy", "No spread filter. Equal bid/ask and bid above ask are accepted for OFI, depth coverage, warmup and scoring, regardless of duration. All other checks remain. Quote columns are diagnostic only. No quotes are repaired; incorrect reconstructed books can still produce unreliable scores.");
        metadata.put("midpoint_policy", "Arithmetic mean of best bid and best ask whenever both sides exist, including zero or negative spread. Used as the bubble fallback when no valid trade is available; not an executable-price estimate.");
        metadata.put("quote_diagnostics", "Counts = MBO post-update locked/crossed states, not episode counts. Residence in *_observed_ms uses Bookmap callback timestamps (including stale residence), not exchange-level duration. Same-timestamp states may count with 0 ms. First issue is the first locked/crossed state observed in this minute; end quotes may already have recovered.");
        metadata.put("nanoseconds","*_ns columns are strings; Excel numeric cells cannot preserve 19-digit timestamps.");
        metadata.put("sizes","Raw Bookmap integer size units, not inferred shares/contracts. No size multiplier is guessed.");
        metadata.put("no_double_count","Trade callbacks only populate OHLC/volume diagnostics; book changes arrive through MBO callbacks.");
        metadata.put("initialization","Initial MBO snapshot is excluded from OFI; initial partial minute is invalid. No automatic historical MBO backfill.");
        metadata.put("future_labels","Not written to the live feature log. Offline tool creates a separate label file.");
        metadata.put("source_api","https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0.10/velox/api/layer1/simplified/MarketByOrderDepthDataListener.html");
        metadata.put("source_formula","https://arxiv.org/abs/1011.6402");metadata.put("source_multilevel","https://arxiv.org/abs/2112.13213");
        Properties cp=config.asProperties();for(String k:new TreeSet<>(cp.stringPropertyNames()))metadata.put("config."+k,cp.getProperty(k));
        try(Writer w=Files.newBufferedWriter(directory.resolve("metadata.txt"),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW)){for(Map.Entry<String,String> e:metadata.entrySet())w.write(e.getKey()+" = "+e.getValue()+"\n");}
        worker=new Thread(this::run,"OFI-Research-Writer-"+safeAlias);worker.setDaemon(true);worker.start();
    }
    public Path directory(){return directory;}
    public String status(){return status;}
    public boolean failed(){return failed;}
    public boolean submit(BarRecord record){
        if(closing||failed)return false;
        if(!queue.offer(record)){failed=true;status="ERROR: export queue full; reload add-on; missing rows must not be ignored";System.err.println(status);return false;}return true;
    }
    private void run(){
        try {
            while(!closing||!queue.isEmpty()){
                BarRecord r=queue.poll(250,TimeUnit.MILLISECONDS);if(r==null)continue;
                String newDay=BarRecord.iso(r.startNs).substring(0,10);
                if(!newDay.equals(day)){
                    closeCsv();day=newDay;daily=new ArrayList<>();
                    csvFile=new FileOutputStream(directory.resolve(day+"_pressure.csv").toFile(),true);
                    csv=new BufferedWriter(new OutputStreamWriter(csvFile,StandardCharsets.UTF_8));
                    if(csvFile.getChannel().size()==0)writeCsv(new ArrayList<Object>(r.headers()));
                }
                writeCsv(r.values());csv.flush();csvFile.getChannel().force(false);daily.add(r);rowCount++;
                try{
                    XlsxSnapshot.write(directory.resolve(day+"_pressure.xlsx"),daily,metadata);
                    if(!failed)status="Saved "+rowCount+" rows; CSV + XLSX current";
                }catch(IOException e){
                    status="CSV saved; XLSX update blocked (close Excel to retry): "+e.getMessage();System.err.println("OFI: "+status);
                }
            }
        }catch(Exception e){failed=true;status="ERROR: research writer stopped: "+e;System.err.println(status);}
        finally{try{closeCsv();}catch(IOException e){failed=true;status="ERROR closing CSV: "+e;}}
    }
    private void writeCsv(List<Object> values)throws IOException{
        for(int i=0;i<values.size();i++){
            if(i>0)csv.write(',');Object v=values.get(i);
            String s=v==null?"":v instanceof Number&&!Double.isFinite(((Number)v).doubleValue())?"":v.toString();
            // Protect spreadsheet users from string-valued formula injection; negative numbers stay numeric.
            if(v instanceof String&&!s.isEmpty()&&"=+-@\t\r".indexOf(s.charAt(0))>=0)s="'"+s;
            csv.write('"');csv.write(s.replace("\"","\"\""));csv.write('"');
        }csv.write("\r\n");
    }
    private void closeCsv()throws IOException{if(csv!=null){csv.flush();csvFile.getChannel().force(false);csv.close();csv=null;csvFile=null;}}
    @Override public void close(){closing=true;try{worker.join(10000);}catch(InterruptedException e){Thread.currentThread().interrupt();}
        if(worker.isAlive()){status="WARNING: writer still draining; do not terminate Bookmap until it completes";System.err.println(status);}}
}
