package com.ofipressure.bookmap;

import java.awt.*;
import javax.swing.*;
import javax.swing.text.DefaultCaret;

/** Bounded Swing view independent of the Bookmap SDK; long paths cannot set the host minimum width. */
public final class SettingsView extends JPanel {
    private final JTextField outputPath=new JTextField(1);
    private final JTextArea details=new JTextArea(10,24);
    private final JScrollPane scroll;

    public SettingsView(Runnable openOutput,Runnable copyPath,Runnable editConfig,Runnable popOut) {
        super(new BorderLayout(0,6));
        setBorder(BorderFactory.createEmptyBorder(6,6,6,6));
        setMinimumSize(new Dimension(220,160));
        setPreferredSize(new Dimension(360,300));
        JPanel actions=new JPanel(new GridLayout(2,2,4,4));
        actions.add(button("Open output","openOutput",openOutput));
        actions.add(button("Copy path","copyPath",copyPath));
        actions.add(button("Edit config","editConfig",editConfig));
        actions.add(button("Pop out","popOut",popOut));
        outputPath.setName("outputPath");outputPath.setEditable(false);
        outputPath.setMinimumSize(new Dimension(0,outputPath.getPreferredSize().height));
        outputPath.setToolTipText("Full output directory. Select/copy here, or use Copy path.");
        outputPath.getAccessibleContext().setAccessibleName("Output directory");
        JPanel header=new JPanel(new BorderLayout(0,4));
        header.add(actions,BorderLayout.NORTH);header.add(outputPath,BorderLayout.SOUTH);
        add(header,BorderLayout.NORTH); // Important: buttons never scroll out of view.
        details.setName("details");details.setEditable(false);details.setLineWrap(true);details.setWrapStyleWord(true);
        details.setFont(outputPath.getFont());details.setMargin(new Insets(6,6,6,6));
        ((DefaultCaret)details.getCaret()).setUpdatePolicy(DefaultCaret.NEVER_UPDATE);
        details.getAccessibleContext().setAccessibleName("Engine and export diagnostics");
        scroll=new JScrollPane(details,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setName("detailsScroll");scroll.setMinimumSize(new Dimension(0,40));
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll,BorderLayout.CENTER);
    }
    private static JButton button(String title,String name,Runnable action) {
        JButton b=new JButton(title);b.setName(name);b.setMargin(new Insets(4,6,4,6));
        b.setEnabled(action!=null);if(action!=null)b.addActionListener(e->action.run());return b;
    }
    /** Call on the Swing event thread. Text never becomes an unbounded JLabel. */
    public void update(String engine,String writer,String parameters,String output,String config,String notice) {
        if(!SwingUtilities.isEventDispatchThread())throw new IllegalStateException("SettingsView.update must run on EDT");
        output=clean(output);
        if(!outputPath.getText().equals(output)){outputPath.setText(output);outputPath.setCaretPosition(0);}
        String text=(clean(notice).isEmpty()?"":clean(notice)+"\n\n")+
                "ENGINE\n"+clean(engine)+"\n\nEXPORT\n"+clean(writer)+"\n\nPARAMETERS\n"+clean(parameters)+
                "\n\nCONFIGURATION\n"+clean(config)+
                "\n\nChange configuration, then disable/re-enable. A new run and warmup start.\n\n"+
                "W0/15: collecting prior valid minutes. Z+2.1*: provisional (15-59 prior samples). " +
                "Asterisk removed with 60 prior samples.\n\n"+
                "Quote-state filter: OFF. Bid/ask ordering does not block OFI, depth coverage, " +
                "warmup or scoring. Depth, freshness and reconstruction checks remain.\n\n"+
                "Pressure is a baseline deviation, not a probability. Validate in replay before use.";
        if(!details.getText().equals(text)) {
            int position=details.getCaretPosition(),vertical=scroll.getVerticalScrollBar().getValue();
            details.setText(text);details.setCaretPosition(Math.min(position,details.getDocument().getLength()));
            scroll.getVerticalScrollBar().setValue(vertical);
        }
    }
    private static String clean(String s){return s==null?"":s;}
}
