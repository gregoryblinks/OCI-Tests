package com.ofipressure.bookmap;

import com.ofipressure.core.*;
import com.ofipressure.io.*;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.*;
import velox.api.layer1.annotations.Layer1ApiVersion;
import velox.api.layer1.annotations.Layer1ApiVersionValue;
import velox.api.layer1.annotations.Layer1SimpleAttachable;
import velox.api.layer1.annotations.Layer1StrategyName;
import velox.api.layer1.data.InstrumentInfo;
import velox.api.layer1.data.TradeInfo;
import velox.api.layer1.messages.indicators.Layer1ApiUserMessageModifyIndicator.GraphType;
import velox.api.layer1.simplified.*;
import velox.gui.StrategyPanel;

/** Read-only Bookmap adapter. No order submission/modification/cancellation API is called. */
@Layer1SimpleAttachable
@Layer1StrategyName("OFI Pressure - 1 Minute Bubbles (Research v1.3.0)")
@Layer1ApiVersion(Layer1ApiVersionValue.VERSION2)
public final class OfiPressureAddon implements CustomModule, MarketByOrderDepthDataListener,
        TimeListener, SnapshotEndListener, TradeDataListener, IntervalListener, CustomSettingsPanelProvider {
    private EngineConfig config;
    private PressureEngine engine;
    private ResearchWriter writer;
    private Indicator bubbles;
    private volatile SettingsView settingsView,popoutView;
    private JDialog popoutDialog; // Only accessed on Swing EDT.
    private final AtomicBoolean updatePending=new AtomicBoolean(),desktopPending=new AtomicBoolean();
    private volatile String startupError="",notice="",engineText="Initializing",writerText="No writer";
    private volatile boolean stopped=false;

    @Override public void initialize(String alias,InstrumentInfo info,Api api,InitialState initialState){
        stopped=false;startupError="";
        try{
            config=EngineConfig.loadOrCreate(EngineConfig.configPath());
            String runId=Instant.now().toString().replace(':','-')+"_"+UUID.randomUUID().toString().substring(0,8);
            writer=new ResearchWriter(config,alias,runId,info.pips);
            bubbles=api.registerIndicator("OFI Pressure 1m bubbles",GraphType.PRIMARY);
            engine=new PressureEngine(config,alias,runId,info.pips,this::onClosedMinute);
            if(initialState!=null)engine.onTime(initialState.getCurrentTime());
            System.out.println("OFI Pressure v1.3.0 output: "+writer.directory());
        }catch(Exception e){startupError="Initialization failed: "+e.getMessage();System.err.println(startupError);if(writer!=null)writer.close();}
        refreshTexts();
    }
    private void onClosedMinute(BarRecord record){
        boolean saved=writer.submit(record);
        if(!saved)System.err.println("OFI RECORDING FAILURE for "+record.get("alias")+" "+record.get("end_utc"));
        if(!Double.isFinite(record.anchorTicks))return;
        if(!Double.isFinite(record.z)&&!config.showWarmup&&saved)return;
        if(Double.isFinite(record.z)&&Math.abs(record.z)<config.minBubbleZ&&saved)return;
        BufferedImage icon=BubbleImage.render(record.z,record.scoreStatus,!saved||writer.failed(),
                record.get("quality_flags").toString(),((Number)record.get("prior_sample_count")).intValue(),
                config.warmup,Boolean.TRUE.equals(record.get("benchmark_reached")));
        bubbles.addIcon(record.anchorTicks,icon,icon.getWidth()/2,icon.getHeight()/2);
    }
    @Override public void send(String orderId,boolean isBid,int price,int size){if(engine!=null&&!stopped)engine.send(orderId,isBid,price,size);}
    @Override public void replace(String orderId,int price,int size){if(engine!=null&&!stopped)engine.replace(orderId,price,size);}
    @Override public void cancel(String orderId){if(engine!=null&&!stopped)engine.cancel(orderId);}
    @Override public void onTimestamp(long t){if(engine!=null&&!stopped)engine.onTime(t);}
    @Override public void onSnapshotEnd(){if(engine!=null&&!stopped)engine.snapshotEnd();}
    @Override public void onTrade(double price,int size,TradeInfo tradeInfo){
        if(engine!=null&&!stopped)engine.trade(price,size,tradeInfo==null?0:tradeInfo.isBidAggressor?1:-1,tradeInfo!=null&&tradeInfo.isOtc);
    }
    @Override public long getInterval(){return 1000000000L;}
    private void refreshTexts(){
        engineText=!startupError.isEmpty()?startupError:engine==null?"Initializing":engine.status();
        writerText=writer==null?"No writer":writer.status();
    }
    @Override public void onInterval(){
        // Book state is read on Bookmap's event thread; Swing receives only immutable text.
        refreshTexts();
        if((settingsView==null&&popoutView==null)||!updatePending.compareAndSet(false,true))return;
        SwingUtilities.invokeLater(()->{try{updateViews();}finally{updatePending.set(false);}});
    }
    @Override public StrategyPanel[] getCustomSettingsPanels(){
        StrategyPanel panel=new StrategyPanel("OFI Pressure v1.3.0",new BorderLayout());
        settingsView=createView(true);
        panel.add(settingsView,BorderLayout.CENTER);
        // Do not call pack/setResizable/setMinimumSize on ANY Bookmap-owned window.
        panel.setMinimumSize(new Dimension(240,180));panel.setPreferredSize(new Dimension(380,330));
        if(SwingUtilities.isEventDispatchThread())updateViews();else SwingUtilities.invokeLater(this::updateViews);
        return new StrategyPanel[]{panel};
    }
    private SettingsView createView(boolean allowPopout){
        return new SettingsView(()->openPath(outputPath(),false),this::copyOutput,
                ()->openPath(EngineConfig.configPath(),true),allowPopout?this::showPopout:null);
    }
    private Path outputPath(){
        return (writer!=null?writer.directory():config!=null?config.outputRoot:
                EngineConfig.configPath().getParent().resolve("data")).toAbsolutePath().normalize();
    }
    private void updateViews(){
        String params=config==null?"Unavailable":config.minLevels+"-"+config.levels+" levels; "+config.weightMode+
                "; depth "+config.depthMode+"\nStart: "+config.warmup+" valid minutes; benchmark: "+config.benchmark+
                "; rolling window: "+config.window;
        for(SettingsView view:new SettingsView[]{settingsView,popoutView})if(view!=null)
            view.update(stopped?"STOPPED - "+engineText:engineText,writerText,params,outputPath().toString(),
                    EngineConfig.configPath().toAbsolutePath().toString(),notice);
    }
    private void setNotice(String text){notice=text;if(SwingUtilities.isEventDispatchThread())updateViews();else SwingUtilities.invokeLater(this::updateViews);}
    private void copyOutput(){
        try{Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(outputPath().toString()),null);setNotice("Output path copied.");}
        catch(RuntimeException ex){setNotice("Clipboard unavailable. Select the path field and copy manually. "+ex.getMessage());}
    }
    private void openPath(Path path,boolean file){
        if(!desktopPending.compareAndSet(false,true)){setNotice("A file-browser/editor request is already running. The path can still be copied.");return;}
        setNotice(file?"Opening configuration file...":"Opening output folder...");
        // Native shell/editor calls are never made on the Swing or market-data thread.
        new SwingWorker<Void,Void>(){
            @Override protected Void doInBackground()throws Exception{
                if(!Files.exists(path))throw new java.io.IOException("Path not yet created: "+path);
                if(!Desktop.isDesktopSupported())throw new UnsupportedOperationException("Desktop integration is unavailable");
                Desktop desktop=Desktop.getDesktop();
                if(file&&desktop.isSupported(Desktop.Action.EDIT))desktop.edit(path.toFile());
                else if(desktop.isSupported(Desktop.Action.OPEN))desktop.open(path.toFile());
                else throw new UnsupportedOperationException("Desktop OPEN is unavailable");
                return null;
            }
            @Override protected void done(){
                desktopPending.set(false);
                try{get();setNotice(file?"Configuration opened. Disable/re-enable after saving changes.":"Folder-open request sent. Use Copy path if no file browser appeared.");}
                catch(InterruptedException ex){Thread.currentThread().interrupt();setNotice("Open request interrupted. Copy the path instead.");}
                catch(ExecutionException|RuntimeException ex){Throwable cause=ex.getCause()==null?ex:ex.getCause();setNotice("Could not open automatically: "+cause.getMessage()+"\nPath: "+path+"\nUse Copy path or select the path above.");}
            }
        }.execute();
    }
    private void showPopout(){
        if(stopped){setNotice("The add-on is stopped. Re-enable it to open live diagnostics.");return;}
        if(popoutDialog!=null&&popoutDialog.isDisplayable()){popoutDialog.toFront();return;}
        Window owner=settingsView==null?null:SwingUtilities.getWindowAncestor(settingsView);
        final JDialog dialog=new JDialog(owner,"OFI Pressure v1.3.0 - diagnostics",Dialog.ModalityType.MODELESS);
        popoutDialog=dialog;popoutView=createView(false);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);dialog.setResizable(true);
        dialog.setContentPane(popoutView);dialog.setMinimumSize(new Dimension(260,200));
        dialog.setPreferredSize(new Dimension(480,440));updateViews();dialog.pack();
        Rectangle screen=dialog.getGraphicsConfiguration().getBounds();
        Insets insets=Toolkit.getDefaultToolkit().getScreenInsets(dialog.getGraphicsConfiguration());
        int availableWidth=Math.max(1,screen.width-insets.left-insets.right);
        int availableHeight=Math.max(1,screen.height-insets.top-insets.bottom);
        dialog.setMinimumSize(new Dimension(Math.min(260,availableWidth),Math.min(200,availableHeight)));
        dialog.setSize(Math.min(dialog.getWidth(),availableWidth),Math.min(dialog.getHeight(),availableHeight));
        dialog.setLocationRelativeTo(owner);
        dialog.setLocation(Math.max(screen.x+insets.left,Math.min(dialog.getX(),screen.x+screen.width-insets.right-dialog.getWidth())),
                Math.max(screen.y+insets.top,Math.min(dialog.getY(),screen.y+screen.height-insets.bottom-dialog.getHeight())));
        dialog.getRootPane().registerKeyboardAction(e->dialog.dispose(),KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE,0),JComponent.WHEN_IN_FOCUSED_WINDOW);
        dialog.addWindowListener(new WindowAdapter(){@Override public void windowClosed(WindowEvent e){if(popoutDialog==dialog){popoutDialog=null;popoutView=null;}}});
        dialog.setVisible(true);
    }
    @Override public void stop(){
        stopped=true;if(writer!=null)writer.close();
        SwingUtilities.invokeLater(()->{if(popoutDialog!=null)popoutDialog.dispose();updateViews();});
        // Incomplete last minute is intentionally not exported/scored.
    }
}
