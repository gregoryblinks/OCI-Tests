# Research schema 4 - adaptive multi-level OFI

Default 10-level configuration: **167 columns**, one immutable row per completed observed minute. The workbook has `minute_pressure` and `metadata` sheets. Blank numeric cells mean unavailable/unscored, not zero. All time buckets are UTC half-open intervals `[start, end)`.

## Principal fields

| Field | Definition |
| --- | --- |
| pressure_z | Current normalized OFI minus prior mean, divided by prior sample SD; blank unless data are valid and baseline variance/count permit a score |
| normalized_ofi | Event-weighted integrated OFI divided by selected shared depth |
| score_status | WARMUP, READY, FLAT_BASELINE or INVALID; both provisional and mature numeric scores have READY status |
| calibration_stage | WARMUP below minimum; PROVISIONAL below benchmark; MATURE at/above benchmark; describes stored prior history even when this minute is invalid |
| benchmark_reached | Prior sample count has reached configured benchmark; not a statistical confidence guarantee |
| data_valid | True only for a complete, usable, non-fatal-quality minute |
| quality_flags | Fatal bar-quality reasons, pipe-delimited; none when valid |
| quality_warnings | Informational only: BAD_TRADE_IGNORED, REDUCED_DEPTH, VARIABLE_DEPTH |
| prior_sample_count | Number of prior valid observations used for this minute; capped at rolling capacity, default 60 |
| prior_mean / prior_sample_sd | Statistics from only those prior values; sample SD uses n-1 |
| minimum_prior_samples / benchmark_samples / rolling_capacity | Effective configuration recorded with every row |
| baseline_span_minutes | Elapsed minutes from the oldest retained sample's start to this minute's start; may exceed sample count because invalid minutes are skipped |
| prior_empirical_percentile | Fraction below current value plus half ties in prior observations; 0..1; not a fitted normal CDF or next-return probability |
| flow_direction / deviation_direction | Separate signs of normalized raw OFI and centered pressure Z |

## Depth and trade diagnostics

| Field | Definition |
| --- | --- |
| levels / minimum_levels | Target rank count and minimum acceptable count per side |
| levels_used_min / levels_used_max / levels_used_avg | Common pre/post paired ranks used in valid OFI events; average is event-weighted, not time-weighted; blank if no valid event |
| bid_levels_end / ask_levels_end | Populated ranks at candle end, capped at target; not the total unlimited book depth |
| valid_book_coverage | Fresh usable book duration divided by 60 seconds, 0..1 |
| book_valid_pct | Same coverage in percentage points, 0..100 |
| mbo_events / valid_mbo_events | Count of mutations and count with a usable common-rank comparison |
| bad_trade_count | Ignored nonfinite-price or nonpositive-size trade callbacks; never included in price/volume diagnostics or OFI |
| trade_diagnostics_complete | False when any bad diagnostic trade was ignored; independent of OFI validity |
| otc_trades_excluded | OTC callbacks omitted from trade OHLC and volume |
| trade_open/high/low/close | Usable non-OTC trade prices; may be incomplete when bad trades were ignored |
| mid_open/high/low/close | Arithmetic best-quote midpoint whenever both sides exist, including zero/negative spread; price units, not an executable-price estimate |
| bubble_price / bubble_price_source | Last usable trade close, otherwise midpoint; source LAST_TRADE or MIDPOINT |
| aggressive_buy_size / aggressive_sell_size / unknown_aggressor_size | Diagnostic trade volumes in raw Bookmap size units; not guessed contracts/shares |
| trade_delta | Aggressive buy minus aggressive sell size; distinct from MBO-derived OFI |
| integrated_raw_ofi | Sum over events and their available common ranks of actual renormalized weight times event OFI |
| shared_depth_event | Mean across valid OFI events of each event's mean post-event paired-rank depth |
| shared_depth_time | Time average of mean currently available paired-rank depth over fresh usable coverage |
| normalization_depth | The configured EVENT or TIME depth denominator |

## Quote diagnostics (export only in v1.3.0)

| Field | Definition |
| --- | --- |
| quote_state_policy | NO_SPREAD_FILTER; bid/ask ordering has no acceptance effect |
| book_state_end | NORMAL, LOCKED, CROSSED, EMPTY, NO_BID, or NO_ASK; separate from the minute's cumulative quality flags |
| best_bid_end / best_ask_end | Actual reconstructed best prices at minute end, in price units; blank for an absent side |
| spread_ticks_end | Ask minus bid in integer price-level units; zero locked, negative crossed; blank if either side absent |
| locked_post_event_count / crossed_post_event_count | Count of MBO updates leaving the post-update book locked/crossed; not distinct episodes, not the number of validity checks |
| locked_observed_ms / crossed_observed_ms | Bookmap callback-clock residence in the state, including stale residence; not proof of matching-engine duration; same-timestamp states may count with 0 ms |
| first_quote_issue_state | First LOCKED or CROSSED state observed within this minute; blank if none |
| first_quote_issue_ns | Timestamp of that observation, stored as text; inherited issues are recorded at minute start |
| first_quote_issue_bid / first_quote_issue_ask | First-issue best prices, in price units; blank when no quote issue occurred |
| first_quote_issue_spread_ticks | First-issue ask minus bid in price-level units; blank if none |

There is no spread filter: equal/inverted quotes do not add quality flags, exclude events, subtract fresh depth coverage, or veto warmup/calibration, regardless of duration. Quote diagnostics are informational only. The historical `first_quote_issue_*` names are retained for compatibility. No quotes are repaired, dropped or shifted. Configuration schema remains 2; export schema advances to 4 and model version to 1.3.0. Other data-quality checks remain.

## Per-level fields (L1 through target L)

`Lk_ofi`: sum of rank-k before/after OFI on events where k is observed on both sides, before and after. Blank if never observed; not zero-padding.

`Lk_normalized_ofi`: that rank sum divided by the selected shared depth. It is not independently depth-normalized at rank k.

`Lk_depth_event`: mean post-event paired-side rank depth **conditional on observing rank k**. Its denominator is Lk_event_count, not the total minute event count.

`Lk_weight`: configured full-target L1-normalized weight. It is not the changing active weight used in every event.

`Lk_weighted_ofi`: actual sum of event OFI times the event-specific renormalized rank-k weight. Summing observed values across ranks reconstructs integrated_raw_ofi exactly (up to floating-point precision).

`Lk_effective_weight_event`: mean effective weight across all valid events, using zero exposure when the rank is absent. Do not multiply this mean by Lk_ofi to reconstruct weighted flow; weighting and event flow can covary.

`Lk_event_count`: number of valid OFI events where this rank is used.

`Lk_time_coverage`: fraction of fresh usable book time for which the rank exists on both sides. Time exposure and event exposure can differ.

## Timing, identity and boundaries

`start_ns`, `end_ns`, `available_ns`, `first_quote_issue_ns` are **strings** to preserve nanosecond precision in Excel. Their UTC ISO counterparts are also saved. `available_ns` is when the engine froze/emitted the observation, not silently backdated to end_ns. `close_latency_ms` and `last_mbo_age_ms` retain diagnostic delays.

`run_id`, `run_label`, `model_version`, `schema_version`, `config_sha256`, tick size, raw size unit, depth mode and weight mode identify the observation/model. Parameter reloads start new runs. Use the full identity when joining offline labels.

`direction_persistence` is the fraction of nonzero within-minute one-second weighted-flow slices agreeing with total flow direction. It is not a predictive probability.

## Invalid vs warning

A bad diagnostic trade produces a warning and a count, not a fatal flag. A 3-9-level book is valid under default settings, with REDUCED_DEPTH warning. Fewer than 3 levels, stale coverage, no usable MBO events, a partial initial minute or a clock gap remain invalid.

Ordinary invalid minutes do not update or erase the baseline. Long market-clock gaps, rewind, fatal order reconstruction faults, initialization and reload still reset it. Do not treat adaptation across different level counts as a guarantee of distributional comparability.
