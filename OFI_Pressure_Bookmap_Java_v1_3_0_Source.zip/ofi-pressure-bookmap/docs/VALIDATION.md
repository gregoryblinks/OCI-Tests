# Validation - OFI Pressure Java v1.3.0

## Delivery status

Updated source, not a precompiled or runtime-verified Bookmap JAR. The independent production engine, exporter, bubble renderer and Swing settings view compile and pass their tests. The Bookmap adapter was not compiled against its official SDK or run inside Bookmap in this environment.

The official SDK build was attempted with `python tools/build.py`. Download failed because this environment could not resolve `maven.bookmap.com`. See `sdk-build-check.txt`. No API stubs were used and no substitute JAR is presented as a working add-on.

## Executed tests

Command: `python tools/test_core.py`.

Compiler/runtime: OpenJDK 21.0.11, with `javac --release 17 -encoding UTF-8`; Java tests ran headlessly.

| Suite | Passing tests |
| --- | ---: |
| EngineTests | 36 |
| AdaptiveEngineTests | 27 |
| QuoteStateTests | 29 |
| SettingsViewTests | 11 |
| **Total** | **103** |

The full output is in `core-test-log.txt`. No failing tests were disabled to obtain this result. The old tests expecting lock/cross rejection were changed to assert the newly requested acceptance policy and expanded to check numerical behavior.

## Specific acceptance-policy checks

- Equal/inverted quotes pass both top-book validity overloads when depth is adequate.
- Same-timestamp entry, update and recovery callbacks are all included as usable OFI events.
- Full-minute locked/crossed sequences remain eligible; there is no duration limit.
- Quote ordering does not subtract fresh time coverage or time-normalization depth.
- Known three-level size updates produce hand-calculated OFI and depth-normalized values under both quote states.
- 80-minute matched normal/locked/crossed sequences have identical flow/depth/calibration outputs when only the absolute ask-price offset is changed. This is checked separately for EVENT and TIME normalization.
- Continuous locked/crossed data advance the 15-sample warmup, reach the 60-sample benchmark, and roll using exactly 60 preceding observations without current-bar leakage.
- No-trade midpoint anchors remain available for zero/negative spreads. Usable trades retain priority.
- Minimum depth, missing sides, stale input, initial partial bars, flat baselines and actual reconstruction faults remain checked.
- Quote columns remain export-only; LOCKED_BOOK/CROSSED_BOOK flags and LOCK/CROSS bubble labels are absent from the new processing path.
- Settings continue to keep file actions visible at small sizes. The 220x160 rendering was visually inspected after the update; all four buttons are visible.

## Export verification

The adaptive regression wrote 65 synthetic observations with 167 fields per row using export schema 4. Independent Python CSV parsing verified row/column counts, model/policy fields, and absence of lock/cross invalidation flags. Z-scores at observations 16, 61 and 65 were independently recalculated from the preceding accepted observations and matched within 1e-9.

The generated XLSX is a readable ZIP package; its first worksheet has 66 rows including the header. Existing workbook-creation and simulated Excel-lock recovery tests pass. No new spreadsheet styling, live-feed performance or profitability claim is made. Synthetic test data are not market observations.

## Remaining acceptance work

Build with the real SDK using the supplied script or your already-downloaded `lib` files, then test inside your Bookmap installation and MBO connection. In particular, verify provider snapshot semantics, callback ordering, units, timestamps, host rendering and export behavior under live load.

Disabling spread validation does not prove that a reconstructed book is accurate. Incorrect input may now produce a numeric pressure score. Other integrity checks are retained, but these tests do not validate the user's actual feed or determine the cause of previous quote anomalies.

Configuration schema remains 2. Export schema is 4. Model identifier is `mlofi-adaptive-depth-1.3.0`, with `quote_state_policy=NO_SPREAD_FILTER`. Research should keep this policy/version distinct from older runs.
