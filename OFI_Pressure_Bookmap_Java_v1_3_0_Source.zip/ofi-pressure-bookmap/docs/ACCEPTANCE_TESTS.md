# Bookmap/feed acceptance checklist - v1.3.0

Independent tests do not replace these checks in your Bookmap installation. Use a replay or non-trading test workspace with a supported MBO feed. Do not run old and new add-ons simultaneously.

1. Build with the real official SDK. Confirm the JAR is `ofi-pressure-bookmap-1.3.0.jar` and the entry says **Research v1.3.0**. A compile error is a blocker.
2. Confirm default parameters: 3-10 levels, startup 15, benchmark 60, rolling capacity 60. Existing custom schema-2 settings are preserved. The panel should say **Quote-state filter: OFF**.
3. Confirm initial snapshot orders are excluded from flow. The partial startup minute must still be unscored. Verify price/size units against Bookmap and the feed contract.
4. On controlled input with at least three paired levels, check equal and inverted quotes. Both entering and leaving such states must count as usable MBO events if the remaining checks pass. No LOCKED_BOOK/CROSSED_BOOK quality flags or LOCK/CROSS bubbles should appear.
5. Test continuous equal/inverted quotes for a full minute with fresh mutations and adequate depth. That minute must count toward warmup. No duration cutoff is used. Quote ordering must not subtract coverage.
6. Verify no-trade bubble placement at the arithmetic midpoint, including zero/negative spread. A usable last trade takes priority. Do not confuse this reference with an executable price.
7. Verify prior sample counts 0..14 yield WARMUP, the first eligible bar with 15 prior values yields a provisional numeric score when variance permits, and the bar with 60 prior values is MATURE. Default count stays capped at 60. The current bar must not enter its own baseline.
8. Insufficient depth, missing sides, stale input, no usable MBO events, and partial startup still reject the affected minute. A bad diagnostic trade is counted, not an OFI veto. Unknown order IDs, rewind and large clock gaps retain their failure/reset behavior.
9. Verify ordinary invalid minutes retain prior history without being added to it. A flat baseline must show FLAT rather than an infinite/fabricated score.
10. Each bubble must match its frozen CSV/XLSX record. Verify `available_ns` and close latency: rendering occurs at the first API callback at/after the boundary, not retroactively.
11. Confirm schema 4 has 167 fields with default ten levels, model `mlofi-adaptive-depth-1.3.0`, and `quote_state_policy=NO_SPREAD_FILTER`. Old quote diagnostic columns remain informational. Nanosecond values must retain text precision.
12. Test CSV continuity when Excel locks the workbook, recovery after closing Excel, permissions, orderly disable, instrument isolation, day rollover, and peak feed load.
13. Verify Open output and Copy path remain visible in a small settings panel and after scrolling. Pop out must be resizable and non-modal, and close when the add-on stops. Native folder/editor failures must not block market processing.
14. Keep v1.3 runs separate from old-policy runs. Check offline forward labels across missing/invalid minutes. These are diagnostic returns, not executable strategy P&L.

This release intentionally disables the spread-based safeguard. It does not establish that an inverted reconstructed book is correct. Compare against your feed and Bookmap independently; persistent bad input can now produce a numeric pressure value. The add-on does not execute orders.
