# v1.3.0 changes from v1.2.0

- Removed spread ordering from both OrderBook.Top validity overloads. Minimum populated levels still apply.
- Removed LOCKED_BOOK/CROSSED_BOOK invalid flags and LOCK/CROSS bubble labels.
- Included locked/crossed before/after comparisons in event OFI, active-rank integration and depth normalization.
- Included fresh locked/crossed residence in depth-time averages and valid-book coverage, regardless of duration.
- Made the arithmetic midpoint available whenever both sides exist for research and no-trade anchoring.
- Isolated quote-state observations as export-only diagnostics. Removed quote alarms from the visible engine status.
- Kept 15-prior-observation startup, the rolling 60-observation benchmark, 3-10 levels, other quality checks, export, and the compact settings window.
- Added quote_state_policy=NO_SPREAD_FILTER, advanced export schema to 4 (167 fields at ten levels), and versioned the model fingerprint.
- Updated 29 quote-policy tests including 80-minute normal/locked/crossed comparison sequences in EVENT and TIME modes; 103 independent tests pass in total.
- Build output: ofi-pressure-bookmap-1.3.0.jar. Source release; real-SDK compilation and in-Bookmap acceptance remain pending.

---

# v1.2.0 changes from v1.1.0

- Replaced unbounded SimpleStrategyPanel labels with a bounded, wrapped, scrollable Swing view.
- Pinned file actions and selectable output path; no changes to Bookmap-owned window resize settings.
- Added a separately resizable, non-modal diagnostics popout, cleaned up on stop.
- Moved Desktop open/edit into a SwingWorker with in-panel error reporting and copy-path fallback.
- Split locked equality (LOCKED_BOOK / LOCK) from strictly crossed quotes (CROSSED_BOOK / CROSS).
- Preserved strict positive-spread scoring; no automatic quote repair or bypass for transient anomalies.
- Added 13 quote diagnostics and advanced export schema to 3 (166 fields at 10 levels); config schema remains 2.
- Retained 15/60 calibration, 3-10 ranks, ignored bad-trade diagnostics, and ordinary-invalid history retention.
- Added 15 quote-state and 10 Swing view tests; all 88 independent tests pass.
- Build output is ofi-pressure-bookmap-1.2.0.jar. This delivery is source only; Bookmap SDK compilation and in-app acceptance remain pending.

---

# v1.1.0 changes from the supplied Java v1 source

- Default warmup reduced to 15 prior valid completed observations.
- Actual default rolling window changed from 240 observations to 60; benchmark stage is reached at 60 prior observations.
- Added `rolling.benchmark.minutes`, `levels.minimum` and config schema version 2.
- Safe one-time legacy-config migration with exact backup; preserves unrelated properties and does not overwrite later schema-2 customizations.
- Adaptive minimum 3 / target 10 ranks per side. Uses common ranks in both before/after states; no artificial flow from zero-padded absent levels.
- Renormalizes active-prefix weights at each event. Records actual weighted per-rank flow contributions, counts and exposures.
- Ignores/counts bad diagnostic trades and exports `BAD_TRADE_IGNORED` as a warning. OHLC/volume completeness is separately reported.
- Ordinary invalid minutes are skipped; previous valid calibration survives. Genuine reconstruction faults, rewind and long clock gaps still reset/fail closed.
- Added sample-count calibration stages, rolling-baseline span, bad-trade and depth diagnostics to schema 2.
- Added `Wn/15` warmup bubbles, provisional `*` marker and specific invalid-data labels.
- Retained separate raw-flow and standardized-deviation directions, asynchronous genuine XLSX/CSV export and strict prior-only scoring.
- Added 27 adaptive regression tests alongside 36 original tests.
- Offline labels carry calibration stage, prior sample count, depth range and bad-trade count.
- Versioned build output is `ofi-pressure-bookmap-1.1.0.jar`.

## Scope

Updated source only in this delivery. No official SDK binary, prebuilt add-on JAR, Bookmap installation, live feed, statistical forecasting model, automated order execution, or profitability claim is included.
