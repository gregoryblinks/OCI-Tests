# Generate synthetic test data locally

No market-data samples or performance results are included. Running `python tools/test_core.py` exercises the actual Java writer and creates a 65-minute adaptive-depth synthetic dataset. Its generated output directory is recorded in `build/adaptive-export-path.txt`. `QuoteStateTests` additionally creates locked/crossed quote diagnostics in a temporary test directory. The test log and schema description identify the current export (schema 4). Do not treat test fixtures as trading observations.
