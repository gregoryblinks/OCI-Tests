from ym_ofi.ofi import BestQuote, cont_ofi


def test_unchanged_prices_size_shift() -> None:
    previous = BestQuote(100, 10, 101, 12)
    current = BestQuote(100, 15, 101, 8)
    assert cont_ofi(previous, current) == 9


def test_bid_and_ask_move_up() -> None:
    previous = BestQuote(100, 10, 101, 12)
    current = BestQuote(101, 7, 102, 9)
    # New bid enters (+7); old ask leaves (+12).
    assert cont_ofi(previous, current) == 19


def test_bid_and_ask_move_down() -> None:
    previous = BestQuote(100, 10, 101, 12)
    current = BestQuote(99, 7, 100, 9)
    # Old bid leaves (-10); new ask enters (-9).
    assert cont_ofi(previous, current) == -19
