# Primary references

- Databento Python historical quickstart:
  https://databento.com/docs/getting-started/historical
- Databento MBO schema:
  https://databento.com/docs/schemas-and-data-formats/mbo
- Databento MBO snapshots:
  https://databento.com/docs/standards-and-conventions/mbo-snapshot
- Databento order-state example:
  https://databento.com/docs/examples/order-book/order-tracking
- Databento full limit-order-book example:
  https://databento.com/docs/examples/order-book/limit-order-book
- Databento historical cost endpoint:
  https://databento.com/docs/api-reference-historical/metadata/metadata-get-cost
- Databento live snapshot subscription:
  https://databento.com/docs/api-reference-live/client/live-threaded-subscribe-with-snapshot
- Databento continuous futures symbology:
  https://databento.com/docs/knowledge-base/new-users/symbology
- Cont, Kukanov, and Stoikov, The Price Impact of Order Book Events:
  https://arxiv.org/abs/1011.6402
