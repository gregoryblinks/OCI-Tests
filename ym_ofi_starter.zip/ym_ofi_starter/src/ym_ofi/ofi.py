from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class BestQuote:
    bid_price: int
    bid_size: int
    ask_price: int
    ask_size: int


@dataclass(slots=True)
class EventStats:
    trade_buy: int = 0
    trade_sell: int = 0
    add_bid: int = 0
    add_ask: int = 0
    cancel_bid: int = 0
    cancel_ask: int = 0

    def clear(self) -> None:
        self.trade_buy = 0
        self.trade_sell = 0
        self.add_bid = 0
        self.add_ask = 0
        self.cancel_bid = 0
        self.cancel_ask = 0


@dataclass(frozen=True, slots=True)
class PressureEvent:
    ts_event: int
    ofi: float
    best_depth: float
    trade_buy: int
    trade_sell: int
    add_bid: int
    add_ask: int
    cancel_bid: int
    cancel_ask: int


@dataclass(frozen=True, slots=True)
class Prediction:
    horizon_seconds: int
    up_pressure_pct: float
    down_pressure_pct: float
    net_ofi: float
    average_best_depth: float
    impact_score: float
    trade_buy_pct: float
    trade_sell_pct: float
    mbo_buy_support_pct: float
    mbo_sell_support_pct: float
    current_bid_depth_pct: float
    current_ask_depth_pct: float
    direction: str
    fully_warmed: bool


def cont_ofi(previous: BestQuote, current: BestQuote) -> float:
    """Cont-Kukanov-Stoikov best-level OFI event contribution."""
    value = 0.0

    if current.bid_price >= previous.bid_price:
        value += current.bid_size
    if current.bid_price <= previous.bid_price:
        value -= previous.bid_size
    if current.ask_price <= previous.ask_price:
        value -= current.ask_size
    if current.ask_price >= previous.ask_price:
        value += previous.ask_size

    return value


@dataclass(slots=True)
class RollingPressure:
    horizon_seconds: int
    events: deque[PressureEvent] = field(default_factory=deque)
    positive_ofi: float = 0.0
    negative_ofi_abs: float = 0.0
    depth_sum: float = 0.0
    trade_buy: int = 0
    trade_sell: int = 0
    add_bid: int = 0
    add_ask: int = 0
    cancel_bid: int = 0
    cancel_ask: int = 0

    @property
    def horizon_ns(self) -> int:
        return self.horizon_seconds * 1_000_000_000

    def clear(self) -> None:
        self.events.clear()
        self.positive_ofi = 0.0
        self.negative_ofi_abs = 0.0
        self.depth_sum = 0.0
        self.trade_buy = 0
        self.trade_sell = 0
        self.add_bid = 0
        self.add_ask = 0
        self.cancel_bid = 0
        self.cancel_ask = 0

    def add(self, event: PressureEvent) -> None:
        self.events.append(event)
        self._apply(event, sign=1)
        self.expire(event.ts_event)

    def expire(self, now_ns: int) -> None:
        cutoff = now_ns - self.horizon_ns
        while self.events and self.events[0].ts_event < cutoff:
            old = self.events.popleft()
            self._apply(old, sign=-1)

    def snapshot(
        self,
        now_ns: int,
        started_at_ns: int,
        current_bid_depth: int,
        current_ask_depth: int,
    ) -> Prediction:
        self.expire(now_ns)

        total_ofi_activity = self.positive_ofi + self.negative_ofi_abs
        if total_ofi_activity > 0:
            up = 100.0 * self.positive_ofi / total_ofi_activity
        else:
            up = 50.0
        down = 100.0 - up

        event_count = len(self.events)
        avg_depth = self.depth_sum / event_count if event_count else 0.0
        net_ofi = self.positive_ofi - self.negative_ofi_abs
        impact = net_ofi / avg_depth if avg_depth > 0 else 0.0

        trade_total = self.trade_buy + self.trade_sell
        trade_buy_pct = 100.0 * self.trade_buy / trade_total if trade_total else 50.0
        trade_sell_pct = 100.0 - trade_buy_pct

        # Additions to bids and cancellations from asks support the buy side.
        # Additions to asks and cancellations from bids support the sell side.
        mbo_buy_support = self.add_bid + self.cancel_ask
        mbo_sell_support = self.add_ask + self.cancel_bid
        mbo_total = mbo_buy_support + mbo_sell_support
        mbo_buy_pct = 100.0 * mbo_buy_support / mbo_total if mbo_total else 50.0
        mbo_sell_pct = 100.0 - mbo_buy_pct

        current_depth_total = current_bid_depth + current_ask_depth
        bid_depth_pct = (
            100.0 * current_bid_depth / current_depth_total
            if current_depth_total
            else 50.0
        )
        ask_depth_pct = 100.0 - bid_depth_pct

        if up >= 55.0:
            direction = "UP"
        elif down >= 55.0:
            direction = "DOWN"
        else:
            direction = "NEUTRAL"

        warmed = now_ns - started_at_ns >= self.horizon_ns

        return Prediction(
            horizon_seconds=self.horizon_seconds,
            up_pressure_pct=up,
            down_pressure_pct=down,
            net_ofi=net_ofi,
            average_best_depth=avg_depth,
            impact_score=impact,
            trade_buy_pct=trade_buy_pct,
            trade_sell_pct=trade_sell_pct,
            mbo_buy_support_pct=mbo_buy_pct,
            mbo_sell_support_pct=mbo_sell_pct,
            current_bid_depth_pct=bid_depth_pct,
            current_ask_depth_pct=ask_depth_pct,
            direction=direction,
            fully_warmed=warmed,
        )

    def _apply(self, event: PressureEvent, sign: int) -> None:
        if event.ofi >= 0:
            self.positive_ofi += sign * event.ofi
        else:
            self.negative_ofi_abs += sign * (-event.ofi)
        self.depth_sum += sign * event.best_depth
        self.trade_buy += sign * event.trade_buy
        self.trade_sell += sign * event.trade_sell
        self.add_bid += sign * event.add_bid
        self.add_ask += sign * event.add_ask
        self.cancel_bid += sign * event.cancel_bid
        self.cancel_ask += sign * event.cancel_ask


@dataclass(slots=True)
class OFIPredictor:
    horizons_seconds: tuple[int, ...]
    previous_quote: BestQuote | None = None
    started_at_ns: int | None = None
    current_bid_depth: int = 0
    current_ask_depth: int = 0
    windows: dict[int, RollingPressure] = field(init=False)

    def __post_init__(self) -> None:
        self.windows = {
            horizon: RollingPressure(horizon) for horizon in self.horizons_seconds
        }

    def start(self, first_event_ns: int) -> None:
        self.started_at_ns = first_event_ns
        self.previous_quote = None
        self.current_bid_depth = 0
        self.current_ask_depth = 0
        for window in self.windows.values():
            window.clear()

    def observe(
        self,
        ts_event: int,
        quote: BestQuote,
        stats: EventStats,
        current_bid_depth: int,
        current_ask_depth: int,
    ) -> None:
        if self.started_at_ns is None:
            self.start(ts_event)

        ofi_value = (
            cont_ofi(self.previous_quote, quote)
            if self.previous_quote is not None
            else 0.0
        )
        self.previous_quote = quote
        self.current_bid_depth = current_bid_depth
        self.current_ask_depth = current_ask_depth

        event = PressureEvent(
            ts_event=ts_event,
            ofi=ofi_value,
            best_depth=(quote.bid_size + quote.ask_size) / 2.0,
            trade_buy=stats.trade_buy,
            trade_sell=stats.trade_sell,
            add_bid=stats.add_bid,
            add_ask=stats.add_ask,
            cancel_bid=stats.cancel_bid,
            cancel_ask=stats.cancel_ask,
        )
        for window in self.windows.values():
            window.add(event)

    def predictions(self, now_ns: int) -> list[Prediction]:
        if self.started_at_ns is None:
            return []
        return [
            self.windows[horizon].snapshot(
                now_ns=now_ns,
                started_at_ns=self.started_at_ns,
                current_bid_depth=self.current_bid_depth,
                current_ask_depth=self.current_ask_depth,
            )
            for horizon in self.horizons_seconds
        ]
