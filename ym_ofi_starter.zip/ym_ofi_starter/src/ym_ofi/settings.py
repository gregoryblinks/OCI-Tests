from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

DATASET = "GLBX.MDP3"
SCHEMA = "mbo"
SYMBOL = "YM.v.0"
STYPE_IN = "continuous"

NY_TZ = ZoneInfo("America/New_York")
UTC = timezone.utc

SESSION_START = time(9, 30)
SESSION_END = time(11, 0)
LABEL_BUFFER_MINUTES = 15
HORIZONS_SECONDS = (120, 300, 600, 900)
EMIT_INTERVAL_SECONDS = 1
TOP_DEPTH_LEVELS = 5

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RAW_DIR = PROJECT_ROOT / "data" / "raw"
OUTPUT_DIR = PROJECT_ROOT / "data" / "output"


@dataclass(frozen=True, slots=True)
class RequestWindow:
    start: datetime
    end: datetime
    limit: int | None


def require_api_key() -> str:
    """Load .env and ensure Databento authentication is configured."""
    load_dotenv(PROJECT_ROOT / ".env")
    key = os.getenv("DATABENTO_API_KEY", "").strip()
    if not key or key == "db-REPLACE_WITH_YOUR_KEY":
        raise RuntimeError(
            "DATABENTO_API_KEY is missing. Copy .env.example to .env and add your key."
        )
    return key


def parse_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError("Date must use YYYY-MM-DD format.") from exc


def session_datetimes(session_date: date) -> tuple[datetime, datetime, datetime]:
    start = datetime.combine(session_date, SESSION_START, tzinfo=NY_TZ)
    end = datetime.combine(session_date, SESSION_END, tzinfo=NY_TZ)
    label_end = end + timedelta(minutes=LABEL_BUFFER_MINUTES)
    return start, end, label_end


def request_window(session_date: date, mode: str) -> RequestWindow:
    session_start, _, label_end = session_datetimes(session_date)

    if mode == "smoke":
        # A cheap raw-record check. It deliberately has no book snapshot and
        # therefore must not be used to calculate a valid opening order book.
        return RequestWindow(
            start=session_start,
            end=session_start + timedelta(minutes=1),
            limit=5_000,
        )

    if mode == "day":
        # Historical CME MBO snapshots are generated at 00:00 UTC. Starting
        # exactly at midnight lets the order book be reconstructed before 09:30 ET.
        session_start_utc = session_start.astimezone(UTC)
        midnight_utc = datetime.combine(session_start_utc.date(), time(0, 0), tzinfo=UTC)
        return RequestWindow(start=midnight_utc, end=label_end, limit=None)

    raise ValueError("mode must be 'smoke' or 'day'")


def raw_file(session_date: date, mode: str) -> Path:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    return RAW_DIR / f"YM_{session_date.isoformat()}_{mode}.dbn"


def output_file(session_date: date, suffix: str = "predictions") -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUTPUT_DIR / f"YM_{session_date.isoformat()}_{suffix}.csv"


def datetime_to_ns(value: datetime) -> int:
    value_utc = value.astimezone(UTC)
    seconds = int(value_utc.timestamp())
    return seconds * 1_000_000_000 + value_utc.microsecond * 1_000


def ns_to_ny_string(value: int) -> str:
    seconds, nanoseconds = divmod(value, 1_000_000_000)
    dt = datetime.fromtimestamp(seconds, tz=UTC).astimezone(NY_TZ)
    return f"{dt:%Y-%m-%d %H:%M:%S}.{nanoseconds:09d} ET"
