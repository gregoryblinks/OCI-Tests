from __future__ import annotations

import csv
from pathlib import Path
from typing import TextIO

import databento as db

from ym_ofi.engine import SignalBatch
from ym_ofi.settings import ns_to_ny_string

CSV_FIELDS = [
    "timestamp_et",
    "ts_event_ns",
    "instrument_id",
    "publisher_id",
    "best_bid",
    "best_bid_size",
    "best_ask",
    "best_ask_size",
    "mid_price",
    "horizon_seconds",
    "up_pressure_pct",
    "down_pressure_pct",
    "net_ofi",
    "average_best_depth",
    "impact_score",
    "trade_buy_pct",
    "trade_sell_pct",
    "mbo_buy_support_pct",
    "mbo_sell_support_pct",
    "top5_bid_depth_pct",
    "top5_ask_depth_pct",
    "direction",
    "fully_warmed",
]


class PredictionCsvWriter:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self._handle: TextIO = path.open("w", newline="", encoding="utf-8")
        self._writer = csv.DictWriter(self._handle, fieldnames=CSV_FIELDS)
        self._writer.writeheader()

    def write(self, batch: SignalBatch) -> None:
        scale = db.FIXED_PRICE_SCALE
        bid = batch.best_bid.price / scale
        ask = batch.best_ask.price / scale
        mid = (bid + ask) / 2.0
        timestamp = ns_to_ny_string(batch.ts_event)

        for prediction in batch.predictions:
            self._writer.writerow(
                {
                    "timestamp_et": timestamp,
                    "ts_event_ns": batch.ts_event,
                    "instrument_id": batch.instrument_id,
                    "publisher_id": batch.publisher_id,
                    "best_bid": bid,
                    "best_bid_size": batch.best_bid.size,
                    "best_ask": ask,
                    "best_ask_size": batch.best_ask.size,
                    "mid_price": mid,
                    "horizon_seconds": prediction.horizon_seconds,
                    "up_pressure_pct": round(prediction.up_pressure_pct, 4),
                    "down_pressure_pct": round(prediction.down_pressure_pct, 4),
                    "net_ofi": round(prediction.net_ofi, 4),
                    "average_best_depth": round(
                        prediction.average_best_depth, 4
                    ),
                    "impact_score": round(prediction.impact_score, 6),
                    "trade_buy_pct": round(prediction.trade_buy_pct, 4),
                    "trade_sell_pct": round(prediction.trade_sell_pct, 4),
                    "mbo_buy_support_pct": round(
                        prediction.mbo_buy_support_pct, 4
                    ),
                    "mbo_sell_support_pct": round(
                        prediction.mbo_sell_support_pct, 4
                    ),
                    "top5_bid_depth_pct": round(
                        prediction.current_bid_depth_pct, 4
                    ),
                    "top5_ask_depth_pct": round(
                        prediction.current_ask_depth_pct, 4
                    ),
                    "direction": prediction.direction,
                    "fully_warmed": prediction.fully_warmed,
                }
            )
        self._handle.flush()

    def close(self) -> None:
        self._handle.close()

    def __enter__(self) -> "PredictionCsvWriter":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def format_batch(batch: SignalBatch) -> str:
    scale = db.FIXED_PRICE_SCALE
    bid = batch.best_bid.price / scale
    ask = batch.best_ask.price / scale
    lines = [
        f"{ns_to_ny_string(batch.ts_event)}  YM {bid:.0f} x {ask:.0f}",
    ]
    for p in batch.predictions:
        minutes = p.horizon_seconds // 60
        warm = "READY" if p.fully_warmed else "WARMING"
        lines.append(
            f"  {minutes:>2}m  UP {p.up_pressure_pct:5.1f}%  "
            f"DOWN {p.down_pressure_pct:5.1f}%  "
            f"impact {p.impact_score:+7.3f}  {p.direction:<7} {warm}"
        )
    return "\n".join(lines)
