from __future__ import annotations

from dataclasses import dataclass, field

import databento as db
from sortedcontainers import SortedDict


class BookError(RuntimeError):
    """Raised when an MBO event is inconsistent with the reconstructed book."""


@dataclass(slots=True)
class Order:
    order_id: int
    side: str
    price: int
    size: int
    ts_event: int


@dataclass(slots=True)
class Level:
    size: int = 0
    count: int = 0


@dataclass(frozen=True, slots=True)
class PriceLevel:
    price: int
    size: int
    count: int


@dataclass(slots=True)
class OrderBook:
    """A compact order-level book aggregated into price levels."""

    strict: bool = True
    orders: dict[int, Order] = field(default_factory=dict)
    bids: SortedDict[int, Level] = field(default_factory=SortedDict)
    asks: SortedDict[int, Level] = field(default_factory=SortedDict)
    missing_order_events: int = 0

    def apply(self, mbo: db.MBOMsg) -> None:
        action = mbo.action

        # Databento documents Trade, Fill, and None as non-book-changing actions.
        if action in ("T", "F", "N"):
            return

        if action == "R":
            self.clear()
            return

        if mbo.side not in ("A", "B"):
            self._problem(f"Invalid side {mbo.side!r} for action {action!r}")
            return

        # This is mainly relevant to top-of-book publishers. It is harmless to
        # support it even though CME MBO is a full order-level feed.
        if mbo.flags & db.RecordFlags.F_TOB:
            if mbo.price == db.UNDEF_PRICE:
                self._clear_side(mbo.side)
                return
            if action == "A":
                self._clear_side(mbo.side)

        if action == "A":
            self._add(
                Order(
                    order_id=mbo.order_id,
                    side=mbo.side,
                    price=mbo.price,
                    size=mbo.size,
                    ts_event=mbo.ts_event,
                )
            )
        elif action == "C":
            self._cancel(mbo.order_id, mbo.size)
        elif action == "M":
            self._modify(
                order_id=mbo.order_id,
                side=mbo.side,
                price=mbo.price,
                size=mbo.size,
                ts_event=mbo.ts_event,
            )
        else:
            self._problem(f"Unknown MBO action {action!r}")

    def clear(self) -> None:
        self.orders.clear()
        self.bids.clear()
        self.asks.clear()

    def bbo(self) -> tuple[PriceLevel | None, PriceLevel | None]:
        bid = self._peek("B", 0)
        ask = self._peek("A", 0)
        return bid, ask

    def top_levels(self, side: str, count: int) -> list[PriceLevel]:
        levels = self._levels(side)
        result: list[PriceLevel] = []
        max_count = min(count, len(levels))
        for index in range(max_count):
            item_index = -(index + 1) if side == "B" else index
            price, level = levels.peekitem(item_index)
            result.append(PriceLevel(price=price, size=level.size, count=level.count))
        return result

    def depth(self, side: str, level_count: int) -> int:
        return sum(level.size for level in self.top_levels(side, level_count))

    def _peek(self, side: str, index: int) -> PriceLevel | None:
        levels = self._levels(side)
        if not levels or index >= len(levels):
            return None
        item_index = -(index + 1) if side == "B" else index
        price, level = levels.peekitem(item_index)
        return PriceLevel(price=price, size=level.size, count=level.count)

    def _add(self, order: Order) -> None:
        if order.size <= 0:
            self._problem(f"Cannot add non-positive size for order {order.order_id}")
            return

        if order.order_id in self.orders:
            self._problem(f"Duplicate add for order {order.order_id}")
            if order.order_id in self.orders:
                self._remove_existing(order.order_id)

        self.orders[order.order_id] = order
        level = self._levels(order.side).setdefault(order.price, Level())
        level.size += order.size
        level.count += 1

    def _cancel(self, order_id: int, cancel_size: int) -> None:
        order = self.orders.get(order_id)
        if order is None:
            self._problem(f"Cancel references unknown order {order_id}")
            return
        if cancel_size <= 0 or cancel_size > order.size:
            self._problem(
                f"Invalid cancel size {cancel_size} for order {order_id} with size {order.size}"
            )
            return

        level = self._levels(order.side)[order.price]
        order.size -= cancel_size
        level.size -= cancel_size

        if order.size == 0:
            self.orders.pop(order_id)
            level.count -= 1

        self._drop_empty_level(order.side, order.price)

    def _modify(
        self,
        order_id: int,
        side: str,
        price: int,
        size: int,
        ts_event: int,
    ) -> None:
        order = self.orders.get(order_id)
        if order is None:
            # Databento's reference implementation treats a missing modify as add.
            self._add(Order(order_id, side, price, size, ts_event))
            return

        if order.side != side:
            self._problem(f"Order {order_id} changed side from {order.side} to {side}")
            return

        self._remove_existing(order_id)
        self._add(Order(order_id, side, price, size, ts_event))

    def _remove_existing(self, order_id: int) -> None:
        order = self.orders.pop(order_id)
        level = self._levels(order.side)[order.price]
        level.size -= order.size
        level.count -= 1
        self._drop_empty_level(order.side, order.price)

    def _drop_empty_level(self, side: str, price: int) -> None:
        levels = self._levels(side)
        level = levels.get(price)
        if level is not None and (level.size <= 0 or level.count <= 0):
            levels.pop(price)

    def _clear_side(self, side: str) -> None:
        self.orders = {
            order_id: order
            for order_id, order in self.orders.items()
            if order.side != side
        }
        self._levels(side).clear()

    def _levels(self, side: str) -> SortedDict[int, Level]:
        if side == "B":
            return self.bids
        if side == "A":
            return self.asks
        raise ValueError("side must be 'B' or 'A'")

    def _problem(self, message: str) -> None:
        self.missing_order_events += 1
        if self.strict:
            raise BookError(message)
