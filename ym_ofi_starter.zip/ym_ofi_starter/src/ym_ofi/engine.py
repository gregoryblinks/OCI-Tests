from __future__ import annotations

from dataclasses import dataclass, field

import databento as db

from ym_ofi.book import OrderBook, PriceLevel
from ym_ofi.ofi import BestQuote, EventStats, OFIPredictor, Prediction


@dataclass(frozen=True, slots=True)
class SignalBatch:
    ts_event: int
    instrument_id: int
    publisher_id: int
    best_bid: PriceLevel
    best_ask: PriceLevel
    predictions: tuple[Prediction, ...]


@dataclass(slots=True)
class InstrumentState:
    book: OrderBook
    predictor: OFIPredictor
    pending: EventStats = field(default_factory=EventStats)
    next_emit_ns: int | None = None


class MBOEngine:
    """Shared historical/live event processor."""

    def __init__(
        self,
        session_start_ns: int,
        session_end_ns: int,
        horizons_seconds: tuple[int, ...],
        emit_interval_seconds: int = 1,
        top_depth_levels: int = 5,
        strict_book: bool = True,
    ) -> None:
        self.session_start_ns = session_start_ns
        self.session_end_ns = session_end_ns
        self.horizons_seconds = horizons_seconds
        self.emit_interval_ns = emit_interval_seconds * 1_000_000_000
        self.top_depth_levels = top_depth_levels
        self.strict_book = strict_book
        self.states: dict[tuple[int, int], InstrumentState] = {}

    def process(self, mbo: db.MBOMsg) -> SignalBatch | None:
        key = (mbo.instrument_id, mbo.publisher_id)
        state = self.states.get(key)
        if state is None:
            state = InstrumentState(
                book=OrderBook(strict=self.strict_book),
                predictor=OFIPredictor(self.horizons_seconds),
            )
            self.states[key] = state

        self._capture_event_stats(state.pending, mbo)
        state.book.apply(mbo)

        if not (mbo.flags & db.RecordFlags.F_LAST):
            return None

        pending = state.pending
        state.pending = EventStats()

        best_bid, best_ask = state.book.bbo()
        if best_bid is None or best_ask is None:
            return None

        ts_event = mbo.ts_event
        if ts_event < self.session_start_ns or ts_event >= self.session_end_ns:
            return None

        # A live process started late will warm from its first complete event,
        # rather than pretending it has the missing earlier OFI history.
        if state.predictor.started_at_ns is None:
            state.predictor.start(ts_event)
            state.next_emit_ns = ts_event

        quote = BestQuote(
            bid_price=best_bid.price,
            bid_size=best_bid.size,
            ask_price=best_ask.price,
            ask_size=best_ask.size,
        )
        state.predictor.observe(
            ts_event=ts_event,
            quote=quote,
            stats=pending,
            current_bid_depth=state.book.depth("B", self.top_depth_levels),
            current_ask_depth=state.book.depth("A", self.top_depth_levels),
        )

        assert state.next_emit_ns is not None
        if ts_event < state.next_emit_ns:
            return None

        # Move the emission clock forward without producing duplicate rows if
        # several seconds passed between market events.
        elapsed = ts_event - state.next_emit_ns
        steps = elapsed // self.emit_interval_ns + 1
        state.next_emit_ns += steps * self.emit_interval_ns

        return SignalBatch(
            ts_event=ts_event,
            instrument_id=mbo.instrument_id,
            publisher_id=mbo.publisher_id,
            best_bid=best_bid,
            best_ask=best_ask,
            predictions=tuple(state.predictor.predictions(ts_event)),
        )

    @staticmethod
    def _capture_event_stats(stats: EventStats, mbo: db.MBOMsg) -> None:
        if mbo.action == "T":
            if mbo.side == "B":
                stats.trade_buy += mbo.size
            elif mbo.side == "A":
                stats.trade_sell += mbo.size
        elif mbo.action == "A":
            if mbo.side == "B":
                stats.add_bid += mbo.size
            elif mbo.side == "A":
                stats.add_ask += mbo.size
        elif mbo.action == "C":
            if mbo.side == "B":
                stats.cancel_bid += mbo.size
            elif mbo.side == "A":
                stats.cancel_ask += mbo.size
