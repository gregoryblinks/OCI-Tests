from __future__ import annotations

import databento as db

from ym_ofi.settings import DATASET, SCHEMA, require_api_key


def main() -> None:
    require_api_key()
    client = db.Historical()

    schemas = client.metadata.list_schemas(dataset=DATASET)
    available_range = client.metadata.get_dataset_range(dataset=DATASET)

    print("Databento authentication succeeded.")
    print(f"Dataset: {DATASET}")
    print(f"MBO schema available: {SCHEMA in schemas}")
    print(f"Schemas: {schemas}")
    print(f"Available range for your account: {available_range}")

    if SCHEMA not in schemas:
        raise RuntimeError(f"{SCHEMA!r} is not available for {DATASET}.")


if __name__ == "__main__":
    main()
