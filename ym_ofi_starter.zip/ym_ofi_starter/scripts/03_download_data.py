from __future__ import annotations

import argparse

import databento as db

from ym_ofi.settings import (
    DATASET,
    SCHEMA,
    STYPE_IN,
    SYMBOL,
    parse_date,
    raw_file,
    request_window,
    require_api_key,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Download YM MBO data from Databento.")
    parser.add_argument("--date", required=True, help="NYSE session date: YYYY-MM-DD")
    parser.add_argument("--mode", choices=("smoke", "day"), default="smoke")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    session_date = parse_date(args.date)
    window = request_window(session_date, args.mode)
    destination = raw_file(session_date, args.mode)

    if destination.exists() and not args.overwrite:
        raise FileExistsError(
            f"{destination} already exists. Reuse it or add --overwrite. "
            "Repeated streaming requests are billed again."
        )
    if destination.exists():
        destination.unlink()

    require_api_key()
    client = db.Historical()

    request = {
        "dataset": DATASET,
        "symbols": SYMBOL,
        "schema": SCHEMA,
        "stype_in": STYPE_IN,
        "start": window.start.isoformat(),
        "end": window.end.isoformat(),
        "path": str(destination),
    }
    if window.limit is not None:
        request["limit"] = window.limit

    print(f"Downloading {args.mode} data to {destination} ...")
    store = client.timeseries.get_range(**request)
    print("Download complete.")
    print(f"Saved file: {destination}")
    print(f"Symbology metadata: {store.symbology}")

    if args.mode == "smoke":
        print("This smoke file tests raw records only; it has no midnight snapshot.")
    else:
        print("This day file begins at 00:00 UTC and is intended for book reconstruction.")


if __name__ == "__main__":
    main()
