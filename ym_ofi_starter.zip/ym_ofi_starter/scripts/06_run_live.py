from __future__ import annotations

from datetime import datetime

import databento as db

from ym_ofi.engine import MBOEngine
from ym_ofi.output import PredictionCsvWriter, format_batch
from ym_ofi.settings import (
    DATASET,
    EMIT_INTERVAL_SECONDS,
    HORIZONS_SECONDS,
    NY_TZ,
    RAW_DIR,
    SCHEMA,
    STYPE_IN,
    SYMBOL,
    TOP_DEPTH_LEVELS,
    datetime_to_ns,
    output_file,
    require_api_key,
    session_datetimes,
)


def main() -> None:
    require_api_key()
    now_ny = datetime.now(NY_TZ)
    session_date = now_ny.date()
    session_start, session_end, _ = session_datetimes(session_date)

    engine = MBOEngine(
        session_start_ns=datetime_to_ns(session_start),
        session_end_ns=datetime_to_ns(session_end),
        horizons_seconds=HORIZONS_SECONDS,
        emit_interval_seconds=EMIT_INTERVAL_SECONDS,
        top_depth_levels=TOP_DEPTH_LEVELS,
        strict_book=True,
    )

    output_path = output_file(session_date, "live_predictions")
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    archive_path = RAW_DIR / f"YM_{session_date.isoformat()}_live.dbn"
    writer = PredictionCsvWriter(output_path)

    def handle(record: db.DBNRecord) -> None:
        if isinstance(record, db.MBOMsg):
            batch = engine.process(record)
            if batch is not None:
                writer.write(batch)
                print(format_batch(batch))
        elif isinstance(record, db.SymbolMappingMsg):
            print(
                f"Symbol mapping: {record.stype_in_symbol} -> "
                f"instrument_id={record.instrument_id}"
            )
        elif isinstance(record, db.SystemMsg):
            print(f"Databento system: {record.msg}")
        elif isinstance(record, db.ErrorMsg):
            print(f"Databento error: {record.err}")

    client = db.Live()
    client.subscribe(
        dataset=DATASET,
        schema=SCHEMA,
        symbols=SYMBOL,
        stype_in=STYPE_IN,
        snapshot=True,
    )
    client.add_callback(handle)
    client.add_stream(str(archive_path))

    print(f"Current New York time: {now_ny:%Y-%m-%d %H:%M:%S %Z}")
    print("For a complete opening window, start this script before 09:30 ET.")
    print(f"Raw live archive: {archive_path}")
    print(f"Live predictions: {output_path}")
    print("Press Ctrl+C to stop.")

    try:
        client.start()
        client.block_for_close()
    except KeyboardInterrupt:
        print("Stopping live stream...")
        client.stop()
        client.block_for_close(timeout=5)
    finally:
        writer.close()


if __name__ == "__main__":
    main()
