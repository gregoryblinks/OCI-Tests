from __future__ import annotations

import argparse
from pathlib import Path

import databento as db

from ym_ofi.engine import MBOEngine
from ym_ofi.output import PredictionCsvWriter, format_batch
from ym_ofi.settings import (
    EMIT_INTERVAL_SECONDS,
    HORIZONS_SECONDS,
    TOP_DEPTH_LEVELS,
    datetime_to_ns,
    output_file,
    parse_date,
    raw_file,
    session_datetimes,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Replay a full YM MBO day and calculate OFI.")
    parser.add_argument("--date", required=True, help="NYSE session date: YYYY-MM-DD")
    parser.add_argument("--file", type=Path, help="Override the default day DBN file")
    parser.add_argument("--output", type=Path)
    parser.add_argument(
        "--print-every-seconds",
        type=int,
        default=30,
        help="Terminal display interval; CSV remains one-second output",
    )
    parser.add_argument(
        "--non-strict-book",
        action="store_true",
        help="Continue past unknown-order events while debugging",
    )
    args = parser.parse_args()

    session_date = parse_date(args.date)
    source = args.file or raw_file(session_date, "day")
    destination = args.output or output_file(session_date)
    if not source.exists():
        raise FileNotFoundError(
            f"{source} not found. Run scripts/03_download_data.py --mode day first."
        )

    session_start, session_end, _ = session_datetimes(session_date)
    engine = MBOEngine(
        session_start_ns=datetime_to_ns(session_start),
        session_end_ns=datetime_to_ns(session_end),
        horizons_seconds=HORIZONS_SECONDS,
        emit_interval_seconds=EMIT_INTERVAL_SECONDS,
        top_depth_levels=TOP_DEPTH_LEVELS,
        strict_book=not args.non_strict_book,
    )

    store = db.DBNStore.from_file(source)
    record_count = 0
    batch_count = 0
    last_print_ns: int | None = None
    print_interval_ns = args.print_every_seconds * 1_000_000_000

    print(f"Replaying: {source}")
    print(f"Writing predictions: {destination}")

    with PredictionCsvWriter(destination) as writer:
        for record in store:
            if not isinstance(record, db.MBOMsg):
                continue
            record_count += 1
            batch = engine.process(record)
            if batch is None:
                continue

            writer.write(batch)
            batch_count += 1

            if (
                last_print_ns is None
                or batch.ts_event - last_print_ns >= print_interval_ns
            ):
                print(format_batch(batch))
                last_print_ns = batch.ts_event

            if record_count % 1_000_000 == 0:
                print(f"Processed {record_count:,} MBO records")

    print("Historical replay complete.")
    print(f"MBO records processed: {record_count:,}")
    print(f"One-second signal batches: {batch_count:,}")
    print(f"CSV rows written: {batch_count * len(HORIZONS_SECONDS):,}")
    print(f"Output: {destination}")


if __name__ == "__main__":
    main()
