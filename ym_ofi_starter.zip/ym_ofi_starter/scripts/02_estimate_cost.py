from __future__ import annotations

import argparse

import databento as db

from ym_ofi.settings import (
    DATASET,
    SCHEMA,
    STYPE_IN,
    SYMBOL,
    parse_date,
    request_window,
    require_api_key,
)


def human_bytes(value: int) -> str:
    amount = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if amount < 1024.0 or unit == "TB":
            return f"{amount:,.2f} {unit}"
        amount /= 1024.0
    return f"{amount:,.2f} TB"


def main() -> None:
    parser = argparse.ArgumentParser(description="Estimate Databento MBO request cost.")
    parser.add_argument("--date", required=True, help="NYSE session date: YYYY-MM-DD")
    parser.add_argument("--mode", choices=("smoke", "day"), default="smoke")
    args = parser.parse_args()

    session_date = parse_date(args.date)
    window = request_window(session_date, args.mode)
    require_api_key()

    client = db.Historical()
    request = {
        "dataset": DATASET,
        "symbols": SYMBOL,
        "schema": SCHEMA,
        "stype_in": STYPE_IN,
        "start": window.start.isoformat(),
        "end": window.end.isoformat(),
        "limit": window.limit,
    }

    cost = client.metadata.get_cost(**request)
    billable_size = client.metadata.get_billable_size(**request)
    record_count = client.metadata.get_record_count(**request)

    print(f"Mode: {args.mode}")
    print(f"Symbol: {SYMBOL} ({STYPE_IN})")
    print(f"Start: {window.start.isoformat()}")
    print(f"End:   {window.end.isoformat()}")
    print(f"Record limit: {window.limit if window.limit is not None else 'none'}")
    print(f"Estimated records: {record_count:,}")
    print(f"Estimated billable size: {human_bytes(billable_size)}")
    print(f"Estimated cost: ${cost:,.6f}")
    print("No market data was downloaded by this script.")


if __name__ == "__main__":
    main()
