from __future__ import annotations

import argparse
from collections import Counter
from itertools import islice
from pathlib import Path

import databento as db

from ym_ofi.settings import parse_date, raw_file


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect a downloaded Databento DBN file.")
    parser.add_argument("--file", type=Path)
    parser.add_argument("--date", help="Used when --file is omitted")
    parser.add_argument("--mode", choices=("smoke", "day"), default="smoke")
    parser.add_argument("--show", type=int, default=20, help="Records to print")
    parser.add_argument(
        "--scan-limit",
        type=int,
        default=100_000,
        help="Maximum records to scan for the summary",
    )
    args = parser.parse_args()

    if args.file is not None:
        path = args.file
    elif args.date:
        path = raw_file(parse_date(args.date), args.mode)
    else:
        parser.error("Provide --file or --date.")

    if not path.exists():
        raise FileNotFoundError(path)

    store = db.DBNStore.from_file(path)
    print(f"File: {path}")
    print(f"Metadata: {store.metadata}")
    print(f"Symbology: {store.symbology}")
    print("\nFirst MBO records:")

    shown = 0
    for record in store:
        if not isinstance(record, db.MBOMsg):
            continue
        price = (
            "UNDEF"
            if record.price == db.UNDEF_PRICE
            else f"{record.price / db.FIXED_PRICE_SCALE:.6f}"
        )
        print(
            f"{record.pretty_ts_event} action={record.action} side={record.side} "
            f"price={price} size={record.size} order_id={record.order_id} "
            f"last={bool(record.flags & db.RecordFlags.F_LAST)} "
            f"snapshot={bool(record.flags & db.RecordFlags.F_SNAPSHOT)}"
        )
        shown += 1
        if shown >= args.show:
            break

    actions: Counter[str] = Counter()
    instruments: Counter[int] = Counter()
    snapshot_count = 0
    last_count = 0
    scanned = 0

    for record in islice(store, args.scan_limit):
        if not isinstance(record, db.MBOMsg):
            continue
        scanned += 1
        actions[record.action] += 1
        instruments[record.instrument_id] += 1
        if record.flags & db.RecordFlags.F_SNAPSHOT:
            snapshot_count += 1
        if record.flags & db.RecordFlags.F_LAST:
            last_count += 1

    print("\nSummary:")
    print(f"MBO records scanned: {scanned:,}")
    print(f"Actions: {dict(actions)}")
    print(f"Instrument IDs: {dict(instruments)}")
    print(f"Snapshot records: {snapshot_count:,}")
    print(f"F_LAST records: {last_count:,}")

    if args.mode == "day" and snapshot_count == 0:
        print("WARNING: No snapshot was found in the scanned records.")


if __name__ == "__main__":
    main()
