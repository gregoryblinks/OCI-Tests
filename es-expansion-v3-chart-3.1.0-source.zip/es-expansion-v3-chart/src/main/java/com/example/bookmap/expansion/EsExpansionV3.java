package com.example.bookmap.expansion;

import java.awt.Color;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Locale;
import velox.api.layer1.annotations.Layer1ApiVersion;
import velox.api.layer1.annotations.Layer1ApiVersionValue;
import velox.api.layer1.annotations.Layer1SimpleAttachable;
import velox.api.layer1.annotations.Layer1StrategyName;
import velox.api.layer1.data.InstrumentInfo;
import velox.api.layer1.data.TradeInfo;
import velox.api.layer1.messages.indicators.Layer1ApiUserMessageModifyIndicator.GraphType;
import velox.api.layer1.simplified.Api;
import velox.api.layer1.simplified.CustomModule;
import velox.api.layer1.simplified.HistoricalModeListener;
import velox.api.layer1.simplified.Indicator;
import velox.api.layer1.simplified.InitialState;
import velox.api.layer1.simplified.IntervalListener;
import velox.api.layer1.simplified.Parameter;
import velox.api.layer1.simplified.TimeListener;
import velox.api.layer1.simplified.TradeDataListener;
import static com.example.bookmap.expansion.ExpansionModel.*;

/**
 * Display-only Bookmap add-on. Attach to the ES contract on an existing Rithmic subscription.
 * No separate connection, order-book subscription, MBO requirement, or order submission.
 * Target SDK: Bookmap api-core/api-simplified 7.6.0.20; Java 17.
 */
@Layer1SimpleAttachable
@Layer1StrategyName("ES Expansion V3 - 1m arrows + vertical metrics")
@Layer1ApiVersion(Layer1ApiVersionValue.VERSION2)
public final class EsExpansionV3 implements CustomModule, TradeDataListener, TimeListener,
        IntervalListener, HistoricalModeListener {
    // Bookmap persists these annotated settings and reloads on edits. No source change needed.
    @Parameter(name = "Lookback (completed minutes)", minimum = 2, maximum = 240, step = 1)
    public Integer lookback = 15;
    @Parameter(name = "RVOL threshold (x)", minimum = 0.1, maximum = 100, step = 0.1)
    public Double rvolThreshold = 2.0;
    @Parameter(name = "ACC threshold (robust z of VOLUME LEVEL)", minimum = 0.1, maximum = 20, step = 0.1)
    public Double accelerationThreshold = 2.0;
    @Parameter(name = "SV threshold (+/- robust z)", minimum = 0.1, maximum = 20, step = 0.1)
    public Double svThreshold = 2.0;
    @Parameter(name = "SI threshold (+/- robust z)", minimum = 0.1, maximum = 20, step = 0.1)
    public Double siThreshold = 2.0;
    @Parameter(name = "Show full-signal arrows")
    public Boolean showArrows = true;
    @Parameter(name = "Show four vertical readings")
    public Boolean showLabels = true;
    @Parameter(name = "Labels: 0 every candle, 1 any pass, 2 full signals", minimum = 0, maximum = 2, step = 1)
    public Integer labelMode = 0;
    @Parameter(name = "Show thresholds alongside readings")
    public Boolean showThresholds = true;
    @Parameter(name = "Extend labels left of close (avoid live-edge clipping)")
    public Boolean extendLabelsLeft = true;
    @Parameter(name = "No-signal placement: 0 candle direction, 1 below, 2 above", minimum = 0, maximum = 2, step = 1)
    public Integer noSignalPlacement = 0;
    @Parameter(name = "Font size (pixels)", minimum = 9, maximum = 20, step = 1)
    public Integer fontSize = 12;
    @Parameter(name = "Arrow distance beyond high/low (ticks)", minimum = 0, maximum = 50, step = 1)
    public Double priceOffsetTicks = 2.0;
    @Parameter(name = "Extra visual gap (pixels)", minimum = 0, maximum = 40, step = 1)
    public Integer gapPixels = 5;
    @Parameter(name = "Label timezone (IANA name; LOCAL uses computer timezone)")
    public String labelTimezone = "LOCAL";
    @Parameter(name = "Audio for confirmed signals (catch-up history stays silent)")
    public Boolean enableAudio = false;
    @Parameter(name = "Exclude OTC trades")
    public Boolean excludeOtc = true;
    @Parameter(name = "Log all completed candles (otherwise signals only)")
    public Boolean logEveryCandle = false;
    @Parameter(name = "Maximum annotation/alert clock delay (seconds)", minimum = 0.1, maximum = 30, step = 0.1)
    public Double maximumEventDelaySeconds = 2.0;

    private String alias;
    private MinuteEngine engine;
    private Indicator annotations;
    private AnnotationRenderer renderer;
    private AudioAlert audio;
    private boolean running, caughtUp;
    private long eventTimestampNs = -1, lastClockNs = -1, realtimeGateNs = Long.MAX_VALUE;
    private long maximumEventDelayNs, knownLateCount, knownInvalidCount, suppressedStaleAnnotations;

    @Override public void initialize(String alias, InstrumentInfo info, Api api, InitialState initialState) {
        this.alias = alias;
        Parameters parameters = new Parameters(lookback, rvolThreshold, accelerationThreshold,
                svThreshold, siThreshold, info.pips);
        ZoneId zone = "LOCAL".equalsIgnoreCase(labelTimezone.trim())
                ? ZoneId.systemDefault() : ZoneId.of(labelTimezone.trim());
        renderer = new AnnotationRenderer(new AnnotationRenderer.Settings(showArrows, showLabels,
                showThresholds, extendLabelsLeft, labelMode, fontSize, gapPixels,
                noSignalPlacement, priceOffsetTicks, zone));
        maximumEventDelayNs = (long) (maximumEventDelaySeconds * 1_000_000_000L);
        annotations = api.registerIndicator("ES Expansion V3 annotations", GraphType.PRIMARY,
                Double.NaN, true, false);
        // Only addIcon is used. No price line is generated by the model.
        annotations.setColor(new Color(0, 0, 0, 0));
        if (enableAudio) audio = new AudioAlert();
        engine = new MinuteEngine(parameters, this::onCompletedMinute);
        caughtUp = false;
        running = true;
        // DO NOT seed a history-enabled module from InitialState's live timestamp/last trade.
        // Bookmap may first replay older subscription data. Wait for its TimeListener callbacks.
        System.out.println("ES Expansion V3 initialized for " + alias + "; label zone=" + zone
                + "; N=" + lookback + "; ACC=robust z(volume level); research thresholds, not an entry recommendation");
    }

    @Override public void onTimestamp(long timestampNs) {
        if (!running || timestampNs < 0) return;
        eventTimestampNs = timestampNs; // retain true event timestamp, including any regressions
        lastClockNs = Math.max(lastClockNs, timestampNs);
    }
    @Override public long getInterval() { return 100_000_000L; } // 100 ms Bookmap timer, NOT wall clock
    @Override public void onInterval() {
        if (!running || lastClockNs < 0) return;
        engine.onClock(lastClockNs);
    }
    @Override public void onTrade(double price, int size, TradeInfo tradeInfo) {
        if (!running || eventTimestampNs < 0) return;
        if (tradeInfo != null && excludeOtc && tradeInfo.isOtc) return;
        Side side = tradeInfo == null ? Side.UNKNOWN
                : tradeInfo.isBidAggressor ? Side.BUY : Side.SELL;
        // isBidAggressor=true means BUY aggressor, not a sell hitting the bid.
        engine.onTrade(eventTimestampNs, price, size, side);
        if (engine.droppedLateTrades() != knownLateCount) {
            knownLateCount = engine.droppedLateTrades();
            System.err.println("ES Expansion " + alias + ": late trade rejected; prior signals frozen; baseline reset.");
        }
        if (engine.invalidTrades() != knownInvalidCount) {
            knownInvalidCount = engine.invalidTrades();
            System.err.println("ES Expansion " + alias + ": invalid execution; affected candle cannot signal.");
        }
    }
    @Override public void onRealtimeStart() {
        if (!running) return;
        caughtUp = true;
        realtimeGateNs = lastClockNs;
        // In replay, this callback describes the replay frontier, NOT proof of a live exchange feed.
    }

    private void onCompletedMinute(Result result, long notificationNs) {
        if (!running) return;
        boolean timely = notificationNs >= result.candle.endNs
                && notificationNs - result.candle.endNs <= maximumEventDelayNs;
        // Simplified addIcon has NO timestamp argument: it is placed at current notification time.
        // Do not draw hours of missed labels piled up at a reconnect timestamp.
        if (timely) {
            AnnotationRenderer.Annotation annotation = renderer.render(result);
            if (annotation != null) annotations.addIcon(annotation.priceLevel, annotation.image,
                    annotation.anchorX, annotation.anchorY);
        } else {
            suppressedStaleAnnotations++;
        }
        if (logEveryCandle || result.signal != Signal.NONE) {
            System.out.printf(Locale.ROOT,
                    "ES_EXPANSION alias=%s end=%s notification=%s status=%s signal=%s "
                    + "V=%d B=%d S=%d UNKNOWN=%d RVOL=%.6f ACCz=%.6f SVraw=%.6f SVz=%.6f SIraw=%.9f SIz=%.6f "
                    + "N=%d thresholds=[%.3f,%.3f,%.3f,%.3f] timely=%s%n",
                    alias, instant(result.candle.endNs), instant(notificationNs), result.status, result.signal,
                    result.candle.volume, result.candle.buyVolume, result.candle.sellVolume, result.candle.unknownVolume,
                    result.rvol, result.accelerationZ, result.signedVolumeRaw, result.signedVolumeZ,
                    result.signedImpactRaw, result.signedImpactZ, result.parameters.lookback,
                    result.parameters.rvolThreshold, result.parameters.accelerationThreshold,
                    result.parameters.svThreshold, result.parameters.siThreshold, timely);
        }
        if (audio != null && caughtUp && timely && result.candle.endNs > realtimeGateNs
                && result.signal != Signal.NONE) audio.play(result.signal == Signal.BULLISH);
    }
    private static Instant instant(long nanos) {
        return Instant.ofEpochSecond(nanos / 1_000_000_000L, nanos % 1_000_000_000L);
    }
    @Override public void stop() {
        running = false;
        if (audio != null) { audio.close(); audio = null; }
        if (engine != null) {
            System.out.println("ES Expansion stopped for " + alias + "; completed=" + engine.completedCandles()
                    + "; late=" + engine.droppedLateTrades() + "; invalid=" + engine.invalidTrades()
                    + "; skipped empty gap minutes=" + engine.skippedEmptyMinutes()
                    + "; stale annotations withheld=" + suppressedStaleAnnotations);
        }
        // No finalize/flush: an unfinished minute must never become a confirmed signal.
    }
}
