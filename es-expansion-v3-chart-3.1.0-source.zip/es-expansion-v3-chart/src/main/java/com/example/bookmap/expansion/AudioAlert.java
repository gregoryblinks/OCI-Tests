package com.example.bookmap.expansion;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;

/** Opt-in, two-tone audio. Never block Bookmap's data thread with audio I/O. */
public final class AudioAlert implements AutoCloseable {
    private final ThreadPoolExecutor worker;
    private volatile boolean closed;
    public AudioAlert() {
        worker = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(2), task -> {
            Thread thread = new Thread(task, "ES-Expansion-audio");
            thread.setDaemon(true);
            return thread;
        }, new ThreadPoolExecutor.DiscardPolicy());
    }
    public void play(boolean bullish) {
        if (!closed) worker.execute(() -> playNow(bullish));
    }
    private void playNow(boolean bullish) {
        if (closed) return;
        final int sampleRate = 16_000;
        final int samplesPerTone = 1_280;
        byte[] bytes = new byte[samplesPerTone * 2 * 2];
        double[] frequencies = bullish ? new double[] {880, 1320} : new double[] {660, 440};
        for (int tone = 0; tone < 2; tone++) {
            for (int i = 0; i < samplesPerTone; i++) {
                double envelope = Math.min(1.0, Math.min(i / 100.0, (samplesPerTone - 1 - i) / 100.0));
                short sample = (short) (4500 * envelope * Math.sin(2 * Math.PI * frequencies[tone] * i / sampleRate));
                int offset = 2 * (tone * samplesPerTone + i);
                bytes[offset] = (byte) sample;
                bytes[offset + 1] = (byte) (sample >> 8);
            }
        }
        AudioFormat format = new AudioFormat(sampleRate, 16, 1, true, false);
        try (SourceDataLine line = AudioSystem.getSourceDataLine(format)) {
            line.open(format);
            if (closed) return;
            line.start();
            line.write(bytes, 0, bytes.length);
            line.drain();
        } catch (Exception ex) {
            System.err.println("ES Expansion: audio unavailable: " + ex.getMessage());
        }
    }
    @Override public void close() { closed = true; worker.shutdownNow(); }
}
