package com.example.bookmap.expansion;

import java.util.Objects;
import static com.example.bookmap.expansion.ExpansionModel.*;

/** One-minute aggregator driven ONLY by the Bookmap event-time clock. Not thread-safe by design. */
public final class MinuteEngine {
    @FunctionalInterface
    public interface CompletionListener {
        void onComplete(Result result, long notificationTimestampNs);
    }
    private final Parameters parameters;
    private final Window window;
    private final CompletionListener listener;
    private MutableCandle current;
    private double lastPrice = Double.NaN;
    private long completedCandles, droppedLateTrades, invalidTrades, skippedEmptyMinutes;

    public MinuteEngine(Parameters parameters, CompletionListener listener) {
        this.parameters = Objects.requireNonNull(parameters);
        this.window = new Window(parameters);
        this.listener = Objects.requireNonNull(listener);
    }
    public long completedCandles() { return completedCandles; }
    public long droppedLateTrades() { return droppedLateTrades; }
    public long invalidTrades() { return invalidTrades; }
    public long skippedEmptyMinutes() { return skippedEmptyMinutes; }
    public int historySize() { return window.size(); }

    /** Close [start,end) exactly once when the Bookmap clock first reaches end. */
    public void onClock(long timestampNs) {
        if (timestampNs < 0) return;
        long minuteStart = timestampNs / MINUTE_NS * MINUTE_NS;
        if (current == null) {
            current = new MutableCandle(minuteStart, timestampNs == minuteStart, lastPrice);
            return;
        }
        if (timestampNs < current.startNs + MINUTE_NS) return;
        while (timestampNs >= current.startNs + MINUTE_NS) {
            Candle finished = current.freeze();
            // Move the state forward before notifying consumers; no unclosed candle is emitted on stop.
            current = new MutableCandle(finished.endNs, true, lastPrice);
            Result result = window.accept(finished);
            completedCandles++;
            listener.onComplete(result, timestampNs);
            // Bound work on multi-day gaps. Missing minutes are never replaced by old traded candles.
            long remaining = (minuteStart - current.startNs) / MINUTE_NS;
            if (remaining > parameters.lookback + 1L) {
                long skip = remaining - parameters.lookback;
                skippedEmptyMinutes += skip;
                window.reset();
                current = new MutableCandle(current.startNs + skip * MINUTE_NS, true, lastPrice);
            }
        }
    }

    public void onTrade(long timestampNs, double price, int size, Side side) {
        if (timestampNs < 0) { invalidTrades++; return; }
        onClock(timestampNs); // rollover BEFORE adding a trade timestamped in the next minute
        if (timestampNs < current.startNs) {
            droppedLateTrades++;
            // Previously emitted bars remain immutable. Rebuild a clean reference after a late trade.
            window.reset();
            current.tainted = true;
            return;
        }
        if (!Double.isFinite(price) || size <= 0) {
            invalidTrades++;
            current.tainted = true;
            return;
        }
        if (side == null) side = Side.UNKNOWN;
        current.add(timestampNs, price, size, side);
        lastPrice = current.close;
    }

    private static final class MutableCandle {
        final long startNs;
        final boolean complete;
        double open, high, low, close;
        long buy, sell, unknown, firstTradeTime = Long.MAX_VALUE, lastTradeTime = Long.MIN_VALUE;
        boolean tainted;
        MutableCandle(long startNs, boolean complete, double carryPrice) {
            this.startNs = startNs;
            this.complete = complete;
            open = high = low = close = carryPrice;
        }
        void add(long timestampNs, double price, int size, Side side) {
            if (firstTradeTime == Long.MAX_VALUE) {
                open = high = low = close = price;
            } else {
                high = Math.max(high, price);
                low = Math.min(low, price);
            }
            // Out-of-order trades WITHIN the open minute are ordered by their timestamps.
            if (timestampNs < firstTradeTime) { firstTradeTime = timestampNs; open = price; }
            if (timestampNs >= lastTradeTime) { lastTradeTime = timestampNs; close = price; }
            try {
                switch (side) {
                    case BUY: buy = Math.addExact(buy, size); break;
                    case SELL: sell = Math.addExact(sell, size); break;
                    case UNKNOWN: unknown = Math.addExact(unknown, size); break;
                    default: throw new IllegalStateException("Unexpected side");
                }
                Math.addExact(Math.addExact(buy, sell), unknown);
            } catch (ArithmeticException ex) {
                tainted = true;
                // Fail closed instead of allowing signed long overflow to produce fake ratios.
                buy = sell = unknown = 0;
            }
        }
        Candle freeze() {
            return new Candle(startNs, open, high, low, close, buy, sell, unknown, complete, tainted);
        }
    }
}
