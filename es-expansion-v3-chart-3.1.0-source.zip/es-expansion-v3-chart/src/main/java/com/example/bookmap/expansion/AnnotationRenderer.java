package com.example.bookmap.expansion;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import static com.example.bookmap.expansion.ExpansionModel.*;

/** Renders an actual Bookmap icon: optional arrow plus FOUR vertically stacked metric rows. */
public final class AnnotationRenderer {
    public static final Color BULL = new Color(55, 222, 132);
    public static final Color BEAR = new Color(255, 102, 116);
    public static final Color COMMON_PASS = new Color(247, 202, 91);
    public static final Color NEUTRAL = new Color(188, 198, 212);
    private static final Color DIM = new Color(142, 155, 173);
    private static final Color BACKGROUND = new Color(15, 21, 31, 232);
    private static final Color BORDER = new Color(91, 107, 128, 230);
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT);

    public static final class Settings {
        public final boolean showArrows, showLabels, showThresholds, extendLeft;
        public final int labelMode, fontSize, gapPixels, noSignalPlacement;
        public final double priceOffsetTicks;
        public final ZoneId timeZone;
        public Settings(boolean showArrows, boolean showLabels, boolean showThresholds,
                boolean extendLeft, int labelMode, int fontSize, int gapPixels,
                int noSignalPlacement, double priceOffsetTicks, ZoneId timeZone) {
            if (labelMode < 0 || labelMode > 2 || fontSize < 9 || fontSize > 20
                    || gapPixels < 0 || gapPixels > 40 || noSignalPlacement < 0 || noSignalPlacement > 2
                    || !Double.isFinite(priceOffsetTicks) || priceOffsetTicks < 0) {
                throw new IllegalArgumentException("Invalid annotation settings");
            }
            this.showArrows = showArrows;
            this.showLabels = showLabels;
            this.showThresholds = showThresholds;
            this.extendLeft = extendLeft;
            this.labelMode = labelMode;
            this.fontSize = fontSize;
            this.gapPixels = gapPixels;
            this.noSignalPlacement = noSignalPlacement;
            this.priceOffsetTicks = priceOffsetTicks;
            this.timeZone = timeZone;
        }
    }
    public static final class Annotation {
        public final BufferedImage image;
        public final int anchorX, anchorY;
        public final double priceLevel;
        public final boolean below, arrowVisible, labelVisible;
        Annotation(BufferedImage image, int anchorX, int anchorY, double priceLevel,
                boolean below, boolean arrowVisible, boolean labelVisible) {
            this.image = image;
            this.anchorX = anchorX;
            this.anchorY = anchorY;
            this.priceLevel = priceLevel;
            this.below = below;
            this.arrowVisible = arrowVisible;
            this.labelVisible = labelVisible;
        }
    }
    private final Settings settings;
    public AnnotationRenderer(Settings settings) { this.settings = settings; }

    /** Returns null only when there is nothing to display, or no valid price anchor exists. */
    public Annotation render(Result result) {
        boolean signal = result.signal != Signal.NONE;
        boolean arrow = signal && settings.showArrows;
        boolean label = settings.showLabels && (settings.labelMode == 0
                || settings.labelMode == 1 && result.anyPass() || settings.labelMode == 2 && signal);
        if (!arrow && !label) return null;
        boolean below = result.signal == Signal.BULLISH || result.signal != Signal.BEARISH
                && (settings.noSignalPlacement == 1 || settings.noSignalPlacement == 0
                        && result.candle.close >= result.candle.open);
        double price = below ? result.candle.low - settings.priceOffsetTicks
                : result.candle.high + settings.priceOffsetTicks;
        if (!Double.isFinite(price)) return null;

        Font body = new Font(Font.MONOSPACED, Font.BOLD, settings.fontSize);
        Font titleFont = new Font(Font.SANS_SERIF, Font.BOLD, Math.max(10, settings.fontSize - 1));
        Font small = new Font(Font.MONOSPACED, Font.PLAIN, Math.max(9, settings.fontSize - 2));
        BufferedImage measuring = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics2D measure = measuring.createGraphics();
        measure.setFont(body);
        FontMetrics fm = measure.getFontMetrics();
        int rowHeight = fm.getHeight() + 2;
        int ascent = fm.getAscent();
        FontMetrics smallMetrics = measure.getFontMetrics(small);
        FontMetrics titleMetrics = measure.getFontMetrics(titleFont);
        String title = title(result);
        String[] names = {"RVOL", "ACC", "SV", "SI"};
        String[] values = {format(result.rvol, false) + "x", format(result.accelerationZ, true) + "z",
                format(result.signedVolumeZ, true) + "z", format(result.signedImpactZ, true) + "z"};
        double[] numbers = {result.rvol, result.accelerationZ, result.signedVolumeZ, result.signedImpactZ};
        for (int i = 0; i < values.length; i++) if (!Double.isFinite(numbers[i])) values[i] = "N/A";
        String[] thresholds = {
            ">=" + format(result.parameters.rvolThreshold, false) + "x",
            ">=+" + format(result.parameters.accelerationThreshold, false) + "z",
            "+/-" + format(result.parameters.svThreshold, false) + "z",
            "+/-" + format(result.parameters.siThreshold, false) + "z"
        };
        int nameWidth = fm.stringWidth("RVOL") + 12;
        int valueWidth = fm.stringWidth("-999.99z");
        for (String v : values) valueWidth = Math.max(valueWidth, fm.stringWidth(v));
        int thresholdWidth = 0;
        if (settings.showThresholds) for (String t : thresholds)
            thresholdWidth = Math.max(thresholdWidth, smallMetrics.stringWidth(t));
        int pad = 9;
        int width = label ? Math.max(2 * pad + nameWidth + valueWidth
                + (settings.showThresholds ? 12 + thresholdWidth : 0), 2 * pad + titleMetrics.stringWidth(title)) : 28;
        int titleHeight = titleMetrics.getHeight() + 7;
        int labelHeight = label ? pad + titleHeight + 4 * rowHeight + 4 : 0;
        int arrowHeight = arrow ? 23 : 0;
        int separator = arrow && label ? 5 : 0;
        int height = Math.max(1, settings.gapPixels + labelHeight + arrowHeight + separator + 1);
        measure.dispose();

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        // Left extension keeps the complete label visible near Bookmap's live/right edge.
        // The arrow itself always remains centered on its price/time anchor.
        int anchorX = settings.extendLeft && label ? width - 13 : width / 2;
        int anchorY = below ? 0 : height - 1;
        int labelY = below ? settings.gapPixels + arrowHeight + separator : 0;
        Color signalColor = result.signal == Signal.BULLISH ? BULL
                : result.signal == Signal.BEARISH ? BEAR : NEUTRAL;
        if (label) {
            g.setColor(BACKGROUND);
            g.fillRoundRect(0, labelY, width - 1, labelHeight - 1, 9, 9);
            g.setColor(signal ? signalColor : BORDER);
            g.setStroke(new BasicStroke(signal ? 1.5f : 1.0f));
            g.drawRoundRect(1, labelY + 1, width - 3, labelHeight - 3, 8, 8);
            g.setFont(titleFont);
            g.setColor(signalColor);
            g.drawString(title, pad, labelY + pad + titleMetrics.getAscent());
            int firstRowY = labelY + pad + titleHeight + ascent;
            Color[] colors = {
                result.rvolPass() ? COMMON_PASS : NEUTRAL,
                result.accelerationPass() ? COMMON_PASS : NEUTRAL,
                directionalColor(result.signedVolumeZ, result.parameters.svThreshold),
                directionalColor(result.signedImpactZ, result.parameters.siThreshold)
            };
            for (int i = 0; i < 4; i++) {
                int y = firstRowY + i * rowHeight;
                g.setFont(body);
                g.setColor(NEUTRAL);
                g.drawString(names[i], pad, y);
                g.setColor(colors[i]);
                g.drawString(values[i], pad + nameWidth + valueWidth - fm.stringWidth(values[i]), y);
                if (settings.showThresholds) {
                    g.setFont(small);
                    g.setColor(DIM);
                    g.drawString(thresholds[i], pad + nameWidth + valueWidth + 12, y);
                }
            }
        }
        if (arrow) {
            g.setColor(signalColor);
            int tipY = below ? settings.gapPixels : height - 1 - settings.gapPixels;
            int direction = below ? 1 : -1;
            Polygon polygon = new Polygon(
                    new int[] {anchorX, anchorX - 8, anchorX - 3, anchorX - 3,
                               anchorX + 3, anchorX + 3, anchorX + 8},
                    new int[] {tipY, tipY + direction * 10, tipY + direction * 10,
                               tipY + direction * 22, tipY + direction * 22,
                               tipY + direction * 10, tipY + direction * 10}, 7);
            g.fillPolygon(polygon);
        }
        g.dispose();
        return new Annotation(image, anchorX, anchorY, price, below, arrow, label);
    }

    private String title(Result r) {
        String state;
        if (r.signal == Signal.BULLISH) state = "BULLISH EXPANSION";
        else if (r.signal == Signal.BEARISH) state = "BEARISH EXPANSION";
        else switch (r.status) {
            case WARMUP: state = "WARM-UP " + r.historyCount + "/" + r.parameters.lookback; break;
            case PARTIAL: state = "PARTIAL - IGNORED"; break;
            case NO_TRADES: state = "NO TRADES"; break;
            case INVALID_DATA: state = "DATA ISSUE - NO SIGNAL"; break;
            case UNDEFINED: state = "NO SIGNAL - N/A"; break;
            default: state = "NO SIGNAL";
        }
        String time = TIME_FORMAT.withZone(settings.timeZone).format(
                Instant.ofEpochSecond(r.candle.endNs / 1_000_000_000L,
                        r.candle.endNs % 1_000_000_000L));
        return state + "  " + time;
    }
    private static Color directionalColor(double value, double threshold) {
        if (Double.isFinite(value) && value >= threshold) return BULL;
        if (Double.isFinite(value) && value <= -threshold) return BEAR;
        return NEUTRAL;
    }
    private static String format(double value, boolean signed) {
        if (!Double.isFinite(value)) return "N/A";
        return String.format(Locale.ROOT, signed ? "%+.2f" : "%.2f", value);
    }
}
