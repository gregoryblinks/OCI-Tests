package com.example.bookmap.expansion;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.ZoneId;
import javax.imageio.ImageIO;
import static com.example.bookmap.expansion.ExpansionModel.*;

/** Generates samples using the PRODUCTION icon renderer. Not a Bookmap screenshot. */
public final class RenderSamples {
    public static void main(String[] args) throws Exception {
        Path directory = Path.of(args.length == 0 ? "build/render-samples" : args[0]);
        Files.createDirectories(directory);
        AnnotationRenderer renderer = new AnnotationRenderer(new AnnotationRenderer.Settings(
                true, true, true, true, 0, 12, 5, 0, 2, ZoneId.of("UTC")));
        Result[] results = {CoreSelfTest.signalResult(true), CoreSelfTest.signalResult(false), CoreSelfTest.noSignalResult()};
        String[] names = {"bullish", "bearish", "no-signal"};
        String[] captions = {"Bullish: below candle low", "Bearish: above candle high", "No full alignment: label only"};
        BufferedImage sheet = new BufferedImage(1050, 430, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = sheet.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new Color(9, 14, 22)); g.fillRect(0, 0, sheet.getWidth(), sheet.getHeight());
        g.setColor(new Color(233, 239, 247)); g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 21));
        g.drawString("ES EXPANSION V3 | Actual annotation renderer", 27, 34);
        g.setColor(new Color(152, 168, 187)); g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        g.drawString("Synthetic test candles. These are generated icons, not a live Bookmap screenshot. z = robust standardized score.", 27, 58);
        for (int i = 0; i < results.length; i++) {
            AnnotationRenderer.Annotation a = renderer.render(results[i]);
            ImageIO.write(a.image, "png", directory.resolve(names[i] + ".png").toFile());
            int anchorX = 316 + i * 345;
            int anchorY = a.below ? 200 : 261;
            g.setColor(new Color(31, 43, 59)); g.drawLine(20 + i * 345, 208, 338 + i * 345, 208);
            int candleX = anchorX - 4;
            boolean candleUp = results[i].candle.close >= results[i].candle.open;
            g.setColor(candleUp ? AnnotationRenderer.BULL : AnnotationRenderer.BEAR);
            int candleTop = a.below ? 116 : 276;
            g.drawLine(candleX, candleTop - 12, candleX, candleTop + 58);
            g.fillRect(candleX - 7, candleTop, 14, 40);
            g.drawImage(a.image, anchorX - a.anchorX, anchorY - a.anchorY, null);
            g.setColor(new Color(222, 230, 242)); g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
            g.drawString(captions[i], 24 + i * 345, 380);
        }
        g.setColor(new Color(152, 168, 187)); g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        g.drawString("Gold = RVOL/ACC threshold passed (non-directional). Green/red = SV/SI directional threshold. Gray = not passed.", 27, 410);
        g.dispose(); ImageIO.write(sheet, "png", directory.resolve("annotation-preview.png").toFile());
        System.out.println("Renderer samples saved in " + directory.toAbsolutePath());
    }
}
