package com.example.bookmap.expansion;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import static com.example.bookmap.expansion.ExpansionModel.*;

/** Dependency-free executable tests. Throws on first failure; exit code is nonzero. */
public final class CoreSelfTest {
    private static int passed;
    private static final Parameters P = new Parameters(15, 2, 2, 2, 2, 0.25);
    public static void main(String[] args) {
        test("median odd/even and does not mutate input", CoreSelfTest::medianTest);
        test("MAD and robust normalization", CoreSelfTest::zTest);
        test("zero MAD / missing data / infinity fail closed", CoreSelfTest::undefinedTest);
        test("inclusive bullish gate", () -> equal(Signal.BULLISH, decide(2, 2, 2, 2, P)));
        test("inclusive bearish gate", () -> equal(Signal.BEARISH, decide(2, 2, -2, -2, P)));
        test("direction disagreement never signals", () -> equal(Signal.NONE, decide(4, 4, 3, -3, P)));
        test("each of the four gates is mandatory", CoreSelfTest::allGatesTest);
        test("undefined inputs cannot signal", () -> {
            equal(Signal.NONE, decide(2, 2, Double.NaN, 2, P));
            equal(Signal.NONE, decide(Double.POSITIVE_INFINITY, 2, 2, 2, P));
        });
        test("first 15 full candles warm up; candle 16 can signal", CoreSelfTest::warmupTest);
        test("bullish all-four synthetic expansion", () -> equal(Signal.BULLISH, signalResult(true).signal));
        test("bearish all-four synthetic expansion", () -> equal(Signal.BEARISH, signalResult(false).signal));
        test("current volume excluded from its own median and MAD", CoreSelfTest::noLookAheadTest);
        test("rolling reference removes the oldest minute", CoreSelfTest::fifoTest);
        test("zero-volume minute blocks directional baseline", CoreSelfTest::zeroVolumeTest);
        test("unknown aggressor does not become a sell", CoreSelfTest::unknownTest);
        test("partial / tainted candles reset the reference", CoreSelfTest::taintedTest);
        test("nonconsecutive candles reset rather than compress time", CoreSelfTest::gapWindowTest);
        test("duplicate/out-of-order completed candles rejected", CoreSelfTest::duplicateTest);
        test("trade on exact minute boundary belongs to the new minute", CoreSelfTest::boundaryTest);
        test("clock alone closes a candle once, without next trade", CoreSelfTest::clockTest);
        test("initial partial minute is not baseline history", CoreSelfTest::partialStartTest);
        test("within-minute out-of-order trades preserve OHLC", CoreSelfTest::inMinuteOrderTest);
        test("late trade cannot rewrite a closed signal; resets history", CoreSelfTest::lateTradeTest);
        test("missing minutes count as empty consecutive minutes", CoreSelfTest::emptyMinutesTest);
        test("multi-day gap processing is bounded", CoreSelfTest::largeGapTest);
        test("malformed executions taint instead of inventing volume", CoreSelfTest::invalidTest);
        test("signed volume is buy-minus-sell divided by total", CoreSelfTest::signedVolumeTest);
        test("SI is (close-open) times tick size divided by volume", CoreSelfTest::impactTest);
        test("bull arrow below low and labels below arrow", CoreSelfTest::bullPlacementTest);
        test("bear arrow above high and labels above arrow", CoreSelfTest::bearPlacementTest);
        test("non-signal labels remain visible without arrows", CoreSelfTest::noSignalLabelTest);
        test("arrow toggle does not hide labels", CoreSelfTest::independentTogglesTest);
        test("label visibility modes do not hide qualifying arrows", CoreSelfTest::labelModesTest);
        test("changing thresholds changes signal, not price or volume", CoreSelfTest::thresholdTest);
        test("constant scaling of SI cancels under robust z", CoreSelfTest::scaleTest);
        test("future changes cannot alter already emitted results", CoreSelfTest::immutableTest);
        test("streamed volume conservation over 100 synthetic minutes", CoreSelfTest::conservationTest);
        System.out.println("PASS: " + passed + " test groups. No Bookmap runtime or live Rithmic feed was used.");
    }
    private static void test(String name, Runnable run) {
        run.run(); passed++; System.out.println("PASS " + name);
    }
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    private static void equal(Object a, Object b) { check(a.equals(b), "Expected " + a + ", got " + b); }
    private static void near(double a, double b) {
        check(Math.abs(a - b) <= 1e-10 * Math.max(1, Math.abs(a)), "Expected " + a + ", got " + b);
    }
    private static void nan(double x) { check(Double.isNaN(x), "Expected NaN, got " + x); }
    private static void medianTest() {
        double[] a = {3, 1, 2}; near(2, median(a)); near(3, a[0]); near(2.5, median(new double[] {4, 1, 3, 2}));
    }
    private static void zTest() {
        double[] a = new double[15]; for (int i = 0; i < 15; i++) a[i] = i + 1;
        near(8, median(a)); near(4, mad(a, 8)); near(2, robustZ(8 + 2 * 1.4826 * 4, a));
    }
    private static void undefinedTest() {
        nan(robustZ(100, new double[] {3, 3, 3})); nan(median(new double[0]));
        nan(robustZ(3, new double[] {1, Double.NaN, 2}));
        nan(robustZ(Double.POSITIVE_INFINITY, new double[] {1, 2, 3}));
    }
    private static void allGatesTest() {
        for (int i = 0; i < 4; i++) { double[] v = {2, 2, 2, 2}; v[i] = 1.9999;
            equal(Signal.NONE, decide(v[0], v[1], v[2], v[3], P)); }
        equal(Signal.NONE, decide(3, -3, -3, -3, P));
    }
    public static Candle baseline(int minute) {
        int j = minute % 15 - 7;
        long volume = 400 + 40L * j;
        long buy = Math.round(volume * (0.5 + j * 0.01));
        return candle(minute, volume, buy, j, true, false);
    }
    public static Candle candle(int minute, long volume, long buy, double ticks, boolean complete, boolean tainted) {
        double open = 24000, close = open + ticks;
        return new Candle(minute * MINUTE_NS, open, Math.max(open, close), Math.min(open, close), close,
                buy, volume - buy, 0, complete, tainted);
    }
    private static Window warm(Parameters p) {
        Window w = new Window(p); for (int i = 0; i < p.lookback; i++) w.accept(baseline(i)); return w;
    }
    public static Result signalResult(boolean bullish) {
        return warm(P).accept(candle(15, 1200, bullish ? 1140 : 60, bullish ? 80 : -80, true, false));
    }
    private static void warmupTest() {
        Window w = new Window(P);
        for (int i = 0; i < 15; i++) { Result r = w.accept(baseline(i)); equal(Status.WARMUP, r.status);
            equal(Signal.NONE, r.signal); check(r.historyCount == i, "Wrong historical candle count"); }
        equal(Status.READY, w.accept(candle(15, 1200, 1140, 80, true, false)).status);
    }
    private static void noLookAheadTest() {
        Result r = signalResult(true); near(400, r.medianVolume); near(160, r.volumeMad);
        near(3, r.rvol); near(800 / (1.4826 * 160), r.accelerationZ);
    }
    private static void fifoTest() {
        Window w = warm(P); w.accept(candle(15, 1200, 1140, 80, true, false));
        Result r = w.accept(candle(16, 440, 220, 0, true, false)); near(440, r.medianVolume); near(1, r.rvol);
    }
    private static void zeroVolumeTest() {
        Window w = warm(P); Result empty = w.accept(candle(15, 0, 0, 0, true, false));
        equal(Status.NO_TRADES, empty.status); equal(Signal.NONE, empty.signal);
        Result next = w.accept(candle(16, 1200, 1140, 80, true, false));
        nan(next.signedVolumeZ); nan(next.signedImpactZ); equal(Signal.NONE, next.signal);
    }
    private static void unknownTest() {
        Candle c = new Candle(15 * MINUTE_NS, 24000, 24080, 24000, 24080, 1140, 50, 10, true, false);
        near(1200, c.volume); nan(c.signedVolume()); Result r = warm(P).accept(c); equal(Signal.NONE, r.signal);
        check(Double.isFinite(r.rvol), "Volume itself should remain available");
    }
    private static void taintedTest() {
        Window w = warm(P); equal(Status.PARTIAL, w.accept(candle(15, 1200, 1140, 80, false, false)).status);
        check(w.size() == 0, "Partial minute must not remain in baseline");
        equal(Status.INVALID_DATA, w.accept(candle(16, 1200, 1140, 80, true, true)).status);
    }
    private static void gapWindowTest() {
        Result r = warm(P).accept(candle(16, 1200, 1140, 80, true, false)); equal(Status.WARMUP, r.status);
        check(r.historyCount == 0, "Must reset on missing calendar minute");
    }
    private static void duplicateTest() {
        Window w = warm(P); boolean thrown = false;
        try { w.accept(baseline(14)); } catch (IllegalArgumentException ex) { thrown = true; }
        check(thrown, "Duplicate completed candle was accepted");
    }
    private static MinuteEngine engine(List<Result> out) { return new MinuteEngine(P, (r, t) -> out.add(r)); }
    private static void boundaryTest() {
        List<Result> out = new ArrayList<>(); MinuteEngine e = engine(out); e.onClock(0);
        e.onTrade(1, 100, 3, Side.BUY); e.onTrade(MINUTE_NS - 1, 101, 2, Side.SELL);
        e.onTrade(MINUTE_NS, 200, 999, Side.BUY);
        check(out.size() == 1, "Prior candle should close once"); near(5, out.get(0).candle.volume);
        near(101, out.get(0).candle.close); e.onClock(2 * MINUTE_NS); near(999, out.get(1).candle.volume);
    }
    private static void clockTest() {
        List<Result> out = new ArrayList<>(); MinuteEngine e = engine(out); e.onClock(0); e.onTrade(1, 100, 5, Side.BUY);
        check(out.isEmpty(), "No intrabar signal"); e.onClock(MINUTE_NS); e.onClock(MINUTE_NS); e.onClock(MINUTE_NS + 100);
        check(out.size() == 1, "Repeated clock callbacks must not duplicate results");
    }
    private static void partialStartTest() {
        List<Result> out = new ArrayList<>(); MinuteEngine e = engine(out); e.onTrade(17_000_000_000L, 100, 10, Side.BUY);
        e.onClock(MINUTE_NS); equal(Status.PARTIAL, out.get(0).status); check(e.historySize() == 0, "Partial added to window");
    }
    private static void inMinuteOrderTest() {
        List<Result> out = new ArrayList<>(); MinuteEngine e = engine(out); e.onClock(0);
        e.onTrade(20, 102, 1, Side.BUY); e.onTrade(10, 99, 1, Side.SELL); e.onTrade(15, 110, 1, Side.BUY);
        e.onClock(MINUTE_NS); Candle c = out.get(0).candle;
        near(99, c.open); near(102, c.close); near(110, c.high); near(99, c.low); near(3, c.volume);
    }
    private static void lateTradeTest() {
        List<Result> out = new ArrayList<>(); MinuteEngine e = engine(out); e.onClock(0); e.onTrade(1, 100, 5, Side.BUY);
        e.onClock(MINUTE_NS); e.onTrade(2, 200, 99, Side.BUY);
        check(e.droppedLateTrades() == 1, "Late trade not counted"); near(5, out.get(0).candle.volume);
        check(e.historySize() == 0, "Late trade must reset baseline");
        e.onClock(2 * MINUTE_NS); equal(Status.INVALID_DATA, out.get(1).status);
    }
    private static void emptyMinutesTest() {
        List<Result> out = new ArrayList<>(); MinuteEngine e = engine(out); e.onClock(0); e.onTrade(1, 100, 5, Side.BUY);
        e.onClock(3 * MINUTE_NS); check(out.size() == 3, "Missing minutes skipped incorrectly");
        near(0, out.get(1).candle.volume); near(0, out.get(2).candle.volume);
    }
    private static void largeGapTest() {
        List<Result> out = new ArrayList<>(); MinuteEngine e = engine(out); e.onClock(0);
        e.onClock(50_000 * MINUTE_NS); check(out.size() <= P.lookback + 2, "Gap processing unbounded");
        check(e.skippedEmptyMinutes() > 49_000, "Gap not recorded"); check(e.historySize() == 15, "Wrong empty baseline");
    }
    private static void invalidTest() {
        List<Result> out = new ArrayList<>(); MinuteEngine e = engine(out); e.onClock(0);
        e.onTrade(1, Double.NaN, 4, Side.BUY); e.onClock(MINUTE_NS);
        equal(Status.INVALID_DATA, out.get(0).status); check(e.invalidTrades() == 1, "Invalid not counted");
    }
    private static void signedVolumeTest() { near(0.6, candle(0, 100, 80, 0, true, false).signedVolume()); }
    private static void impactTest() { near(0.01, candle(0, 100, 80, 4, true, false).signedImpact(0.25)); }
    private static AnnotationRenderer renderer(boolean arrows, boolean labels, int mode) {
        return new AnnotationRenderer(new AnnotationRenderer.Settings(arrows, labels, true, true,
                mode, 12, 5, 0, 2, ZoneId.of("UTC")));
    }
    private static void bullPlacementTest() {
        Result r = signalResult(true); AnnotationRenderer.Annotation a = renderer(true, true, 0).render(r);
        check(a.below && a.arrowVisible && a.labelVisible, "Bullish display flags wrong");
        check(a.anchorY == 0, "Bull image must extend below its anchor"); near(r.candle.low - 2, a.priceLevel);
    }
    private static void bearPlacementTest() {
        Result r = signalResult(false); AnnotationRenderer.Annotation a = renderer(true, true, 0).render(r);
        check(!a.below && a.arrowVisible && a.labelVisible, "Bearish display flags wrong");
        check(a.anchorY == a.image.getHeight() - 1, "Bear image must extend above its anchor");
        near(r.candle.high + 2, a.priceLevel);
    }
    public static Result noSignalResult() {
        return warm(P).accept(candle(15, 1200, 1140, -80, true, false));
    }
    private static void noSignalLabelTest() {
        Result r = noSignalResult(); equal(Signal.NONE, r.signal);
        AnnotationRenderer.Annotation a = renderer(true, true, 0).render(r);
        check(a != null && a.labelVisible && !a.arrowVisible, "Non-signal must have label only");
    }
    private static void independentTogglesTest() {
        AnnotationRenderer.Annotation a = renderer(false, true, 0).render(signalResult(true));
        check(a.labelVisible && !a.arrowVisible, "Arrow toggle hid label");
        a = renderer(true, false, 0).render(signalResult(true)); check(a.arrowVisible && !a.labelVisible, "Label toggle hid arrow");
        check(renderer(false, false, 0).render(signalResult(true)) == null, "Both off still renders");
    }
    private static void labelModesTest() {
        check(renderer(true, true, 2).render(noSignalResult()) == null, "Signals-only mode still renders no-signal");
        check(renderer(true, true, 1).render(noSignalResult()) != null, "Any-pass mode hid passing components");
        check(renderer(true, true, 2).render(signalResult(true)).arrowVisible, "Signals-only mode hid bull arrow");
    }
    private static void thresholdTest() {
        Parameters strict = new Parameters(15, 5, 2, 2, 2, 0.25);
        equal(Signal.NONE, warm(strict).accept(candle(15, 1200, 1140, 80, true, false)).signal);
    }
    private static void scaleTest() {
        double[] values = {-0.03, 0.02, 0.01, 0.04, 0.07}; double[] scaled = values.clone();
        for (int i = 0; i < values.length; i++) scaled[i] *= 100;
        near(robustZ(0.2, values), robustZ(20, scaled));
    }
    private static void immutableTest() {
        Window w = warm(P); Result r = w.accept(candle(15, 1200, 1140, 80, true, false));
        for (int i = 16; i < 70; i++) w.accept(candle(i, 10_000, 100, -100, true, false));
        near(3, r.rvol); near(400, r.medianVolume); equal(Signal.BULLISH, r.signal);
    }
    private static void conservationTest() {
        List<Result> out = new ArrayList<>(); MinuteEngine e = engine(out); e.onClock(0); Random rng = new Random(923);
        long[] expected = new long[100];
        for (int m = 0; m < 100; m++) {
            for (int j = 0; j < 20; j++) {
                int size = 1 + rng.nextInt(100); expected[m] += size;
                e.onTrade(m * MINUTE_NS + j * 2_000_000_000L, 24000 + rng.nextInt(100), size,
                        rng.nextBoolean() ? Side.BUY : Side.SELL);
            }
        }
        e.onClock(100 * MINUTE_NS); check(out.size() == 100, "Wrong number of candles");
        for (int m = 0; m < 100; m++) near(expected[m], out.get(m).candle.volume);
    }
}
