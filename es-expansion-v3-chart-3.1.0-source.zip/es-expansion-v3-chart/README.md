# ES Expansion V3 - Bookmap chart overlay

Version 3.1.0 | Java 17 | Target Bookmap SDK: api-core/api-simplified 7.6.0.20

A display-only, trade-based research indicator for an ES contract already subscribed through Rithmic in Bookmap. It places optional expansion arrows and four vertically stacked readings directly on the primary heatmap. It does not open a separate indicator window, subscribe to MBO/order-book data, connect to Rithmic separately, or submit orders.

## Delivery and verification status

**This package contains source and build scripts, not a precompiled, verified Bookmap JAR.** The development environment could not resolve external download hosts, so the official Bookmap SDK jars could not be downloaded. Consequently, a real-SDK compilation and Bookmap runtime test were not performed here.

The SDK-independent calculation engine, minute aggregator, image renderer, and audio source compiled with `javac --release 17`. All **37 dependency-free test groups passed**. An additional optional syntax/callback preflight passed using small API test doubles; that is explicitly not evidence of SDK/runtime compatibility. The Linux/macOS build script's `--test-only` path ran successfully. The full SDK-build paths, PowerShell execution, actual audio output, and live Rithmic behavior remain unverified.

See `QUICKSTART.md` to produce a JAR on a computer with JDK 17+ and access to the Bookmap SDK. See `docs/VALIDATION.md` before trading from this display.

## Chart behavior

| Candle outcome | Arrow | Vertical readings |
| --- | --- | --- |
| BULLISH EXPANSION | Green up arrow below the completed candle's low | Below the arrow |
| BEARISH EXPANSION | Red down arrow above the completed candle's high | Above the arrow |
| No full alignment | No arrow | Still displayed by default |
| Warm-up / unavailable calculation | No arrow | Available values, or N/A, with a status heading |

The row order is always **RVOL, ACC, SV, SI**. Each row contains a value and, by default, its threshold. RVOL is shown in `x`; standardized components are shown in `z`. Here `2.00z` means a robust score of 2, not a claim about a normal-distribution tail probability.

A full signal gets a green/red heading and border. RVOL/ACC threshold passes are gold because they are non-directional. SV/SI values are green at their positive threshold and red at their negative threshold. Values that have not passed are gray. A green SV and a red SI can coexist in a **NO SIGNAL** label; that is disagreement, not a trade signal.

The `showArrows` and `showLabels` controls are independent. Turning arrows off does not turn labels off. The default label mode is **0: every completed minute**, including non-signal minutes. Mode 1 shows labels when at least one component passes; mode 2 shows labels only on full signals. These modes do not alter calculations or a qualifying arrow.

For non-signal candles, the default position is below an up/doji candle and above a down candle. It can instead be fixed above or below. No-trade minutes use the last known price as a neutral annotation anchor; before any known trade price, there is no meaningful price anchor and no icon is drawn.

The arrow's price anchor is two native price levels beyond the low/high by default, plus a small pixel gap. The entire annotation extends away from the candle: downward for bullish and upward for bearish. To reduce clipping at the live/right edge, labels extend left from the time anchor by default; the arrow remains on its time anchor. Disable that option to center the label block beneath/above the arrow when sufficient horizontal space is available.

`docs/render-samples/annotation-preview.png` is made by the actual production renderer using synthetic test candles. It is **not** a screenshot of a running Bookmap installation.

### Important time-anchor limitation

Bookmap's Simplified `Indicator.addIcon(value, image, centerX, centerY)` has no explicit timestamp argument. Each icon is therefore anchored at the **notification event time**, normally the first callback at/after the completed candle's close boundary. Its price anchor uses that completed candle's own low/high, not the next candle's price.

This version does not backdate the icon to the candle midpoint. The label shows the completed candle's end time. A small gap between end time and notification time is possible. The diagnostic log records both. This avoids suggesting that an after-close signal was known halfway through the candle. Exact candle-midpoint anchoring would require a different rendering implementation, such as a screen-space painter.

## Exact research calculations

Let `t` be the just-completed one-minute candle. The reference is the previous `N` consecutive completed one-minute candles, `t-N ... t-1`; default `N=15`. The current candle is evaluated before it enters the reference.

For a baseline vector `X`:

```text
center = median(X)
MAD    = median(abs(X - center))
z(x)   = (x - center) / (1.4826 * MAD)
```

A zero or non-finite denominator produces N/A. There is no hidden epsilon denominator, infinity-as-signal behavior, winsorization, or standard-deviation fallback.

**RVOL**

```text
RVOL_t = volume_t / median(volume_(t-N ... t-1))
pass: RVOL_t >= 2.0
```

A nonpositive median volume produces N/A.

**ACC: distribution-relative volume acceleration proxy**

```text
ACC_t = robustZ(volume_t, previous N candle volumes)
pass: ACC_t >= +2.0
```

This preserves the definition agreed in the initial version: an unusual current volume level relative to the prior distribution. It is **not** a first difference, growth rate, or second derivative of volume. RVOL and ACC use the same underlying volume observation and are not independent statistical confirmations. A true volume-change/acceleration definition should be a separately specified research version, not a silent change to this one.

**SV: signed volume**

```text
SVraw_t = (aggressiveBuyVolume_t - aggressiveSellVolume_t)
          / (aggressiveBuyVolume_t + aggressiveSellVolume_t)
SVz_t   = robustZ(SVraw_t, previous N SVraw values)
bull pass: SVz_t >= +2.0
bear pass: SVz_t <= -2.0
```

Bookmap's `TradeInfo.isBidAggressor == true` is mapped to BUY, as in Bookmap's official buy/sell trade-listener example. It must not be interpreted as a sell hitting the bid. Each execution's size is counted once; execution-chain and order-ID fields are not used to add extra volume.

Missing trade metadata is counted as UNKNOWN volume, rather than being guessed as a buy or sell. In that case total volume and trade OHLC remain available, but SV for that candle is N/A and cannot contribute to a full signal. A boolean side field cannot reveal an upstream provider's misclassification; side quality still needs live/replay verification.

**SI: signed price impact V3**

```text
SIraw_t = (lastTradePrice_t - firstTradePrice_t) / volume_t
SIz_t   = robustZ(SIraw_t, previous N SIraw values)
bull pass: SIz_t >= +2.0
bear pass: SIz_t <= -2.0
```

The engine receives prices in Bookmap price levels and multiplies the change by `InstrumentInfo.pips`, so logged SIraw is in price points per raw volume unit. The constant price-unit scaling cancels in a robust z-score. Open is the first execution in the minute and close is the last, not the previous candle's close. This is a descriptive price-per-volume proxy, not a causal estimate of market impact.

**Final gate**

```text
BULLISH: RVOL >= rvolThreshold AND ACC >= accelerationThreshold
         AND SVz >= svThreshold AND SIz >= siThreshold

BEARISH: RVOL >= rvolThreshold AND ACC >= accelerationThreshold
         AND SVz <= -svThreshold AND SIz <= -siThreshold
```

All four values must be finite. Equality passes. The four thresholds can be edited separately in Bookmap. Consecutive qualifying candles can each signal; no extra crossover requirement, cooldown, or strength score has been introduced.

Direction follows the requested standardized SV/SI rules. A positive z-score means above the recent median, not necessarily a positive raw value. No additional raw-SV/raw-SI sign filter has been silently added. This distinction matters in strongly one-sided baselines and should be examined during research.

The 2x and +/-2z defaults are **research hypotheses, not evidence of profitability**. There is no entry/exit execution logic or performance backtest in this package.

## Candle timing and data integrity

The engine uses epoch-aligned intervals `[start, start + 60 seconds)`. It subscribes to Bookmap's `TimeListener` and a 100 ms `IntervalListener`. The interval requests clock opportunities; it does **not** recompute the four values every 100 ms. Results are emitted only when a minute closes. A trade on an exact new-minute boundary is added to the new minute after the previous candle is finalized.

The computer's wall clock is not used for aggregation. That preserves the same calculations for live event streams and replay streams. Bookmap's clock/data backlog, not this indicator, determines how soon a callback is available. This does not guarantee zero-latency notification.

The first observed minute is discarded from the statistical reference unless observation began exactly at its boundary. That avoids treating a partial attachment minute as a full candle. The first evaluation needs 15 full prior candles plus the current completed candle. Bookmap may supply already-collected subscription history to the `HistoricalModeListener`, allowing warm-up without waiting another 16 live minutes. This does not promise arbitrary server backfill availability.

Empty completed minutes have zero volume and undefined signed metrics. They occupy positions in the 15-minute window; the engine never substitutes older traded minutes. Missing directional values suppress that component until the affected minute leaves the window. An invalid/partial candle or an externally supplied calendar gap resets the baseline.

Within the open minute, trades are ordered by timestamp for open/close calculation and all valid volumes are counted. A trade arriving with a timestamp in an already finalized minute is rejected; completed outputs are not revised. The current candle is marked tainted and the reference is reset. The late-trade count is logged. No real-time system can guarantee receipt of every exchange execution or retroactively eliminate an alert after discovering missing data.

For a very large clock jump, gap processing is bounded: old baseline values are dropped and only enough empty minutes to reconstruct the current reference are processed. Stale annotations/alerts more than two seconds behind the observed Bookmap notification timestamp are withheld by default rather than piled onto a reconnect time. This limit is configurable and affects presentation/alerts, not the four formulas. It does not detect wall-clock latency when Bookmap's entire event clock is delayed.

OTC executions are excluded by default; the setting can be changed. Match filtering when comparing native candles or other volume displays. There is no session-time filter, daily reset, contract-roll stitching, or broker-specific reconnection detection. Attach a separate instance to each desired ES contract. After any suspected incomplete feed period, reload/reset and verify the reference before relying on signals.

## Optional alerts and diagnostics

Audio is **off by default**. When enabled, a bullish full signal uses an ascending two-tone sound and a bearish full signal uses a descending sound. No partial-condition sounds are generated. Audio runs on a small background worker, not on Bookmap's data callback thread. Historical catch-up is silent; only subsequent eligible completed candles can sound. In replay, `onRealtimeStart` denotes the replay frontier, not proof of a live connection, so leave audio off for silent replay.

This is generated Java audio, not Bookmap's native alert-center/popup integration. Audio hardware, operating-system mixer behavior, and audibility have not been tested here. If no audio line is available, the add-on logs an error and continues displaying signals.

Confirmed signals are logged. `Log all completed candles` adds the candle end, notification time, status, raw total/buy/sell/unknown volumes, RVOL, ACCz, SVraw/SVz, SIraw/SIz, thresholds, and timely flag for every emitted candle. Logs use ISO timestamps in UTC. Labels use the computer timezone by default; set the IANA label timezone to match your Bookmap chart, such as `America/Chicago` or `Europe/Amsterdam`. Timezone changes do not change minute boundaries.

There is no network telemetry, credential storage, auto-order routing, or automatic file export. Diagnostic output goes through standard output/error for collection by the host application.

## Build, tests, and project structure

### Windows PowerShell, from the extracted folder

```powershell
.\build.ps1
```

The script downloads the two pinned SDK jars directly from Bookmap, compiles the add-on, runs the core tests, and creates:

```text
build/libs/es-expansion-v3-chart-3.1.0.jar
```

A full JDK 17+ is needed; Bookmap's bundled runtime alone may not include `javac`. The script does not install software or permanently change your PowerShell execution policy. Review scripts before running them and follow your machine's execution-policy requirements.

To use existing API jars in a directory instead of downloading them:

```powershell
.\build.ps1 -SdkDir "C:\path\to\bookmap-api-jars"
```

### Linux/macOS

```sh
sh build.sh
# Or use existing API jars:
sh build.sh --sdk-dir /path/to/bookmap-api-jars
```

### Calculation/rendering tests without the SDK

```powershell
.\build.ps1 -TestOnly
```

```sh
sh build.sh --test-only
```

Test-only mode does not generate an installable JAR. Rendered examples are placed in `build/render-samples`.

### Gradle alternative

With JDK 17+ and an installed compatible Gradle:

```sh
gradle clean jar renderSamples
```

SDK jars are `compileOnly` and are never bundled in the add-on. The pinned SDK version matches the official DemoStrategies build configuration inspected during development; it is not a claim that every Bookmap version is compatible. Older/newer installations must be validated with their supported SDK/runtime. `-PbookmapApiVersion=...` can override the Gradle dependency, but that alone does not establish compatibility.

### Files

```text
src/main/java/com/example/bookmap/expansion/
  EsExpansionV3.java       Bookmap adapter, settings, labels and alert dispatch
  ExpansionModel.java     Formulas, robust statistics, rolling reference, exact signal gate
  MinuteEngine.java       Event-time aggregation, boundaries, late data and gaps
  AnnotationRenderer.java Arrow plus vertical numeric-label image generation
  AudioAlert.java         Optional nonblocking two-tone sound
src/test/java/com/example/bookmap/expansion/
  CoreSelfTest.java        37 deterministic test groups, no external libraries
  RenderSamples.java      Generates examples with the actual renderer
tools/contract_preflight.py Optional offline API-double check, NOT an SDK build
```

The pure `ExpansionModel.Window` accepts chronological `Candle` objects for later research/backtesting without Bookmap. The minute engine can instead consume trade events. Feed the same filtering and timestamps as the live implementation, retain separate calibration/validation samples, and model realistic entry availability after the notification boundary. This package does not demonstrate a trading edge.

## Bookmap display setup and limits

After building, disable/remove the earlier prototype to avoid duplicate displays. Load this JAR through Bookmap's API add-ons configuration and enable **ES Expansion V3 - 1m arrows + vertical metrics** for the desired Rithmic ES instrument. See the detailed quick start.

Enable native **Candles**, choose **1 minute**, and select **OHLC by Trades**. Turn off automatic candlestick aggregation when checking one-to-one candle alignment. Quote-derived high/low modes can produce different extrema from this execution-only indicator. Matching settings and complete trade coverage still need verification against your installation.

This implementation uses fixed-pixel icons in price/time coordinates, not a custom floating panel. It does not automatically resolve overlapping labels at wide zoom levels. Reduce font size, hide threshold text, zoom into a shorter time span, or change label mode for a cleaner view. Historical icons are subject to Bookmap's own indicator retention and reload behavior; there is no separate persistent signal database. Editing parameters reloads and recalculates available history with the new settings rather than mixing different parameter definitions in one rolling window.

## Primary documentation consulted

These references describe the intended integration; they do not substitute for running the add-on in Bookmap.

- Bookmap API overview: https://bookmap.com/knowledgebase/docs/API
- Bookmap official development/loading tutorial, event clock and trade-side examples: https://bookmap.com/knowledgebase/docs/API-Tutorial
- Official Java/SDK dependency configuration: https://github.com/BookmapAPI/DemoStrategies/blob/master/Strategies/build.gradle
- Simplified Indicator/addIcon and anchor coordinates: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/Indicator.html
- Simplified parameters and reload behavior: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/Parameter.html
- Bookmap event-clock interval semantics: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0.10/velox/api/layer1/simplified/IntervalListener.html
- Historical mode notification: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0/velox/api/layer1/simplified/HistoricalModeListener.html
- Native candle setup/modes: https://bookmap.com/knowledgebase/docs/KB-SettingUpAndOperating-HeatmapCandlestickView

Use an appropriately entitled Bookmap edition and live Rithmic ES data subscription. Confirm any vendor/exchange restrictions on custom API use. Bookmap libraries, data licenses, account access, and font files are not included.
