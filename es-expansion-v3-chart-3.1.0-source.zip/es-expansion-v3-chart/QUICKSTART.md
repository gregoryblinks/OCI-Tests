# Quick start - ES Expansion V3 chart overlay

## What you have

Source code, tests, and build scripts. **There is no verified install-ready Bookmap JAR in this download.** The calculation/rendering tests passed here, but the official SDK was unavailable in the development environment. A successful SDK build and replay verification are the next steps.

## 1. Build the add-on

Extract the ZIP into a local folder. Use a full **Java JDK 17 or newer**. Verify `javac -version` in a terminal; a Java runtime without `javac` is not enough.

On Windows, open PowerShell in the extracted `es-expansion-v3-chart` folder, review the script, then run:

```powershell
.\build.ps1
```

On macOS/Linux:

```sh
sh build.sh
```

The script downloads the pinned official Bookmap SDK jars, compiles the code, runs the calculation/rendering tests, and packages:

```text
build/libs/es-expansion-v3-chart-3.1.0.jar
```

If SDK download access is blocked, use a directory containing the supported API jars:

```powershell
.\build.ps1 -SdkDir "C:\path\to\bookmap-api-jars"
```

A compilation error means the build has not succeeded. Do not load a stale JAR from an earlier build. Full-build paths and PowerShell execution were not run in this development environment. Gradle and SDK-free test alternatives are in `README.md`.

## 2. Load in Bookmap

First disable or remove the earlier ES Expansion prototype, if installed.

Open **Settings > API plugins configuration** (or the corresponding **Configure API plugins / add-ons** toolbar control). Choose **Add**, select the newly built JAR, then select:

**ES Expansion V3 - 1m arrows + vertical metrics**

Enable it on the intended ES contract in the Rithmic-connected instrument tab. No Rithmic credentials are entered into this indicator; it uses Bookmap's existing trade subscription. It never sends orders.

Bookmap's loading instructions: https://bookmap.com/knowledgebase/docs/API-Tutorial

## 3. Match the visible candles

Open the Bookmap **Studies** configuration, enable **Candles**, set the candle interval to **1 minute**, and choose **OHLC by Trades**. For initial alignment checks, turn off automatic candlestick aggregation. The indicator's candle calculation always uses executions, not quote highs/lows.

Native candle documentation: https://bookmap.com/knowledgebase/docs/KB-SettingUpAndOperating-HeatmapCandlestickView

## 4. Leave these initial settings

| Setting | Default |
| --- | --- |
| Lookback | 15 completed minutes |
| RVOL / ACC / SV / SI thresholds | 2.0 / 2.0 / 2.0 / 2.0 |
| Show full-signal arrows | On |
| Show four vertical readings | On |
| Labels mode | 0 = every completed candle |
| Threshold text | On |
| Extend labels left of close | On, to reduce live-edge clipping |
| Audio | Off; opt in after testing |

Bullish arrows point up below the completed candle's low, with readings below. Bearish arrows point down above the high, with readings above. Non-signal candles still have a four-row label, but no arrow. Warm-up/undefined values show N/A and never generate an arrow.

Set the label timezone to match the chart. `LOCAL` uses the computer timezone; IANA names such as `America/Chicago` and `Europe/Amsterdam` are accepted.

## 5. Verify before relying on signals

Run a replay/simulation test with `Log all completed candles` enabled. Confirm minute volumes, buy/sell direction, first/last trade prices, one update per minute, and the green/red marker positions. Historical catch-up should be silent. Test actual audio separately after enabling it. Use `docs/VALIDATION.md` as the acceptance checklist.

The first partially observed minute is excluded. With no usable supplied history, 15 full reference candles plus the current completed candle are required. Zero-MAD and missing/zero-volume directional baselines can extend the N/A period.

Icons appear at the notification time at/just after the completed candle's close boundary, not retroactively at the candle midpoint. The label shows the candle end time. Results are fixed once emitted under unchanged parameters; settings changes reload/recalculate history.

ACC is the robust z-score of current volume relative to prior volumes, not a minute-to-minute volume derivative. All defaults are research parameters and have not been shown to be profitable.
