param(
    [string]$SdkDir = "",
    [switch]$TestOnly
)
# Windows PowerShell 5.1+ or PowerShell 7; Java JDK 17+ required. No Gradle needed.
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    function Find-JdkTool([string]$Name) {
        if ($env:JAVA_HOME) {
            $candidate = Join-Path $env:JAVA_HOME "bin/$Name.exe"
            if (Test-Path $candidate) { return $candidate }
            $candidate = Join-Path $env:JAVA_HOME "bin/$Name"
            if (Test-Path $candidate) { return $candidate }
        }
        $command = Get-Command $Name -ErrorAction SilentlyContinue
        if ($null -eq $command) { throw "Install a Java JDK 17 or newer and set JAVA_HOME ($Name not found)." }
        return $command.Source
    }
    $javac = Find-JdkTool "javac"
    $java = Find-JdkTool "java"
    $jar = Find-JdkTool "jar"
    & $javac -version
    if ($LASTEXITCODE -ne 0) { throw "Cannot run javac" }
    foreach ($directory in @("build/classes", "build/test-classes", "build/libs", ".deps")) {
        New-Item -ItemType Directory -Force -Path $directory | Out-Null
    }
    Remove-Item "build/libs/es-expansion-v3-chart-3.1.0.jar" -Force -ErrorAction SilentlyContinue
    Remove-Item "build/classes", "build/test-classes" -Recurse -Force
    New-Item -ItemType Directory -Path "build/classes", "build/test-classes" | Out-Null
    $apiJars = @()
    if (-not $TestOnly) {
        if ($SdkDir) {
            if (-not (Test-Path -PathType Container $SdkDir)) { throw "SDK directory not found: $SdkDir" }
            $apiJars = @(Get-ChildItem -Path $SdkDir -Filter *.jar -File | ForEach-Object { $_.FullName })
            if ($apiJars.Count -eq 0) { throw "No API jars in SDK directory" }
        } else {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            foreach ($artifact in @("api-core", "api-simplified")) {
                $file = Join-Path $PSScriptRoot ".deps/$artifact-7.6.0.20.jar"
                if (-not (Test-Path $file)) {
                    $url = "https://maven.bookmap.com/maven2/releases/com/bookmap/api/$artifact/7.6.0.20/$artifact-7.6.0.20.jar"
                    Write-Host "Downloading $artifact 7.6.0.20 from Bookmap..."
                    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile "$file.part" -TimeoutSec 180
                    Move-Item -Force "$file.part" $file
                }
                & $jar tf $file | Out-Null
                if ($LASTEXITCODE -ne 0) { throw "Invalid SDK jar: $file" }
                $apiJars += $file
            }
        }
    }
    $separator = [IO.Path]::PathSeparator
    $classpath = $apiJars -join $separator
    $sources = @(Get-ChildItem "src/main/java" -Filter *.java -Recurse -File |
        Where-Object { (-not $TestOnly) -or $_.Name -ne "EsExpansionV3.java" } |
        ForEach-Object { $_.FullName })
    $compileArgs = @("--release", "17", "-encoding", "UTF-8", "-Xlint:all", "-d", "build/classes")
    if ($classpath) { $compileArgs += @("-cp", $classpath) }
    & $javac @compileArgs @sources
    if ($LASTEXITCODE -ne 0) { throw "Java compilation failed. Confirm the SDK version and JDK 17+." }
    $testSources = @(Get-ChildItem "src/test/java" -Filter *.java -Recurse -File | ForEach-Object { $_.FullName })
    $testCompileClasspath = "build/classes"
    if ($classpath) { $testCompileClasspath += "$separator$classpath" }
    & $javac --release 17 -encoding UTF-8 -Xlint:all -cp $testCompileClasspath -d build/test-classes @testSources
    if ($LASTEXITCODE -ne 0) { throw "Test compilation failed" }
    $runtime = "build/classes${separator}build/test-classes"
    & $java -Djava.awt.headless=true -cp $runtime com.example.bookmap.expansion.CoreSelfTest
    if ($LASTEXITCODE -ne 0) { throw "Core self-tests failed" }
    & $java -Djava.awt.headless=true -cp $runtime com.example.bookmap.expansion.RenderSamples build/render-samples
    if ($LASTEXITCODE -ne 0) { throw "Sample rendering failed" }
    if (-not $TestOnly) {
        & $jar --create --file build/libs/es-expansion-v3-chart-3.1.0.jar -C build/classes .
        if ($LASTEXITCODE -ne 0) { throw "JAR packaging failed" }
        Write-Host "Created: build/libs/es-expansion-v3-chart-3.1.0.jar"
        Write-Host "Compiled against API jars; still requires Bookmap replay/live validation."
    } else {
        Write-Host "Core tests only. No SDK compilation or installable add-on JAR was produced."
    }
} finally {
    Pop-Location
}
