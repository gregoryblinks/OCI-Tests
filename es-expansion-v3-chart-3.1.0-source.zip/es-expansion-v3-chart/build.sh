#!/bin/sh
# Java 17+ required. No Gradle installation needed.
set -eu
cd "$(dirname "$0")"
TEST_ONLY=0
SDK_DIR=""
while [ "$#" -gt 0 ]; do
    case "$1" in
        --test-only) TEST_ONLY=1; shift ;;
        --sdk-dir) [ "$#" -ge 2 ] || { echo 'Missing SDK directory' >&2; exit 2; }; SDK_DIR="$2"; shift 2 ;;
        *) echo 'Usage: sh build.sh [--test-only] [--sdk-dir /path/to/api-jars]' >&2; exit 2 ;;
    esac
done
JAVA=java
JAVAC=javac
JAR=jar
if [ -n "${JAVA_HOME:-}" ]; then
    JAVA="$JAVA_HOME/bin/java"
    JAVAC="$JAVA_HOME/bin/javac"
    JAR="$JAVA_HOME/bin/jar"
fi
command -v "$JAVAC" >/dev/null 2>&1 || { echo 'Install a Java JDK 17 or newer and set JAVA_HOME.' >&2; exit 1; }
"$JAVAC" -version
mkdir -p build/classes build/test-classes build/libs .deps
rm -f build/libs/es-expansion-v3-chart-3.1.0.jar
rm -rf build/classes build/test-classes
mkdir -p build/classes build/test-classes
CP=""
if [ "$TEST_ONLY" -eq 0 ]; then
    if [ -n "$SDK_DIR" ]; then
        [ -d "$SDK_DIR" ] || { echo "SDK directory not found: $SDK_DIR" >&2; exit 1; }
        for file in "$SDK_DIR"/*.jar; do
            [ -f "$file" ] || continue
            CP="${CP:+$CP:}$file"
        done
        [ -n "$CP" ] || { echo 'No API jars found in SDK directory.' >&2; exit 1; }
    else
        for artifact in api-core api-simplified; do
            file=".deps/$artifact-7.6.0.20.jar"
            url="https://maven.bookmap.com/maven2/releases/com/bookmap/api/$artifact/7.6.0.20/$artifact-7.6.0.20.jar"
            if [ ! -s "$file" ]; then
                echo "Downloading $artifact 7.6.0.20 from Bookmap..."
                if command -v curl >/dev/null 2>&1; then
                    curl --fail --location --connect-timeout 20 --max-time 180 "$url" -o "$file.part"
                elif command -v wget >/dev/null 2>&1; then
                    wget -O "$file.part" "$url"
                else
                    echo 'curl or wget is required, or use --sdk-dir.' >&2; exit 1
                fi
                mv "$file.part" "$file"
            fi
            "$JAR" tf "$file" >/dev/null
            CP="${CP:+$CP:}$file"
        done
    fi
    find src/main/java -name '*.java' > build/main-sources.txt
    "$JAVAC" --release 17 -encoding UTF-8 -Xlint:all -cp "$CP" -d build/classes @build/main-sources.txt
else
    find src/main/java -name '*.java' ! -name 'EsExpansionV3.java' > build/main-sources.txt
    "$JAVAC" --release 17 -encoding UTF-8 -Xlint:all -d build/classes @build/main-sources.txt
fi
find src/test/java -name '*.java' > build/test-sources.txt
"$JAVAC" --release 17 -encoding UTF-8 -Xlint:all -cp "build/classes${CP:+:$CP}" -d build/test-classes @build/test-sources.txt
"$JAVA" -Djava.awt.headless=true -cp build/classes:build/test-classes com.example.bookmap.expansion.CoreSelfTest
"$JAVA" -Djava.awt.headless=true -cp build/classes:build/test-classes com.example.bookmap.expansion.RenderSamples build/render-samples
if [ "$TEST_ONLY" -eq 0 ]; then
    "$JAR" --create --file build/libs/es-expansion-v3-chart-3.1.0.jar -C build/classes .
    echo 'Created: build/libs/es-expansion-v3-chart-3.1.0.jar'
    echo 'Compiled against API jars; still requires Bookmap replay/live validation.'
else
    echo 'Core tests only. No SDK compilation or installable add-on JAR was produced.'
fi
