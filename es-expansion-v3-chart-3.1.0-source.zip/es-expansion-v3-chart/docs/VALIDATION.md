# Validation record and Bookmap acceptance checklist

## Performed in this development environment

- JDK: OpenJDK 21, compiling the SDK-independent source with Java 17 target bytecode.
- `sh build.sh --test-only`: successful.
- All 37 deterministic core test groups: passed. Full output: `test-results.txt`.
- Tests include robust median/MAD, inclusive thresholds, separate four-way gating, bullish/bearish/mixed-direction cases, current-candle exclusion, rolling eviction, zero volume, unknown aggressors, incomplete history, calendar gaps, timestamp boundaries, first partial minute, duplicate completions, late trades, invalid executions, OHLC ordering, no future rewriting, and volume conservation over 100 synthetic minutes.
- Renderer tests verify above/below anchor geometry and independent arrow/label switches. Production-renderer PNG examples were generated and visually inspected. They use synthetic candles, not actual Bookmap rendering.
- `tools/contract_preflight.py`: the full adapter source passed Java syntax checking and 3 callback scenarios with **local API test doubles** based on documented method signatures. See `contract-preflight-results.txt`. These doubles are not the official SDK, are not deployment dependencies, and produce no JAR.

## Not verified here

- A full compilation against official Bookmap SDK binaries. SDK downloads were unavailable due to DNS/network restrictions in the development container.
- Full-build network download and packaging paths, Windows PowerShell execution, or Gradle execution.
- Loading the resulting JAR in the user's Bookmap build or persistence/reload behavior in the actual UI.
- Actual Rithmic ES timestamps, delivery completeness, aggressor classification, OTC filtering, or live/replay agreement.
- Bookmap icon rendering at the live edge, price zoom, historical scrolling, indicator visibility, or GPU/display scaling.
- Actual system audio, Bookmap native alert-center integration, trade execution, slippage, profitability, or out-of-sample performance.

## Acceptance checklist on your installation

1. **Build:** use a supported JDK/SDK combination; all compilation and test commands must exit successfully. Load only the resulting new JAR. Keep Bookmap's installed libraries outside the packaged add-on.
2. **Scope:** enable the add-on only for the intended ES/Rithmic instrument. Confirm that it creates no bottom-panel study and sends no orders. Remove the older prototype first.
3. **Visible candles:** use one-minute, OHLC-by-Trades candles without automatic aggregation for this test. Match the indicator and chart timezones and trade filtering.
4. **Tape reconciliation:** for several known minutes, sum execution sizes and compare with logged V/B/S/UNKNOWN. `isBidAggressor=true` must contribute to B. Compare SI's open/close with the first/last execution in that minute, not a previous-close convention.
5. **Timing:** confirm a trade timestamped exactly at the new minute belongs to that new candle. Check one result per minute, no intrabar arrow, and no duplicate arrow after repeated interval callbacks. Label end time and notification time should differ only by the observed callback delay.
6. **Signals and labels:** inspect known bullish, bearish, and mixed-direction examples. Up arrow below low with rows below; down arrow above high with rows above. Mode 0 must show labels on non-signal candles. Hiding arrows must leave labels available.
7. **Warm-up and failure states:** mid-minute attachment must not use the partial minute as a full reference bar. Verify N/A/no signal during insufficient history, zero MAD, missing side data, and empty directional baselines.
8. **History/replay:** compare a recording run from the beginning with the same available trade history supplied at attachment. After the initial discarded partial minute and warm-up, matching input data/settings should give matching results. Historical warm-up must not play sounds.
9. **Gaps/reconnects:** confirm no burst of old labels/alerts at a resumed timestamp. Investigate any dropped-late/invalid counts. Reload after suspected missing feed data; the add-on cannot certify a vendor's delivery completeness.
10. **Usability:** verify no unexpected line between icons, labels remain legible at the live edge, and no clipping at chosen font/zoom. Fixed-size labels can overlap on a wide time span; adjust zoom or label mode. The time anchor is the close-notification boundary, not the candle center.
11. **Audio:** enable deliberately and verify distinct bullish/bearish tones on your device. There should be one sound per eligible signal candle, none for partial conditions, and no backlog of sounds on history load. Disable during silent replay.
12. **Research:** use independent validation data and realistic post-notification execution assumptions before treating any output as an entry rule. A correct calculation is not evidence of predictive edge.

## Known limitations by design

No custom screen-space dashboard, tooltip expansion, collision-aware text layout, native alert-center popup, retained cross-session signal database, automatic session reset, ES contract rolling, or order management. The supplied renderer creates primary-chart icons with native API event-time anchors. There is no hidden order-book, OFI, VPIN, Fibonacci, VWAP, or extra entry filter.
