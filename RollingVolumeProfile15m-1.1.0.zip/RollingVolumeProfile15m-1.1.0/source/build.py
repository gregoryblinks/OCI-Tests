#!/usr/bin/env python3
"""Build the Bookmap add-on with JDK 17+, without requiring Maven or Gradle.

Use --bookmap-lib to compile against the user's installed Bookmap API jars.
--ecj accepts an existing Eclipse compiler jar for environments with a JRE only.
No compiler or dependency is included in the resulting add-on jar.
"""
import argparse
import hashlib
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
API_VERSION = '7.4.0.10'
JAR_NAME = 'RollingVolumeProfile15m-1.1.0.jar'


def run(command):
    print(' '.join(str(x) for x in command), flush=True)
    subprocess.run([str(x) for x in command], cwd=ROOT, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bookmap-lib', type=Path)
    parser.add_argument('--api-version', default=API_VERSION)
    parser.add_argument('--ecj', type=Path, help='Existing Eclipse ECJ compiler jar')
    parser.add_argument('--skip-tests', action='store_true')
    args = parser.parse_args()
    build = ROOT / 'build'
    build.mkdir(exist_ok=True)
    if args.bookmap_lib:
        jars = sorted(args.bookmap_lib.glob('*.jar'))
        if not jars:
            raise SystemExit('No jars found in --bookmap-lib. Supply Bookmap\'s lib directory.')
    else:
        if not re.fullmatch(r'[0-9]+(?:\.[0-9]+){3}', args.api_version):
            raise SystemExit('Use a numeric published Bookmap API version such as 7.4.0.10.')
        dep = build / 'dependencies' / ('api-core-' + args.api_version + '.jar')
        dep.parent.mkdir(exist_ok=True)
        if not dep.exists():
            url = ('https://maven.bookmap.com/maven2/releases/com/bookmap/api/api-core/'
                   + args.api_version + '/' + dep.name)
            print('Downloading published Bookmap API ' + args.api_version, flush=True)
            with urllib.request.urlopen(url, timeout=60) as response:
                data = response.read()
            if not zipfile.is_zipfile(__import__('io').BytesIO(data)):
                raise SystemExit('Downloaded API response is not a jar.')
            dep.write_bytes(data)
        jars = [dep]
    java = shutil.which('java')
    javac = shutil.which('javac')
    if not java:
        raise SystemExit('Java 17+ is required. Install a JDK and add its bin folder to PATH.')
    if args.ecj:
        if not args.ecj.is_file():
            raise SystemExit('--ecj must name an existing Eclipse compiler jar.')
        compiler = [java, '-jar', args.ecj.resolve(), '-17', '-encoding', 'UTF-8']
    else:
        if not javac:
            raise SystemExit('javac was not found. Install JDK 17+ (a JRE alone is insufficient).')
        compiler = [javac, '--release', '17', '-encoding', 'UTF-8']
    classes = build / 'classes'
    tests = build / 'test-classes'
    for folder in [classes, tests]:
        if folder.exists():
            shutil.rmtree(folder)
        folder.mkdir()
    api_classpath = os.pathsep.join(str(p.resolve()) for p in jars)
    sources = sorted((ROOT / 'src/main/java').rglob('*.java'))
    run(compiler + ['-cp', api_classpath, '-d', classes] + sources)
    if not args.skip_tests:
        test_sources = sorted((ROOT / 'src/test/java').rglob('*.java'))
        test_classpath = os.pathsep.join([str(classes), api_classpath])
        run(compiler + ['-cp', test_classpath, '-d', tests] + test_sources)
        runtime_classpath = os.pathsep.join([str(classes), str(tests), api_classpath])
        # Every dependency-free test runner is discovered by its explicit main.
        for path in test_sources:
            content = path.read_text(encoding='utf-8')
            if 'public static void main(' not in content:
                continue
            package = re.search(r'^package\s+([\w.]+);', content, re.MULTILINE)
            if not package:
                continue
            name = package.group(1) + '.' + path.stem
            run([java, '-ea', '-Djava.awt.headless=true', '-cp', runtime_classpath, name])
    out = build / 'libs' / JAR_NAME
    out.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('META-INF/MANIFEST.MF',
                         'Manifest-Version: 1.0\r\n'
                         'Implementation-Title: Rolling Volume Profile 15m\r\n'
                         'Implementation-Version: 1.1.0\r\n'
                         'Build-Jdk-Spec: 17\r\n\r\n')
        for path in sorted(classes.rglob('*.class')):
            archive.write(path, path.relative_to(classes).as_posix())
    digest = hashlib.sha256(out.read_bytes()).hexdigest()
    out.with_suffix('.jar.sha256').write_text(digest + '  ' + out.name + '\n', encoding='ascii')
    print('Built: ' + str(out))
    print('SHA256: ' + digest)


if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as exc:
        raise SystemExit(exc.returncode)
