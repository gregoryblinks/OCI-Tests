package com.rollingprofile.bookmap;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

import com.rollingprofile.core.RollingVolumeProfile;
import com.rollingprofile.core.RollingVolumeProfile.Side;
import com.rollingprofile.core.RollingVolumeProfile.Snapshot;
import com.rollingprofile.view.ProfileRenderer;

import velox.api.layer1.Layer1ApiAdminAdapter;
import velox.api.layer1.Layer1ApiDataAdapter;
import velox.api.layer1.Layer1ApiFinishable;
import velox.api.layer1.Layer1ApiInstrumentAdapter;
import velox.api.layer1.Layer1ApiProvider;
import velox.api.layer1.Layer1CustomPanelsGetter;
import velox.api.layer1.annotations.Layer1ApiVersion;
import velox.api.layer1.annotations.Layer1ApiVersionValue;
import velox.api.layer1.annotations.Layer1Attachable;
import velox.api.layer1.annotations.Layer1StrategyName;
import velox.api.layer1.annotations.UnrestrictedData;
import velox.api.layer1.common.ListenableHelper;
import velox.api.layer1.data.DisconnectionReason;
import velox.api.layer1.data.InstrumentInfo;
import velox.api.layer1.data.TradeInfo;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpaceCanvas;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpaceCanvas.CanvasIcon;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpaceCanvas.CompositeCoordinateBase;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpaceCanvas.CompositeHorizontalCoordinate;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpaceCanvas.CompositeVerticalCoordinate;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpaceCanvas.PreparedImage;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpaceCanvasFactory;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpaceCanvasFactory.ScreenSpaceCanvasType;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpacePainter;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpacePainterAdapter;
import velox.api.layer1.layers.strategies.interfaces.ScreenSpacePainterFactory;
import velox.api.layer1.messages.CurrentTimeUserMessage;
import velox.api.layer1.messages.Layer1ApiRequestCurrentTimeEvents;
import velox.api.layer1.messages.UserMessageLayersChainCreatedTargeted;
import velox.api.layer1.messages.indicators.Layer1ApiUserMessageModifyScreenSpacePainter;
import velox.api.layer1.messages.indicators.SettingsAccess;
import velox.api.layer1.settings.Layer1ConfigSettingsInterface;
import velox.gui.StrategyPanel;

/**
 * Read-only rolling executed-volume profile. No order-book update is counted as
 * volume. The provider's clock drives both live and replay expiry; the drawing
 * timer never advances market time.
 */
@Layer1Attachable
@Layer1StrategyName("Rolling Volume Profile — 15 minute")
@Layer1ApiVersion(Layer1ApiVersionValue.VERSION2)
@UnrestrictedData
public final class RollingProfileAddon implements Layer1ApiFinishable,
        Layer1ApiAdminAdapter, Layer1ApiDataAdapter, Layer1ApiInstrumentAdapter,
        ScreenSpacePainterFactory, Layer1CustomPanelsGetter,
        Layer1ConfigSettingsInterface {

    static final String NAME = "Rolling Volume Profile";
    private static final long SECOND = TimeUnit.SECONDS.toNanos(1);
    private static final long MINUTE = TimeUnit.MINUTES.toNanos(1);
    private static final long TRACE_LIFETIME = TimeUnit.MINUTES.toNanos(60);
    private static final int MAX_TRACES = 3601;
    private static final Color POC = ProfileRenderer.POC;
    private static final Color VAH = ProfileRenderer.VALUE;
    private static final Color VAL = ProfileRenderer.VALUE;
    private static final Color FROZEN = new Color(195, 168, 255);

    private final Layer1ApiProvider provider;
    // Initialize before addListeners: Bookmap may immediately replay instruments.
    private final Map<String, InstrumentState> instruments = new ConcurrentHashMap<>();
    private final List<ProfilePainter> painters = new CopyOnWriteArrayList<>();
    private final Layer1ApiRequestCurrentTimeEvents timeRequest =
            new Layer1ApiRequestCurrentTimeEvents(true, 0, TimeUnit.MILLISECONDS.toNanos(100));
    private volatile SettingsAccess settingsAccess;
    private volatile boolean active;
    private volatile boolean connected = true;
    private volatile long clock = RollingVolumeProfile.NO_TIME;
    private ScheduledExecutorService renderer;

    public RollingProfileAddon(Layer1ApiProvider provider) {
        this.provider = provider;
        ListenableHelper.addListeners(provider, this);
    }

    @Override
    public void onUserMessage(Object data) {
        if (data instanceof UserMessageLayersChainCreatedTargeted) {
            UserMessageLayersChainCreatedTargeted message =
                    (UserMessageLayersChainCreatedTargeted) data;
            if (message.targetClass == getClass()) {
                activate();
            }
        } else if (data instanceof CurrentTimeUserMessage && active) {
            CurrentTimeUserMessage message = (CurrentTimeUserMessage) data;
            if (message.isBeforeEventsSkipped) {
                // Bookmap warns that clock notifications will be skipped. This
                // does not prove missing trade data, so don't call it a feed gap.
                for (InstrumentState state : instruments.values()) {
                    synchronized (state) { state.notice = "Bookmap clock jump pending"; }
                }
            }
            advanceClock(message.time, message.isEventsSkipped);
        }
    }

    private synchronized void activate() {
        if (active) {
            return;
        }
        active = true;
        provider.sendUserMessage(Layer1ApiUserMessageModifyScreenSpacePainter
                .builder(RollingProfileAddon.class, NAME).setIsAdd(true)
                .setScreenSpacePainterFactory(this).build());
        timeRequest.setAdd(true);
        provider.sendUserMessage(timeRequest);
        renderer = Executors.newSingleThreadScheduledExecutor(task -> {
            Thread thread = new Thread(task, "rolling-volume-profile-renderer");
            thread.setDaemon(true);
            return thread;
        });
        renderer.scheduleWithFixedDelay(this::renderFrames, 0, 200, TimeUnit.MILLISECONDS);
    }

    private void advanceClock(long now, boolean eventsSkipped) {
        long previous = clock;
        clock = now;
        boolean backwards = previous != RollingVolumeProfile.NO_TIME && now < previous;
        for (InstrumentState state : instruments.values()) {
            synchronized (state) {
                if (backwards || eventsSkipped) {
                    state.clear(now, backwards ? "Replay/time reset" : "Clock jump; restarted");
                } else if (connected) {
                    // getCurrentTime() can expose the next event's time when a
                    // consumer is slow. A slightly earlier clock pulse must
                    // not erase the profile; only pulse-sequence rewind does.
                    state.advance(state.lastTime == RollingVolumeProfile.NO_TIME
                            ? now : Math.max(now, state.lastTime));
                }
            }
        }
    }

    @Override
    public void onTrade(String alias, double price, int size, TradeInfo tradeInfo) {
        if (!active || !connected || size <= 0 || !Double.isFinite(price)) {
            return;
        }
        InstrumentState state = instruments.get(alias);
        if (state == null) {
            return;
        }
        long rounded = Math.round(price);
        if (rounded < Integer.MIN_VALUE || rounded > Integer.MAX_VALUE
                || Math.abs(price - rounded) > 0.000001) {
            // An integer-tick profile must not silently merge off-grid prints.
            synchronized (state) { state.notice = "Off-grid trade ignored"; }
            return;
        }
        long now;
        synchronized (this) {
            // finish() owns the same short lifecycle lock, so this provider
            // call cannot start after teardown has completed.
            if (!active || !connected) { return; }
            now = provider.getCurrentTime();
        }
        Side side = tradeInfo == null ? Side.UNKNOWN
                : tradeInfo.isBidAggressor ? Side.BUY : Side.SELL;
        synchronized (state) {
            // A disconnect/removal may occur after the initial callback guard.
            if (!active || !connected || instruments.get(alias) != state) { return; }
            // The Bookmap API supplies no per-trade timestamp in this callback.
            // getCurrentTime() is its event/replay clock; clamp read skew. Seek
            // resets are detected from ordered CurrentTimeUserMessage events.
            if (state.lastTime != RollingVolumeProfile.NO_TIME) { now = Math.max(now, state.lastTime); }
            state.advance(now);
            state.profile.addTrade(now, (int) rounded, size, side);
        }
    }

    @Override
    public void onInstrumentAdded(String alias, InstrumentInfo info) {
        InstrumentState state = new InstrumentState(info);
        loadSettings(alias, state);
        long now = clock;
        if (now != RollingVolumeProfile.NO_TIME) {
            synchronized (state) { state.advance(now); }
        }
        instruments.put(alias, state);
    }

    @Override
    public void onInstrumentRemoved(String alias) {
        instruments.remove(alias);
        for (ProfilePainter painter : painters) {
            if (painter.alias.equals(alias)) {
                painter.dispose();
            }
        }
    }

    @Override
    public void onConnectionLost(DisconnectionReason reason, String message) {
        connected = false;
        for (InstrumentState state : instruments.values()) {
            synchronized (state) {
                state.clear(RollingVolumeProfile.NO_TIME, "Disconnected; data cleared");
            }
        }
    }

    @Override
    public void onConnectionRestored() {
        connected = true;
        clock = RollingVolumeProfile.NO_TIME;
        for (InstrumentState state : instruments.values()) {
            synchronized (state) {
                state.clear(RollingVolumeProfile.NO_TIME, "Reconnected; rebuilding");
            }
        }
    }

    @Override
    public void acceptSettingsInterface(SettingsAccess access) {
        settingsAccess = access;
        instruments.forEach(this::loadSettings);
    }

    private void loadSettings(String alias, InstrumentState state) {
        SettingsAccess access = settingsAccess;
        if (access != null) {
            Object saved = access.getSettings(alias, NAME, RollingProfileSettings.class);
            if (saved instanceof RollingProfileSettings) {
                synchronized (state) {
                    state.configure(((RollingProfileSettings) saved).copy(), "Settings loaded");
                }
            }
        }
    }

    private void saveSettings(String alias, RollingProfileSettings settings) {
        SettingsAccess access = settingsAccess;
        if (access != null) {
            access.setSettings(alias, NAME, settings.copy(), RollingProfileSettings.class);
        }
    }

    @Override
    public StrategyPanel[] getCustomGuiFor(String alias, String indicatorName) {
        InstrumentState state = alias == null ? null : instruments.get(alias);
        StrategyPanel panel = new StrategyPanel("Rolling Volume Profile");
        panel.setLayout(new GridLayout(0, 2, 6, 6));
        if (state == null) {
            panel.add(new JLabel("Select a subscribed instrument to configure."));
            return new StrategyPanel[] {panel};
        }
        RollingProfileSettings current;
        synchronized (state) { current = state.settings.copy(); }
        JSpinner minutes = new JSpinner(new SpinnerNumberModel(current.windowMinutes, 1, 120, 1));
        JSpinner bins = new JSpinner(new SpinnerNumberModel(current.binTicks, 1, 100, 1));
        JSpinner value = new JSpinner(new SpinnerNumberModel(current.valueAreaPercent, 1, 100, 1));
        JSpinner width = new JSpinner(new SpinnerNumberModel(current.profileWidth, 220, 600, 10));
        JCheckBox colours = new JCheckBox("Aggressor buy / sell colouring", current.aggressorColours);
        JCheckBox trails = new JCheckBox("Historical level trails (60 minutes)", current.historicalTrails);
        JCheckBox developing = new JCheckBox("Show live developing levels", current.developingLevels);
        panel.add(new JLabel("Trailing window (minutes)")); panel.add(minutes);
        panel.add(new JLabel("Price bin (instrument ticks)")); panel.add(bins);
        panel.add(new JLabel("Value area (%)")); panel.add(value);
        panel.add(new JLabel("Histogram width (pixels)")); panel.add(width);
        panel.add(colours); panel.add(trails);
        panel.add(new JLabel("Optional intraminute reference")); panel.add(developing);
        JButton apply = new JButton("Apply settings");
        apply.addActionListener(event -> {
            RollingProfileSettings updated = new RollingProfileSettings();
            updated.windowMinutes = ((Number) minutes.getValue()).intValue();
            updated.binTicks = ((Number) bins.getValue()).intValue();
            updated.valueAreaPercent = ((Number) value.getValue()).intValue();
            updated.profileWidth = ((Number) width.getValue()).intValue();
            updated.aggressorColours = colours.isSelected();
            updated.historicalTrails = trails.isSelected();
            updated.developingLevels = developing.isSelected();
            synchronized (state) { state.configure(updated, "Calculation changed; rebuilding"); }
            saveSettings(alias, updated);
        });
        JButton freeze = new JButton("Freeze published POC / VAH / VAL");
        freeze.addActionListener(event -> {
            synchronized (state) {
                Snapshot snapshot = state.published;
                state.frozen = snapshot != null && snapshot.hasData() ? snapshot : null;
            }
        });
        JButton unfreeze = new JButton("Clear frozen levels");
        unfreeze.addActionListener(event -> { synchronized (state) { state.frozen = null; } });
        panel.add(apply); panel.add(freeze);
        panel.add(new JLabel("Live profile keeps updating while levels are frozen.")); panel.add(unfreeze);
        panel.add(new JLabel("Warm-up starts at attachment or calculation reset."));
        panel.add(new JLabel("Already-loaded chart history is not imported."));
        panel.add(new JLabel("Main levels publish at each completed minute."));
        panel.add(new JLabel("Histogram and aggressor colours remain live."));
        return new StrategyPanel[] {panel};
    }

    @Override
    public ScreenSpacePainter createScreenSpacePainter(String indicatorName, String alias,
            ScreenSpaceCanvasFactory factory) {
        ProfilePainter painter = new ProfilePainter(alias, factory.createCanvas(ScreenSpaceCanvasType.HEATMAP));
        painters.add(painter);
        return painter;
    }

    private void renderFrames() {
        if (!active) { return; }
        for (ProfilePainter painter : painters) {
            InstrumentState state = instruments.get(painter.alias);
            if (state == null) { continue; }
            Frame frame;
            synchronized (state) { frame = state.frame(connected); }
            try {
                painter.draw(frame);
            } catch (RuntimeException failure) {
                // Preserve feed processing if Bookmap disposes a canvas mid-frame.
                synchronized (state) { state.notice = "Display error: " + failure.getClass().getSimpleName(); }
            }
        }
    }

    @Override
    public synchronized void finish() {
        boolean wasActive = active;
        active = false;
        if (renderer != null) {
            renderer.shutdownNow();
            renderer = null;
        }
        if (wasActive) {
            timeRequest.setAdd(false);
            provider.sendUserMessage(timeRequest);
            provider.sendUserMessage(Layer1ApiUserMessageModifyScreenSpacePainter
                    .builder(RollingProfileAddon.class, NAME).setIsAdd(false).build());
        }
        for (ProfilePainter painter : painters) { painter.dispose(); }
        painters.clear();
        instruments.clear();
        ListenableHelper.removeListeners(provider, this);
    }

    private static final class InstrumentState {
        final InstrumentInfo info;
        RollingProfileSettings settings = new RollingProfileSettings();
        RollingVolumeProfile profile = engine(settings);
        Snapshot published, frozen;
        long publishedAt = RollingVolumeProfile.NO_TIME;
        long nextMinute = RollingVolumeProfile.NO_TIME;
        long startTime = RollingVolumeProfile.NO_TIME;
        long lastTime = RollingVolumeProfile.NO_TIME;
        long generation;
        String notice = "Attached; warming up";
        final Deque<Trace> traces = new ArrayDeque<>();

        InstrumentState(InstrumentInfo info) { this.info = info; }

        void advance(long now) {
            if (lastTime != RollingVolumeProfile.NO_TIME && now < lastTime) {
                clear(now, "Replay/time reset");
                return;
            }
            if (startTime == RollingVolumeProfile.NO_TIME) {
                startTime = now;
                // Attaching at 10:00:25 must not invent a 10:00 close from
                // unobserved history. The first publication will be at 10:01.
                nextMinute = nextMinuteAfter(now);
            }
            // A long quiet interval need not manufacture years of trail
            // points. Only the last hour is visible, and no trades occurred
            // between the previous callback and this advance.
            long latestMinute = Math.floorDiv(now, MINUTE) * MINUTE;
            if (nextMinute <= latestMinute - TRACE_LIFETIME - MINUTE) {
                nextMinute = latestMinute - TRACE_LIFETIME;
            }
            while (nextMinute <= now) {
                long boundary = nextMinute;
                // The completed candle is [boundary-1m,boundary), so its
                // rolling window is [boundary-window,boundary). The engine
                // uses (time-window,time]; boundary-1ns gives exactly that
                // half-open interval at nanosecond timestamp resolution.
                // This runs BEFORE expiry at now and BEFORE a new-minute
                // trade is added, including a print exactly at the boundary.
                profile.advanceTime(boundary - 1);
                published = profile.snapshot();
                publishedAt = boundary;
                recordTrace(boundary, true);
                nextMinute = nextMinuteAfter(boundary);
            }
            lastTime = now;
            profile.advanceTime(now);
            recordTrace(now, false);
        }

        void clear(long now, String message) {
            profile.reset(); published = null; frozen = null; traces.clear(); generation++;
            publishedAt = RollingVolumeProfile.NO_TIME;
            nextMinute = RollingVolumeProfile.NO_TIME;
            startTime = RollingVolumeProfile.NO_TIME;
            lastTime = RollingVolumeProfile.NO_TIME;
            notice = message;
            if (now != RollingVolumeProfile.NO_TIME) { advance(now); }
        }

        void configure(RollingProfileSettings next, String message) {
            boolean calculationChanged = next.windowMinutes != settings.windowMinutes
                    || next.binTicks != settings.binTicks
                    || next.valueAreaPercent != settings.valueAreaPercent;
            settings = next.copy();
            if (calculationChanged) {
                profile = engine(settings);
                clear(lastTime, message);
            }
        }

        private static long nextMinuteAfter(long now) {
            return (Math.floorDiv(now, MINUTE) + 1) * MINUTE;
        }

        void recordTrace(long time, boolean force) {
            Trace previous = traces.peekLast();
            if (previous == null || time > previous.time && (force
                    || Math.floorDiv(time, SECOND) > Math.floorDiv(previous.time, SECOND))) {
                // Capture in the data clock, so accelerated replay does not
                // reduce trail resolution to the wall-clock rendering rate.
                // Forced minute-close points preserve the exact step time;
                // one-second held points extend the current published level.
                traces.addLast(new Trace(time, published == null ? null : published.pocTicks,
                        published == null ? null : published.vahTicks,
                        published == null ? null : published.valTicks));
            }
            while (!traces.isEmpty() && (traces.size() > MAX_TRACES
                    || time - traces.peekFirst().time > TRACE_LIFETIME)) {
                traces.removeFirst();
            }
        }

        Frame frame(boolean connected) {
            Snapshot snapshot = profile.snapshot();
            long elapsed = startTime == RollingVolumeProfile.NO_TIME || lastTime < startTime
                    ? 0 : lastTime - startTime;
            String status;
            if (!connected) {
                status = "DISCONNECTED | data cleared";
            } else if (startTime == RollingVolumeProfile.NO_TIME) {
                status = "WAITING FOR BOOKMAP CLOCK";
            } else if (elapsed < profile.windowNanos) {
                status = "WARM-UP " + Math.min(elapsed / SECOND, profile.windowNanos / SECOND)
                        + "/" + profile.windowNanos / SECOND + "s | " + notice;
            } else {
                status = "WINDOW READY | observed since attachment";
            }
            return new Frame(snapshot, published, publishedAt, frozen, settings.copy(), info.pips, status,
                    generation, new ArrayList<>(traces));
        }

        static RollingVolumeProfile engine(RollingProfileSettings settings) {
            return new RollingVolumeProfile(TimeUnit.MINUTES.toNanos(settings.windowMinutes),
                    settings.binTicks, settings.valueAreaPercent / 100.0);
        }
    }

    private static final class Trace {
        final long time;
        final int poc, vah, val;
        final boolean valid;
        Trace(long time, Integer poc, Integer vah, Integer val) {
            this.time = time;
            this.valid = poc != null && vah != null && val != null;
            this.poc = poc == null ? 0 : poc;
            this.vah = vah == null ? 0 : vah;
            this.val = val == null ? 0 : val;
        }
    }

    private static final class Frame {
        final Snapshot live, published, frozen;
        final long publishedAt;
        final RollingProfileSettings settings;
        final double pips;
        final String status;
        final long generation;
        final List<Trace> traces;
        Frame(Snapshot live, Snapshot published, long publishedAt, Snapshot frozen, RollingProfileSettings settings,
                double pips, String status, long generation, List<Trace> traces) {
            this.live = live; this.published = published; this.publishedAt = publishedAt;
            this.frozen = frozen; this.settings = settings;
            this.pips = pips; this.status = status; this.generation = generation; this.traces = traces;
        }
    }

    private final class ProfilePainter implements ScreenSpacePainterAdapter {
        final String alias;
        final ScreenSpaceCanvas canvas;
        final List<CanvasIcon> levels = new ArrayList<>();
        final Deque<TrailIcons> trailIcons = new ArrayDeque<>();
        int width, height;
        double bottom, priceHeight;
        boolean disposed;
        CanvasIcon profileIcon;
        long generation = Long.MIN_VALUE;
        Trace lastTrace;

        ProfilePainter(String alias, ScreenSpaceCanvas canvas) {
            this.alias = alias; this.canvas = canvas;
        }

        @Override public synchronized void onHeatmapFullPixelsWidth(int width) { this.width = width; }
        @Override public synchronized void onHeatmapPixelsHeight(int height) { this.height = height; }
        @Override public synchronized void onHeatmapPriceBottom(long bottom) { this.bottom = bottom; }
        @Override public synchronized void onHeatmapPriceHeight(long height) { this.priceHeight = height; }

        synchronized void draw(Frame frame) {
            if (disposed || width < 100 || height < 100 || priceHeight <= 0) { return; }
            if (generation != frame.generation) {
                clearTrails(); generation = frame.generation;
            }
            updateTrails(frame);
            for (CanvasIcon icon : levels) { canvas.removeShape(icon); }
            levels.clear();
            if (frame.settings.developingLevels) { drawDevelopingLevels(frame.live); }
            drawLevels(frame.published, false);
            if (frame.frozen != null) { drawLevels(frame.frozen, true); }
            int panelWidth = Math.min(frame.settings.profileWidth, width);
            BufferedImage image = ProfileRenderer.render(frame.live, frame.published, frame.publishedAt,
                    panelWidth, height,
                    bottom, bottom + priceHeight, frame.pips, frame.status,
                    frame.settings.aggressorColours, frame.settings.developingLevels, frame.frozen);
            PreparedImage prepared = new PreparedImage(image);
            if (profileIcon == null) {
                profileIcon = new CanvasIcon(prepared, pixelX(width - panelWidth), pixelY(0),
                        pixelX(width), pixelY(height));
                canvas.addShape(profileIcon);
            } else {
                profileIcon.setImage(prepared);
                profileIcon.setX1(pixelX(width - panelWidth)); profileIcon.setX2(pixelX(width));
                profileIcon.setY1(pixelY(0)); profileIcon.setY2(pixelY(height));
            }
        }

        private void drawLevels(Snapshot snapshot, boolean frozen) {
            if (snapshot == null || !snapshot.hasData()) { return; }
            addLevel(snapshot.pocTicks, POC, frozen ? 1 : 3, frozen);
            addLevel(snapshot.vahTicks, VAH, frozen ? 1 : 2, frozen);
            addLevel(snapshot.valTicks, VAL, frozen ? 1 : 2, frozen);
        }

        private void drawDevelopingLevels(Snapshot snapshot) {
            if (!snapshot.hasData()) { return; }
            addLevel(snapshot.pocTicks, faint(POC), 1, false);
            addLevel(snapshot.vahTicks, faint(VAH), 1, false);
            addLevel(snapshot.valTicks, faint(VAL), 1, false);
        }

        private Color faint(Color colour) {
            return new Color(colour.getRed(), colour.getGreen(), colour.getBlue(), 85);
        }

        private void addLevel(int ticks, Color colour, int thickness, boolean dashed) {
            CanvasIcon line = new CanvasIcon(pattern(dashed ? FROZEN : colour, dashed), pixelX(0),
                    dataY(ticks, -thickness / 2), pixelX(width),
                    dataY(ticks, thickness - thickness / 2));
            levels.add(line); canvas.addShape(line);
        }

        private void updateTrails(Frame frame) {
            if (!frame.settings.historicalTrails) { clearTrails(); return; }
            for (Trace trace : frame.traces) {
                if (lastTrace == null) { lastTrace = trace; continue; }
                if (trace.time <= lastTrace.time) { continue; }
                if (!lastTrace.valid || !trace.valid) { lastTrace = trace; continue; }
                List<CanvasIcon> icons = new ArrayList<>();
                addTrail(icons, lastTrace, trace, lastTrace.poc, trace.poc, POC);
                addTrail(icons, lastTrace, trace, lastTrace.vah, trace.vah, VAH);
                addTrail(icons, lastTrace, trace, lastTrace.val, trace.val, VAL);
                trailIcons.addLast(new TrailIcons(trace.time, icons));
                lastTrace = trace;
            }
            long minimum = frame.live.currentTimeNanos - TRACE_LIFETIME;
            while (!trailIcons.isEmpty() && (trailIcons.size() > MAX_TRACES
                    || trailIcons.peekFirst().time < minimum)) {
                for (CanvasIcon icon : trailIcons.removeFirst().icons) { canvas.removeShape(icon); }
            }
        }

        private void addTrail(List<CanvasIcon> icons, Trace previous, Trace next,
                int oldTicks, int newTicks, Color colour) {
            Color faded = new Color(colour.getRed(), colour.getGreen(), colour.getBlue(), 155);
            CanvasIcon horizontal = new CanvasIcon(pattern(faded, false), timeX(previous.time, 0),
                    dataY(oldTicks, 0), timeX(next.time, 0), dataY(oldTicks, 1));
            icons.add(horizontal); canvas.addShape(horizontal);
            if (oldTicks != newTicks) {
                CanvasIcon vertical = new CanvasIcon(pattern(faded, false), timeX(next.time, 0),
                        dataY(Math.min(oldTicks, newTicks), 0), timeX(next.time, 1),
                        dataY(Math.max(oldTicks, newTicks), 1));
                icons.add(vertical); canvas.addShape(vertical);
            }
        }

        private void clearTrails() {
            for (TrailIcons segment : trailIcons) {
                for (CanvasIcon icon : segment.icons) { canvas.removeShape(icon); }
            }
            trailIcons.clear(); lastTrace = null;
        }

        @Override
        public synchronized void dispose() {
            if (disposed) { return; }
            disposed = true;
            canvas.dispose(); painters.remove(this);
        }
    }

    private static final class TrailIcons {
        final long time;
        final List<CanvasIcon> icons;
        TrailIcons(long time, List<CanvasIcon> icons) { this.time = time; this.icons = icons; }
    }

    private static CompositeHorizontalCoordinate pixelX(int x) {
        return new CompositeHorizontalCoordinate(CompositeCoordinateBase.PIXEL_ZERO, x, 0);
    }
    private static CompositeHorizontalCoordinate timeX(long time, int pixels) {
        return new CompositeHorizontalCoordinate(CompositeCoordinateBase.DATA_ZERO, pixels, time);
    }
    private static CompositeVerticalCoordinate pixelY(int y) {
        return new CompositeVerticalCoordinate(CompositeCoordinateBase.PIXEL_ZERO, y, 0);
    }
    private static CompositeVerticalCoordinate dataY(double ticks, int pixels) {
        return new CompositeVerticalCoordinate(CompositeCoordinateBase.DATA_ZERO, pixels, ticks);
    }
    private static PreparedImage pattern(Color colour, boolean dashed) {
        // CanvasIcon scales the texture, so a true repeating dash is unavailable;
        // a translucent thin line distinguishes a frozen reference instead.
        BufferedImage image = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        image.setRGB(0, 0, (dashed ? new Color(colour.getRed(), colour.getGreen(), colour.getBlue(), 105)
                : colour).getRGB());
        return new PreparedImage(image);
    }
}
