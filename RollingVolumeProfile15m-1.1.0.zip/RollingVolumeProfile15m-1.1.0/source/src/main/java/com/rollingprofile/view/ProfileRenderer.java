package com.rollingprofile.view;

import com.rollingprofile.core.RollingVolumeProfile.Level;
import com.rollingprofile.core.RollingVolumeProfile.Snapshot;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Stateless, headless-safe rendering of a right-edge executed-volume profile. */
public final class ProfileRenderer {
    public static final Color POC = new Color(255, 209, 102);
    public static final Color VALUE = new Color(100, 218, 234);
    public static final Color BUY = new Color(46, 203, 151);
    public static final Color SELL = new Color(239, 105, 118);
    public static final Color UNKNOWN = new Color(161, 171, 190);
    private static final Color TEXT = new Color(231, 236, 244);
    private static final Color MUTED = new Color(165, 177, 194);
    private static final Color FROZEN = new Color(195, 168, 255);
    private static final Font LABEL_FONT = new Font("SansSerif", Font.BOLD, 11);
    private static final Font SMALL_FONT = new Font("SansSerif", Font.PLAIN, 10);
    private static final DateTimeFormatter CLOSE_TIME =
            DateTimeFormatter.ofPattern("HH:mm 'UTC'", Locale.ROOT).withZone(ZoneOffset.UTC);

    private ProfileRenderer() { }

    /**
     * Renders prices against the complete image height, with topTicks at y=0.
     * Bookmap callers should place this image flush with the right edge of the
     * heatmap, using the same visible price bounds. pips is price per tick.
     * The caller supplies truthful coverage / connection status; the age of
     * the oldest trade by itself cannot establish complete coverage.
     *
     * <p>Aggressor colors divide each row into SELL / UNKNOWN / BUY executed
     * volume. All three contribute to POC and value area. Disabling colors
     * displays the exact same total profile with a neutral blue histogram.</p>
     */
    public static BufferedImage render(Snapshot snapshot, int width, int height,
                                       double bottomTicks, double topTicks,
                                       double pips, String status,
                                       boolean showAggressorColors, Snapshot frozen) {
        return renderInternal(snapshot, snapshot, width, height, bottomTicks, topTicks,
                pips, status, showAggressorColors, false, frozen, "Levels: live");
    }

    /** Live rows with independently held minute-close levels and value-area shading. */
    public static BufferedImage render(Snapshot live, Snapshot published, long publishedAt,
                                       int width, int height, double bottomTicks, double topTicks,
                                       double pips, String status, boolean showAggressorColors,
                                       boolean developingLevels, Snapshot frozen) {
        String levelStatus = publishedAt == Long.MIN_VALUE
                ? "Levels: waiting for next minute close"
                : published == null || !published.hasData()
                        ? "Levels: no trades at last 1m close"
                        : "Levels: 1m close " + CLOSE_TIME.format(Instant.ofEpochSecond(
                                Math.floorDiv(publishedAt, 1_000_000_000L),
                                Math.floorMod(publishedAt, 1_000_000_000L)));
        return renderInternal(live, published, width, height, bottomTicks, topTicks,
                pips, status, showAggressorColors, developingLevels, frozen, levelStatus);
    }

    private static BufferedImage renderInternal(Snapshot snapshot, Snapshot published,
                                       int width, int height, double bottomTicks, double topTicks,
                                       double pips, String status, boolean showAggressorColors,
                                       boolean developingLevels, Snapshot frozen, String levelStatus) {
        int w = Math.max(1, width);
        int h = Math.max(1, height);
        BufferedImage image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setColor(new Color(14, 21, 31, 198));
            g.fillRect(0, 0, w, h);
            g.setColor(new Color(114, 138, 160, 72));
            g.drawLine(0, 0, 0, h - 1);
            if (w < 90 || h < 45) {
                g.setFont(SMALL_FONT);
                g.setColor(TEXT);
                g.drawString("15m VP", 4, Math.min(h - 2, 13));
                return image;
            }
            boolean validBounds = finite(bottomTicks) && finite(topTicks)
                    && topTicks > bottomTicks;
            if (!validBounds) {
                header(g, snapshot, w, "Waiting for chart price range", showAggressorColors, levelStatus);
                return image;
            }
            if (snapshot != null && snapshot.hasData()) {
                histogram(g, snapshot, published, w, h, bottomTicks, topTicks, showAggressorColors);
            }
            List<Marker> markers = new ArrayList<Marker>();
            if (developingLevels) {
                addMarkers(markers, snapshot, false, true, bottomTicks, topTicks, h, pips);
            }
            addMarkers(markers, published, false, false, bottomTicks, topTicks, h, pips);
            addMarkers(markers, frozen, true, false, bottomTicks, topTicks, h, pips);
            drawLines(g, markers, w);
            // The header is deliberately compact: the histogram keeps the full
            // chart transform and can continue behind the translucent header.
            header(g, snapshot, w, status, showAggressorColors, levelStatus);
            if (snapshot == null || !snapshot.hasData()) {
                g.setFont(SMALL_FONT);
                g.setColor(MUTED);
                g.drawString("Waiting for executed trades", 10, Math.min(h - 10, 111));
            }
            drawLabels(g, markers, w, h);
            return image;
        } finally {
            g.dispose();
        }
    }

    private static void histogram(Graphics2D g, Snapshot snapshot, Snapshot area, int w, int h,
                                  double bottom, double top, boolean aggressors) {
        int right = w - 10;
        int maximumWidth = Math.max(8, w - 24);
        long maximumVolume = 1;
        for (Level row : snapshot.levels) {
            // Normalize to visible rows. An offscreen POC does not flatten the
            // portion of the profile the user is currently inspecting.
            if (row.priceTicks + (double) snapshot.binTicks >= bottom
                    && row.priceTicks <= top) {
                maximumVolume = Math.max(maximumVolume, row.totalVolume);
            }
        }
        if (area != null && area.valTicks != null && area.vahTicks != null) {
            int yTop = clippedY(area.vahTicks + 0.5, bottom, top, h);
            int yBottom = clippedY(area.valTicks - 0.5, bottom, top, h);
            if (yBottom >= yTop) {
                g.setColor(new Color(VALUE.getRed(), VALUE.getGreen(), VALUE.getBlue(), 20));
                g.fillRect(5, yTop, w - 10, Math.max(1, yBottom - yTop));
            }
        }
        for (Level row : snapshot.levels) {
            double low = row.priceTicks - 0.5;
            double high = row.priceTicks + (double) snapshot.binTicks - 0.5;
            if (high < bottom || low > top) {
                continue;
            }
            int yTop = clippedY(high, bottom, top, h);
            int yBottom = clippedY(low, bottom, top, h);
            int rowHeight = Math.max(1, yBottom - yTop);
            if (rowHeight > 3) {
                rowHeight--;
            }
            int rowWidth = Math.max(1, (int) Math.round(maximumWidth
                    * (row.totalVolume / (double) maximumVolume)));
            rowWidth = Math.min(maximumWidth, rowWidth);
            int x = right - rowWidth;
            boolean inValue = area != null && area.valTicks != null && area.vahTicks != null
                    && row.priceTicks >= area.valTicks && row.priceTicks <= area.vahTicks;
            int alpha = inValue ? 227 : 145;
            if (aggressors) {
                // Cumulative boundaries keep segments exactly within the total
                // row width even when tiny sides round down to zero pixels.
                int sellEnd = (int) Math.round(rowWidth * (row.sellVolume / (double) row.totalVolume));
                int unknownEnd = (int) Math.round(rowWidth
                        * ((row.sellVolume + row.unknownVolume) / (double) row.totalVolume));
                fill(g, SELL, alpha, x, yTop, sellEnd, rowHeight);
                fill(g, UNKNOWN, alpha, x + sellEnd, yTop, unknownEnd - sellEnd, rowHeight);
                fill(g, BUY, alpha, x + unknownEnd, yTop, rowWidth - unknownEnd, rowHeight);
            } else {
                fill(g, new Color(116, 161, 203), alpha, x, yTop, rowWidth, rowHeight);
            }
        }
    }

    private static void fill(Graphics2D g, Color color, int alpha, int x, int y, int w, int h) {
        if (w > 0) {
            g.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha));
            g.fillRect(x, y, w, h);
        }
    }

    private static void header(Graphics2D g, Snapshot snapshot, int w,
                               String status, boolean aggressors, String levelStatus) {
        g.setColor(new Color(14, 21, 31, 228));
        g.fillRoundRect(5, 4, Math.max(1, w - 10), 83, 8, 8);
        g.setFont(new Font("SansSerif", Font.BOLD, 12));
        g.setColor(TEXT);
        double minutes = snapshot == null ? 15.0 : snapshot.windowNanos / 60_000_000_000.0;
        String title = number(minutes) + "m ROLLING VOLUME";
        g.drawString(fit(g, title, w - 20), 10, 19);
        g.setFont(SMALL_FONT);
        String volume = snapshot == null ? "0" : integer(snapshot.totalVolume);
        double areaPercent = snapshot == null ? 70.0 : snapshot.valueAreaFraction * 100;
        g.setColor(MUTED);
        g.drawString(fit(g, volume + " contracts  |  VA " + number(areaPercent) + "%", w - 20), 10, 34);
        if (aggressors) {
            int x = legend(g, 10, 46, SELL, "Sell");
            x = legend(g, x + 10, 46, BUY, "Buy");
            legend(g, x + 10, 46, UNKNOWN, "Unknown");
        } else {
            g.setColor(MUTED);
            g.drawString("Executed volume", 10, 48);
        }
        g.setColor(MUTED);
        g.drawString(fit(g, levelStatus, w - 20), 10, 63);
        g.setColor(new Color(205, 215, 230));
        String effectiveStatus = status == null || status.trim().isEmpty()
                ? "Coverage status unavailable" : status.trim();
        g.drawString(fit(g, effectiveStatus, w - 20), 10, 79);
    }

    private static int legend(Graphics2D g, int x, int y, Color color, String text) {
        g.setColor(color);
        g.fillRect(x, y - 6, 6, 6);
        g.setColor(MUTED);
        g.drawString(text, x + 9, y);
        return x + 9 + g.getFontMetrics().stringWidth(text);
    }

    private static void addMarkers(List<Marker> markers, Snapshot s, boolean frozen, boolean developing,
                                   double bottom, double top, int h, double pips) {
        if (s == null || !s.hasData()) {
            return;
        }
        Map<Integer, Marker> grouped = new LinkedHashMap<Integer, Marker>();
        addMarker(grouped, "POC", s.pocTicks, POC, frozen, developing, bottom, top, h, pips);
        addMarker(grouped, "VAH", s.vahTicks, VALUE, frozen, developing, bottom, top, h, pips);
        addMarker(grouped, "VAL", s.valTicks, VALUE, frozen, developing, bottom, top, h, pips);
        markers.addAll(grouped.values());
    }

    private static void addMarker(Map<Integer, Marker> markers, String name,
                                  Integer ticks, Color color, boolean frozen, boolean developing,
                                  double bottom, double top, int h, double pips) {
        if (ticks == null || ticks < bottom || ticks > top) {
            return;
        }
        Marker existing = markers.get(ticks);
        if (existing != null) {
            existing.name += "/" + name;
            return;
        }
        Marker marker = new Marker();
        marker.name = name;
        marker.price = price(ticks, pips);
        marker.y = y(ticks, bottom, top, h);
        marker.color = frozen ? FROZEN : developing
                ? new Color(color.getRed(), color.getGreen(), color.getBlue(), 140) : color;
        marker.frozen = frozen;
        marker.developing = developing;
        markers.put(ticks, marker);
    }

    private static void drawLines(Graphics2D g, List<Marker> markers, int w) {
        for (Marker marker : markers) {
            g.setColor(marker.color);
            g.setStroke(marker.frozen || marker.developing
                    ? new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, new float[] {4f, 4f}, 0f)
                    : new BasicStroke(marker.name.contains("POC") ? 2f : 1f));
            g.draw(new Line2D.Double(5, marker.y, w - 6, marker.y));
        }
        g.setStroke(new BasicStroke(1f));
    }

    private static void drawLabels(Graphics2D g, List<Marker> markers, int w, int h) {
        if (markers.isEmpty()) {
            return;
        }
        Collections.sort(markers, new Comparator<Marker>() {
            @Override public int compare(Marker a, Marker b) {
                return Double.compare(a.y, b.y);
            }
        });
        int labelHeight = 17;
        int topLimit = h >= 145 ? 97 : 9;
        int bottomLimit = h - 10;
        // In a small pane, reduce spacing rather than pushing labels beyond
        // the image. Text is clipped safely if the pane cannot fit all labels.
        int spacing = Math.min(labelHeight + 3,
                Math.max(1, (bottomLimit - topLimit) / Math.max(1, markers.size() - 1)));
        double last = topLimit - spacing;
        for (Marker marker : markers) {
            marker.labelY = Math.max(Math.max(topLimit, marker.y), last + spacing);
            last = marker.labelY;
        }
        double overflow = markers.get(markers.size() - 1).labelY - bottomLimit;
        if (overflow > 0) {
            for (Marker marker : markers) {
                marker.labelY -= overflow;
            }
        }
        g.setFont(LABEL_FONT);
        FontMetrics fm = g.getFontMetrics();
        for (Marker marker : markers) {
            String label = (marker.frozen ? "F " : marker.developing ? "Live " : "")
                    + marker.name + " " + marker.price;
            label = fit(g, label, w - 26);
            int boxWidth = fm.stringWidth(label) + 10;
            int boxY = (int) Math.round(marker.labelY) - 8;
            g.setColor(new Color(14, 21, 31, 240));
            g.fillRoundRect(6, boxY, boxWidth, labelHeight, 5, 5);
            g.setColor(marker.color);
            g.drawString(label, 11, boxY + 12);
            if (Math.abs(marker.labelY - marker.y) > 3) {
                g.setColor(new Color(marker.color.getRed(), marker.color.getGreen(), marker.color.getBlue(), 185));
                g.draw(new Line2D.Double(6 + boxWidth, marker.labelY,
                        Math.min(w - 7, 14 + boxWidth), marker.y));
            }
        }
    }

    /** Exact decimal price text for common decimal instrument tick sizes. */
    public static String price(int ticks, double pips) {
        if (!finite(pips) || pips <= 0) {
            return Integer.toString(ticks) + "t";
        }
        BigDecimal tickSize = BigDecimal.valueOf(pips).stripTrailingZeros();
        int decimals = Math.max(0, Math.min(10, tickSize.scale()));
        return tickSize.multiply(BigDecimal.valueOf(ticks))
                .setScale(decimals, RoundingMode.HALF_UP).toPlainString();
    }

    private static double y(double ticks, double bottom, double top, int h) {
        return (top - ticks) / (top - bottom) * (h - 1.0);
    }

    private static int clippedY(double ticks, double bottom, double top, int h) {
        return (int) Math.max(0, Math.min(h - 1, Math.round(y(ticks, bottom, top, h))));
    }

    private static boolean finite(double value) {
        return !Double.isNaN(value) && !Double.isInfinite(value);
    }

    private static String fit(Graphics2D g, String text, int maxWidth) {
        if (maxWidth <= 0) {
            return "";
        }
        FontMetrics fm = g.getFontMetrics();
        if (fm.stringWidth(text) <= maxWidth) {
            return text;
        }
        String ellipsis = "\u2026";
        int length = text.length();
        while (length > 0 && fm.stringWidth(text.substring(0, length) + ellipsis) > maxWidth) {
            length--;
        }
        return text.substring(0, length) + ellipsis;
    }

    private static String integer(long value) {
        DecimalFormat format = new DecimalFormat("#,##0", DecimalFormatSymbols.getInstance(Locale.US));
        return format.format(value);
    }

    private static String number(double value) {
        DecimalFormat format = new DecimalFormat("0.#", DecimalFormatSymbols.getInstance(Locale.US));
        return format.format(value);
    }

    private static final class Marker {
        String name;
        String price;
        double y;
        double labelY;
        Color color;
        boolean frozen;
        boolean developing;
    }
}
