package com.rollingprofile.bookmap;

import velox.api.layer1.settings.StrategySettingsVersion;

/** Per-instrument settings stored by Bookmap. */
@StrategySettingsVersion(currentVersion = 1, compatibleVersions = {})
public final class RollingProfileSettings {
    public int windowMinutes = 15;
    public int binTicks = 1;
    public int valueAreaPercent = 70;
    public int profileWidth = 300;
    public boolean aggressorColours = true;
    public boolean historicalTrails = true;
    public boolean developingLevels = false;

    public RollingProfileSettings() {}

    RollingProfileSettings copy() {
        RollingProfileSettings copy = new RollingProfileSettings();
        copy.windowMinutes = Math.max(1, Math.min(120, windowMinutes));
        copy.binTicks = Math.max(1, Math.min(100, binTicks));
        copy.valueAreaPercent = Math.max(1, Math.min(100, valueAreaPercent));
        copy.profileWidth = Math.max(220, Math.min(600, profileWidth));
        copy.aggressorColours = aggressorColours;
        copy.historicalTrails = historicalTrails;
        copy.developingLevels = developingLevels;
        return copy;
    }
}
