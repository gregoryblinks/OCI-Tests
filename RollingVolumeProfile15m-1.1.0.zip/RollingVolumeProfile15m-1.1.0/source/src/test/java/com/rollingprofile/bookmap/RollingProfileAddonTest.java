package com.rollingprofile.bookmap;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.rollingprofile.core.RollingVolumeProfile;
import com.rollingprofile.core.RollingVolumeProfile.Snapshot;

import velox.api.layer1.Layer1ApiProvider;
import velox.api.layer1.data.InstrumentInfo;
import velox.api.layer1.data.TradeInfo;
import velox.api.layer1.messages.CurrentTimeUserMessage;
import velox.api.layer1.messages.Layer1ApiRequestCurrentTimeEvents;
import velox.api.layer1.messages.UserMessageLayersChainCreatedTargeted;

/** Tests real adapter callbacks against a mock Bookmap provider, without a GUI. */
public final class RollingProfileAddonTest {
    private static final String YM = "YMZ6@RITHMIC";
    private static int assertions;

    public static void main(String[] args) throws Exception {
        executedTradesAndAggressorsOnly();
        providerClockExpiresQuietWindow();
        replayRewindAndExplicitDataGap();
        clockReadSkewPreservesValidVolume();
        minuteClosePublishesAndHoldsLevels();
        boundaryTradeStartsFollowingMinute();
        publicationUsesExactClosedMinuteWindow();
        skippedMinuteClosesNeverIncludeFutureTrades();
        longQuietJumpKeepsBoundedMinuteHistory();
        attachmentMidminuteWaitsForFirstClose();
        heldLevelsResetWithTheirDataGeneration();
        displaySettingsPreserveHeldLevels();
        fractionalTickInstrumentUsesApiTickCoordinates();
        connectionGapsRestartCoverage();
        lifecycleRemovesListenersAndStopsUpdates();
        System.out.println("RollingProfileAddon: " + assertions + " assertions passed");
    }

    private static void executedTradesAndAggressorsOnly() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.trade(YM, 42000, 4, new TradeInfo(false, false));
            harness.trade(YM, 42001, 3, null);
            // Execution-chain flags do not authorize discarding ordinary fills.
            harness.trade(YM, 42001, 2, new TradeInfo(false, true, false, false));
            harness.addon.onDepth(YM, true, 42000, 1_000_000);
            harness.addon.onDepth(YM, false, 42001, 1_000_000);
            harness.addon.onDepth(YM, true, 42000, 0);
            Snapshot snapshot = harness.snapshot(YM);
            equal(19, snapshot.totalVolume, "only executed trades contribute volume");
            equal(12, snapshot.buyVolume, "Bookmap bid aggressor maps to initiating buy side");
            equal(4, snapshot.sellVolume, "Bookmap ask aggressor maps to initiating sell side");
            equal(3, snapshot.unknownVolume, "missing aggressor is retained as unknown");
            equal(42000, snapshot.pocTicks, "YM API tick coordinate is unscaled");
            equal(4, snapshot.tradeCount, "fills counted once, independent of execution-chain flags");
            harness.trade("UNSUBSCRIBED", 42000, 100, new TradeInfo(false, true));
            harness.trade(YM, Double.NaN, 100, new TradeInfo(false, true));
            harness.trade(YM, Double.POSITIVE_INFINITY, 100, new TradeInfo(false, true));
            harness.trade(YM, 42000.1, 100, new TradeInfo(false, true));
            harness.trade(YM, 42000, 0, new TradeInfo(false, true));
            harness.trade(YM, 42000, -1, new TradeInfo(false, true));
            equal(19, harness.snapshot(YM).totalVolume, "invalid or unrelated prints do not affect volume");
        }
    }

    private static void providerClockExpiresQuietWindow() throws Exception {
        try (Harness harness = new Harness()) {
            long window = TimeUnit.MINUTES.toNanos(15);
            harness.pulse(0);
            harness.trade(YM, 42000, 20, new TradeInfo(false, false));
            harness.pulse(TimeUnit.SECONDS.toNanos(100));
            harness.trade(YM, 42010, 15, new TradeInfo(false, true));
            harness.pulse(window - 1);
            equal(35, harness.snapshot(YM).totalVolume, "pre-boundary quiet pulse retains window");
            check(harness.status(YM).startsWith("WARM-UP"), "coverage stays partial before 900 seconds");
            harness.pulse(window);
            equal(15, harness.snapshot(YM).totalVolume, "pulse expires exactly 900-second-old trade");
            equal(42010, harness.snapshot(YM).pocTicks, "quiet expiry changes POC without new buying");
            check(harness.status(YM).startsWith("WINDOW READY"), "full observed interval marks ready");
            harness.pulse(window + TimeUnit.SECONDS.toNanos(100));
            check(!harness.snapshot(YM).hasData(), "quiet profile eventually becomes empty");
        }
    }

    private static void replayRewindAndExplicitDataGap() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(TimeUnit.SECONDS.toNanos(1000));
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.pulse(TimeUnit.SECONDS.toNanos(1100));
            harness.pulse(TimeUnit.SECONDS.toNanos(200));
            equal(0, harness.snapshot(YM).totalVolume, "backward pulse clears old replay timeline");
            harness.trade(YM, 41900, 7, new TradeInfo(false, false));
            equal(7, harness.snapshot(YM).totalVolume, "rewound timeline accepts new trades");
            check(harness.status(YM).startsWith("WARM-UP 0/900s"), "rewind restarts observed coverage");
            harness.pulse(TimeUnit.SECONDS.toNanos(250), true);
            equal(0, harness.snapshot(YM).totalVolume, "skipped-event flag clears uncertain volume");
            check(harness.status(YM).startsWith("WARM-UP 0/900s"), "skipped events restart coverage");
            harness.trade(YM, 41910, 5, new TradeInfo(false, true));
            equal(5, harness.snapshot(YM).totalVolume, "new gap generation receives trades once");
        }
    }

    private static void clockReadSkewPreservesValidVolume() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.pulse(TimeUnit.SECONDS.toNanos(1));
            // CurrentTime events and getCurrentTime can disagree slightly.
            // API documentation also allows getCurrentTime to read next-event
            // time for slow consumers. Neither should erase a valid profile.
            harness.provider.now = TimeUnit.MILLISECONDS.toNanos(950);
            harness.trade(YM, 42001, 7, new TradeInfo(false, false));
            equal(17, harness.snapshot(YM).totalVolume, "future pulse versus provider read cannot clear data");
            harness.provider.now = TimeUnit.SECONDS.toNanos(2);
            harness.trade(YM, 42002, 3, new TradeInfo(false, true));
            harness.pulse(TimeUnit.MILLISECONDS.toNanos(1100));
            equal(20, harness.snapshot(YM).totalVolume, "ordered pulse behind future provider read preserves volume");
            equal(TimeUnit.SECONDS.toNanos(2), harness.snapshot(YM).currentTimeNanos,
                    "per-instrument clock remains monotonic absent authoritative rewind");
            harness.pulse(TimeUnit.MILLISECONDS.toNanos(1050));
            equal(0, harness.snapshot(YM).totalVolume, "backward pulse sequence still triggers replay reset");
        }
    }

    private static void fractionalTickInstrumentUsesApiTickCoordinates() throws Exception {
        try (Harness harness = new Harness()) {
            String alias = "ESZ6@RITHMIC";
            harness.addon.onInstrumentAdded(alias, instrument("ES", .25));
            harness.pulse(0);
            harness.trade(alias, 240000, 6, new TradeInfo(false, true));
            Snapshot snapshot = harness.snapshot(alias);
            equal(240000, snapshot.pocTicks, "API price is already a tick coordinate; never divide by pips");
            equal(6, snapshot.totalVolume, "fractional tick size does not alter contract volume");
            equal(0, harness.snapshot(YM).totalVolume, "instrument profiles are isolated");
            harness.addon.onInstrumentRemoved(alias);
            harness.trade(alias, 240001, 10, new TradeInfo(false, true));
            check(!harness.states().containsKey(alias), "removed instrument cannot receive new profile state");
        }
    }

    private static void minuteClosePublishesAndHoldsLevels() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            check(harness.published(YM) == null, "main levels wait for a completed minute");
            harness.pulse(seconds(60));
            Snapshot closed = harness.published(YM);
            equal(seconds(60), harness.publishedAt(YM), "publication is stamped with minute close");
            equal(seconds(60) - 1, closed.currentTimeNanos,
                    "published distribution ends immediately before minute boundary");
            equal(42000, closed.pocTicks, "first completed minute publishes original POC");
            harness.trade(YM, 42010, 40, new TradeInfo(false, false));
            equal(42010, harness.snapshot(YM).pocTicks, "live histogram responds to new volume");
            check(harness.published(YM) == closed, "published snapshot remains unchanged after an intraminute trade");
            harness.pulse(seconds(61));
            Object heldTrace = harness.traceAt(YM, seconds(61));
            check((Boolean) field(heldTrace, "valid"), "historical trail receives valid held levels after close");
            equal(42000, (Integer) field(heldTrace, "poc"), "intraminute trail uses held POC instead of live POC");
            harness.pulse(seconds(119));
            harness.trade(YM, 42020, 100, new TradeInfo(false, true));
            equal(42020, harness.snapshot(YM).pocTicks, "live profile continues moving between closes");
            equal(42000, harness.published(YM).pocTicks, "main POC stays fixed throughout following minute");
            equal(42000, harness.published(YM).vahTicks, "main VAH stays fixed throughout following minute");
            equal(42000, harness.published(YM).valTicks, "main VAL stays fixed throughout following minute");
            Object frame = harness.frame(YM);
            check(field(frame, "published") == closed, "drawing frame receives held levels rather than live levels");
            equal(seconds(60), (Long) field(frame, "publishedAt"), "frame preserves publication timestamp");
            equal(150, ((Snapshot) field(frame, "live")).totalVolume,
                    "drawing frame retains current histogram and aggressor volume");
            equal(110, ((Snapshot) field(frame, "live")).buyVolume,
                    "aggressor buy coloring keeps live volume between publications");
            equal(40, ((Snapshot) field(frame, "live")).sellVolume,
                    "aggressor sell coloring keeps live volume between publications");
            harness.pulse(seconds(120));
            equal(seconds(120), harness.publishedAt(YM), "next close advances held timestamp");
            equal(42020, harness.published(YM).pocTicks, "next close publishes developing POC");
            equal(150, harness.published(YM).totalVolume, "closed snapshot retains trailing fifteen minutes");
            Object boundaryTrace = harness.traceAt(YM, seconds(120));
            equal(seconds(120), (Long) field(boundaryTrace, "time"),
                    "new historical level starts at minute boundary, never one nanosecond earlier");
            equal(42020, (Integer) field(boundaryTrace, "poc"), "boundary trail publishes newly closed POC");
        }
    }

    private static void boundaryTradeStartsFollowingMinute() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            // A trade callback can be the first event to cross the close, before
            // the next requested CurrentTime callback arrives.
            harness.provider.now = seconds(60);
            harness.trade(YM, 42100, 100, new TradeInfo(false, false));
            equal(seconds(60), harness.publishedAt(YM), "boundary trade triggers preceding minute close");
            equal(10, harness.published(YM).totalVolume, "boundary print is excluded from closing snapshot");
            equal(42000, harness.published(YM).pocTicks, "boundary print cannot move preceding candle reference");
            equal(110, harness.snapshot(YM).totalVolume, "boundary print immediately enters live histogram");
            Snapshot closed = harness.published(YM);
            harness.pulse(seconds(60));
            check(harness.published(YM) == closed, "later pulse at same boundary cannot republish with boundary volume");
            harness.pulse(seconds(120));
            equal(110, harness.published(YM).totalVolume, "boundary print enters following closed snapshot");
            equal(42100, harness.published(YM).pocTicks, "following candle may publish boundary print POC");
        }
    }

    private static void publicationUsesExactClosedMinuteWindow() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.pulse(1);
            harness.trade(YM, 42001, 20, new TradeInfo(false, false));
            harness.pulse(seconds(60));
            harness.trade(YM, 42002, 30, new TradeInfo(false, true));
            harness.pulse(seconds(900));
            equal(60, harness.published(YM).totalVolume,
                    "closed [0,900s) window includes exact left endpoint trade");
            equal(50, harness.snapshot(YM).totalVolume,
                    "live (0,900s] window has already expired exact left endpoint trade");
            equal(seconds(900) - 1, harness.published(YM).currentTimeNanos,
                    "quiet close uses boundary minus one nanosecond");
            harness.pulse(seconds(900) + 1);
            equal(30, harness.snapshot(YM).totalVolume, "quiet timer keeps expiring live prints between closes");
            equal(60, harness.published(YM).totalVolume, "live expiry cannot change held closed-minute distribution");
            harness.pulse(seconds(960));
            equal(30, harness.published(YM).totalVolume,
                    "next [60s,960s) snapshot still includes trade exactly at sixty seconds");
            equal(0, harness.snapshot(YM).totalVolume, "same trade expires from live window at exact age");
            harness.pulse(seconds(1020));
            check(!harness.published(YM).hasData(), "a completed empty window clears main levels");
            equal(seconds(1020), harness.publishedAt(YM), "empty close advances timestamp instead of retaining stale levels");
        }
    }

    private static void skippedMinuteClosesNeverIncludeFutureTrades() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(seconds(10));
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.provider.now = seconds(190);
            harness.trade(YM, 42100, 100, new TradeInfo(false, false));
            equal(seconds(180), harness.publishedAt(YM), "quiet jump publishes latest crossed minute close");
            equal(10, harness.published(YM).totalVolume,
                    "multiple crossed closes exclude newer trade that caused callback");
            equal(42000, harness.published(YM).pocTicks, "past closed levels never include future aggression");
            equal(110, harness.snapshot(YM).totalVolume, "current trade still updates live profile after crossed closes");
            for (long boundary = 60; boundary <= 180; boundary += 60) {
                equal(42000, (Integer) field(harness.traceAt(YM, seconds(boundary)), "poc"),
                        "accelerated callback retains each exact minute-close trail without future trade");
            }
            harness.pulse(seconds(240));
            equal(110, harness.published(YM).totalVolume, "next close incorporates previously newer trade");
        }
    }

    private static void attachmentMidminuteWaitsForFirstClose() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(seconds(25));
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            check(harness.published(YM) == null, "midminute attachment has no fabricated preceding snapshot");
            equal(RollingVolumeProfile.NO_TIME, harness.publishedAt(YM), "waiting state has no publication timestamp");
            harness.pulse(seconds(60) - 1);
            check(harness.published(YM) == null, "main levels remain absent until next whole minute");
            harness.pulse(seconds(60));
            equal(10, harness.published(YM).totalVolume, "first close publishes observed partial history");
            check(harness.status(YM).startsWith("WARM-UP"), "first close does not imply complete fifteen-minute coverage");
        }
    }

    private static void longQuietJumpKeepsBoundedMinuteHistory() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.pulse(seconds(10000));
            equal(seconds(9960), harness.publishedAt(YM), "long quiet jump publishes most recent completed minute");
            check(!harness.published(YM).hasData(), "long quiet jump cannot retain expired reaction levels");
            int count = 0;
            for (Object trace : (Iterable<?>) field(harness.states().get(YM), "traces")) {
                long time = (Long) field(trace, "time");
                check(time >= seconds(10000 - 3600) && time <= seconds(10000),
                        "quiet jump retains only last hour of observed closed-minute history");
                check(!(Boolean) field(trace, "valid"), "expired quiet history cannot manufacture valid levels");
                count++;
            }
            check(count <= 62, "long quiet jump generates a bounded number of minute points");
        }
    }

    private static void heldLevelsResetWithTheirDataGeneration() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.pulse(seconds(60));
            check(harness.published(YM) != null, "precondition has published levels");
            harness.pulse(seconds(45));
            check(harness.published(YM) == null, "replay rewind clears held reference");
            equal(RollingVolumeProfile.NO_TIME, harness.publishedAt(YM), "rewind clears held timestamp");
            harness.trade(YM, 41900, 7, new TradeInfo(false, false));
            harness.pulse(seconds(60));
            equal(7, harness.published(YM).totalVolume, "rewound close contains new generation only");
            harness.pulse(seconds(90), true);
            check(harness.published(YM) == null, "explicit skipped data clears held reference");
            harness.trade(YM, 41800, 8, new TradeInfo(false, true));
            harness.pulse(seconds(120));
            equal(8, harness.published(YM).totalVolume, "post-gap close uses post-gap executions only");
            harness.addon.onConnectionLost(null, "test held-level reset");
            check(harness.published(YM) == null, "disconnect clears held reference");
            harness.addon.onConnectionRestored();
            check(harness.published(YM) == null, "reconnect does not restore stale held reference");
            harness.pulse(seconds(130));
            harness.trade(YM, 41700, 9, new TradeInfo(false, false));
            harness.pulse(seconds(180));
            equal(9, harness.published(YM).totalVolume, "reconnected close publishes new executions");
            RollingProfileSettings settings = new RollingProfileSettings();
            settings.binTicks = 2;
            harness.configure(YM, settings);
            check(harness.published(YM) == null, "calculation setting change clears held reference");
            equal(RollingVolumeProfile.NO_TIME, harness.publishedAt(YM), "calculation reset clears held timestamp");
        }
    }

    private static void displaySettingsPreserveHeldLevels() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.pulse(seconds(60));
            Snapshot closed = harness.published(YM);
            RollingProfileSettings settings = new RollingProfileSettings();
            settings.profileWidth = 400;
            settings.aggressorColours = false;
            settings.historicalTrails = false;
            harness.configure(YM, settings);
            check(harness.published(YM) == closed, "display-only settings preserve held reference and volume");
            equal(seconds(60), harness.publishedAt(YM), "display-only settings preserve reference timestamp");
        }
    }

    private static long seconds(long count) { return TimeUnit.SECONDS.toNanos(count); }

    private static void connectionGapsRestartCoverage() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.addon.onConnectionLost(null, "test gap");
            equal(0, harness.snapshot(YM).totalVolume, "disconnect clears incomplete window");
            check(harness.status(YM).startsWith("DISCONNECTED"), "disconnect status is explicit");
            harness.trade(YM, 42001, 15, new TradeInfo(false, true));
            equal(0, harness.snapshot(YM).totalVolume, "trades ignored while disconnected");
            harness.pulse(TimeUnit.SECONDS.toNanos(600));
            harness.addon.onConnectionRestored();
            harness.pulse(TimeUnit.SECONDS.toNanos(1000));
            harness.trade(YM, 42100, 3, new TradeInfo(false, false));
            equal(3, harness.snapshot(YM).totalVolume, "reconnected data has no pre-gap volume");
            check(harness.status(YM).startsWith("WARM-UP 0/900s"), "reconnect starts a fresh observed window");
        }
    }

    private static void lifecycleRemovesListenersAndStopsUpdates() throws Exception {
        Harness harness = new Harness();
        harness.pulse(0);
        harness.trade(YM, 42000, 10, new TradeInfo(false, true));
        check(harness.provider.addedListeners > 0, "constructor registers API listeners");
        check(harness.provider.clockRequests == 1, "activation requests provider clock events once");
        harness.addon.onUserMessage(new UserMessageLayersChainCreatedTargeted(RollingProfileAddon.class, true));
        equal(1, harness.provider.clockRequests, "duplicate activation cannot register duplicate clock stream");
        harness.close();
        equal(harness.provider.addedListeners, harness.provider.removedListeners,
                "finish removes every registered listener");
        equal(1, harness.provider.clockRemovals, "finish unregisters clock event request");
        check(harness.states().isEmpty(), "finish releases per-instrument state");
        harness.trade(YM, 42000, 100, new TradeInfo(false, true));
        check(harness.states().isEmpty(), "late callbacks after finish do not recreate state");
    }

    private static InstrumentInfo instrument(String symbol, double pips) {
        return new InstrumentInfo(symbol, "CBOT", "FUTURE", pips, 5,
                symbol + " integration test", true, 1);
    }

    private static final class Harness implements AutoCloseable {
        final MockProvider provider = new MockProvider();
        final RollingProfileAddon addon = new RollingProfileAddon(provider.proxy());

        Harness() {
            addon.onInstrumentAdded(YM, instrument("YM", 1));
            addon.onUserMessage(new UserMessageLayersChainCreatedTargeted(RollingProfileAddon.class, true));
        }

        void pulse(long now) { pulse(now, false); }

        void pulse(long now, boolean skipped) {
            provider.now = now;
            addon.onUserMessage(new CurrentTimeUserMessage(now, skipped));
        }

        void trade(String alias, double ticks, int size, TradeInfo info) {
            addon.onTrade(alias, ticks, size, info);
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> states() throws Exception {
            return (Map<String, Object>) field(addon, "instruments");
        }

        Snapshot snapshot(String alias) throws Exception {
            Object state = states().get(alias);
            synchronized (state) {
                return ((RollingVolumeProfile) field(state, "profile")).snapshot();
            }
        }

        String status(String alias) throws Exception {
            return (String) field(frame(alias), "status");
        }

        Snapshot published(String alias) throws Exception {
            Object state = states().get(alias);
            synchronized (state) { return (Snapshot) field(state, "published"); }
        }

        long publishedAt(String alias) throws Exception {
            Object state = states().get(alias);
            synchronized (state) { return (Long) field(state, "publishedAt"); }
        }

        void configure(String alias, RollingProfileSettings settings) throws Exception {
            Object state = states().get(alias);
            synchronized (state) {
                Method configure = state.getClass().getDeclaredMethod("configure", RollingProfileSettings.class,
                        String.class);
                configure.setAccessible(true);
                configure.invoke(state, settings, "Test calculation change");
            }
        }

        Object traceAt(String alias, long time) throws Exception {
            Object state = states().get(alias);
            synchronized (state) {
                for (Object trace : (Iterable<?>) field(state, "traces")) {
                    if ((Long) field(trace, "time") == time) return trace;
                }
            }
            throw new AssertionError("No historical trail at exact expected time " + time);
        }

        Object frame(String alias) throws Exception {
            Object state = states().get(alias);
            synchronized (state) {
                Method frame = state.getClass().getDeclaredMethod("frame", boolean.class);
                frame.setAccessible(true);
                return frame.invoke(state, (Boolean) field(addon, "connected"));
            }
        }

        @Override public void close() { addon.finish(); }
    }

    private static final class MockProvider implements InvocationHandler {
        long now;
        int addedListeners;
        int removedListeners;
        int clockRequests;
        int clockRemovals;
        final List<Object> messages = new ArrayList<Object>();

        Layer1ApiProvider proxy() {
            return (Layer1ApiProvider) Proxy.newProxyInstance(Layer1ApiProvider.class.getClassLoader(),
                    new Class<?>[] {Layer1ApiProvider.class}, this);
        }

        @Override public Object invoke(Object proxy, Method method, Object[] args) {
            String name = method.getName();
            if (name.equals("getCurrentTime")) return now;
            if (name.equals("getSource")) return "Mock Rithmic";
            if (name.equals("hashCode")) return System.identityHashCode(proxy);
            if (name.equals("equals")) return proxy == args[0];
            if (name.equals("toString")) return "Mock Bookmap Layer1 provider";
            if (name.startsWith("add") && name.toLowerCase().contains("listener")) addedListeners++;
            if (name.startsWith("remove") && name.toLowerCase().contains("listener")) removedListeners++;
            if (name.equals("sendUserMessage")) {
                Object message = args[0];
                messages.add(message);
                if (message instanceof Layer1ApiRequestCurrentTimeEvents) {
                    if (((Layer1ApiRequestCurrentTimeEvents) message).isAdd) clockRequests++;
                    else clockRemovals++;
                }
            }
            Class<?> result = method.getReturnType();
            if (result == boolean.class) return false;
            if (result == int.class) return 0;
            if (result == long.class) return 0L;
            if (result == double.class) return 0.0;
            if (result == float.class) return 0f;
            if (result == short.class) return (short) 0;
            if (result == byte.class) return (byte) 0;
            if (result == char.class) return (char) 0;
            return null;
        }
    }

    private static Object field(Object object, String name) throws Exception {
        Field field = object.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.get(object);
    }

    private static void equal(long expected, long actual, String message) {
        check(expected == actual, message + " (expected " + expected + ", got " + actual + ")");
    }

    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }
}
