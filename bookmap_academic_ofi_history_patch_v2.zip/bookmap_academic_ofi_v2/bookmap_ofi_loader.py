import runpy
runpy.run_path(r"C:\BookmapScripts\academic_ofi.py", run_name="__main__")
