"""Offline v2 regression tests. No live Bookmap/Rithmic connection is used."""
import ast
import math
import random
import sqlite3
import tempfile
import time
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

import academic_ofi as ofi

class FormulaTests(unittest.TestCase):
    def setUp(self):
        self.old = (100, 10, 102, 12)

    def test_unchanged_book(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, self.old), 0)

    def test_bid_add(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 15, 102, 12)), 5)

    def test_bid_size_reduction(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 7, 102, 12)), -3)

    def test_ask_add(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 102, 20)), -8)

    def test_ask_size_reduction(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 102, 8)), 4)

    def test_bid_price_improves(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (101, 3, 102, 12)), 3)

    def test_bid_price_worsens(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (99, 999, 102, 12)), -10)

    def test_ask_price_improves(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 101, 7)), -7)

    def test_ask_price_worsens(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 103, 999)), 12)

    def test_both_sides_change(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (101, 5, 103, 90)), 17)

    def test_randomized_against_piecewise_definition(self):
        rng = random.Random(7)
        for _ in range(10000):
            old = (100, rng.randrange(1, 100), 105, rng.randrange(1, 100))
            new = (100 + rng.randrange(-1, 2), rng.randrange(1, 100),
                   105 + rng.randrange(-1, 2), rng.randrange(1, 100))
            bid = new[1] if new[0] > old[0] else (-old[1] if new[0] < old[0] else new[1] - old[1])
            ask = -new[3] if new[2] < old[2] else (old[3] if new[2] > old[2] else old[3] - new[3])
            self.assertEqual(ofi.academic_ofi_event(old, new), bid + ask)


class BookTests(unittest.TestCase):
    def setUp(self):
        self.book = ofi.MBOBook()
        self.book.apply("BID_NEW", "b1", 100, 10)
        self.book.apply("ASK_NEW", "a1", 102, 12)

    def test_aggregates_multiple_orders(self):
        self.book.apply("BID_NEW", "b2", 100, 4)
        self.assertEqual(self.book.bbo(), (100, 14, 102, 12))

    def test_deeper_events_have_no_l1_effect(self):
        old = self.book.bbo()
        self.book.apply("ASK_NEW", "deep", 200, 10000)
        self.assertEqual(ofi.academic_ofi_event(old, self.book.bbo()), 0)

    def test_replace_price_and_size_atomic(self):
        old = self.book.bbo()
        self.book.apply("REPLACE", "b1", 101, 4)
        self.assertEqual(self.book.bbo(), (101, 4, 102, 12))
        self.assertEqual(ofi.academic_ofi_event(old, self.book.bbo()), 4)

    def test_zero_size_replace_removes_order(self):
        self.book.apply("BID_NEW", "b2", 99, 100)
        self.book.apply("REPLACE", "b1", 100, 0)
        self.assertEqual(self.book.bbo(), (99, 100, 102, 12))
        self.assertNotIn("b1", self.book.orders)

    def test_cancel_uses_stored_payload(self):
        self.book.apply("BID_NEW", "b2", 99, 7)
        old = self.book.bbo()
        self.book.apply("CANCEL", "b1", 0, 0)
        self.assertEqual(ofi.academic_ofi_event(old, self.book.bbo()), -10)

    def test_unknown_replace_rejected(self):
        with self.assertRaises(ofi.BookIntegrityError):
            self.book.apply("REPLACE", "missing", 100, 5)

    def test_unknown_cancel_rejected(self):
        with self.assertRaises(ofi.BookIntegrityError):
            self.book.apply("CANCEL", "missing", 0, 0)

    def test_duplicate_new_rejected(self):
        with self.assertRaises(ofi.BookIntegrityError):
            self.book.apply("BID_NEW", "b1", 100, 1)
        self.assertEqual(self.book.bbo(), (100, 10, 102, 12))

    def test_invalid_size_rejected_without_book_change(self):
        with self.assertRaises(ofi.BookIntegrityError):
            self.book.apply("REPLACE", "b1", 100, -4)
        self.assertEqual(self.book.bbo(), (100, 10, 102, 12))

    def test_empty_and_locked_books_invalid(self):
        self.book.apply("CANCEL", "b1", 0, 0)
        self.assertIsNone(self.book.bbo())
        self.book.apply("BID_NEW", "b2", 102, 5)
        self.assertIsNone(self.book.bbo())

    def test_heap_compaction(self):
        for index in range(3000):
            self.book.apply("ASK_NEW", "deep", 200 + index, 1)
            self.book.apply("CANCEL", "deep", 0, 0)
        self.assertLessEqual(len(self.book.heaps[False]), 1028)
        self.assertEqual(self.book.bbo(), (100, 10, 102, 12))

    def test_randomized_book_matches_reaggregation(self):
        rng = random.Random(11)
        for index in range(4000):
            action = rng.randrange(3)
            if action == 0 or not self.book.orders:
                side = bool(rng.randrange(2))
                price = rng.randrange(90, 101) if side else rng.randrange(102, 113)
                self.book.apply("BID_NEW" if side else "ASK_NEW", str(index), price, rng.randrange(1, 50))
            else:
                key = rng.choice(list(self.book.orders))
                side = self.book.orders[key][0]
                price = rng.randrange(90, 101) if side else rng.randrange(102, 113)
                self.book.apply("REPLACE" if action == 1 else "CANCEL", key, price, rng.randrange(1, 50))
            expected = {True: {}, False: {}}
            for side, price, size in self.book.orders.values():
                expected[side][price] = expected[side].get(price, 0) + size
            self.assertEqual(self.book.levels, expected)
            if expected[True] and expected[False]:
                b, a = max(expected[True]), min(expected[False])
                self.assertEqual(self.book.bbo(), (b, expected[True][b], a, expected[False][a]))


class RollingTests(unittest.TestCase):
    def test_empty_is_zero(self):
        self.assertEqual(ofi.RollingOFI().values(0), {60: 0, 180: 0, 300: 0})

    def test_exact_horizon_boundaries(self):
        r = ofi.RollingOFI()
        r.add(10.0, 5)
        self.assertEqual(r.values(69.999)[60], 5)
        self.assertEqual(r.values(70.0)[60], 0)
        self.assertEqual(r.values(190.0)[180], 0)
        self.assertEqual(r.values(310.0)[300], 0)

    def test_same_timestamp_multiple_events(self):
        r = ofi.RollingOFI()
        r.add(1.0, 10)
        r.add(1.0, -3)
        self.assertEqual(r.values(1.0)[60], 7)

    def test_no_events_still_expires_flow(self):
        r = ofi.RollingOFI()
        r.add(1, 17)
        self.assertEqual(r.values(1000), {60: 0, 180: 0, 300: 0})
        r.add(1001, -2)
        self.assertEqual(r.values(1001), {60: -2, 180: -2, 300: -2})

    def test_non_monotonic_time_rejected(self):
        r = ofi.RollingOFI()
        r.add(10, 1)
        with self.assertRaises(ValueError):
            r.add(9, 2)

    def test_nan_time_rejected(self):
        with self.assertRaises(ValueError):
            ofi.RollingOFI().values(math.nan)

    def test_randomized_against_direct_event_sums_and_compaction(self):
        rng = random.Random(91)
        r = ofi.RollingOFI()
        r.COMPACT_THRESHOLD = 32
        history, now = [], 0.0
        for index in range(12000):
            now += rng.random() * 0.5
            delta = rng.randrange(-100, 101)
            r.add(now, delta)
            history.append((now, delta))
            if index % 37 == 0:
                actual = r.values(now)
                for h in ofi.WINDOWS_SECONDS:
                    self.assertEqual(actual[h], sum(d for ts, d in history if ts > now - h))
        r.values(now + 1000)
        self.assertLess(len(r.timestamps), 32)


class FakeAPI:
    def __init__(self):
        self.registered, self.points, self.notices, self.subscriptions = [], [], [], []
    def register_indicator(self, addon, alias, request_id, name, graph, **kwargs):
        self.registered.append((alias, request_id, name))
    def add_boolean_settings_parameter(self, *args, **kwargs):
        pass
    def add_number_settings_parameter(self, *args, **kwargs):
        pass
    def add_label_to_settings(self, *args):
        pass
    def subscribe_to_mbo(self, addon, alias, request_id):
        self.subscriptions.append((alias, request_id))
    def send_user_message(self, addon, alias, text):
        self.notices.append(text)
    def add_point(self, addon, alias, indicator_id, value):
        self.points.append((alias, indicator_id, value))



class MemoryArchive:
    def __init__(self, rows=(), total=0, first_started=None, last_at=-math.inf):
        self.recent = list(rows)
        self.restored_total = total
        self.first_started = first_started
        self.last_at = last_at
        self.error = None
        self.rows = []
        self.path = Path('test-memory-archive')

    def submit(self, row):
        if self.error:
            raise ofi.ArchiveError(self.error)
        self.rows.append(row)


class StateTests(unittest.TestCase):
    def ready_state(self, multiplier=1):
        history = ofi.OFIHistory(MemoryArchive())
        state = ofi.InstrumentState(multiplier, 0, history)
        state.consume(0.1, 'BID_NEW', 'b', 100, 10)
        state.consume(0.2, 'ASK_NEW', 'a', 102, 12)
        self.assertFalse(state.start_if_ready(0.2))
        self.assertTrue(state.start_if_ready(5.3))
        return state

    def test_snapshot_is_not_flow(self):
        s = self.ready_state()
        self.assertEqual(s.history.total, 0)
        self.assertEqual(s.displayed_values(5.3), {60: 0, 180: 0, 300: 0})
        self.assertFalse(any(row[1] == 'OFI' for row in s.history.archive.rows))

    def test_incremental_ofi_unchanged(self):
        s = self.ready_state()
        s.consume(6, 'BID_NEW', 'b2', 100, 5)
        s.consume(7, 'REPLACE', 'a', 102, 8)
        self.assertEqual(s.history.total, 9)
        self.assertEqual(s.displayed_values(8)[60], 9)

    def test_empty_book_retains_history(self):
        s = self.ready_state()
        s.consume(6, 'BID_NEW', 'b2', 100, 5)
        history, rolling = s.history, s.history.rolling
        original_rows = list(history.archive.rows)
        s.consume(7, 'CANCEL', 'a', 0, 0)
        self.assertIs(history, s.history)
        self.assertIs(rolling, s.history.rolling)
        self.assertEqual(s.history.total, 5)
        self.assertEqual(s.displayed_values(7)[60], 5)
        self.assertEqual(s.history.archive.rows[:len(original_rows)], original_rows)
        self.assertTrue(s.gap_open)
        self.assertEqual(s.status(7), -1)

    def test_locked_book_retains_history(self):
        s = self.ready_state()
        s.consume(6, 'REPLACE', 'b', 100, 13)
        s.consume(7, 'BID_NEW', 'lock', 102, 55)
        self.assertEqual(s.history.total, 3)
        self.assertEqual(s.displayed_values(7)[60], 3)
        self.assertTrue(s.gap_open)

    def test_crossed_book_retains_history(self):
        s = self.ready_state()
        s.consume(6, 'REPLACE', 'b', 100, 13)
        s.consume(7, 'BID_NEW', 'cross', 103, 55)
        self.assertEqual(s.history.total, 3)
        self.assertTrue(s.gap_open)

    def test_recovery_rebaselines_without_bridging_gap(self):
        s = self.ready_state()
        s.consume(6, 'BID_NEW', 'b2', 100, 5)
        s.consume(7, 'CANCEL', 'a', 0, 0)
        s.consume(8, 'REPLACE', 'b', 105, 50)
        s.consume(9, 'ASK_NEW', 'a_new', 110, 1000)
        self.assertFalse(s.gap_open)
        self.assertFalse(s.warming_up)
        self.assertEqual(s.previous, (105, 50, 110, 1000))
        self.assertEqual(s.history.total, 5)
        s.consume(9.1, 'REPLACE', 'b', 105, 52)
        self.assertEqual(s.history.total, 7)
        self.assertEqual(s.displayed_values(9.1)[60], 7)

    def test_repeated_invalid_events_have_one_gap_start(self):
        s = self.ready_state()
        s.consume(6, 'CANCEL', 'a', 0, 0)
        for i in range(7, 20):
            s.consume(i, 'BID_NEW', str(i), 95, 1)
        self.assertEqual(sum(row[1] == 'GAP_START' for row in s.history.archive.rows), 1)

    def test_gap_cycle_does_not_restart_five_second_guard(self):
        s = self.ready_state()
        s.consume(6, 'CANCEL', 'a', 0, 0)
        s.consume(6.1, 'ASK_NEW', 'a2', 102, 12)
        s.consume(6.2, 'REPLACE', 'a2', 102, 10)
        self.assertEqual(s.history.total, 2)
        self.assertEqual(s.history.started_at, 5.3)

    def test_rolling_expiry_is_not_history_deletion(self):
        s = self.ready_state()
        s.consume(6, 'BID_NEW', 'b2', 100, 5)
        rows = list(s.history.archive.rows)
        s.history.rolling.COMPACT_THRESHOLD = 1
        self.assertEqual(s.displayed_values(1000), {60: 0, 180: 0, 300: 0})
        self.assertEqual(len(s.history.rolling.timestamps), 0)
        self.assertEqual(s.history.total, 5)
        self.assertEqual(s.history.archive.rows, rows)

    def test_long_gap_preserves_cumulative_but_events_age_out(self):
        s = self.ready_state()
        s.consume(6, 'REPLACE', 'b', 100, 18)
        s.consume(7, 'CANCEL', 'a', 0, 0)
        self.assertEqual(s.displayed_values(1000), {60: 0, 180: 0, 300: 0})
        self.assertEqual(s.history.total, 8)
        s.consume(1001, 'ASK_NEW', 'a2', 110, 500)
        self.assertEqual(s.history.total, 8)
        s.consume(1002, 'REPLACE', 'b', 100, 20)
        self.assertEqual(s.displayed_values(1002)[300], 2)
        self.assertEqual(s.history.total, 10)

    def test_zero_ofi_bbo_change_is_archived(self):
        h = ofi.OFIHistory(MemoryArchive())
        h.add(1, (100, 10, 102, 12), (100, 15, 102, 17))
        self.assertEqual(h.total, 0)
        self.assertEqual(len(h.archive.rows), 1)
        self.assertEqual(h.archive.rows[0][1:4], ('OFI', 0, 0))

    def test_non_bbo_event_is_not_raw_mbo_log(self):
        s = self.ready_state()
        before = len(s.history.archive.rows)
        s.consume(6, 'BID_NEW', 'deep', 99, 600)
        self.assertEqual(len(s.history.archive.rows), before)

    def test_normal_size_multiplier_conversion(self):
        s = self.ready_state(10)
        s.consume(6, 'REPLACE', 'b', 100, 15)
        self.assertEqual(s.displayed_values(6)[60], 0.5)

    def test_hidden_partial_windows_reappear_after_clean_lookback(self):
        s = self.ready_state()
        s.show_partial = False
        self.assertTrue(math.isnan(s.displayed_values(10)[60]))
        self.assertEqual(s.displayed_values(66)[60], 0)
        s.consume(67, 'CANCEL', 'a', 0, 0)
        s.consume(68, 'ASK_NEW', 'a2', 102, 12)
        self.assertTrue(math.isnan(s.displayed_values(69)[60]))
        self.assertEqual(s.displayed_values(128)[60], 0)
        self.assertTrue(math.isnan(s.displayed_values(129)[180]))

    def test_data_status_does_not_claim_full_during_or_just_after_gap(self):
        s = self.ready_state()
        self.assertEqual(s.status(6), 0)
        self.assertEqual(s.status(306), 1)
        s.consume(307, 'CANCEL', 'a', 0, 0)
        self.assertEqual(s.status(307), -1)
        s.consume(308, 'ASK_NEW', 'a2', 102, 12)
        self.assertEqual(s.status(308), 0)
        self.assertEqual(s.status(608), 1)

    def test_rebuild_retains_same_archive_and_total(self):
        s = self.ready_state()
        s.consume(6, 'REPLACE', 'b', 100, 15)
        rebuilt = ofi.InstrumentState(1, 8, s.history)
        self.assertEqual(rebuilt.book.orders, {})
        self.assertEqual(rebuilt.displayed_values(8)[60], 5)
        rebuilt.consume(8.1, 'BID_NEW', 'b', 500, 1000)
        rebuilt.consume(8.2, 'ASK_NEW', 'a', 501, 1200)
        rebuilt.start_if_ready(8.3)
        self.assertTrue(rebuilt.start_if_ready(13.4))
        self.assertEqual(rebuilt.history.total, 5)
        rebuilt.consume(14, 'REPLACE', 'b', 500, 1003)
        self.assertEqual(rebuilt.history.total, 8)

    def test_archive_failure_does_not_modify_committed_memory_total(self):
        s = self.ready_state()
        s.consume(6, 'REPLACE', 'b', 100, 15)
        s.history.archive.error = 'Disk full'
        with self.assertRaises(ofi.ArchiveError):
            s.consume(7, 'REPLACE', 'b', 100, 25)
        self.assertEqual(s.history.total, 5)
        self.assertEqual(s.history.rolling.values(7)[60], 5)

    def test_no_public_reset_method_remains(self):
        self.assertFalse(hasattr(ofi.InstrumentState, 'reset_flow'))

    def test_backwards_archive_timestamp_fails_without_deletion(self):
        h = ofi.OFIHistory(MemoryArchive())
        h.note(10, 'BASELINE', bbo=(100, 10, 102, 12))
        before = list(h.archive.rows)
        with self.assertRaises(ofi.ArchiveError):
            h.add(9, (100, 10, 102, 12), (100, 15, 102, 12))
        self.assertEqual(h.archive.rows, before)
        self.assertEqual(h.total, 0)

    def test_first_interval_starts_snapshot_guard(self):
        h = ofi.OFIHistory(MemoryArchive())
        s = ofi.InstrumentState(1, 0, h)
        s.consume(0, 'BID_NEW', 'b', 100, 10)
        s.consume(0, 'ASK_NEW', 'a', 102, 12)
        self.assertFalse(s.start_if_ready(100))
        self.assertFalse(s.start_if_ready(104))
        self.assertTrue(s.start_if_ready(105))


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'test.sqlite3'
        self.identity = ofi._identity('ES_TEST', 'ES_TEST', .25, 1, 50)
        self.archives = []

    def open_archive(self, now=0, identity=None):
        a = ofi.SQLiteArchive(self.path, identity or self.identity, now)
        self.archives.append(a)
        return a

    def tearDown(self):
        for archive in self.archives:
            archive.close()
        self.temp.cleanup()

    def rows(self):
        with closing(sqlite3.connect(str(self.path))) as c:
            return c.execute('SELECT received_at_utc, kind, ofi_raw, cumulative_raw FROM records ORDER BY seq').fetchall()

    def seed(self, a):
        h = ofi.OFIHistory(a)
        h.note(1, 'BASELINE', bbo=(100, 10, 102, 12))
        h.add(2, (100, 10, 102, 12), (100, 15, 102, 12))
        h.add(150, (100, 15, 102, 12), (100, 18, 102, 12))
        h.note(151, 'GAP_START', 'test gap')
        h.note(153, 'GAP_END', bbo=(110, 10, 112, 12))
        return h

    def test_close_reopen_preserves_total_and_recent_windows(self):
        a = self.open_archive()
        self.seed(a)
        a.close()
        original_rows = self.rows()
        b = self.open_archive(200)
        h = ofi.OFIHistory(b)
        self.assertEqual(h.total, 8)
        self.assertEqual(h.started_at, 1)
        self.assertEqual(h.rolling.values(200), {60: 3, 180: 3, 300: 8})
        self.assertEqual(self.rows(), original_rows)

    def test_old_rows_survive_cache_expiration_and_reopening(self):
        a = self.open_archive()
        h = self.seed(a)
        h.rolling.COMPACT_THRESHOLD = 1
        self.assertEqual(h.rolling.values(1000), {60: 0, 180: 0, 300: 0})
        a.close()
        self.assertEqual(len(self.rows()), 5)
        b = self.open_archive(1000)
        restored = ofi.OFIHistory(b)
        self.assertEqual(restored.total, 8)
        self.assertEqual(len(restored.rolling.timestamps), 0)
        self.assertEqual(len(self.rows()), 5)

    def test_gaps_are_retained_with_before_after_bbo(self):
        a = self.open_archive()
        self.seed(a)
        a.flush()
        with closing(sqlite3.connect(str(self.path))) as c:
            row = c.execute("SELECT old_bid, old_bid_size, bid, bid_size, ofi_raw FROM records WHERE kind='OFI' LIMIT 1").fetchone()
            self.assertEqual(row, (100, 10, 100, 15, 5))
            self.assertEqual(c.execute("SELECT count(*) FROM records WHERE kind LIKE 'GAP_%'").fetchone()[0], 2)

    def test_automatic_timed_flush(self):
        with patch.object(ofi, 'ARCHIVE_FLUSH_SECONDS', 0.01):
            a = self.open_archive()
            h = ofi.OFIHistory(a)
            h.note(1, 'BASELINE')
            deadline = time.monotonic() + 2
            while not self.rows() and time.monotonic() < deadline:
                time.sleep(.01)
            self.assertEqual(len(self.rows()), 1)

    def test_identity_mismatch_does_not_reset_archive(self):
        a = self.open_archive()
        self.seed(a)
        a.close()
        rows = self.rows()
        bad = dict(self.identity, size_multiplier=10)
        with self.assertRaises(ofi.ArchiveError):
            self.open_archive(200, bad)
        self.assertEqual(self.rows(), rows)

    def test_duplicate_writer_is_rejected(self):
        a = self.open_archive()
        self.seed(a)
        a.flush()
        with self.assertRaises(ofi.ArchiveError):
            self.open_archive(200)
        self.assertEqual(len(self.rows()), 5)

    def test_backward_computer_clock_does_not_erase_history(self):
        a = self.open_archive()
        self.seed(a)
        a.close()
        with self.assertRaises(ofi.ArchiveError):
            self.open_archive(100)
        self.assertEqual(len(self.rows()), 5)

    def test_batch_order_and_integrity_after_many_events(self):
        a = self.open_archive()
        h = ofi.OFIHistory(a)
        h.note(0, 'BASELINE')
        h.rolling.COMPACT_THRESHOLD = 16
        previous = (100, 10, 102, 12)
        for i in range(1, 10001):
            current = (100, 10 + i, 102, 12)
            h.add(i * .1, previous, current)
            previous = current
        a.close()
        rows = self.rows()
        self.assertEqual(len(rows), 10001)
        self.assertEqual(rows[-1][3], 10000)
        self.assertEqual(sum(row[2] for row in rows), 10000)
        with closing(sqlite3.connect(str(self.path))) as c:
            self.assertEqual(c.execute('PRAGMA integrity_check').fetchone()[0], 'ok')

    def test_existing_committed_rows_survive_write_failure(self):
        a = self.open_archive()
        self.seed(a)
        a.flush()
        good = self.rows()
        a.submit((1,))  # Intentionally malformed record: exercise writer failure.
        with self.assertRaises(ofi.ArchiveError):
            a.flush()
        self.assertIsNotNone(a.error)
        self.assertEqual(self.rows(), good)

    def test_no_history_delete_statements_exist(self):
        tree = ast.parse(Path(ofi.__file__).read_text())
        sql = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                if node.func.attr in ('execute', 'executemany') and node.args:
                    if isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                        sql.append(node.args[0].value.strip().upper())
        self.assertFalse(any(s.startswith(('DELETE', 'DROP', 'TRUNCATE', 'REPLACE')) for s in sql))


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.fake = FakeAPI()
        self.patches = [patch.object(ofi, 'bm', self.fake),
                        patch.object(ofi._clock, 'now', return_value=0),
                        patch.object(ofi, 'HISTORY_DIRECTORY', Path(self.temp.name)),
                        patch('builtins.print')]
        self.patches[0].start()
        self.clock = self.patches[1].start()
        self.patches[2].start()
        self.patches[3].start()
        ofi._states.clear()
        ofi._pending_indicators.clear()
        ofi._histories.clear()

    def tearDown(self):
        ofi._close_histories()
        ofi._states.clear()
        ofi._pending_indicators.clear()
        ofi._histories.clear()
        for p in reversed(self.patches):
            p.stop()
        self.temp.cleanup()

    def subscribe(self, alias='TEST', mbo=True):
        ofi.handle_subscribe_instrument(None, alias, alias, False, .25, 1, 50, {'mbo': mbo})
        for name, request_id, label in reversed(self.fake.registered):
            ofi.handle_indicator_response(None, request_id, request_id + 1000)

    def ready(self, alias='TEST'):
        self.subscribe(alias)
        ofi.handle_mbo_event(None, alias, 'BID_NEW', 'b', 100, 10)
        ofi.handle_mbo_event(None, alias, 'ASK_NEW', 'a', 102, 12)
        ofi.on_interval(None, alias)
        self.clock.return_value = 5.1
        ofi.on_interval(None, alias)
        self.clock.return_value = 6
        ofi.handle_mbo_event(None, alias, 'BID_NEW', 'b2', 100, 5)
        ofi.on_interval(None, alias)
        return ofi._states[alias]

    def test_callback_smoke_registered_lines_and_flow(self):
        s = self.ready()
        self.assertEqual(len(s.indicators), 6)
        self.assertIn(('TEST', s.indicators[60], 5.0), self.fake.points)
        self.assertIn(('TEST', s.indicators[0], 0.0), self.fake.points)
        self.assertIn(('TEST', s.indicators[ofi.STATUS_KEY], 0.0), self.fake.points)

    def test_invalid_book_callback_preserves_values_and_marks_status(self):
        s = self.ready()
        self.clock.return_value = 7
        ofi.handle_mbo_event(None, 'TEST', 'CANCEL', 'a', 0, 0)
        ofi.on_interval(None, 'TEST')
        self.assertEqual(s.history.total, 5)
        self.assertIn(('TEST', s.indicators[60], 5.0), self.fake.points)
        self.assertIn(('TEST', s.indicators[ofi.STATUS_KEY], -1.0), self.fake.points)
        self.assertTrue(any('HISTORY RETAINED' in n for n in self.fake.notices))

    def test_unsubscribe_and_resubscribe_preserve_same_history(self):
        s = self.ready()
        self.clock.return_value = 7
        ofi.handle_unsubscribe_instrument(None, 'TEST')
        self.assertNotIn('TEST', ofi._states)
        self.assertEqual(len(ofi._histories), 1)
        self.clock.return_value = 8
        self.subscribe()
        new = ofi._states['TEST']
        self.assertIs(s.history, new.history)
        self.assertEqual(new.history.total, 5)
        self.assertEqual(new.book.orders, {})
        self.assertEqual(new.displayed_values(8)[60], 5)

    def test_duplicate_subscribe_rebuilds_without_history_reset(self):
        s = self.ready()
        self.clock.return_value = 7
        self.subscribe()
        self.assertEqual(ofi._states['TEST'].history.total, 5)
        self.assertIs(ofi._states['TEST'].history, s.history)

    def test_process_like_restart_loads_saved_history(self):
        s = self.ready()
        self.clock.return_value = 7
        ofi.handle_unsubscribe_instrument(None, 'TEST')
        ofi._close_histories()
        ofi._histories.clear()
        self.clock.return_value = 8
        self.subscribe()
        self.assertEqual(ofi._states['TEST'].history.total, 5)
        self.assertEqual(ofi._states['TEST'].displayed_values(8)[60], 5)
        self.assertIsNot(ofi._states['TEST'].history, s.history)

    def test_legacy_reset_setting_cannot_clear_anything(self):
        s = self.ready()
        rows = list(s.history.rolling.prefixes)
        ofi.on_settings_change(None, 'TEST', ofi.LEGACY_RESET_SETTING, 'NUMBER', 20)
        self.assertEqual(s.history.total, 5)
        self.assertEqual(list(s.history.rolling.prefixes), rows)
        self.assertTrue(any('DISABLED' in n for n in self.fake.notices))

    def test_cumulative_can_be_enabled_without_reset(self):
        s = self.ready()
        ofi.on_settings_change(None, 'TEST', ofi.CUMULATIVE_SETTING, 'BOOLEAN', 'true')
        self.clock.return_value = 7
        ofi.on_interval(None, 'TEST')
        self.assertIn(('TEST', s.indicators[ofi.CUMULATIVE_KEY], 5.0), self.fake.points)
        self.clock.return_value = 1000
        ofi.on_interval(None, 'TEST')
        self.assertIn(('TEST', s.indicators[60], 0.0), self.fake.points)
        cumulative_points = [point for point in self.fake.points
                             if point[1] == s.indicators[ofi.CUMULATIVE_KEY]]
        self.assertEqual(cumulative_points[-1], ('TEST', s.indicators[ofi.CUMULATIVE_KEY], 5.0))

    def test_missing_order_stops_without_discarding_history(self):
        s = self.ready()
        self.clock.return_value = 7
        ofi.handle_mbo_event(None, 'TEST', 'CANCEL', 'missing', 0, 0)
        self.assertTrue(s.failed)
        self.assertEqual(s.history.total, 5)
        ofi.on_interval(None, 'TEST')
        self.assertIn(('TEST', s.indicators[60], 5.0), self.fake.points)
        self.assertIn(('TEST', s.indicators[ofi.STATUS_KEY], -1.0), self.fake.points)

    def test_archive_error_stops_without_automatic_reset(self):
        s = self.ready()
        self.clock.return_value = 7
        with patch.object(s.history.archive, 'error', 'Simulated disk failure'):
            ofi.on_interval(None, 'TEST')
            self.assertTrue(s.failed)
            self.assertEqual(s.history.total, 5)
            ofi.handle_mbo_event(None, 'TEST', 'REPLACE', 'b', 100, 99)
            self.assertEqual(s.history.total, 5)

    def test_aliases_and_archives_are_isolated(self):
        self.subscribe('A')
        self.subscribe('B')
        ofi.handle_mbo_event(None, 'A', 'BID_NEW', 'same-id', 100, 10)
        self.assertEqual(ofi._states['B'].book.orders, {})
        self.assertNotEqual(ofi._states['A'].history.archive.path, ofi._states['B'].history.archive.path)

    def test_unsupported_mbo_does_not_subscribe(self):
        self.subscribe(mbo=False)
        self.assertTrue(ofi._states['TEST'].failed)
        self.assertEqual(self.fake.subscriptions, [])

    def test_wire_nan_spelling(self):
        self.assertTrue(math.isnan(ofi.NAN))
        self.assertEqual(str(ofi.NAN), 'NaN')

    def test_settings_handler_singular_name(self):
        called = []
        self.fake.add_on_setting_change_handler = lambda *args: called.append(args)
        ofi._register_settings_handler('addon')
        self.assertEqual(called, [('addon', ofi.on_settings_change)])

    def test_settings_handler_plural_name(self):
        called = []
        self.fake.add_on_settings_change_handler = lambda *args: called.append(args)
        ofi._register_settings_handler('addon')
        self.assertEqual(called, [('addon', ofi.on_settings_change)])

    def test_no_trading_calls_exist(self):
        tree = ast.parse(Path(ofi.__file__).read_text())
        methods = {n.func.attr for n in ast.walk(tree) if isinstance(n, ast.Call)
                   and isinstance(n.func, ast.Attribute)}
        self.assertFalse(methods.intersection({'send_order', 'cancel_order', 'move_order', 'resize_order'}))


if __name__ == '__main__':
    unittest.main(verbosity=2)
