"""Academic L1 OFI for Bookmap Python API -- history-preserving patch 2.0.

Formula unchanged: Cont, Kukanov & Stoikov, section 2.1.
https://arxiv.org/html/1011.6402
Bookmap Python API: https://github.com/BookmapAPI/python-api

NO FORECASTS, MODEL, TRAINING, ORDER PLACEMENT OR AUTOMATIC HISTORY RESET.
The 60/180/300 second curves are rolling lookbacks, not predictions.
A persistent SQLite archive keeps every observed BBO-changing OFI event,
including zero-valued BBO changes, baselines and detected data-gap markers.
Deep-book events that do not change the BBO are not a raw-MBO recording.

Invalid/empty/locked/crossed books PAUSE accumulation, never erase history.
Recovery installs a NEW baseline; no OFI is fabricated across the gap.
Archives are NEVER automatically deleted, including when Bookmap closes.
Re-enabling the add-on rebuilds the book but reuses the same archive.

No third-party Python packages are required beyond Bookmap's own module.
Timing uses monotonic elapsed time anchored to local UTC, NOT exchange time.
Use for LIVE data, not accelerated replay. The initial 5-second guard is
heuristic: the documented Python MBO callback has no snapshot-end flag.

Writes are batched on a background thread (normally <= 1 second of pending
records, more under disk load). Orderly shutdown flushes; forced termination,
OS/power failure or a full/failed disk can lose uncommitted tail records.
A persistence failure stops accumulation rather than silently continuing.
"""

import hashlib
import heapq
import itertools
import json
import math
import os
import queue
import sqlite3
import threading
import time
from array import array
from bisect import bisect_right
from pathlib import Path
from typing import Dict, Optional, Tuple

VERSION = "2.0-preserve-history"
WINDOWS_SECONDS = (60, 180, 300)
STARTUP_GUARD_SECONDS = 5.0
PLOT_EVERY_SECONDS = 0.25
SHOW_PARTIAL_WINDOWS_DEFAULT = True
SHOW_CUMULATIVE_DEFAULT = False  # Optional: cumulative scale can dwarf rolling OFI.
HISTORY_DIRECTORY = Path.home() / "Bookmap_OFI_History"
ARCHIVE_FLUSH_SECONDS = 1.0
ARCHIVE_BATCH_SIZE = 4096
ARCHIVE_QUEUE_LIMIT = 100000
PARTIAL_SETTING = "Show partial windows (startup or data gaps)"
CUMULATIVE_SETTING = "Show cumulative recorded OFI"
LEGACY_PARTIAL_SETTING = "Show partial windows during startup"
LEGACY_RESET_SETTING = "Reset OFI counter (increase to reset)"
CUMULATIVE_KEY = -1
STATUS_KEY = -2
BBO = Tuple[int, int, int, int]


class _WireNaN(float):
    """Bookmap's Java-side numeric parser needs 'NaN', not Python's 'nan'."""
    def __new__(cls):
        return super().__new__(cls, "nan")

    def __str__(self):
        return "NaN"


NAN = _WireNaN()
bm = None


class ReceiptClock:
    """UTC-labelled, monotonic receipt clock for this Python process."""
    def __init__(self):
        self.utc_anchor = time.time()
        self.monotonic_anchor = time.monotonic()

    def now(self):
        return self.utc_anchor + time.monotonic() - self.monotonic_anchor


_clock = ReceiptClock()


def academic_ofi_event(previous: BBO, current: BBO) -> int:
    """Exact CKS event contribution, in integer Bookmap size units.

    The four conditions are INDEPENDENT. Equality activates both terms
    on that side, which gives the change in queue size at unchanged price.
    """
    old_bid, old_bid_size, old_ask, old_ask_size = previous
    bid, bid_size, ask, ask_size = current
    return (
        (bid_size if bid >= old_bid else 0)
        - (old_bid_size if bid <= old_bid else 0)
        - (ask_size if ask <= old_ask else 0)
        + (old_ask_size if ask >= old_ask else 0)
    )


class BookIntegrityError(ValueError):
    """The local MBO book cannot safely be continued without resubscribing."""


class MBOBook:
    """Individual orders plus aggregate price-level queues.

    Lazy heaps make best-price lookup inexpensive. Heap compaction prevents
    stale price entries from accumulating indefinitely. A REPLACE is atomic:
    its old and new legs are BOTH applied before the BBO is read.
    """

    def __init__(self):
        self.orders = {}  # order_id -> (is_bid, integer_price, integer_size)
        self.levels = {True: {}, False: {}}
        self.heaps = {True: [], False: []}

    def _change_level(self, is_bid: bool, price: int, delta: int) -> None:
        levels = self.levels[is_bid]
        heap = self.heaps[is_bid]
        old_size = levels.get(price, 0)
        new_size = old_size + delta
        if new_size < 0:
            raise BookIntegrityError("Negative aggregate queue size")
        if new_size:
            levels[price] = new_size
            if old_size == 0:
                heapq.heappush(heap, -price if is_bid else price)
        else:
            levels.pop(price, None)
        if len(heap) > 2 * len(levels) + 1024:
            heap[:] = [-p if is_bid else p for p in levels]
            heapq.heapify(heap)

    def apply(self, event_type: str, order_id: str,
              price: int, size: int) -> None:
        if event_type in ("BID_NEW", "ASK_NEW"):
            if order_id in self.orders:
                raise BookIntegrityError("Duplicate NEW order ID: %s" % order_id)
            if not isinstance(price, int) or not isinstance(size, int) or size <= 0:
                raise BookIntegrityError("NEW requires an integer price and positive size")
            is_bid = event_type == "BID_NEW"
            self.orders[order_id] = (is_bid, price, size)
            self._change_level(is_bid, price, size)
        elif event_type in ("REPLACE", "CANCEL"):
            old_order = self.orders.get(order_id)
            if old_order is None:
                raise BookIntegrityError("%s for unknown order ID: %s" %
                                         (event_type, order_id))
            if event_type == "REPLACE" and (
                not isinstance(price, int) or not isinstance(size, int) or size < 0
            ):
                raise BookIntegrityError("REPLACE requires an integer price and nonnegative size")
            is_bid, old_price, old_size = old_order
            self._change_level(is_bid, old_price, -old_size)
            if event_type == "REPLACE" and size > 0:
                self.orders[order_id] = (is_bid, price, size)
                self._change_level(is_bid, price, size)
            else:
                # CANCEL payload price/size are deliberately ignored.
                del self.orders[order_id]
        else:
            raise BookIntegrityError("Unsupported MBO event: %r" % event_type)

    def _best(self, is_bid: bool):
        heap, levels = self.heaps[is_bid], self.levels[is_bid]
        while heap:
            price = -heap[0] if is_bid else heap[0]
            if price in levels:
                return price, levels[price]
            heapq.heappop(heap)
        return None

    def bbo(self) -> Optional[BBO]:
        bid, ask = self._best(True), self._best(False)
        if bid is None or ask is None:
            return None
        if bid[0] >= ask[0]:
            # Do not interpret a locked/crossed reconstructed book as valid OFI.
            return None
        return bid[0], bid[1], ask[0], ask[1]


class RollingOFI:
    """Exact trailing sums on (now - horizon, now], without time bucketing.

    Compact arrays store timestamps and cumulative integer OFI. Three rolling
    sums share one history. Non-BBO events and zero contributions use no history.
    This is only an expendable working cache. The separate append-only SQLite
    archive retains the complete recorded OFI history; cache trimming never
    deletes archived events or changes the recorded cumulative OFI.
    """

    COMPACT_THRESHOLD = 65536

    def __init__(self, windows=WINDOWS_SECONDS):
        if not windows or any(w <= 0 for w in windows):
            raise ValueError("OFI windows must be positive")
        self.windows = tuple(windows)
        self.timestamps = array("d")
        self.prefixes = array("q")
        self.total = 0
        self.base_total = 0
        self.head = 0
        self.last_time = -math.inf
        self._since_trim = 0

    def _check_time(self, now: float) -> None:
        if not math.isfinite(now) or now < self.last_time:
            raise ValueError("RollingOFI requires finite, nondecreasing timestamps")
        self.last_time = now

    def add(self, now: float, contribution: int) -> None:
        self._check_time(now)
        if not contribution:
            return
        self.total += contribution
        self.timestamps.append(now)
        self.prefixes.append(self.total)
        self._since_trim += 1
        if self._since_trim >= self.COMPACT_THRESHOLD:
            self._trim(now)
            self._since_trim = 0

    def values(self, now: float) -> Dict[int, int]:
        self._check_time(now)
        result = {}
        for horizon in self.windows:
            boundary = bisect_right(self.timestamps, now - horizon, lo=self.head)
            before = self.prefixes[boundary - 1] if boundary > self.head else self.base_total
            result[horizon] = self.total - before
        self._trim(now)
        return result

    def _trim(self, now: float) -> None:
        new_head = bisect_right(self.timestamps, now - max(self.windows), lo=self.head)
        if new_head > self.head:
            self.base_total = self.prefixes[new_head - 1]
            self.head = new_head
        if self.head >= self.COMPACT_THRESHOLD and self.head * 2 >= len(self.timestamps):
            del self.timestamps[:self.head]
            del self.prefixes[:self.head]
            self.head = 0



class ArchiveError(RuntimeError):
    """History cannot be safely appended; no automatic reset is allowed."""


class _FileLock:
    """One live writer per instrument archive, including across processes."""
    def __init__(self, path):
        self.file = open(str(path), "a+b")
        try:
            self.file.seek(0, os.SEEK_END)
            if self.file.tell() == 0:
                self.file.write(b"0")
                self.file.flush()
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, ImportError) as exc:
            self.file.close()
            raise ArchiveError(
                "Archive is already in use or could not be locked. "
                "Run only ONE copy of this indicator per instrument: %s" % path
            ) from exc

    def close(self):
        if not self.file.closed:
            self.file.close()  # OS releases the lock; do not delete the lock file.


class _Barrier:
    def __init__(self):
        self.done = threading.Event()


_STOP = object()


class SQLiteArchive:
    """Append-only event journal with a bounded, nonblocking writer queue.

    Reads/schema checks happen once at subscription. Only the writer thread
    performs subsequent database I/O. No DELETE, REPLACE, TRUNCATE or cleanup
    path exists for recorded history. Identity mismatches fail closed.
    """
    INSERT = """INSERT INTO records
        (received_at_utc, kind, ofi_raw, cumulative_raw,
         old_bid, old_bid_size, old_ask, old_ask_size,
         bid, bid_size, ask, ask_size, note)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""

    def __init__(self, path, identity, now):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = _FileLock(str(self.path) + ".lock")
        self.error = None
        self._closed = False
        self._queue = queue.Queue(maxsize=ARCHIVE_QUEUE_LIMIT)
        self._thread = None
        try:
            connection = sqlite3.connect(str(self.path), timeout=5)
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute("PRAGMA synchronous=FULL")
                connection.execute("""CREATE TABLE IF NOT EXISTS metadata
                    (key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
                connection.execute("""CREATE TABLE IF NOT EXISTS records (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT,
                    received_at_utc REAL NOT NULL,
                    kind TEXT NOT NULL,
                    ofi_raw INTEGER NOT NULL,
                    cumulative_raw INTEGER NOT NULL,
                    old_bid INTEGER, old_bid_size INTEGER,
                    old_ask INTEGER, old_ask_size INTEGER,
                    bid INTEGER, bid_size INTEGER, ask INTEGER, ask_size INTEGER,
                    note TEXT NOT NULL
                )""")
                connection.execute("CREATE INDEX IF NOT EXISTS records_time ON records(received_at_utc)")
                expected = json.dumps(identity, sort_keys=True, separators=(",", ":"))
                stored = connection.execute("SELECT value FROM metadata WHERE key='identity'").fetchone()
                if stored is None:
                    if connection.execute("SELECT 1 FROM records LIMIT 1").fetchone():
                        raise ArchiveError("Archive identity is missing; existing records were NOT changed.")
                    connection.execute("INSERT INTO metadata VALUES ('identity', ?)", (expected,))
                    connection.execute("INSERT INTO metadata VALUES ('schema', '2')")
                elif stored[0] != expected:
                    raise ArchiveError("Instrument metadata does not match the existing archive; nothing was reset.")
                schema = connection.execute("SELECT value FROM metadata WHERE key='schema'").fetchone()
                if schema != ('2',):
                    raise ArchiveError("Unsupported history schema; existing records were NOT changed.")
                connection.commit()
                last = connection.execute(
                    "SELECT received_at_utc, cumulative_raw FROM records ORDER BY seq DESC LIMIT 1"
                ).fetchone()
                self.last_at = last[0] if last else -math.inf
                self.restored_total = int(last[1]) if last else 0
                if self.last_at > now:
                    raise ArchiveError(
                        "Archive timestamp is ahead of this computer's clock. "
                        "Correct the clock before resuming; history was NOT reset."
                    )
                first = connection.execute(
                    "SELECT received_at_utc FROM records WHERE kind='BASELINE' ORDER BY seq LIMIT 1"
                ).fetchone()
                self.first_started = first[0] if first else None
                # Load only the working-window cache. All earlier rows stay on disk.
                self.recent = list(connection.execute(
                    "SELECT received_at_utc, ofi_raw FROM records "
                    "WHERE received_at_utc > ? AND kind='OFI' ORDER BY seq",
                    (now - max(WINDOWS_SECONDS),)
                ))
            finally:
                connection.close()
            self._thread = threading.Thread(target=self._writer,
                                            name="OFI-history-writer", daemon=True)
            self._thread.start()
        except Exception:
            self._lock.close()
            raise

    def submit(self, row):
        if self.error is not None:
            raise ArchiveError(self.error)
        if self._closed:
            raise ArchiveError("Archive is closed; no history was reset.")
        try:
            self._queue.put_nowait(row)
        except queue.Full as exc:
            raise ArchiveError(
                "History writer queue is full. Accumulation stopped; already queued/committed history is retained."
            ) from exc

    def _writer(self):
        connection = None
        try:
            connection = sqlite3.connect(str(self.path), timeout=5)
            connection.execute("PRAGMA synchronous=FULL")
            stopping = False
            while not stopping:
                item = self._queue.get()
                batch = []
                barrier = None
                deadline = time.monotonic() + ARCHIVE_FLUSH_SECONDS
                while True:
                    if item is _STOP:
                        stopping = True
                        break
                    if isinstance(item, _Barrier):
                        barrier = item
                        break
                    batch.append(item)
                    if len(batch) >= ARCHIVE_BATCH_SIZE:
                        break
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    try:
                        item = self._queue.get(timeout=remaining)
                    except queue.Empty:
                        break
                if batch:
                    with connection:
                        connection.executemany(self.INSERT, batch)
                if barrier is not None:
                    barrier.done.set()
        except Exception as exc:
            self.error = "History archive write failed: %s. Previously committed rows remain intact." % exc
        finally:
            if connection is not None:
                connection.close()

    def flush(self, timeout=10):
        if self._closed:
            if self.error:
                raise ArchiveError(self.error)
            return
        barrier = _Barrier()
        self.submit(barrier)
        deadline = time.monotonic() + timeout
        while not barrier.done.wait(0.05):
            if self.error:
                raise ArchiveError(self.error)
            if time.monotonic() >= deadline:
                raise ArchiveError("History flush timed out; do not delete the archive.")

    def close(self):
        if self._closed:
            return
        try:
            if self.error is None:
                self.flush()
        finally:
            self._closed = True
            if self._thread is not None and self._thread.is_alive():
                try:
                    self._queue.put(_STOP, timeout=10)
                except queue.Full:
                    self.error = self.error or "Could not stop history writer: queue remains full."
                self._thread.join(timeout=10)
            if self._thread is None or not self._thread.is_alive():
                self._lock.close()
            else:
                # Keep the file locked while the writer is still alive.
                raise ArchiveError("History writer is still busy; archive was not deleted.")


class OFIHistory:
    """Permanent archive + cumulative total, independent of the live book."""
    def __init__(self, archive):
        self.archive = archive
        self.rolling = RollingOFI()
        for timestamp, contribution in archive.recent:
            self.rolling.add(timestamp, contribution)
        self.total = archive.restored_total
        self.started_at = archive.first_started
        self.last_at = archive.last_at

    def _record(self, now, kind, contribution=0, before=None, after=None, note=""):
        if not math.isfinite(now) or now < self.last_at:
            raise ArchiveError("History requires nondecreasing receipt times; history was not reset.")
        total = self.total + contribution
        if not -(2 ** 63) <= total < 2 ** 63:
            raise ArchiveError("Cumulative OFI exceeds archive integer range; history was not reset.")
        if not -(2 ** 63) <= contribution < 2 ** 63:
            raise ArchiveError("OFI contribution exceeds archive integer range.")
        old = before or (None,) * 4
        new = after or (None,) * 4
        row = (now, kind, contribution, total) + tuple(old) + tuple(new) + (note,)
        self.archive.submit(row)  # Fail before changing the in-memory cumulative.
        self.total = total
        self.last_at = now
        if kind == "BASELINE" and self.started_at is None:
            self.started_at = now

    def note(self, now, kind, message="", bbo=None):
        self._record(now, kind, after=bbo, note=message)

    def add(self, now, previous, current):
        contribution = academic_ofi_event(previous, current)
        # Persist BBO changes even when the four terms net to zero.
        if current != previous:
            if now < self.rolling.last_time:
                raise ArchiveError("OFI event arrived behind the rolling clock.")
            self._record(now, "OFI", contribution, previous, current)
            self.rolling.add(now, contribution)


class InstrumentState:
    def __init__(self, size_multiplier, now, history):
        if not math.isfinite(size_multiplier) or size_multiplier <= 0:
            raise ValueError("Instrument size_multiplier must be finite and positive")
        self.size_multiplier = size_multiplier
        self.history = history
        self.book = MBOBook()
        self.indicators = {}
        self.previous = None
        self.first_event_at = None
        self.first_interval_at = None
        self.created_at = now
        self.warming_up = True
        self.gap_open = False
        self.clean_since = None
        self.last_plot = -math.inf
        self.last_gap_notice = -math.inf
        self.failed = None
        self.show_partial = SHOW_PARTIAL_WINDOWS_DEFAULT
        self.show_cumulative = SHOW_CUMULATIVE_DEFAULT
        self.no_data_reported = False
        self.history.note(now, "SUBSCRIBE", "Book rebuild started; all earlier OFI retained.")

    def consume(self, now, event_type, order_id, price, size):
        if self.failed:
            return None
        self.book.apply(event_type, order_id, price, size)
        if self.first_event_at is None:
            self.first_event_at = now
        if self.warming_up:
            return None  # Reconstruct snapshot but do not add its orders as flow.
        current = self.book.bbo()
        if current is None:
            if not self.gap_open:
                self.history.note(now, "GAP_START", "Book is empty, locked or crossed.")
                self.gap_open = True
                self.previous = None
                self.clean_since = None
                if now - self.last_gap_notice >= 10:
                    self.last_gap_notice = now
                    return "Book temporarily invalid. OFI HISTORY RETAINED; new accumulation paused."
            return None
        if self.gap_open or self.previous is None:
            self.history.note(now, "GAP_END", "New valid baseline; gap transition NOT counted.", current)
            self.previous = current
            self.gap_open = False
            self.clean_since = now
            # No fresh 5-second guard, no history reset and no bridged contribution.
            return None
        self.history.add(now, self.previous, current)
        self.previous = current
        return None

    def start_if_ready(self, now):
        if self.first_interval_at is None:
            self.first_interval_at = now
        if self.failed or not self.warming_up or self.first_event_at is None:
            return False
        guard_start = max(self.first_event_at, self.first_interval_at, self.created_at)
        current = self.book.bbo()
        if now - guard_start < STARTUP_GUARD_SECONDS or current is None:
            return False
        self.history.note(now, "BASELINE", "Snapshot guard completed; accumulation starts here.", current)
        self.previous = current
        self.warming_up = False
        self.clean_since = now
        return True

    def complete(self, now, horizon):
        return (not self.failed and not self.warming_up and not self.gap_open
                and self.clean_since is not None and now - self.clean_since >= horizon)

    def displayed_values(self, now):
        if self.history.started_at is None:
            return {h: NAN for h in WINDOWS_SECONDS}
        raw = self.history.rolling.values(now)
        return {h: (raw[h] / self.size_multiplier
                    if self.show_partial or self.complete(now, h) else NAN)
                for h in WINDOWS_SECONDS}

    def status(self, now):
        # -1: paused/error. 0: initial/rebuild guard OR incomplete rolling windows.
        #  1: every 1/3/5-minute window is clear of detected gaps and warmup.
        if self.failed or self.gap_open:
            return -1.0
        return 1.0 if self.complete(now, max(WINDOWS_SECONDS)) else 0.0


_states = {}
_histories = {}
_pending_indicators = {}
_request_ids = itertools.count(1)


def _notice(addon, alias, message):
    text = "Academic OFI [%s]: %s" % (alias, message)
    print(text, flush=True)
    bm.send_user_message(addon, alias, text)


def _identity(alias, full_name, pips, size_multiplier, instrument_multiplier):
    numbers = (float(pips), float(size_multiplier), float(instrument_multiplier))
    if any(not math.isfinite(x) or x <= 0 for x in numbers):
        raise ValueError("Instrument price/size multipliers must be finite and positive")
    return dict(alias=str(alias), full_name=str(full_name), pips=numbers[0],
                size_multiplier=numbers[1], instrument_multiplier=numbers[2])


def _get_history(alias, full_name, pips, size_multiplier, instrument_multiplier, now):
    identity = _identity(alias, full_name, pips, size_multiplier, instrument_multiplier)
    key = json.dumps(identity, sort_keys=True, separators=(",", ":"))
    if key not in _histories:
        readable = "".join(c if ord(c) < 128 and c.isalnum() else "_" for c in str(alias))[:48]
        digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]
        path = HISTORY_DIRECTORY / (readable + "_" + digest + ".sqlite3")
        _histories[key] = OFIHistory(SQLiteArchive(path, identity, now))
    return _histories[key]


def _stop(addon, alias, state, now, error):
    if state.failed:
        return
    state.failed = str(error)
    state.previous = None
    state.clean_since = None
    try:
        state.history.note(now, "STOP", state.failed)
    except (ArchiveError, OSError, sqlite3.Error):
        pass  # Existing committed archive is untouched; the console still warns.
    _notice(addon, alias, "PAUSED: %s. History RETAINED. Re-enable the add-on to rebuild "
            "the book; fix any archive/disk error first." % error)


def handle_subscribe_instrument(addon, alias, full_name, is_crypto, pips,
                                size_multiplier, instrument_multiplier,
                                supported_features=None):
    if alias in _states:
        handle_unsubscribe_instrument(addon, alias)
    now = _clock.now()
    try:
        history = _get_history(alias, full_name, pips, size_multiplier, instrument_multiplier, now)
        state = InstrumentState(float(size_multiplier), now, history)
    except (ArchiveError, ValueError, TypeError, OSError, sqlite3.Error) as exc:
        _notice(addon, alias, "Cannot start: %s. Existing history was NOT deleted." % exc)
        return
    _states[alias] = state
    specifications = (
        (60, "Academic OFI - 1m", (0, 200, 255), "SOLID"),
        (180, "Academic OFI - 3m", (255, 180, 0), "SOLID"),
        (300, "Academic OFI - 5m", (215, 120, 255), "SOLID"),
        (0, "Academic OFI - Zero", (140, 140, 140), "SHORT_DASH"),
        (CUMULATIVE_KEY, "Academic OFI - Cumulative (recorded)", (70, 200, 140), "SOLID"),
        (STATUS_KEY, "Academic OFI - Data status", (210, 210, 210), "SOLID"),
    )
    for horizon, name, color, style in specifications:
        request_id = next(_request_ids)
        _pending_indicators[request_id] = (alias, state, horizon)
        bm.register_indicator(addon, alias, request_id, name, "BOTTOM",
                              color=color, line_style=style, initial_value=NAN)
    bm.add_boolean_settings_parameter(addon, alias, PARTIAL_SETTING,
                                       SHOW_PARTIAL_WINDOWS_DEFAULT, reload_if_change=False)
    bm.add_boolean_settings_parameter(addon, alias, CUMULATIVE_SETTING,
                                       SHOW_CUMULATIVE_DEFAULT, reload_if_change=False)
    bm.add_label_to_settings(addon, alias,
        "v2: history never auto-cleared. Status: -1 paused, 0 partial, 1 full. "
        "1/3/5m are lookbacks, not forecasts. Re-enable after feed reconnect.")
    _notice(addon, alias, "v%s; history archive: %s; recorded cumulative OFI = %g. "
            "Building book; previous history retained." %
            (VERSION, history.archive.path, history.total / state.size_multiplier))
    if supported_features and supported_features.get("mbo") is False:
        _stop(addon, alias, state, now, "Instrument/connection reports no MBO support.")
        return
    bm.subscribe_to_mbo(addon, alias, next(_request_ids))


def handle_unsubscribe_instrument(addon, alias):
    state = _states.pop(alias, None)
    if state is not None:
        try:
            state.history.note(_clock.now(), "UNSUBSCRIBE", "Add-on disabled; recorded OFI retained.")
        except (ArchiveError, OSError, sqlite3.Error) as exc:
            print("Academic OFI: archive warning on unsubscribe: %s" % exc, flush=True)
    for request_id, record in list(_pending_indicators.items()):
        if record[0] == alias and record[1] is state:
            del _pending_indicators[request_id]
    # Drop only the live order book. _histories and all database rows survive.


def handle_indicator_response(addon, request_id, indicator_id):
    record = _pending_indicators.pop(request_id, None)
    if record is not None:
        alias, state, horizon = record
        if _states.get(alias) is state:
            state.indicators[horizon] = indicator_id


def handle_mbo_event(addon, alias, event_type, order_id, price_level, size_level):
    state = _states.get(alias)
    if state is None or state.failed:
        return
    now = _clock.now()
    try:
        if state.history.archive.error:
            raise ArchiveError(state.history.archive.error)
        message = state.consume(now, event_type, order_id, price_level, size_level)
        if message:
            _notice(addon, alias, message)
    except (ArchiveError, BookIntegrityError, OverflowError, ValueError, TypeError) as exc:
        _stop(addon, alias, state, now, exc)


def on_interval(addon, alias):
    state = _states.get(alias)
    if state is None:
        return
    now = _clock.now()
    try:
        if state.history.archive.error:
            raise ArchiveError(state.history.archive.error)
        if state.start_if_ready(now):
            _notice(addon, alias, "OFI collection active. Existing history RETAINED. "
                    "Partial/gapped windows are flagged by Data status until their lookbacks fill.")
    except (ArchiveError, ValueError, TypeError) as exc:
        _stop(addon, alias, state, now, exc)
    if (state.first_event_at is None and not state.failed and
            not state.no_data_reported and now - state.created_at >= 15):
        state.no_data_reported = True
        _notice(addon, alias, "No MBO events received. Check live feed and MBO support. History retained.")
    if now - state.last_plot < PLOT_EVERY_SECONDS:
        return
    state.last_plot = now
    values = state.displayed_values(now)
    values[0] = 0.0
    values[CUMULATIVE_KEY] = state.history.total / state.size_multiplier if state.show_cumulative else NAN
    values[STATUS_KEY] = state.status(now)
    for horizon, indicator_id in state.indicators.items():
        bm.add_point(addon, alias, indicator_id, values[horizon])


def on_settings_change(addon, alias, setting_name, field_type, new_value):
    state = _states.get(alias)
    if state is None:
        return
    flag = new_value.lower() == "true" if isinstance(new_value, str) else bool(new_value)
    if setting_name in (PARTIAL_SETTING, LEGACY_PARTIAL_SETTING):
        state.show_partial = flag
    elif setting_name == CUMULATIVE_SETTING:
        state.show_cumulative = flag
    elif setting_name == LEGACY_RESET_SETTING:
        _notice(addon, alias, "History reset is DISABLED in v2. All OFI history retained.")


def _register_settings_handler(addon):
    register = getattr(bm, "add_on_settings_change_handler", None)
    if register is None:
        register = getattr(bm, "add_on_setting_change_handler", None)
    if register is None:
        raise RuntimeError("This Bookmap Python API version has no settings-change handler")
    register(addon, on_settings_change)


def _close_histories():
    for history in _histories.values():
        try:
            history.archive.close()
        except (ArchiveError, OSError, sqlite3.Error) as exc:
            print("Academic OFI: shutdown archive warning: %s" % exc, flush=True)


def main():
    global bm
    try:
        import bookmap as bm
    except ImportError as exc:
        raise SystemExit("Run INSIDE Bookmap's Python API add-on through the existing loader.") from exc
    addon = bm.create_addon()
    bm.add_mbo_handler(addon, handle_mbo_event)
    bm.add_on_interval_handler(addon, on_interval)
    bm.add_indicator_response_handler(addon, handle_indicator_response)
    _register_settings_handler(addon)
    try:
        bm.start_addon(addon, handle_subscribe_instrument, handle_unsubscribe_instrument)
        bm.wait_until_addon_is_turned_off(addon)
    finally:
        # This closes/flushes files; it does NOT delete any history.
        _close_histories()


if __name__ == "__main__":
    main()
