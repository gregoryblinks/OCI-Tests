# Academic OFI v2 - history-preserving patch

## Install over the existing, working indicator

1. Disable the old OFI Python add-on.
2. Replace the old external `academic_ofi.py` with the patched file. With the
   loader used in this conversation, the location is:
   `C:\BookmapScripts\academic_ofi.py`.
3. Keep only the same two-line loader in Bookmap's Python editor:

```python
import runpy
runpy.run_path(r"C:\BookmapScripts\academic_ofi.py", run_name="__main__")
```

4. Use the same **Build** operation that worked before and enable the rebuilt
   add-on for the instrument. No separate Play button is required by this guide.
   Rebuild/restart the script, not just its instrument subscription, so the
   external file is re-executed. Do not paste the full file back into the editor.

Look for a startup message containing `v2.0-preserve-history` and the history
archive path. If the old message `OFI history cleared` still appears, the old
Python process/script is still running. Stop that old add-on and rebuild the
loader; do not run two copies for the same instrument.

The new file uses Python's standard library plus Bookmap's own Python module.
There is no model, training, network service or order-placement functionality.

## What changed

The academic four-term L1 OFI equation is unchanged. The history lifetime is not.

- An empty, locked or crossed reconstructed book pauses new accumulation.
  Previously observed OFI and the cumulative total are NOT reset.
- Every detected gap is recorded. The first valid book after a gap establishes
  a fresh baseline; the transition across the missing/invalid data is NOT
  treated as an academic OFI event. Accumulation resumes from the next valid
  event. A transient invalid book no longer restarts the five-second guard.
- Unknown order IDs, duplicate NEW messages and malformed book events stop new
  accumulation rather than guess. Recorded history remains intact. Re-enable
  the add-on to obtain a new book snapshot; the same history is reused.
- Re-enabling for the same instrument or restarting the Python script restores
  the retained cumulative total and the recent rolling-window cache.
- The manual OFI-reset control was removed. A stale saved reset-setting event
  is ignored with a warning; it cannot erase history.
- No automatic delete, expiry, midnight reset or application-exit purge is
  performed on the history archive. It persists even after Bookmap closes.

## Rolling windows are not the complete history

The three original curves are still exact trailing sums over `(now - h, now]`,
for h = 60, 180 and 300 seconds. An event naturally stops contributing to the
current one-minute value once it is one minute old. It is NOT deleted from the
archive. The in-memory five-minute cache may be compacted; this never purges
saved history or resets the cumulative total.

The default setting **Show partial windows (startup or data gaps)** keeps
available observed sums visible during gaps, including while accumulation is
paused. These values are incomplete measurements, not estimates of missing
flow. With that setting disabled, an affected line is blank until its lookback
has a sufficiently long uninterrupted valid-book segment. This hides a value;
it does not remove history.

Enable **Show cumulative recorded OFI** to show the extra cumulative curve.
It sums the retained archive for that instrument, not just the current trading
day or current Bookmap run. It is disabled by default because its scale may
make the rolling curves difficult to read when sharing a panel.

The new **Academic OFI - Data status** curve means:

| Value | Meaning |
| --- | --- |
| -1 | Accumulation paused because the book is invalid or an error occurred. |
| 0 | Startup/book rebuild is in progress, or at least one lookback still includes a detected gap or startup period. |
| 1 | All three lookbacks have a full valid-book segment with no detected interruption. |

Status 1 is NOT proof that the upstream feed delivered every exchange event.
Only problems visible to this add-on can be flagged. A silent feed outage is
not reliably distinguishable from an inactive market using the documented MBO
callback alone. Re-enable the add-on after a known feed reconnect so that it
receives a fresh book; historical OFI is retained.

## Where history is stored

Default directory:

```text
C:\Users\YOUR_USERNAME\Bookmap_OFI_History
```

On Windows, paste `%USERPROFILE%\Bookmap_OFI_History` into File Explorer's address
bar. The exact full database path is printed by the script on subscription.
On other systems the directory is `Bookmap_OFI_History` under the user's home.

There is one SQLite database per instrument identity, with a readable alias
prefix and a hash suffix. Identity includes the full instrument name, alias,
tick size, size multiplier and instrument multiplier. A different contract or
changed metadata gets a different archive; earlier archives are not deleted or
silently combined. Keep the same directory to restore the same history.

The archive records local UTC-labelled receipt time, the OFI contribution,
the cumulative recorded OFI, and before/after BBO values. It also retains
SUBSCRIBE, BASELINE, GAP_START, GAP_END, STOP and UNSUBSCRIBE records. Valid
BBO-changing events with a zero net contribution are retained too. Deep-book
updates that leave the BBO unchanged are not recorded, and invalid-period flow
is not invented. This is an OFI audit trail, NOT a complete raw-MBO recording.

The `records` table is append-only in this implementation. `ofi_raw` and
`cumulative_raw` are in integer Bookmap size units. Divide by the instrument's
`size_multiplier` for the displayed OFI. Price levels multiplied by `pips` give
actual prices. Instrument metadata is in the `metadata` table as JSON.

An offline, read-only SQLite query can recover observed OFI for any archived
interval without changing the archive:

```sql
SELECT SUM(ofi_raw)
FROM records
WHERE kind = 'OFI'
  AND received_at_utc > :start_utc_epoch
  AND received_at_utc <= :end_utc_epoch;
```

For meaningful interpretation, also inspect the gap/baseline/stop/subscription
markers within and before that interval. Summing recorded events cannot recover
unobserved market flow during an interruption. The BBO fields allow the recorded
valid-event contributions to be independently checked against the formula.

Archives grow with activity and have no automatic pruning. Keep sufficient
free disk space. Do not delete the databases, lock files, or SQLite `-wal` and
`-shm` sidecars while the add-on is running. Prefer a proper SQLite backup or
close the add-on cleanly before copying the complete archive directory.

## Durability and timing limits

Database writes are batched on a background thread, normally once per second
or when a batch fills. Orderly script shutdown flushes queued records. Forced
process termination, a power failure, disk exhaustion or an I/O error can lose
uncommitted tail records. This is not an absolute crash-proof durability claim.
A writer error or full queue stops new accumulation and warns; previously
committed rows are not deliberately erased or replaced. Fix disk/permissions
problems before rebuilding the Python script. Only one writer for a given
instrument archive is allowed at a time.

Local monotonic time is anchored to local UTC at Python startup. This makes
saved timestamps usable across ordinary restarts, but these are NOT exchange
timestamps. Keep the computer clock correct. An archive whose latest record
is ahead of the new process clock is rejected without resetting it. This code
is for LIVE data, not accelerated replay or historical backfill.

The initial five-second book-build guard remains a heuristic, not a guarantee
that a feed snapshot has completed. The documented Python MBO handler does not
expose an explicit snapshot-end flag. Resubscription rebuilds the book and does
not count incoming snapshot orders as flow during that guard.

Saved indicator data and the visible Bookmap chart are different. This patch
restores calculation state, but it does not inject archived points back into
a prior chart timeline after the indicator is re-created. The documented
Python `add_point` call plots a current value and has no historical timestamp
argument. Historical observations remain accessible in the database.

The old v1 implementation did not write an OFI archive. This patch cannot
recover history already erased by v1 or transfer its unsaved live memory
through a Python-process restart. The persistent archive begins with v2.

## Local verification

Run outside Bookmap, from the package folder:

```text
python -m unittest -v test_academic_ofi.py
```

The included 75 tests check the original equation, MBO aggregation, exact
rolling boundaries, invalid-book and long-gap handling, no bridging across
gaps, repeated subscription, simulated process restart, real SQLite
close/reopen, writer failure, archive identity/locking, historical retention,
settings, and mocked Bookmap indicator callbacks. A 10,000-event journal test
also checks SQLite integrity and exact contribution totals.

All 75 tests passed in the supplied local test run. Bookmap API calls are
mocked in these tests. This patch has NOT been tested in a live Bookmap/Rithmic
session or in the user's Windows environment.

## Primary references

Bookmap API signatures, MBO events, initial snapshot and indicator API:
https://github.com/BookmapAPI/python-api

Original academic formula:
https://arxiv.org/html/1011.6402

Python SQLite documentation:
https://docs.python.org/3/library/sqlite3.html
