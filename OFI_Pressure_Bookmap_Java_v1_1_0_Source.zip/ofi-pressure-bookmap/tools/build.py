#!/usr/bin/env python3
"""Build a Bookmap-loadable JAR using Bookmap's real published SDK (never API stubs)."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REPOSITORY = 'https://maven.bookmap.com/maven2/releases/com/bookmap/api'


def run(args: list[str]) -> None:
    subprocess.run(args, check=True, cwd=ROOT)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--offline', action='store_true', help='Require SDK JARs already present in lib/')
    parser.add_argument('--sdk-version', default='7.6.0.20')
    options = parser.parse_args()
    if any(ch not in '0123456789.' for ch in options.sdk_version):
        raise ValueError('SDK version must be digits and dots')
    for command in ('java', 'javac', 'jar'):
        if not shutil.which(command):
            raise RuntimeError(f'{command} is missing. Install JDK 17+ and put its bin directory on PATH.')
    libs = ROOT / 'lib'
    libs.mkdir(exist_ok=True)
    artifacts = []
    checksums = {}
    for name in ('api-core', 'api-simplified'):
        filename = f'{name}-{options.sdk_version}.jar'
        target = libs / filename
        if not target.exists():
            if options.offline:
                raise FileNotFoundError(f'Missing {target}')
            url = f'{REPOSITORY}/{name}/{options.sdk_version}/{filename}'
            print(f'Downloading official SDK: {url}', flush=True)
            temp = target.with_suffix('.download')
            try:
                with urllib.request.urlopen(url, timeout=60) as response, temp.open('wb') as out:
                    shutil.copyfileobj(response, out)
                if not zipfile.is_zipfile(temp):
                    raise RuntimeError(f'{url} did not return a valid JAR')
                temp.replace(target)
            finally:
                temp.unlink(missing_ok=True)
        if not zipfile.is_zipfile(target):
            raise RuntimeError(f'{target} is not a valid JAR; delete it and rebuild')
        artifacts.append(target)
        checksums[filename] = hashlib.sha256(target.read_bytes()).hexdigest()
    # The independent tests do not require any SDK and test the exact same production engine.
    run([sys.executable, str(ROOT / 'tools/test_core.py')])
    classes = ROOT / 'build' / 'classes'
    if classes.exists():
        shutil.rmtree(classes)
    classes.mkdir(parents=True)
    sources = sorted((ROOT / 'src/main/java').rglob('*.java'))
    argfile = ROOT / 'build' / 'javac-sources.txt'
    argfile.write_text('\n'.join('"' + str(p).replace('\\', '/') + '"' for p in sources), encoding='utf-8')
    classpath = os.pathsep.join(map(str, artifacts))
    run(['javac', '--release', '17', '-encoding', 'UTF-8', '-cp', classpath, '-d', str(classes), '@' + str(argfile)])
    dist = ROOT / 'dist'
    dist.mkdir(exist_ok=True)
    jar = dist / 'ofi-pressure-bookmap-1.1.0.jar'
    run(['jar', '--create', '--file', str(jar), '-C', str(classes), '.'])
    with zipfile.ZipFile(jar) as archive:
        if any(name.startswith('velox/') for name in archive.namelist()):
            raise RuntimeError('Refusing to ship Bookmap SDK classes inside the add-on')
        assert 'com/ofipressure/bookmap/OfiPressureAddon.class' in archive.namelist()
    (dist / 'build-info.json').write_text(json.dumps({
        'sdk_version': options.sdk_version,
        'sdk_sha256': checksums,
        'addon_sha256': hashlib.sha256(jar.read_bytes()).hexdigest(),
        'note': 'Built against official SDK. Actual Bookmap/feed acceptance testing is still required.'
    }, indent=2), encoding='utf-8')
    print(f'\nBUILT: {jar}\nLoad this JAR through Bookmap API plugins configuration. Use Replay first.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, ValueError, subprocess.CalledProcessError) as exc:
        print(f'BUILD FAILED: {exc}\nNo verified Bookmap JAR was produced by this run.', file=sys.stderr)
        raise SystemExit(1)
