# Synthetic regression data only

65 generated minutes with exactly 3 levels per side and one deliberately ignored zero-size trade per minute. 15 WARMUP rows, 45 PROVISIONAL scores and 5 MATURE scores. These are test fixtures, not market observations or trading performance.
