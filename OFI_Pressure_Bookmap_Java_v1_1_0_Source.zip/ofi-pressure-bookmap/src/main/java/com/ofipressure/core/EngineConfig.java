package com.ofipressure.core;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Explicit, immutable parameters. No parameters are fitted on the current bar. */
public final class EngineConfig {
    public static final String MODEL_VERSION = "mlofi-adaptive-depth-1.1.0";
    public static final int CONFIG_SCHEMA_VERSION = 2;
    public final int levels, minLevels, window, warmup, benchmark, maxOrders;
    public final double decay, varianceFloor, minCoverage, minBubbleZ;
    public final long staleNanos, gapResetNanos;
    public final String depthMode, weightMode, runLabel;
    public final Path outputRoot;
    public final double[] weights;
    public final boolean showWarmup;

    public EngineConfig(Properties p) {
        levels = integer(p, "levels", 10, 1, 50);
        minLevels = integer(p, "levels.minimum", Math.min(3, levels), 1, levels);
        window = integer(p, "rolling.window.minutes", 60, 2, 10080);
        warmup = integer(p, "rolling.minimum.minutes", Math.min(15, window), 2, window);
        benchmark = integer(p, "rolling.benchmark.minutes", Math.min(60, window), warmup, window);
        maxOrders = integer(p, "book.max.orders", 2000000, 1000, 10000000);
        decay = number(p, "weights.decay", 0.25, 0, 5);
        varianceFloor = number(p, "rolling.sd.floor", 1e-9, 1e-15, 1e3);
        minCoverage = number(p, "quality.minimum.coverage", 0.99, 0.5, 1.0);
        minBubbleZ = number(p, "display.minimum.abs.z", 0, 0, 20);
        staleNanos = (long)(number(p, "quality.stale.seconds", 30, 1, 3600) * 1e9);
        gapResetNanos = (long)(number(p, "quality.clock.gap.seconds", 120, 60, 86400) * 1e9);
        depthMode = p.getProperty("depth.mode", "EVENT").trim().toUpperCase(Locale.ROOT);
        if (!depthMode.equals("EVENT") && !depthMode.equals("TIME")) throw new IllegalArgumentException("depth.mode must be EVENT or TIME");
        weightMode = p.getProperty("weights.mode", "EXPONENTIAL").trim().toUpperCase(Locale.ROOT);
        weights = new double[levels];
        if (weightMode.equals("MANUAL")) {
            String[] a = p.getProperty("weights.manual", "").split(",");
            if (a.length != levels) throw new IllegalArgumentException("weights.manual must have exactly levels entries");
            for (int i=0; i<levels; i++) { weights[i] = Double.parseDouble(a[i].trim()); if (!Double.isFinite(weights[i])) throw new IllegalArgumentException("Nonfinite weight"); }
        } else if (weightMode.equals("UNIFORM") || weightMode.equals("EXPONENTIAL")) {
            for (int i=0; i<levels; i++) weights[i] = weightMode.equals("UNIFORM") ? 1.0 : Math.exp(-decay*i);
        } else throw new IllegalArgumentException("weights.mode must be EXPONENTIAL, UNIFORM or MANUAL");
        double l1=0; for(double w:weights) l1+=Math.abs(w);
        if (!(l1 > 0)) throw new IllegalArgumentException("Weights cannot all be zero");
        for (int i=0; i<levels; i++) weights[i] /= l1;
        // Every supported prefix must have a nonzero mass for adaptive renormalization.
        if (!(activeWeightMass(minLevels) > 0))
            throw new IllegalArgumentException("First levels.minimum weights cannot all be zero");
        showWarmup = Boolean.parseBoolean(p.getProperty("display.show.warmup", "true"));
        runLabel = p.getProperty("run.label", "UNSPECIFIED").trim();
        outputRoot = Paths.get(p.getProperty("output.directory", Paths.get(System.getProperty("user.home"), "Bookmap", "OFI-Pressure", "data").toString()));
    }
    private static int integer(Properties p,String k,int d,int lo,int hi) {
        int v=Integer.parseInt(p.getProperty(k,""+d).trim());
        if(v<lo || v>hi) throw new IllegalArgumentException(k+" must be "+lo+".."+hi); return v;
    }
    private static double number(Properties p,String k,double d,double lo,double hi) {
        double v=Double.parseDouble(p.getProperty(k,""+d).trim());
        if(!Double.isFinite(v) || v<lo || v>hi) throw new IllegalArgumentException(k+" outside allowed range"); return v;
    }
    public Properties asProperties() {
        Properties p=new Properties();
        p.setProperty("config.schema.version", ""+CONFIG_SCHEMA_VERSION);
        p.setProperty("levels.minimum", ""+minLevels);
        p.setProperty("rolling.benchmark.minutes", ""+benchmark);
        p.setProperty("levels",""+levels); p.setProperty("rolling.window.minutes",""+window); p.setProperty("rolling.minimum.minutes",""+warmup);
        p.setProperty("weights.mode",weightMode); p.setProperty("weights.decay",""+decay);
        StringJoiner w=new StringJoiner(","); for(double v:weights)w.add(Double.toString(v)); p.setProperty("weights.manual",w.toString());
        p.setProperty("depth.mode",depthMode); p.setProperty("rolling.sd.floor",""+varianceFloor);
        p.setProperty("quality.minimum.coverage",""+minCoverage); p.setProperty("quality.stale.seconds",""+(staleNanos/1e9));
        p.setProperty("quality.clock.gap.seconds",""+(gapResetNanos/1e9)); p.setProperty("book.max.orders",""+maxOrders);
        p.setProperty("display.minimum.abs.z",""+minBubbleZ); p.setProperty("display.show.warmup",""+showWarmup);
        p.setProperty("run.label",runLabel); p.setProperty("output.directory",outputRoot.toString()); return p;
    }
    public String fingerprint() {
        try {
            StringBuilder b=new StringBuilder(MODEL_VERSION+"\n"); Properties p=asProperties();
            for(String k:new TreeSet<>(p.stringPropertyNames())) b.append(k).append('=').append(p.getProperty(k)).append('\n');
            byte[] hash=MessageDigest.getInstance("SHA-256").digest(b.toString().getBytes(StandardCharsets.UTF_8));
            StringBuilder h=new StringBuilder(); for(byte x:hash)h.append(String.format(Locale.ROOT,"%02x",x&255)); return h.toString();
        } catch(Exception e) { throw new IllegalStateException(e); }
    }
    public static Path configPath() { return Paths.get(System.getProperty("user.home"),"Bookmap","OFI-Pressure","config.properties"); }
    /** L1 mass of the available prefix. Renormalize per EVENT, not at candle close. */
    public double activeWeightMass(int count) {
        if(count < minLevels || count > levels) throw new IllegalArgumentException("Invalid active rank count");
        double mass=0;
        for(int i=0;i<count;i++) mass+=Math.abs(weights[i]);
        return mass;
    }

    /** One-time, backed-up migration makes persisted v1 60/240 settings take the requested defaults. */
    public static synchronized EngineConfig loadOrCreate(Path file) throws IOException {
        Path absolute=file.toAbsolutePath();
        Files.createDirectories(absolute.getParent());
        if(!Files.exists(absolute)) {
            EngineConfig defaults=new EngineConfig(new Properties());
            storeAtomically(absolute, defaults.asProperties(), "OFI Pressure v1.1.0: 15 valid-minute start; rolling 60-valid-minute benchmark; 3-10 levels.");
            return defaults;
        }
        Properties p=new Properties();
        try(InputStream in=Files.newInputStream(absolute)){p.load(in);}
        int version=Integer.parseInt(p.getProperty("config.schema.version", "1").trim());
        if(version>CONFIG_SCHEMA_VERSION || version<1)
            throw new IOException("Unsupported config.schema.version: "+version);
        if(version==1) {
            p.setProperty("config.schema.version", ""+CONFIG_SCHEMA_VERSION);
            p.setProperty("rolling.minimum.minutes", "15");
            p.setProperty("rolling.window.minutes", "60");
            p.setProperty("rolling.benchmark.minutes", "60");
            int target=Integer.parseInt(p.getProperty("levels", "10").trim());
            p.setProperty("levels.minimum", ""+Math.min(3,target));
            EngineConfig migrated=new EngineConfig(p); // Validate before touching the old file.
            Path backup=absolute.resolveSibling(absolute.getFileName()+".pre-v1.1.0-"+UUID.randomUUID().toString().substring(0,8)+".bak");
            Files.copy(absolute, backup);
            storeAtomically(absolute, p, "Migrated to OFI Pressure v1.1.0. Previous config backed up at "+backup.getFileName());
            System.out.println("OFI config migrated: 15-min warmup / 60-valid-minute benchmark / min "+migrated.minLevels+" levels. Backup: "+backup);
            return migrated;
        }
        return new EngineConfig(p);
    }
    private static void storeAtomically(Path file, Properties p, String comment) throws IOException {
        Path temp=Files.createTempFile(file.getParent(), ".ofi-config-", ".tmp");
        try {
            try(OutputStream out=Files.newOutputStream(temp)){p.store(out,comment);}
            try {Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException e){Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING);}
        } finally {Files.deleteIfExists(temp);}
    }
}
