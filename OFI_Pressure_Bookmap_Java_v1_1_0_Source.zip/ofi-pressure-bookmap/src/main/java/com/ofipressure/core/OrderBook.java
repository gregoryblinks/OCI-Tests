package com.ofipressure.core;

import java.util.*;

/** MBO reconstruction: replace size is the NEW total, not a delta. */
public final class OrderBook {
    private static final class Order { final boolean bid; int price; long size; Order(boolean b,int p,long s){bid=b;price=p;size=s;} }
    private final Map<String,Order> orders=new HashMap<>();
    private final NavigableMap<Integer,Long> bids=new TreeMap<>(Comparator.reverseOrder());
    private final NavigableMap<Integer,Long> asks=new TreeMap<>();
    private final int maxOrders;
    public OrderBook(int maxOrders){this.maxOrders=maxOrders;}
    public static final class BookFault extends RuntimeException { public BookFault(String s){super(s);} }
    public void send(String id,boolean bid,int price,int size) {
        if(id==null || id.isEmpty() || size<=0) throw new BookFault("INVALID_SEND");
        if(orders.containsKey(id)) throw new BookFault("DUPLICATE_ORDER_ID");
        if(orders.size()>=maxOrders) throw new BookFault("ORDER_LIMIT");
        orders.put(id,new Order(bid,price,size)); add(bid,price,size);
    }
    public void replace(String id,int price,int size) {
        Order o=orders.get(id); if(o==null)throw new BookFault("UNKNOWN_REPLACE");
        if(size<0)throw new BookFault("NEGATIVE_REPLACE_SIZE");
        add(o.bid,o.price,-o.size);
        if(size==0){orders.remove(id);return;}
        add(o.bid,price,size); o.price=price; o.size=size;
    }
    public void cancel(String id) {
        Order o=orders.remove(id); if(o==null)throw new BookFault("UNKNOWN_CANCEL"); add(o.bid,o.price,-o.size);
    }
    private void add(boolean bid,int price,long delta) {
        NavigableMap<Integer,Long> side=bid?bids:asks;
        long n=Math.addExact(side.getOrDefault(price,0L),delta);
        if(n<0)throw new BookFault("NEGATIVE_AGGREGATE_DEPTH");
        if(n==0)side.remove(price);else side.put(price,n);
    }
    public int orderCount(){return orders.size();}
    public static final class Top {
        public final int[] bidPrice,askPrice;
        public final long[] bidSize,askSize;
        public boolean full,uncrossed;
        public int bidLevels,askLevels;
        public double midpoint=Double.NaN;
        public Top(int levels){bidPrice=new int[levels];askPrice=new int[levels];bidSize=new long[levels];askSize=new long[levels];}
        public int availableLevels(){return Math.min(bidLevels,askLevels);}
        public boolean valid(){return full&&uncrossed;}
        public boolean valid(int minimum){return availableLevels()>=minimum&&uncrossed;}
        public double averageDepth(){double v=0; for(int i=0;i<bidSize.length;i++)v+=(double)bidSize[i]+askSize[i]; return v/(2*bidSize.length);}
    }
    public void top(Top target) {
        Arrays.fill(target.bidSize,0);Arrays.fill(target.askSize,0);
        Arrays.fill(target.bidPrice,0);Arrays.fill(target.askPrice,0);
        int b=0,a=0;
        for(Map.Entry<Integer,Long> e:bids.entrySet()) {if(b==target.bidSize.length)break;target.bidPrice[b]=e.getKey();target.bidSize[b++]=e.getValue();}
        for(Map.Entry<Integer,Long> e:asks.entrySet()) {if(a==target.askSize.length)break;target.askPrice[a]=e.getKey();target.askSize[a++]=e.getValue();}
        target.bidLevels=b;target.askLevels=a;
        target.full=b==target.bidSize.length&&a==target.askSize.length;
        target.uncrossed=b>0&&a>0&&target.bidPrice[0]<target.askPrice[0];
        target.midpoint=target.uncrossed?0.5*((double)target.bidPrice[0]+target.askPrice[0]):Double.NaN;
    }
    /** Standard Cont before/after indicator formula, extended to each CURRENT rank. */
    public static double eventOfi(int bp0,long bq0,int ap0,long aq0,int bp1,long bq1,int ap1,long aq1) {
        double bid=(bp1>=bp0?(double)bq1:0)-(bp1<=bp0?(double)bq0:0);
        double ask=-(ap1<=ap0?(double)aq1:0)+(ap1>=ap0?(double)aq0:0);
        return bid+ask;
    }
}
