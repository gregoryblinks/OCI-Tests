package com.ofipressure.core;

import java.util.*;
import java.util.function.Consumer;

/** Single-threaded market-clock engine. No trading calls, wall-clock timers or file I/O. */
public final class PressureEngine {
    public static final long SECOND=1000000000L, MINUTE=60*SECOND;
    private final EngineConfig c;
    private final String alias,runId,configHash;
    private final double tickSize;
    private final Consumer<BarRecord> sink;
    private final OrderBook book;
    private OrderBook.Top before,after;
    private final RollingCalibration calibration;
    private final ArrayDeque<Long> sampleEnds=new ArrayDeque<>();
    private long now=Long.MIN_VALUE,lastMbo=Long.MIN_VALUE;
    private boolean armed=false,failed=false;
    private String failure="",status="WAITING_FOR_SNAPSHOT";
    private Minute m;

    private static final class Minute {
        final long start,end;
        final double[] ofi,weightedOfi,depthTime,depthEvent,effectiveWeightSum,seconds=new double[60];
        final long[] levelEvents,levelNanos;
        final Set<String> flags=new LinkedHashSet<>(), warnings=new LinkedHashSet<>();
        long observedFrom,cursor,coverage,events,validEvents,trades,buySize,sellSize,unknownSize,otcTrades,badTrades;
        long levelsUsedSum;
        int levelsUsedMin=Integer.MAX_VALUE,levelsUsedMax=0;
        double sharedDepthEventSum,sharedDepthTimeSum;
        double tradeOpen=Double.NaN,tradeHigh=Double.NaN,tradeLow=Double.NaN,tradeClose=Double.NaN;
        double midOpen=Double.NaN,midHigh=Double.NaN,midLow=Double.NaN,midClose=Double.NaN;
        Minute(long start,long from,int levels) {
            this.start=start;end=start+MINUTE;observedFrom=from;cursor=from;
            ofi=new double[levels];weightedOfi=new double[levels];depthTime=new double[levels];depthEvent=new double[levels];
            effectiveWeightSum=new double[levels];levelEvents=new long[levels];levelNanos=new long[levels];
            if(from>start)flags.add("PARTIAL_START");
        }
        void mid(double x) {
            if(!Double.isFinite(x))return;
            if(!Double.isFinite(midOpen)){midOpen=midHigh=midLow=x;}
            midHigh=Math.max(midHigh,x);midLow=Math.min(midLow,x);midClose=x;
        }
        void trade(double p,long q,int side) {
            if(!Double.isFinite(tradeOpen)){tradeOpen=tradeHigh=tradeLow=p;}
            tradeHigh=Math.max(tradeHigh,p);tradeLow=Math.min(tradeLow,p);tradeClose=p;trades++;
            if(side>0)buySize+=q;else if(side<0)sellSize+=q;else unknownSize+=q;
        }
    }
    public PressureEngine(EngineConfig c,String alias,String runId,double tickSize,Consumer<BarRecord> sink) {
        if(!(tickSize>0)||!Double.isFinite(tickSize))throw new IllegalArgumentException("Invalid instrument tick size");
        this.c=c;this.alias=alias;this.runId=runId;this.tickSize=tickSize;this.sink=sink;configHash=c.fingerprint();
        book=new OrderBook(c.maxOrders);before=new OrderBook.Top(c.levels);after=new OrderBook.Top(c.levels);
        calibration=new RollingCalibration(c.window,c.warmup,c.varianceFloor);
    }
    public String status(){return failed?"RELOAD_REQUIRED: "+failure:status;}
    public boolean failed(){return failed;}
    public int orderCount(){return book.orderCount();}
    public long currentTime(){return now;}
    private void clearCalibration(){calibration.clear();sampleEnds.clear();}
    public void fail(String reason){failed=true;failure=reason;clearCalibration();if(m!=null)m.flags.add(reason);}

    public void onTime(long timestamp) {
        if(timestamp<=0)return;
        if(now!=Long.MIN_VALUE&&timestamp<now){fail("TIME_REWIND");return;}
        if(failed)return;
        if(now==Long.MIN_VALUE){now=timestamp;return;}
        boolean gap=timestamp-now>c.gapResetNanos;
        now=timestamp;
        if(!armed)return;
        if(m==null){startMinute(now);return;}
        if(gap) {
            m.flags.add("CLOCK_GAP");accrue(Math.min(now,m.end));
            if(now>=m.end)finish(now);
            clearCalibration();m=null;startMinute(now);m.flags.add("CLOCK_GAP");status="CLOCK_GAP: REWARMING";return;
        }
        while(now>=m.end){long boundary=m.end;accrue(boundary);finish(now);startMinute(boundary);}
        accrue(now);
    }
    public void snapshotEnd() {
        if(failed)return;
        if(now==Long.MIN_VALUE){status="WAITING_FOR_MARKET_TIME";return;}
        if(armed){fail("UNEXPECTED_SNAPSHOT_END");return;}
        book.top(before);armed=true;clearCalibration();lastMbo=now;startMinute(now);status="WARMUP";
    }
    private boolean usable(OrderBook.Top t){return t.valid(c.minLevels);}
    private void checkBook(OrderBook.Top t) {
        if(t.availableLevels()<c.minLevels)m.flags.add("INCOMPLETE_BOOK");
        if(t.bidLevels>0&&t.askLevels>0&&!t.uncrossed)m.flags.add("CROSSED_BOOK");
        if(t.availableLevels()>=c.minLevels&&t.availableLevels()<c.levels)m.warnings.add("REDUCED_DEPTH");
    }
    private void startMinute(long at) {
        m=new Minute(Math.floorDiv(at,MINUTE)*MINUTE,at,c.levels);
        m.mid(before.midpoint);checkBook(before);
    }
    private void accrue(long to) {
        if(m==null||to<=m.cursor)return;
        long end=Math.min(to,m.end);
        long freshEnd=lastMbo==Long.MIN_VALUE?m.cursor:Math.min(end,lastMbo+c.staleNanos);
        long dt=Math.max(0,freshEnd-m.cursor);
        if(usable(before)&&dt>0) {
            m.coverage+=dt;
            int k=before.availableLevels();double depth=0;
            for(int i=0;i<k;i++) {
                double d=0.5*((double)before.bidSize[i]+before.askSize[i]);
                m.depthTime[i]+=d*dt;m.levelNanos[i]+=dt;depth+=d;
            }
            m.sharedDepthTimeSum+=(depth/k)*dt;
        }
        if(freshEnd<end)m.flags.add("STALE_BOOK");
        checkBook(before);m.cursor=end;
    }
    public void send(String id,boolean bid,int price,int size){mutate(()->book.send(id,bid,price,size));}
    public void replace(String id,int price,int size){mutate(()->book.replace(id,price,size));}
    public void cancel(String id){mutate(()->book.cancel(id));}
    private void mutate(Runnable action) {
        if(failed)return;
        try{action.run();}catch(RuntimeException ex){fail(ex.getMessage()==null?"BOOK_ERROR":ex.getMessage());return;}
        if(now!=Long.MIN_VALUE)lastMbo=now;
        book.top(after);
        if(armed&&m!=null) {
            m.events++;checkBook(before);checkBook(after);
            // Use ranks actually present on BOTH sides BEFORE and AFTER the event.
            // Missing ranks are not zero-sized queues and must not generate fictitious flow.
            int k=Math.min(before.availableLevels(),after.availableLevels());
            if(usable(before)&&usable(after)&&k>=c.minLevels) {
                m.validEvents++;m.levelsUsedSum+=k;
                m.levelsUsedMin=Math.min(m.levelsUsedMin,k);m.levelsUsedMax=Math.max(m.levelsUsedMax,k);
                if(k<c.levels)m.warnings.add("REDUCED_DEPTH");
                double mass=c.activeWeightMass(k),weighted=0,depth=0;
                for(int i=0;i<k;i++) {
                    double e=OrderBook.eventOfi(before.bidPrice[i],before.bidSize[i],before.askPrice[i],before.askSize[i],
                            after.bidPrice[i],after.bidSize[i],after.askPrice[i],after.askSize[i]);
                    double w=c.weights[i]/mass;
                    m.ofi[i]+=e;m.weightedOfi[i]+=w*e;weighted+=w*e;
                    double d=0.5*((double)after.bidSize[i]+after.askSize[i]);
                    m.depthEvent[i]+=d;m.levelEvents[i]++;m.effectiveWeightSum[i]+=w;depth+=d;
                }
                m.sharedDepthEventSum+=depth/k;
                int second=(int)Math.min(59,Math.max(0,(now-m.start)/SECOND));m.seconds[second]+=weighted;
            }
            m.mid(after.midpoint);
        }
        OrderBook.Top tmp=before;before=after;after=tmp;
    }
    /** Diagnostic only: never remove liquidity here or invalidate OFI for a bad trade. */
    public void trade(double priceTicks,int size,int aggressorSide,boolean isOtc) {
        if(!armed||failed||m==null)return;
        if(isOtc){m.otcTrades++;return;}
        if(!Double.isFinite(priceTicks)||size<=0) {
            m.badTrades++;m.warnings.add("BAD_TRADE_IGNORED");return;
        }
        m.trade(priceTicks,size,aggressorSide);
    }
    private static String sign(double x){return !Double.isFinite(x)?"NA":x>0?"POSITIVE":x<0?"NEGATIVE":"ZERO";}
    private static String strength(double z) {
        if(!Double.isFinite(z))return "UNSCORED";
        double x=Math.abs(z);return x<0.5?"NEUTRAL":x<1?"MILD":x<2?"ELEVATED":x<3?"STRONG":"EXTREME";
    }
    private void finish(long available) {
        double cov=(double)m.coverage/MINUTE;
        double eventDepth=m.validEvents>0?m.sharedDepthEventSum/m.validEvents:Double.NaN;
        double timeDepth=m.coverage>0?m.sharedDepthTimeSum/m.coverage:Double.NaN;
        double raw=0;for(double value:m.weightedOfi)raw+=value;
        if(m.events==0)m.flags.add("NO_MBO_EVENTS");
        if(m.validEvents==0)m.flags.add("NO_VALID_MBO_EVENTS");
        if(cov<c.minCoverage)m.flags.add("LOW_COVERAGE");
        if(m.levelsUsedMin!=Integer.MAX_VALUE&&m.levelsUsedMin!=m.levelsUsedMax)m.warnings.add("VARIABLE_DEPTH");
        double depth=c.depthMode.equals("EVENT")?eventDepth:timeDepth;
        if(!(depth>0))m.flags.add("ZERO_DEPTH");
        double normalized=depth>0?raw/depth:Double.NaN;
        if(!Double.isFinite(normalized))m.flags.add("NONFINITE_OFI");
        boolean valid=m.flags.isEmpty()&&m.observedFrom==m.start&&m.validEvents>0;
        RollingCalibration.Score s=calibration.score(normalized);
        String scoreStatus=valid?s.status:"INVALID";
        String stage=s.count<c.warmup?"WARMUP":s.count<c.benchmark?"PROVISIONAL":"MATURE";
        double z=valid?s.z:Double.NaN;
        double weightedSeconds=0;for(double v:m.seconds)weightedSeconds+=v;
        int active=0,agree=0;
        for(double v:m.seconds)if(Math.abs(v)>1e-12){active++;if(Math.signum(v)==Math.signum(weightedSeconds))agree++;}
        double persistence=active>0&&Math.abs(weightedSeconds)>1e-12?(double)agree/active:Double.NaN;
        LinkedHashMap<String,Object> f=new LinkedHashMap<>();
        f.put("start_utc",BarRecord.iso(m.start));f.put("end_utc",BarRecord.iso(m.end));f.put("alias",alias);
        f.put("pressure_z",z);f.put("normalized_ofi",normalized);f.put("score_status",scoreStatus);
        f.put("calibration_stage",stage);f.put("benchmark_reached",s.count>=c.benchmark);
        f.put("flow_direction",sign(normalized));f.put("deviation_direction",sign(z));f.put("pressure_strength",strength(z));
        f.put("prior_empirical_percentile",valid?s.percentile:Double.NaN);f.put("data_valid",valid);
        f.put("quality_flags",String.join("|",m.flags));f.put("quality_warnings",String.join("|",m.warnings));
        f.put("bar_complete",m.observedFrom==m.start);f.put("valid_book_coverage",cov);f.put("book_valid_pct",100*cov);
        f.put("levels_used_avg",m.validEvents>0?(double)m.levelsUsedSum/m.validEvents:Double.NaN);
        f.put("levels_used_min",m.validEvents>0?(double)m.levelsUsedMin:Double.NaN);
        f.put("levels_used_max",m.validEvents>0?(double)m.levelsUsedMax:Double.NaN);
        f.put("bid_levels_end",before.bidLevels);f.put("ask_levels_end",before.askLevels);
        f.put("start_ns",Long.toString(m.start));f.put("end_ns",Long.toString(m.end));
        f.put("available_ns",Long.toString(available));f.put("available_utc",BarRecord.iso(available));
        f.put("close_latency_ms",(available-m.end)/1e6);
        f.put("last_mbo_age_ms",lastMbo==Long.MIN_VALUE?Double.NaN:Math.max(0,m.end-lastMbo)/1e6);
        f.put("trade_open",m.tradeOpen*tickSize);f.put("trade_high",m.tradeHigh*tickSize);f.put("trade_low",m.tradeLow*tickSize);f.put("trade_close",m.tradeClose*tickSize);
        f.put("mid_open",m.midOpen*tickSize);f.put("mid_high",m.midHigh*tickSize);f.put("mid_low",m.midLow*tickSize);f.put("mid_close",m.midClose*tickSize);
        double anchor=Double.isFinite(m.tradeClose)?m.tradeClose:m.midClose;
        f.put("bubble_price",anchor*tickSize);f.put("bubble_price_source",Double.isFinite(m.tradeClose)?"LAST_TRADE":"MIDPOINT");
        f.put("mbo_events",m.events);f.put("valid_mbo_events",m.validEvents);f.put("trade_count",m.trades);
        f.put("bad_trade_count",m.badTrades);f.put("trade_diagnostics_complete",m.badTrades==0);
        f.put("aggressive_buy_size",m.buySize);f.put("aggressive_sell_size",m.sellSize);f.put("unknown_aggressor_size",m.unknownSize);
        f.put("trade_delta",m.buySize-m.sellSize);f.put("otc_trades_excluded",m.otcTrades);
        f.put("shared_depth_event",eventDepth);f.put("shared_depth_time",timeDepth);
        f.put("integrated_raw_ofi",raw);f.put("normalization_depth",depth);f.put("prior_sample_count",s.count);
        f.put("prior_mean",s.mean);f.put("prior_sample_sd",s.sd);
        f.put("minimum_prior_samples",c.warmup);f.put("benchmark_samples",c.benchmark);f.put("rolling_capacity",c.window);
        f.put("baseline_span_minutes",sampleEnds.isEmpty()?Double.NaN:(m.start-(sampleEnds.peekFirst()-MINUTE))/(double)MINUTE);
        f.put("active_seconds",active);f.put("direction_persistence",persistence);
        f.put("levels",c.levels);f.put("minimum_levels",c.minLevels);f.put("tick_size",tickSize);
        f.put("size_unit","BOOKMAP_RAW_SIZE");f.put("depth_mode",c.depthMode);f.put("weight_mode",c.weightMode);
        f.put("model_version",EngineConfig.MODEL_VERSION);f.put("schema_version",2);f.put("run_id",runId);f.put("run_label",c.runLabel);f.put("config_sha256",configHash);
        for(int i=0;i<c.levels;i++) {
            String l="L"+(i+1);boolean seen=m.levelEvents[i]>0;
            f.put(l+"_ofi",seen?m.ofi[i]:Double.NaN);
            f.put(l+"_normalized_ofi",seen&&depth>0?m.ofi[i]/depth:Double.NaN);
            f.put(l+"_depth_event",seen?m.depthEvent[i]/m.levelEvents[i]:Double.NaN);
            f.put(l+"_weight",c.weights[i]); // Configured 10-level weight, NOT the event-normalized weight.
            f.put(l+"_weighted_ofi",seen?m.weightedOfi[i]:Double.NaN);
            f.put(l+"_effective_weight_event",m.validEvents>0?m.effectiveWeightSum[i]/m.validEvents:Double.NaN);
            f.put(l+"_event_count",m.levelEvents[i]);
            f.put(l+"_time_coverage",m.coverage>0?(double)m.levelNanos[i]/m.coverage:Double.NaN);
        }
        BarRecord record=new BarRecord(f,m.start,m.end,available,anchor,z,scoreStatus,valid);
        sink.accept(record);
        // Score is frozen BEFORE observing this minute. Ordinary invalid minutes are skipped.
        // Fatal reconstruction faults, rewind, fresh initialization and long clock gaps still reset.
        if(valid) {
            calibration.observe(normalized);sampleEnds.addLast(m.end);
            if(sampleEnds.size()>c.window)sampleEnds.removeFirst();
        }
        status=scoreStatus+" / "+stage+"; prior="+s.count+"/"+c.benchmark+"; levels="+
                (m.validEvents>0?m.levelsUsedMin+"-"+m.levelsUsedMax:"none")+"; badTrades="+m.badTrades+
                (m.flags.isEmpty()?"":"; "+String.join("|",m.flags))+"; orders="+book.orderCount();
    }
}
