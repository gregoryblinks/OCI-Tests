package com.ofipressure;

import com.ofipressure.core.*;
import com.ofipressure.io.*;
import com.ofipressure.bookmap.BubbleImage;
import java.nio.file.*;
import java.io.*;
import java.time.Instant;
import java.util.*;
import javax.imageio.ImageIO;

/** v1.1 regressions for reported BAD_TRADE / INCOMPLETE_BOOK failure and calibration. */
public final class AdaptiveEngineTests {
    private static int passed=0;
    private static final long T=Instant.parse("2026-01-05T09:00:00Z").getEpochSecond()*PressureEngine.SECOND;
    private static final long S=PressureEngine.SECOND,M=PressureEngine.MINUTE;
    private static void eq(double a,double b){if(!(Math.abs(a-b)<1e-9*Math.max(1,Math.abs(a))))throw new AssertionError("expected "+a+", got "+b);}
    private static void yes(boolean b,String message){if(!b)throw new AssertionError(message);}
    private interface Action{void run()throws Exception;}
    private static void test(String name,Action a)throws Exception{a.run();passed++;System.out.println("PASS "+name);}
    private static double n(BarRecord r,String key){return ((Number)r.get(key)).doubleValue();}
    private static String text(BarRecord r,String key){return r.get(key).toString();}
    private static EngineConfig cfg(String... pairs){Properties p=new Properties();for(int i=0;i<pairs.length;i+=2)p.setProperty(pairs[i],pairs[i+1]);return new EngineConfig(p);}
    private static PressureEngine engine(EngineConfig c,List<BarRecord> out,int bids,int asks) {
        PressureEngine e=new PressureEngine(c,"TEST-ADAPTIVE","regression",.25,out::add);e.onTime(T);
        for(int i=0;i<bids;i++)e.send("B"+i,true,100-i,10);
        for(int i=0;i<asks;i++)e.send("A"+i,false,102+i,10);
        e.snapshotEnd();return e;
    }
    private static void minute(PressureEngine e,int index,int size) {
        for(int second:new int[]{10,25,40,55}){e.onTime(T+index*M+second*S);e.replace("B0",100,size);}
        e.onTime(T+(index+1)*M);
    }
    private static int size(int index){return 10+(index*7)%31;}
    public static void main(String[] args)throws Exception {
        test("defaults are target 10 / minimum 3 / startup 15 / window and benchmark 60",()->{
            EngineConfig c=cfg();eq(10,c.levels);eq(3,c.minLevels);eq(15,c.warmup);eq(60,c.window);eq(60,c.benchmark);
        });
        test("3-level book is valid and never pads levels 4-10 with zeros",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,3,3);minute(e,0,19);
            BarRecord b=r.get(0);yes(b.valid,text(b,"quality_flags"));eq(3,n(b,"levels_used_min"));eq(3,n(b,"levels_used_max"));
            eq(0,n(b,"L4_event_count"));yes(Double.isNaN(n(b,"L4_ofi")),"unobserved flow blank");yes(Double.isNaN(n(b,"L4_depth_event")),"unobserved depth blank");
            yes(text(b,"quality_warnings").contains("REDUCED_DEPTH"),"depth warning");yes(text(b,"quality_flags").isEmpty(),"no fatal flag");
        });
        test("uniform adaptive weights are one third on a three-level book",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg("weights.mode","UNIFORM"),r,3,3);minute(e,0,19);
            eq(3,n(r.get(0),"integrated_raw_ofi"));eq(11.5,n(r.get(0),"normalization_depth"));eq(3/11.5,n(r.get(0),"normalized_ofi"));
            eq(1.0/3,n(r.get(0),"L1_effective_weight_event"));
        });
        test("asymmetric 8-bid / 5-ask book uses five paired ranks",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,8,5);minute(e,0,18);yes(r.get(0).valid,"valid asymmetric");eq(5,n(r.get(0),"levels_used_avg"));eq(8,n(r.get(0),"bid_levels_end"));eq(5,n(r.get(0),"ask_levels_end"));
        });
        test("2-level book remains invalid with no fabricated score",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,2,10);minute(e,0,18);yes(!r.get(0).valid,"2 levels invalid");yes(text(r.get(0),"quality_flags").contains("INCOMPLETE_BOOK"),"depth flag");yes(Double.isNaN(r.get(0).z),"no score");
        });
        test("full 10-level book keeps original fixed-weight result",()->{
            EngineConfig c=cfg();List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(c,r,10,10);minute(e,0,19);
            yes(r.get(0).valid,"10 levels valid");eq(9*c.weights[0],n(r.get(0),"integrated_raw_ofi"));eq(10.45,n(r.get(0),"normalization_depth"));
        });
        test("adaptive 3-to-4-to-3 transitions normalize each event, not minute end",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg("weights.mode","UNIFORM"),r,3,3);
            e.onTime(T+5*S);e.replace("B0",100,20); // 10 / 3
            e.onTime(T+10*S);e.send("B3",true,97,10);e.send("A3",false,105,10); // Newly visible rank ignored.
            e.onTime(T+20*S);e.replace("B0",100,28); // 8 / 4
            e.onTime(T+30*S);e.cancel("B3");e.cancel("A3"); // Vanishing rank is not fake signed flow.
            e.onTime(T+45*S);e.replace("B0",100,28);e.onTime(T+55*S);e.replace("B0",100,28);e.onTime(T+M);
            BarRecord b=r.get(0);yes(b.valid,text(b,"quality_flags"));eq(10.0/3+2,n(b,"integrated_raw_ofi"));
            eq(18,n(b,"L1_ofi"));eq(3,n(b,"levels_used_min"));eq(4,n(b,"levels_used_max"));eq(1,n(b,"L4_event_count"));
            yes(text(b,"quality_warnings").contains("VARIABLE_DEPTH"),"varying-depth warning");
        });
        test("sum of actual weighted per-level contributions equals integrated OFI",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,7,9);minute(e,0,21);
            double sum=0;for(int i=1;i<=10;i++){double v=n(r.get(0),"L"+i+"_weighted_ofi");if(Double.isFinite(v))sum+=v;}
            eq(sum,n(r.get(0),"integrated_raw_ofi"));
        });
        test("time-normalized three-level depth uses observed ranks, not target ten",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg("depth.mode","TIME","weights.mode","UNIFORM"),r,3,3);
            e.onTime(T+20*S);e.replace("B0",100,16);e.onTime(T+40*S);e.replace("B0",100,16);e.onTime(T+M);
            eq(32.0/3,n(r.get(0),"shared_depth_time"));eq(2,n(r.get(0),"integrated_raw_ofi"));eq(2/(32.0/3),n(r.get(0),"normalized_ofi"));
        });
        test("zero-size, negative-size and nonfinite diagnostic trades never invalidate OFI",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,3,3);
            e.trade(102,0,1,false);e.trade(102,-1,1,false);e.trade(Double.NaN,5,1,false);e.trade(Double.POSITIVE_INFINITY,5,1,false);
            minute(e,0,18);BarRecord b=r.get(0);yes(b.valid,text(b,"quality_flags"));eq(4,n(b,"bad_trade_count"));
            eq(0,n(b,"trade_count"));yes(!text(b,"quality_flags").contains("BAD_TRADE"),"not fatal");
            yes(text(b,"quality_warnings").contains("BAD_TRADE_IGNORED"),"diagnostic warning");yes(Boolean.FALSE.equals(b.get("trade_diagnostics_complete")),"incomplete trade diagnostics");
        });
        test("bad trade does not corrupt close or volume; valid trade still populates diagnostics",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,3,3);
            e.trade(103,7,1,false);e.trade(1000,0,1,false);minute(e,0,18);eq(25.75,n(r.get(0),"trade_close"));eq(7,n(r.get(0),"aggressive_buy_size"));eq(1,n(r.get(0),"trade_count"));
        });
        test("only bad trades gives midpoint bubble anchor and blank trade close",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,3,3);e.trade(104,0,1,false);minute(e,0,18);
            yes(text(r.get(0),"bubble_price_source").equals("MIDPOINT"),"fallback source");yes(Double.isNaN(n(r.get(0),"trade_close")),"blank close");eq(25.25,n(r.get(0),"bubble_price"));
        });
        test("first 15 minutes warm up; 16th is provisional; 61st uses mature 60-sample benchmark",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,3,3);
            for(int i=0;i<65;i++){e.trade(100,0,1,false);minute(e,i,size(i));}
            for(int i=0;i<15;i++){yes(r.get(i).valid,"warmup is valid data");yes(r.get(i).scoreStatus.equals("WARMUP"),"prior<15");yes(Double.isNaN(r.get(i).z),"warmup blank");}
            eq(15,n(r.get(15),"prior_sample_count"));yes(Double.isFinite(r.get(15).z),"16th scored");yes(text(r.get(15),"calibration_stage").equals("PROVISIONAL"),"early stage");
            eq(59,n(r.get(59),"prior_sample_count"));yes(text(r.get(59),"calibration_stage").equals("PROVISIONAL"),"60th has only 59 prior");
            eq(60,n(r.get(60),"prior_sample_count"));yes(text(r.get(60),"calibration_stage").equals("MATURE"),"61st full baseline");yes(Boolean.TRUE.equals(r.get(60).get("benchmark_reached")),"benchmark");
        });
        test("rolling benchmark uses exactly latest 60 PRIOR values and no current-minute leakage",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,10,10);for(int i=0;i<80;i++)minute(e,i,size(i));
            BarRecord b=r.get(79);double mean=0;for(int i=19;i<79;i++)mean+=n(r.get(i),"normalized_ofi")/60;
            double sum=0;for(int i=19;i<79;i++)sum+=Math.pow(n(r.get(i),"normalized_ofi")-mean,2);double sd=Math.sqrt(sum/59);
            eq(60,n(b,"prior_sample_count"));eq(mean,n(b,"prior_mean"));eq(sd,n(b,"prior_sample_sd"));eq((n(b,"normalized_ofi")-mean)/sd,b.z);
        });
        test("flat prior baseline still returns FLAT, never divide-by-zero pressure",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,3,3);for(int i=0;i<16;i++)minute(e,i,10);
            yes(r.get(15).scoreStatus.equals("FLAT_BASELINE"),"flat");yes(Double.isNaN(r.get(15).z),"blank flat");
        });
        test("ordinary invalid depth minute is skipped without resetting valid history",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,3,3);for(int i=0;i<16;i++)minute(e,i,size(i));
            e.onTime(T+16*M+10*S);e.cancel("A2");e.onTime(T+16*M+25*S);e.replace("B0",100,20);
            e.onTime(T+16*M+30*S);e.send("A2",false,104,10);e.onTime(T+16*M+45*S);e.replace("B0",100,20);e.onTime(T+17*M);
            yes(!r.get(16).valid,"bad bar invalid");eq(16,n(r.get(16),"prior_sample_count"));minute(e,17,22);
            yes(r.get(17).valid,text(r.get(17),"quality_flags"));eq(16,n(r.get(17),"prior_sample_count"));yes(Double.isFinite(r.get(17).z),"resumes without 15 more minutes");eq(17,n(r.get(17),"baseline_span_minutes"));
        });
        test("stale minute is skipped without clearing existing history",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,3,3);for(int i=0;i<16;i++)minute(e,i,size(i));
            e.onTime(T+16*M+59*S);e.replace("B0",100,20);e.onTime(T+17*M);yes(!r.get(16).valid,"stale invalid");
            minute(e,17,25);eq(16,n(r.get(17),"prior_sample_count"));yes(r.get(17).valid,"next valid");
        });
        test("large market-clock gap still resets rather than trusting an old baseline",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,3,3);for(int i=0;i<16;i++)minute(e,i,size(i));
            e.onTime(T+21*M);minute(e,21,17);BarRecord last=r.get(r.size()-1);eq(0,n(last,"prior_sample_count"));yes(!last.valid,"gap minute invalid");
            minute(e,22,25);last=r.get(r.size()-1);eq(0,n(last,"prior_sample_count"));yes(last.valid,"fresh bar");yes(last.scoreStatus.equals("WARMUP"),"rewarms after real gap");
        });
        test("crossed book remains invalid despite having three levels",()->{
            List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(cfg(),r,3,3);e.onTime(T+5*S);e.send("cross",true,103,1);e.onTime(T+10*S);e.cancel("cross");minute(e,0,18);
            yes(!r.get(0).valid,"crossed invalid");yes(text(r.get(0),"quality_flags").contains("CROSSED_BOOK"),"crossed reason");
        });
        test("newly missing ranks cannot retain stale array prices or quantities",()->{
            OrderBook b=new OrderBook(1000);for(int i=0;i<4;i++){b.send("B"+i,true,100-i,10);b.send("A"+i,false,102+i,10);}
            OrderBook.Top t=new OrderBook.Top(10);b.top(t);eq(4,t.availableLevels());b.cancel("B3");b.top(t);eq(3,t.availableLevels());eq(0,t.bidSize[3]);eq(0,t.bidPrice[3]);yes(t.valid(3),"adaptive valid");
        });
        test("manual weights cannot have zero active-prefix mass",()->{
            try{cfg("weights.mode","MANUAL","weights.manual","0,0,0,1,1,1,1,1,1,1");throw new AssertionError("zero prefix accepted");}catch(IllegalArgumentException good){}
        });
        test("legacy config is backed up and migrated to 15 / 60 / minimum 3",()->{
            Path dir=Files.createTempDirectory("ofi-config-migration-");Path file=dir.resolve("config.properties");
            String old="levels=10\nrolling.minimum.minutes=60\nrolling.window.minutes=240\nweights.decay=0.4\nrun.label=KEEP_ME\n";Files.writeString(file,old);
            EngineConfig c=EngineConfig.loadOrCreate(file);eq(15,c.warmup);eq(60,c.window);eq(60,c.benchmark);eq(3,c.minLevels);eq(.4,c.decay);yes(c.runLabel.equals("KEEP_ME"),"preserve unrelated setting");
            List<Path> backups;try(var stream=Files.list(dir)){backups=stream.filter(p->p.toString().endsWith(".bak")).toList();}
            eq(1,backups.size());yes(Files.readString(backups.get(0)).equals(old),"exact backup");EngineConfig.loadOrCreate(file);
            try(var stream=Files.list(dir)){eq(1,stream.filter(p->p.toString().endsWith(".bak")).count());}
        });
        test("current-schema custom settings are not overwritten on later reload",()->{
            Path file=Files.createTempDirectory("ofi-config-current-").resolve("config.properties");
            Files.writeString(file,"config.schema.version=2\nlevels=10\nlevels.minimum=4\nrolling.minimum.minutes=20\nrolling.window.minutes=90\nrolling.benchmark.minutes=60\n");
            EngineConfig c=EngineConfig.loadOrCreate(file);eq(20,c.warmup);eq(90,c.window);eq(4,c.minLevels);
        });
        test("fresh config uses new defaults and fingerprints include new controls",()->{
            Path file=Files.createTempDirectory("ofi-config-new-").resolve("config.properties");EngineConfig c=EngineConfig.loadOrCreate(file);eq(15,c.warmup);eq(60,c.window);yes(Files.readString(file).contains("levels.minimum=3"),"saved default");
            yes(!cfg().fingerprint().equals(cfg("levels.minimum","4").fingerprint()),"hash tracks min depth");
        });
        test("warmup, provisional, mature and depth labels are explicit",()->{
            yes(BubbleImage.label(Double.NaN,"WARMUP",false,"",7,15,false).equals("W7/15"),"progress");
            yes(BubbleImage.label(2.1,"READY",false,"",15,15,false).equals("Z+2.1*"),"early mark");
            yes(BubbleImage.label(2.1,"READY",false,"",60,15,true).equals("Z+2.1"),"mature");
            yes(BubbleImage.label(Double.NaN,"INVALID",false,"INCOMPLETE_BOOK",5,15,false).equals("DEPTH"),"failure reason");
            yes(BubbleImage.label(2.1,"READY",true,"",60,15,true).equals("SAVE!"),"save override");
        });
        test("updated renderer produces provisional, warmup and error PNGs",()->{
            Path out=Paths.get("build","qa");Files.createDirectories(out);
            ImageIO.write(BubbleImage.render(2.8,"READY",false,"",15,15,false),"png",out.resolve("provisional.png").toFile());
            ImageIO.write(BubbleImage.render(Double.NaN,"WARMUP",false,"",14,15,false),"png",out.resolve("warmup.png").toFile());
            ImageIO.write(BubbleImage.render(Double.NaN,"INVALID",false,"INCOMPLETE_BOOK",15,15,false),"png",out.resolve("depth.png").toFile());
            yes(Files.size(out.resolve("provisional.png"))>100,"rendered");
        });
        test("exports retain warnings, level counts and benchmark stages in CSV and XLSX",()->{
            Path dir=Paths.get("build","adaptive-export-test");Files.createDirectories(dir);
            EngineConfig c=cfg("output.directory",dir.toAbsolutePath().toString());List<BarRecord> r=new ArrayList<>();PressureEngine e=engine(c,r,3,3);
            for(int i=0;i<65;i++){e.trade(100,0,1,false);minute(e,i,size(i));}
            String run="qa-"+System.nanoTime();ResearchWriter w=new ResearchWriter(c,"TEST-ADAPTIVE",run,.25);for(BarRecord b:r)yes(w.submit(b),"queued");w.close();yes(!w.failed(),w.status());
            Path csv=w.directory().resolve("2026-01-05_pressure.csv");String content=Files.readString(csv);
            for(String field:new String[]{"calibration_stage","levels_used_min","bad_trade_count","quality_warnings","L4_event_count"})yes(content.contains(field),"export "+field);
            yes(content.contains("MATURE"),"mature export");yes(content.contains("BAD_TRADE_IGNORED"),"bad trade diagnostic export");
            yes(Files.exists(w.directory().resolve("2026-01-05_pressure.xlsx")),"genuine xlsx");
            Files.writeString(Paths.get("build","adaptive-export-path.txt"),w.directory().toString());
        });
        System.out.println("\nRESULT: "+passed+" adaptive regression tests passed.");
    }
}
