# OFI Pressure v1.1.0 - Java / Bookmap one-minute bubbles

Updated from the supplied v1 Java source to address `BAD_TRADE|INCOMPLETE_BOOK`, start scoring with 15 prior valid minutes, and use a rolling 60-valid-minute benchmark.

## Delivery status

This package contains complete updated Java source, regression tests, configuration, and build scripts. **63 Java tests pass** (36 original plus 27 new regressions). The independent engine, renderer and XLSX/CSV exporter compile with Java 17-compatible bytecode.

**No install-ready JAR is included.** Downloading Bookmap's official SDK was unavailable in this environment, so the Bookmap adapter has not been compiled against that SDK here. It has also not been tested in a running Bookmap instance or against your live MBO feed. Use your existing SDK/build environment, or the included build script, to create the updated JAR. No API stubs or fake SDK binaries are provided.

## Changes

| Area | v1.1.0 behavior |
| --- | --- |
| Warmup | 15 **prior valid completed** minute observations |
| Reference window | Grows from 15 to 60, then uses the latest 60 valid observations |
| Calibration stage | WARMUP below 15; PROVISIONAL at 15-59; MATURE at 60 |
| Depth | Target 10, minimum 3 populated price ranks **per side** |
| Adaptive weights | Renormalized per event over common pre/post ranks; missing ranks are not zeros |
| Bad diagnostic trades | Ignored and counted; warning only; do not invalidate OFI |
| Ordinary invalid minute | Exported unscored, skipped for calibration; previous valid history is retained |
| Fatal data failures | Unknown/duplicate orders or time rewind still fail closed; long clock gaps reset calibration |
| Migration | Legacy Java configuration is backed up and migrated once to 15 / 60 / min 3 |
| Bubbles | Progress while warming, asterisk while provisional, specific depth/stale/gap error labels |

The old default was a **240-observation window with a 60-observation minimum**. This update deliberately makes 60 the actual rolling reference window, rather than only a warmup threshold. It does not silently expand back to 240.

## What appears on the chart

- `W7/15`: the current minute cannot yet be scored; 7 prior valid observations are available.
- `Z+2.1*`: a numeric score using 15-59 prior observations; the baseline is provisional.
- `Z+2.1`: a numeric score using the full 60-observation benchmark with default settings.
- `DEPTH`, `CROSS`, `STALE`, `MBO!`, `GAP`, `START`: data issue or startup partial minute. Full reasons remain in the export.
- `FLAT`: previous observations have insufficient variance; no infinite/fabricated Z-score.
- `SAVE!`: export submission failed or the recording writer has failed.

The first eligible numeric score is on **minute 16**, based on completed minutes 1-15. The first default full-benchmark score is on **minute 61**, based on minutes 1-60. Only valid full minutes count. An initial partial minute does not count. The bubble describes the completed minute; it is not a forecast.

`MATURE` means the configured sample-count benchmark has been reached, not that a probability, statistical confidence level, predictive edge, or profitability has been established. Z's sign is deviation from the historical mean, not necessarily raw OFI direction.

## Build the updated JAR

Prerequisites: JDK 17+ on PATH and Python 3.10+ for the build helper. The running Java add-on needs **no Python process or Excel installation**.

Windows, inside the extracted project:

```bat
build.cmd
```

macOS/Linux:

```sh
sh build.sh
```

The helper downloads the official `api-core` and `api-simplified` version `7.6.0.20`, runs both Java test suites, compiles against the real SDK, and produces:

```text
dist/ofi-pressure-bookmap-1.1.0.jar
```

When you already have the SDK JARs from your previous build, place them in `lib/` and run:

```sh
python tools/build.py --offline
```

Expected names:

```text
lib/api-core-7.6.0.20.jar
lib/api-simplified-7.6.0.20.jar
```

Alternatively, build with your existing Gradle setup using `gradle jar`. Both test suites run before packaging. The add-on never packages Bookmap's SDK classes. Build provenance and hashes are written to `dist/build-info.json` by the Python helper.

For another compatible SDK, the build helper supports `--sdk-version VERSION`; this is not a compatibility guarantee. Resolve SDK/build errors before attempting installation.

## Upgrade in Bookmap

1. Preserve the original source/build and old research files. Disable and remove the old OFI add-on entry; do not run old and new copies together.
2. Build the new JAR, then add it through **Settings -> API plugins configuration -> Add**. Select **OFI Pressure - 1 Minute Bubbles (Research v1.1.0)**. Restart Bookmap if the previous class loader remains active.
3. On first initialization, an old Java config at `<user home>/Bookmap/OFI-Pressure/config.properties` is backed up as `config.properties.pre-v1.1.0-<id>.bak`. Its warmup/window become 15/60, with minimum 3 levels for the original 10-level target. Other settings are preserved.
4. Check the settings panel reports `3-10 levels`, `rolling 60 / start 15 / benchmark 60`. New schema-2 settings are not overridden on later reloads.
5. Allow the initial snapshot and the next complete minute. A new run starts; invalid historical rows are **not** imported as calibration data.
6. Verify the most recent exports show `data_valid=true`, no fatal `quality_flags`, `levels_used_min>=3`, and a growing `prior_sample_count`. `BAD_TRADE_IGNORED` and `REDUCED_DEPTH` in **quality_warnings** do not invalidate a row.

After editing configuration, disable/re-enable. Never change parameters midway through a recorded run without starting a new run.

## Active configuration

```properties
config.schema.version=2
levels=10
levels.minimum=3
rolling.minimum.minutes=15
rolling.window.minutes=60
rolling.benchmark.minutes=60
weights.mode=EXPONENTIAL
weights.decay=0.25
depth.mode=EVENT
```

All parameters are in `config.example.properties`. Existing stale-book (30 seconds), clock-gap (120 seconds), coverage (99%), order-ID integrity and variance checks remain. This update does **not** turn faulty/no MBO data into numeric pressure.

## Calculation

For event n, let K_n be the minimum available rank count across bid and ask both **before and after** that event, capped at the target. Both states must be uncrossed and have at least the configured minimum. The original before/after rank OFI formula is evaluated only for ranks 1..K_n.

Event-specific weights are `w_i / sum(abs(w_j), j=1..K_n)`. Integrated raw OFI is the sum of these weighted event contributions across the minute. This is deliberately **not** a reweighting of the minute total using the final book depth.

EVENT normalization averages each valid event's post-event mean depth over its common K_n paired ranks. TIME normalization uses the mean currently available rank depth, weighted by fresh valid time. Missing deep ranks never dilute depth as artificial zero queues.

The pressure score is `(current normalized OFI - prior mean) / prior sample SD`, using at most 60 prior valid observations by default. The current minute is inserted **after** its own score and record are frozen.

Adaptive depth makes the engine usable on 3-10 levels, but renormalization does not make a 3-level and a 10-level signal statistically identical. Exports retain exposures, weights and quality warnings so research can control for depth coverage. This is a configured multi-level pressure model, not fitted PCA and not a replication of Cont's return-forecasting regressions.

## Research files and safeguards

```text
<user home>/Bookmap/OFI-Pressure/data/
    <instrument>/<unique run>/
        YYYY-MM-DD_pressure.xlsx
        YYYY-MM-DD_pressure.csv
        metadata.txt
```

The live writer remains asynchronous. CSV is flushed and forced before replacing the XLSX snapshot. A workbook lock leaves CSV operational and a pending workbook; close Excel to permit subsequent replacement. This is not a raw-MBO event store or a crash-proof transactional database.

Schema 2 adds calibration stage, benchmark status, minimum depth, level usage, bad-trade count, informational warnings and actual per-level weighted contributions. Bad trade callbacks do not affect OFI, but their OHLC/volume diagnostics may be incomplete; use `trade_diagnostics_complete` when researching those fields. The chart falls back to midpoint if there is no usable trade close.

Ordinary invalid minutes are omitted from calibration without deleting earlier valid observations. Thus the latest 60 valid observations may span more than 60 elapsed minutes; `baseline_span_minutes` records that span. A long market-clock gap, rewind, fatal book fault, new snapshot/restart, or parameter reload still resets calibration.

Files use a new run and model/config fingerprint. Do not merge schema-1 and schema-2 records as though their models were identical. All observations are frozen values, not Excel formulas that recalculate history. No prior warmup minute is later backfilled with information learned in the future.

`tools/forward_labels.py` creates a separate diagnostic 1/5/15-minute outcome file and carries calibration stage and depth diagnostics. It refuses to bridge missing/invalid future minutes. Its labels are midpoint diagnostics, not executable returns after spread, latency, commissions, or slippage.

## Tests and remaining acceptance

Run independent tests without the SDK:

```sh
python tools/test_core.py
```

See `docs/VALIDATION.md`, `docs/core-test-log.txt`, and `docs/ACCEPTANCE_TESTS.md`. Complete the replay/live-feed acceptance checklist on your installed Bookmap version before relying on the indicator. This add-on never submits orders.

## Official references

- Bookmap SDK version and Java target: https://github.com/BookmapAPI/DemoStrategies/blob/master/Strategies/build.gradle
- Bookmap loading workflow: https://github.com/BookmapAPI/DemoStrategies
- MBO callbacks: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0.10/velox/api/layer1/simplified/MarketByOrderDepthDataListener.html
- Icon API: https://javadoc.bookmap.com/maven2/releases/com/bookmap/api/api-simplified/7.2.0.10/velox/api/layer1/simplified/Indicator.html
- Cont et al. event OFI background: https://arxiv.org/abs/1011.6402
- Multi-level/cross-asset research background: https://arxiv.org/abs/2112.13213
