# Validation report - OFI Pressure Java v1.1.0

## Completed

- Compiled independent Java engine, configuration, reconstruction, renderer, CSV and XLSX exporter using OpenJDK 21 with `--release 17`.
- **63 automated Java tests passed:** 36 original tests and 27 new adaptive regressions. Exact output is in `core-test-log.txt`.
- New regressions cover minimum-three validity, two-level rejection, asymmetric depth, dynamic 3-to-4-to-3 transitions, active-event weight renormalization, absence of phantom flow from missing ranks, conditional depth denominators, and equality between per-level weighted contributions and integrated OFI.
- Reproduced unusable diagnostic trades (zero/negative size, NaN and infinite price) without invalidating otherwise valid OFI. Checked warning/count, OHLC/volume exclusion and midpoint fallback.
- Verified the first numeric score uses 15 prior valid observations, the 61st valid minute has a 60-value benchmark, and subsequent reference means/SDs use exactly the latest 60 prior values. Current minute never enters its own reference distribution.
- Verified ordinary invalid depth/stale minutes do not clear prior calibration; long clock gaps do reset. Existing order-integrity/rewind tests continue to pass.
- Verified legacy configuration backup/migration and that later schema-2 customizations are not silently overwritten.
- Checked progress/provisional/mature/error label text and rendered bubble PNGs with the actual production renderer; visually inspected a provisional bubble.
- Drove a 65-minute synthetic three-level sequence with one bad diagnostic trade per minute through the production writer. All 65 observations were OFI-valid: 15 WARMUP rows, 45 PROVISIONAL scores and 5 MATURE scores.
- Opened genuine XLSX with openpyxl: 65 data rows, 153 columns, two sheets, exact string nanosecond timestamps, no formula/error cells, blank missing deep ranks and warmup scores, finite later scores, and correct warning/calibration fields.
- Recovered the CSV into a separate XLSX and verified row count. Verified 49, 45 and 35 complete 1/5/15-minute diagnostic labels among this synthetic sequence's scored observations, with calibration stage carried through.
- Rendered portions of both exported sheets and visually inspected the mature transition and metadata. Frozen signal observations remain values; no history is recomputed by workbook formulas.

The example files are synthetic regression fixtures, not exchange data or evidence of predictive performance.

## Not completed / not claimed

- Official Bookmap SDK download failed (host resolution/download unavailable). Therefore the **Bookmap adapter was not compiled against the official SDK in this environment**. No prebuilt installable JAR, fake SDK or stub-compiled adapter is supplied.
- No Bookmap process or live/replay MBO provider was available for runtime integration tests. API lifecycle, placement, feed semantics, provider restrictions and compatibility with the user's installed build require local acceptance testing.
- Peak event throughput, multi-day operation, actual Windows Excel locking and crash recovery are not certified. The automated lock test makes the workbook target nonreplaceable without launching Excel.
- The update is not a return-prediction model, fitted PCA replication, absorption classifier or automated trading strategy.

See `ACCEPTANCE_TESTS.md` before relying on the add-on.
