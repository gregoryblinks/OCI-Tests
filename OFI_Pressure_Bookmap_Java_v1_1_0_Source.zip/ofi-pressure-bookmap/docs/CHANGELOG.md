# v1.1.0 changes from the supplied Java v1 source

- Default warmup reduced to 15 prior valid completed observations.
- Actual default rolling window changed from 240 observations to 60; benchmark stage is reached at 60 prior observations.
- Added `rolling.benchmark.minutes`, `levels.minimum` and config schema version 2.
- Safe one-time legacy-config migration with exact backup; preserves unrelated properties and does not overwrite later schema-2 customizations.
- Adaptive minimum 3 / target 10 ranks per side. Uses common ranks in both before/after states; no artificial flow from zero-padded absent levels.
- Renormalizes active-prefix weights at each event. Records actual weighted per-rank flow contributions, counts and exposures.
- Ignores/counts bad diagnostic trades and exports `BAD_TRADE_IGNORED` as a warning. OHLC/volume completeness is separately reported.
- Ordinary invalid minutes are skipped; previous valid calibration survives. Genuine reconstruction faults, rewind and long clock gaps still reset/fail closed.
- Added sample-count calibration stages, rolling-baseline span, bad-trade and depth diagnostics to schema 2.
- Added `Wn/15` warmup bubbles, provisional `*` marker and specific invalid-data labels.
- Retained separate raw-flow and standardized-deviation directions, asynchronous genuine XLSX/CSV export and strict prior-only scoring.
- Added 27 adaptive regression tests alongside 36 original tests.
- Offline labels carry calibration stage, prior sample count, depth range and bad-trade count.
- Versioned build output is `ofi-pressure-bookmap-1.1.0.jar`.

## Scope

Updated source only in this delivery. No official SDK binary, prebuilt add-on JAR, Bookmap installation, live feed, statistical forecasting model, automated order execution, or profitability claim is included.
