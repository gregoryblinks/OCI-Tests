# Bookmap/feed acceptance checklist - v1.1.0

The independent unit/regression tests do not replace these checks. Use a replay or non-trading test workspace with a supported MBO feed. Do not run the old add-on simultaneously.

1. Build with your real official SDK and check the output says `ofi-pressure-bookmap-1.1.0.jar`. A compile failure is a blocker, not a warning to ignore.
2. Confirm the Bookmap entry has `Research v1.1.0` and the settings panel says `3-10 levels`, startup 15, rolling 60, benchmark 60. Check the configuration backup and migration.
3. Verify initial snapshot orders are excluded from flow and the partial startup minute is unscored. Verify the instrument's actual price/size units against the chart.
4. Compare MBO reconstruction with visible bid/ask prices and levels. Under-three ranks, missing MBO, crossed books, unknown cancels/replaces or duplicate IDs must not generate a numeric score. Fatal reconstruction faults require a fresh add-on/snapshot, not just waiting longer.
5. On a 3-9-level uncrossed book, expect `REDUCED_DEPTH` in `quality_warnings`, not `INCOMPLETE_BOOK` in `quality_flags`. Test quotes moving through multiple prices; ranks must move with the book.
6. Where your provider sends unusable diagnostic trades, verify `bad_trade_count` grows but OFI can stay valid. Verify usable trades still set OHLC and volume correctly. Confirm midpoint fallback when no usable trades exist. Treat incomplete trade diagnostics separately in research.
7. Observe `prior_sample_count` 0..14 without a numeric score, then a finite `Z...*` on the first eligible minute with 15 prior values (assuming nonzero variance). No current-minute leakage.
8. At 60 prior valid observations the asterisk disappears and `calibration_stage=MATURE`; subsequent baseline count stays 60 with default settings. `MATURE` is sample count only.
9. Induce a recoverable invalid minute in a controlled recording. That minute must be exported INVALID with blank Z and omitted from calibration. The next valid minute retains prior history. A genuine long timestamp gap or replay rewind must still reset/fail closed as documented.
10. Confirm each bubble matches the SAME frozen record in the CSV/XLSX, including calibration stage. A bubble is emitted on the first API timestamp at/after minute close; verify `available_ns` and latency rather than assuming backdated availability.
11. Verify workbook and CSV column counts match schema 2, nanosecond fields retain string precision, absent deep ranks remain blank, and informational warnings do not become fatal flags.
12. Open the workbook in desktop Excel and hold it open. Verify CSV continues, writer status reports a workbook lock, and subsequent replacement succeeds after closing Excel. Test orderly disable, output permissions, multiple instruments, day rollover and peak feed load.
13. Keep new runs/model versions separate from v1 research. Test forward-label behavior across missing and invalid minutes. Add transaction-cost and execution assumptions independently before using outcome labels as a trading backtest.

Do not loosen integrity checks to hide a stream/provider incompatibility. Retain the latest CSV rows, settings and Bookmap logs for diagnosing any remaining `DEPTH`, `CROSS`, `STALE`, `MBO!` or `RELOAD_REQUIRED` status.
