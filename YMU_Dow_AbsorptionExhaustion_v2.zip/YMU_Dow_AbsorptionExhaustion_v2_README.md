# YMU / YM E-mini Dow Absorption and Exhaustion Studies

This ACSIL source is the E-mini Dow-specific revision of the earlier generic Volume-at-Price study.

## Instrument scope

- Intended for **YMU**, the September E-mini Dow futures contract, and other **YM** quarterly contracts after rollover.
- Accepts common YM symbol forms such as `YMU26-CME`, `YMZ26-CME`, `YM?##-CME`, `CBOT.YMU26`, and `@YM`.
- Deliberately rejects **MYM**, the Micro E-mini Dow, when the symbol restriction is enabled.
- Requires a **1-index-point tick size**, which is the YM minimum price increment.
- It does not use ES, NQ, MYM, or cash-DJIA data. Every calculation comes from the Volume-at-Price data of the chart to which the study is attached.

The letter `U` is the futures month code for September. The source accepts the full YM quarterly family rather than hard-coding only `YMU`, so the same DLL continues to work when the active contract rolls to `YMH`, `YMM`, or `YMZ`.

## Included studies

1. **YMU/YM E-mini Dow VAP Absorption Candidates**
2. **YMU/YM E-mini Dow VAP Exhaustion Candidates**

Both studies contain these protection inputs, enabled by default:

- **Restrict Study to E-mini Dow YM/YMU Symbols = Yes**
- **Require YM 1-Point Tick Size = Yes**

A hidden diagnostic subgraph called **YMU/YM Chart Compatibility** is set to `1` when the chart passes both tests and `-1` when the study is blocked.

If a data service uses an unusual but valid YM symbol format that the parser does not recognize, temporarily set the symbol restriction to **No**. Keep the one-point tick-size check enabled.

## Default absorption profile

- Edge price levels: 3
- Minimum dominant levels: 2
- Diagonal dominance: 3.0:1
- Minimum aggressive volume per dominant level: 10 contracts
- Edge volume multiple of the current bar average: 1.50
- Minimum total edge volume: disabled
- Minimum close rejection: 35% of bar range
- Minimum bar range: 4 YMU points
- Opposite bar delta requirement: disabled
- Closed bars only: enabled

These are starting values. The ratio and bar-average tests are relative, but the 10-contract minimum and minimum bar range still depend on the YMU chart's bar period and session.

## Default exhaustion profile

- Extreme-to-adjacent volume ratio: no more than 0.25
- Extreme-to-bar-average ratio: no more than 0.35
- Minimum adjacent aggressive volume: 10 contracts
- Maximum absolute extreme volume: disabled
- Finished auction requirement: disabled
- Rejection required: enabled
- Minimum rejection: 20% of bar range
- Minimum bar range: 2 YMU points
- Closed bars only: enabled

## Sierra Chart data requirements

1. Use an intraday **YM futures** chart, not a cash Dow index chart.
2. Set **Global Settings > Data/Trade Service Settings > Intraday Data Storage Time Unit** to **1 Tick**.
3. Re-download the intraday data after changing that setting so historical Bid Volume and Ask Volume are rebuilt accurately.
4. Use a feed that supplies historical Bid/Ask trade classification.
5. The study sets `sc.MaintainVolumeAtPriceData = 1`, so a visible Numbers Bars study is not required for the code to access per-price data.

## Build instructions

1. Copy `YMU_Dow_AbsorptionExhaustion_v2.cpp` into the Sierra Chart `ACS_Source` folder.
2. In Sierra Chart, choose **Analysis > Build Custom Studies DLL**.
3. Select the source file.
4. Choose **Build > Remote Build**.
5. Add either study through **Analysis > Studies > Add Custom Study**.

## Tuning for a YMU chart

The exact bar construction matters more than the contract month. A 1-minute YMU chart, 12-point range chart, 500-volume chart, and 2,000-trade chart produce very different volume per price.

When there are too many low-quality absorption signals, raise the minimum contracts per dominant level first, then raise the edge-volume multiple or rejection percentage. When legitimate YMU absorption is missed, lower the volume multiple in small steps before weakening the 3:1 dominance test.

When there are too many exhaustion signals from tiny prints, raise the minimum adjacent volume and rejection percentage. When gradual tapering is missed, raise the maximum extreme-to-adjacent ratio from 0.25 toward 0.35 while leaving the finished-auction requirement off.

Use separate settings for regular trading hours and the overnight session. Closed-bar mode should remain enabled while evaluating historical performance.

## Verification status

The source passed a standalone C++ syntax check against an ACSIL interface stub. It has not been compiled by Sierra Chart's actual Windows Remote Build service in this environment. Sierra Chart's compiler output is the authoritative compatibility test.
