#include "sierrachart.h"

#include <cctype>
#include <cmath>
#include <cstring>

SCDLLName("YMU YM E-mini Dow Absorption and Exhaustion Studies")

// -----------------------------------------------------------------------------
// YMU / YM E-mini Dow Absorption and Exhaustion Studies for Sierra Chart / ACSIL
//
// These studies operate on per-bar Volume-at-Price (VAP) data from an E-mini Dow
// YM contract chart, including the September YMU contract. They are designed to
// flag configurable candidates, not to assert that discretionary order-flow
// concepts can be identified with certainty.
//
// Bullish absorption candidate:
//   Heavy aggressive selling near the bar low (Bid Volume), one or more dominant
//   edge levels, and a close/rejection away from the low.
//
// Bearish absorption candidate:
//   Heavy aggressive buying near the bar high (Ask Volume), one or more dominant
//   edge levels, and a close/rejection away from the high.
//
// Bullish exhaustion candidate (seller exhaustion):
//   Bid Volume at the lowest traded price is small relative to the next price
//   level and to the bar's average Bid Volume, optionally with a finished auction
//   and rejection away from the low.
//
// Bearish exhaustion candidate (buyer exhaustion):
//   Ask Volume at the highest traded price is small relative to the next price
//   level inside the bar and to the bar's average Ask Volume, optionally with a
//   finished auction and rejection away from the high.
// -----------------------------------------------------------------------------

namespace
{
    bool IsYMEminiDowSymbol(const SCString& Symbol)
    {
        const char* Text = Symbol.GetChars();
        if (Text == NULL || Text[0] == '\0')
            return false;

        const size_t Length = std::strlen(Text);

        // Accept common chart/data-service forms such as YMU26-CME,
        // YMZ26-CME, YM?##-CME, CBOT.YMU26, and @YM. Reject MYM.
        for (size_t Index = 0; Index + 1 < Length; ++Index)
        {
            const unsigned char CurrentRaw =
                static_cast<unsigned char>(Text[Index]);
            const unsigned char NextRaw =
                static_cast<unsigned char>(Text[Index + 1]);

            const char Current =
                static_cast<char>(std::toupper(CurrentRaw));
            const char Next =
                static_cast<char>(std::toupper(NextRaw));

            if (Current != 'Y' || Next != 'M')
                continue;

            // Prevent MYM from being accepted as YM.
            if (Index > 0
                && std::isalnum(
                    static_cast<unsigned char>(Text[Index - 1])) != 0)
            {
                continue;
            }

            if (Index + 2 >= Length)
                return true;

            const unsigned char FollowingRaw =
                static_cast<unsigned char>(Text[Index + 2]);
            const char Following =
                static_cast<char>(std::toupper(FollowingRaw));

            if (Following == 'H'
                || Following == 'M'
                || Following == 'U'
                || Following == 'Z'
                || Following == '?'
                || Following == '#'
                || std::isdigit(FollowingRaw) != 0
                || std::isalnum(FollowingRaw) == 0)
            {
                return true;
            }
        }

        return false;
    }

    bool IsYMOnePointTickSize(const float TickSize)
    {
        return std::fabs(static_cast<double>(TickSize) - 1.0) <= 0.0001;
    }

    double SafeRatio(const double Numerator, const double Denominator)
    {
        if (Denominator > 0.0)
            return Numerator / Denominator;

        return Numerator > 0.0 ? 1000000.0 : 0.0;
    }

    double Clamp(const double Value, const double Minimum, const double Maximum)
    {
        if (Value < Minimum)
            return Minimum;
        if (Value > Maximum)
            return Maximum;
        return Value;
    }

    bool GetVAPElement(
        SCStudyInterfaceRef sc,
        const int BarIndex,
        const int VAPIndex,
        const s_VolumeAtPriceV2*& Element)
    {
        Element = NULL;

        if (sc.VolumeAtPriceForBars == NULL)
            return false;

        return sc.VolumeAtPriceForBars->GetVAPElementAtIndex(
            BarIndex,
            VAPIndex,
            &Element);
    }

    void ClearSubgraphsAtIndex(SCStudyInterfaceRef sc, const int First, const int Last)
    {
        for (int SubgraphIndex = First; SubgraphIndex <= Last; ++SubgraphIndex)
            sc.Subgraph[SubgraphIndex][sc.Index] = 0.0f;
    }
}

// =============================================================================
// Study 1: Absorption Candidates
// =============================================================================
SCSFExport scsf_VAPAbsorptionCandidates(SCStudyInterfaceRef sc)
{
    SCSubgraphRef BullishAbsorption = sc.Subgraph[0];
    SCSubgraphRef BearishAbsorption = sc.Subgraph[1];
    SCSubgraphRef BullishDominanceRatio = sc.Subgraph[2];
    SCSubgraphRef BearishDominanceRatio = sc.Subgraph[3];
    SCSubgraphRef BullishEdgeVolumeMultiple = sc.Subgraph[4];
    SCSubgraphRef BearishEdgeVolumeMultiple = sc.Subgraph[5];
    SCSubgraphRef BullishDominantLevelCount = sc.Subgraph[6];
    SCSubgraphRef BearishDominantLevelCount = sc.Subgraph[7];
    SCSubgraphRef ChartCompatibility = sc.Subgraph[8];

    SCInputRef EdgeLevelsInput = sc.Input[0];
    SCInputRef MinimumDominantLevelsInput = sc.Input[1];
    SCInputRef DominanceRatioInput = sc.Input[2];
    SCInputRef MinimumAggressiveVolumePerLevelInput = sc.Input[3];
    SCInputRef EdgeVolumeMultipleInput = sc.Input[4];
    SCInputRef MinimumTotalEdgeAggressiveVolumeInput = sc.Input[5];
    SCInputRef UseDiagonalComparisonInput = sc.Input[6];
    SCInputRef MinimumRejectionPercentInput = sc.Input[7];
    SCInputRef MinimumBarRangeTicksInput = sc.Input[8];
    SCInputRef RequireOppositeBarDeltaInput = sc.Input[9];
    SCInputRef ClosedBarsOnlyInput = sc.Input[10];
    SCInputRef ArrowOffsetTicksInput = sc.Input[11];
    SCInputRef AlertSoundNumberInput = sc.Input[12];
    SCInputRef RestrictToYMSymbolInput = sc.Input[13];
    SCInputRef RequireOnePointTickInput = sc.Input[14];

    if (sc.SetDefaults)
    {
        sc.GraphName = "YMU/YM E-mini Dow VAP Absorption Candidates";
        sc.StudyDescription =
            "Designed for E-mini Dow YM charts, including the September YMU "
            "contract. Flags configurable bullish and bearish absorption "
            "candidates using Volume-at-Price edge dominance, relative edge "
            "volume, and rejection from the bar extreme. Requires tick-by-tick "
            "Bid/Ask volume data.";

        sc.AutoLoop = 1;
        sc.GraphRegion = 0;
        sc.ValueFormat = sc.BaseGraphValueFormat;
        sc.MaintainVolumeAtPriceData = 1;
        sc.AlertOnlyOncePerBar = 1;
        sc.ResetAlertOnNewBar = 1;

        BullishAbsorption.Name = "Bullish Absorption";
        BullishAbsorption.DrawStyle = DRAWSTYLE_ARROW_UP;
        BullishAbsorption.PrimaryColor = RGB(0, 192, 0);
        BullishAbsorption.LineWidth = 4;
        BullishAbsorption.DrawZeros = false;

        BearishAbsorption.Name = "Bearish Absorption";
        BearishAbsorption.DrawStyle = DRAWSTYLE_ARROW_DOWN;
        BearishAbsorption.PrimaryColor = RGB(220, 30, 30);
        BearishAbsorption.LineWidth = 4;
        BearishAbsorption.DrawZeros = false;

        BullishDominanceRatio.Name = "Bullish Edge Dominance Ratio";
        BullishDominanceRatio.DrawStyle = DRAWSTYLE_IGNORE;
        BullishDominanceRatio.DrawZeros = false;

        BearishDominanceRatio.Name = "Bearish Edge Dominance Ratio";
        BearishDominanceRatio.DrawStyle = DRAWSTYLE_IGNORE;
        BearishDominanceRatio.DrawZeros = false;

        BullishEdgeVolumeMultiple.Name = "Bullish Edge Volume Multiple";
        BullishEdgeVolumeMultiple.DrawStyle = DRAWSTYLE_IGNORE;
        BullishEdgeVolumeMultiple.DrawZeros = false;

        BearishEdgeVolumeMultiple.Name = "Bearish Edge Volume Multiple";
        BearishEdgeVolumeMultiple.DrawStyle = DRAWSTYLE_IGNORE;
        BearishEdgeVolumeMultiple.DrawZeros = false;

        BullishDominantLevelCount.Name = "Bullish Dominant Edge Levels";
        BullishDominantLevelCount.DrawStyle = DRAWSTYLE_IGNORE;
        BullishDominantLevelCount.DrawZeros = false;

        BearishDominantLevelCount.Name = "Bearish Dominant Edge Levels";
        BearishDominantLevelCount.DrawStyle = DRAWSTYLE_IGNORE;
        BearishDominantLevelCount.DrawZeros = false;

        ChartCompatibility.Name =
            "YMU/YM Chart Compatibility (1 = Valid, -1 = Blocked)";
        ChartCompatibility.DrawStyle = DRAWSTYLE_IGNORE;
        ChartCompatibility.DrawZeros = false;

        EdgeLevelsInput.Name = "Edge Price Levels to Evaluate";
        EdgeLevelsInput.SetInt(3);
        EdgeLevelsInput.SetIntLimits(1, 20);

        MinimumDominantLevelsInput.Name = "Minimum Dominant Edge Levels";
        MinimumDominantLevelsInput.SetInt(2);
        MinimumDominantLevelsInput.SetIntLimits(1, 20);

        DominanceRatioInput.Name = "Aggressive Dominance Ratio";
        DominanceRatioInput.SetFloat(3.0f);
        DominanceRatioInput.SetFloatLimits(1.0f, 100.0f);

        MinimumAggressiveVolumePerLevelInput.Name =
            "Minimum Aggressive Volume per Dominant Level (Contracts)";
        MinimumAggressiveVolumePerLevelInput.SetInt(10);
        MinimumAggressiveVolumePerLevelInput.SetIntLimits(0, 1000000000);

        EdgeVolumeMultipleInput.Name =
            "Minimum Edge Volume Multiple of Bar Average";
        EdgeVolumeMultipleInput.SetFloat(1.50f);
        EdgeVolumeMultipleInput.SetFloatLimits(0.0f, 100.0f);

        MinimumTotalEdgeAggressiveVolumeInput.Name =
            "Minimum Total Edge Aggressive Volume (0 = Disabled)";
        MinimumTotalEdgeAggressiveVolumeInput.SetInt(0);
        MinimumTotalEdgeAggressiveVolumeInput.SetIntLimits(0, 1000000000);

        UseDiagonalComparisonInput.Name =
            "Use Diagonal Bid/Ask Comparison";
        UseDiagonalComparisonInput.SetYesNo(1);

        MinimumRejectionPercentInput.Name =
            "Minimum Close Rejection from Extreme (Percent of Bar Range)";
        MinimumRejectionPercentInput.SetFloat(35.0f);
        MinimumRejectionPercentInput.SetFloatLimits(0.0f, 100.0f);

        MinimumBarRangeTicksInput.Name =
            "Minimum Bar Range in YMU Points (1 Point = 1 Tick)";
        MinimumBarRangeTicksInput.SetInt(4);
        MinimumBarRangeTicksInput.SetIntLimits(0, 100000);

        RequireOppositeBarDeltaInput.Name =
            "Require Bar Delta Opposite the Reversal Direction";
        RequireOppositeBarDeltaInput.SetYesNo(0);

        ClosedBarsOnlyInput.Name = "Signal on Closed Bars Only";
        ClosedBarsOnlyInput.SetYesNo(1);

        ArrowOffsetTicksInput.Name = "Arrow Offset in YMU Points";
        ArrowOffsetTicksInput.SetInt(2);
        ArrowOffsetTicksInput.SetIntLimits(0, 1000);

        AlertSoundNumberInput.Name = "Alert Sound Number (0 = Disabled)";
        AlertSoundNumberInput.SetInt(0);
        AlertSoundNumberInput.SetIntLimits(0, 150);

        RestrictToYMSymbolInput.Name =
            "Restrict Study to E-mini Dow YM/YMU Symbols";
        RestrictToYMSymbolInput.SetYesNo(1);

        RequireOnePointTickInput.Name =
            "Require YM 1-Point Tick Size";
        RequireOnePointTickInput.SetYesNo(1);

        return;
    }

    ClearSubgraphsAtIndex(sc, 0, 8);

    const bool SymbolIsValid =
        !RestrictToYMSymbolInput.GetYesNo() || IsYMEminiDowSymbol(sc.Symbol);
    const bool TickSizeIsValid =
        !RequireOnePointTickInput.GetYesNo()
        || IsYMOnePointTickSize(sc.TickSize);

    ChartCompatibility[sc.Index] =
        SymbolIsValid && TickSizeIsValid ? 1.0f : -1.0f;

    if (!SymbolIsValid || !TickSizeIsValid)
        return;

    if (ClosedBarsOnlyInput.GetYesNo()
        && sc.GetBarHasClosedStatus() == BHCS_BAR_HAS_NOT_CLOSED)
    {
        return;
    }

    if (sc.VolumeAtPriceForBars == NULL || sc.TickSize <= 0.0f)
        return;

    const int BarIndex = sc.Index;
    const int VAPCount = sc.VolumeAtPriceForBars->GetSizeAtBarIndex(BarIndex);

    if (VAPCount < 2)
        return;

    const bool UseDiagonalComparison = UseDiagonalComparisonInput.GetYesNo() != 0;

    int EdgeLevels = EdgeLevelsInput.GetInt();
    const int MaximumUsableEdgeLevels = UseDiagonalComparison ? VAPCount - 1 : VAPCount;
    if (EdgeLevels > MaximumUsableEdgeLevels)
        EdgeLevels = MaximumUsableEdgeLevels;
    if (EdgeLevels < 1)
        return;

    int MinimumDominantLevels = MinimumDominantLevelsInput.GetInt();
    if (MinimumDominantLevels > EdgeLevels)
        MinimumDominantLevels = EdgeLevels;

    double TotalBidVolume = 0.0;
    double TotalAskVolume = 0.0;
    double BottomBidVolume = 0.0;
    double BottomOpposingVolume = 0.0;
    double TopAskVolume = 0.0;
    double TopOpposingVolume = 0.0;

    const s_VolumeAtPriceV2* CurrentElement = NULL;
    const s_VolumeAtPriceV2* AdjacentElement = NULL;

    for (int VAPIndex = 0; VAPIndex < VAPCount; ++VAPIndex)
    {
        if (!GetVAPElement(sc, BarIndex, VAPIndex, CurrentElement))
            return;

        TotalBidVolume += CurrentElement->BidVolume;
        TotalAskVolume += CurrentElement->AskVolume;
    }

    int BullishDominantLevels = 0;
    int BearishDominantLevels = 0;

    const double DominanceThreshold = DominanceRatioInput.GetFloat();
    const double MinimumVolumePerLevel =
        static_cast<double>(MinimumAggressiveVolumePerLevelInput.GetInt());

    for (int Offset = 0; Offset < EdgeLevels; ++Offset)
    {
        // Low edge: aggressive sellers are represented by Bid Volume.
        const int LowIndex = Offset;
        if (!GetVAPElement(sc, BarIndex, LowIndex, CurrentElement))
            return;

        double LowOpposingVolume = CurrentElement->AskVolume;
        if (UseDiagonalComparison)
        {
            if (!GetVAPElement(sc, BarIndex, LowIndex + 1, AdjacentElement))
                return;
            LowOpposingVolume = AdjacentElement->AskVolume;
        }

        BottomBidVolume += CurrentElement->BidVolume;
        BottomOpposingVolume += LowOpposingVolume;

        if (CurrentElement->BidVolume >= MinimumVolumePerLevel
            && SafeRatio(CurrentElement->BidVolume, LowOpposingVolume)
                >= DominanceThreshold)
        {
            ++BullishDominantLevels;
        }

        // High edge: aggressive buyers are represented by Ask Volume.
        const int HighIndex = VAPCount - 1 - Offset;
        if (!GetVAPElement(sc, BarIndex, HighIndex, CurrentElement))
            return;

        double HighOpposingVolume = CurrentElement->BidVolume;
        if (UseDiagonalComparison)
        {
            if (!GetVAPElement(sc, BarIndex, HighIndex - 1, AdjacentElement))
                return;
            HighOpposingVolume = AdjacentElement->BidVolume;
        }

        TopAskVolume += CurrentElement->AskVolume;
        TopOpposingVolume += HighOpposingVolume;

        if (CurrentElement->AskVolume >= MinimumVolumePerLevel
            && SafeRatio(CurrentElement->AskVolume, HighOpposingVolume)
                >= DominanceThreshold)
        {
            ++BearishDominantLevels;
        }
    }

    const double AverageBidPerLevel = TotalBidVolume / VAPCount;
    const double AverageAskPerLevel = TotalAskVolume / VAPCount;

    const double BullishVolumeMultiple = SafeRatio(
        BottomBidVolume,
        AverageBidPerLevel * EdgeLevels);

    const double BearishVolumeMultiple = SafeRatio(
        TopAskVolume,
        AverageAskPerLevel * EdgeLevels);

    const double BullishRatio = SafeRatio(BottomBidVolume, BottomOpposingVolume);
    const double BearishRatio = SafeRatio(TopAskVolume, TopOpposingVolume);

    BullishDominanceRatio[BarIndex] = static_cast<float>(BullishRatio);
    BearishDominanceRatio[BarIndex] = static_cast<float>(BearishRatio);
    BullishEdgeVolumeMultiple[BarIndex] = static_cast<float>(BullishVolumeMultiple);
    BearishEdgeVolumeMultiple[BarIndex] = static_cast<float>(BearishVolumeMultiple);
    BullishDominantLevelCount[BarIndex] = static_cast<float>(BullishDominantLevels);
    BearishDominantLevelCount[BarIndex] = static_cast<float>(BearishDominantLevels);

    const double BarRange = sc.High[BarIndex] - sc.Low[BarIndex];
    const double BarRangeTicks = BarRange / sc.TickSize;

    if (BarRangeTicks < MinimumBarRangeTicksInput.GetInt())
        return;

    const double CloseLocation = BarRange > 0.0
        ? Clamp((sc.Close[BarIndex] - sc.Low[BarIndex]) / BarRange, 0.0, 1.0)
        : 0.5;

    const double MinimumRejectionFraction =
        MinimumRejectionPercentInput.GetFloat() / 100.0;

    const bool BullishRejection = CloseLocation >= MinimumRejectionFraction;
    const bool BearishRejection = CloseLocation <= 1.0 - MinimumRejectionFraction;

    const double RequiredVolumeMultiple = EdgeVolumeMultipleInput.GetFloat();
    const double MinimumTotalEdgeVolume =
        static_cast<double>(MinimumTotalEdgeAggressiveVolumeInput.GetInt());

    const bool FixedBullishVolumeOK =
        MinimumTotalEdgeVolume <= 0.0 || BottomBidVolume >= MinimumTotalEdgeVolume;
    const bool FixedBearishVolumeOK =
        MinimumTotalEdgeVolume <= 0.0 || TopAskVolume >= MinimumTotalEdgeVolume;

    const double BarDelta = TotalAskVolume - TotalBidVolume;
    const bool RequireOppositeDelta = RequireOppositeBarDeltaInput.GetYesNo() != 0;

    const bool BullishDeltaOK = !RequireOppositeDelta || BarDelta <= 0.0;
    const bool BearishDeltaOK = !RequireOppositeDelta || BarDelta >= 0.0;

    const bool BullishSignal =
        BullishDominantLevels >= MinimumDominantLevels
        && BullishRatio >= DominanceThreshold
        && BullishVolumeMultiple >= RequiredVolumeMultiple
        && FixedBullishVolumeOK
        && BullishRejection
        && BullishDeltaOK;

    const bool BearishSignal =
        BearishDominantLevels >= MinimumDominantLevels
        && BearishRatio >= DominanceThreshold
        && BearishVolumeMultiple >= RequiredVolumeMultiple
        && FixedBearishVolumeOK
        && BearishRejection
        && BearishDeltaOK;

    const float ArrowOffset =
        static_cast<float>(ArrowOffsetTicksInput.GetInt()) * sc.TickSize;

    if (BullishSignal)
        BullishAbsorption[BarIndex] = sc.Low[BarIndex] - ArrowOffset;

    if (BearishSignal)
        BearishAbsorption[BarIndex] = sc.High[BarIndex] + ArrowOffset;

    const int AlertNumber = AlertSoundNumberInput.GetInt();
    if (AlertNumber > 0 && BarIndex >= sc.ArraySize - 2)
    {
        if (BullishSignal)
            sc.SetAlert(AlertNumber, "YMU/YM bullish absorption candidate");
        else if (BearishSignal)
            sc.SetAlert(AlertNumber, "YMU/YM bearish absorption candidate");
    }
}

// =============================================================================
// Study 2: Exhaustion Candidates
// =============================================================================
SCSFExport scsf_VAPExhaustionCandidates(SCStudyInterfaceRef sc)
{
    SCSubgraphRef BullishExhaustion = sc.Subgraph[0];
    SCSubgraphRef BearishExhaustion = sc.Subgraph[1];
    SCSubgraphRef LowExtremeToAdjacentRatio = sc.Subgraph[2];
    SCSubgraphRef HighExtremeToAdjacentRatio = sc.Subgraph[3];
    SCSubgraphRef LowExtremeToAverageRatio = sc.Subgraph[4];
    SCSubgraphRef HighExtremeToAverageRatio = sc.Subgraph[5];
    SCSubgraphRef ChartCompatibility = sc.Subgraph[6];

    SCInputRef MaximumExtremeToAdjacentRatioInput = sc.Input[0];
    SCInputRef MaximumExtremeToAverageRatioInput = sc.Input[1];
    SCInputRef MinimumAdjacentAggressiveVolumeInput = sc.Input[2];
    SCInputRef MaximumExtremeAggressiveVolumeInput = sc.Input[3];
    SCInputRef RequireFinishedAuctionInput = sc.Input[4];
    SCInputRef RequireRejectionInput = sc.Input[5];
    SCInputRef MinimumRejectionPercentInput = sc.Input[6];
    SCInputRef MinimumBarRangeTicksInput = sc.Input[7];
    SCInputRef ClosedBarsOnlyInput = sc.Input[8];
    SCInputRef ArrowOffsetTicksInput = sc.Input[9];
    SCInputRef AlertSoundNumberInput = sc.Input[10];
    SCInputRef RestrictToYMSymbolInput = sc.Input[11];
    SCInputRef RequireOnePointTickInput = sc.Input[12];

    if (sc.SetDefaults)
    {
        sc.GraphName = "YMU/YM E-mini Dow VAP Exhaustion Candidates";
        sc.StudyDescription =
            "Designed for E-mini Dow YM charts, including the September YMU "
            "contract. Flags seller-exhaustion candidates at bar lows and "
            "buyer-exhaustion candidates at bar highs by comparing aggressive "
            "volume at the extreme with the adjacent inside price and the bar "
            "average. Requires tick-by-tick Bid/Ask volume data.";

        sc.AutoLoop = 1;
        sc.GraphRegion = 0;
        sc.ValueFormat = sc.BaseGraphValueFormat;
        sc.MaintainVolumeAtPriceData = 1;
        sc.AlertOnlyOncePerBar = 1;
        sc.ResetAlertOnNewBar = 1;

        BullishExhaustion.Name = "Bullish Exhaustion (Seller Exhaustion)";
        BullishExhaustion.DrawStyle = DRAWSTYLE_ARROW_UP;
        BullishExhaustion.PrimaryColor = RGB(0, 160, 255);
        BullishExhaustion.LineWidth = 4;
        BullishExhaustion.DrawZeros = false;

        BearishExhaustion.Name = "Bearish Exhaustion (Buyer Exhaustion)";
        BearishExhaustion.DrawStyle = DRAWSTYLE_ARROW_DOWN;
        BearishExhaustion.PrimaryColor = RGB(255, 140, 0);
        BearishExhaustion.LineWidth = 4;
        BearishExhaustion.DrawZeros = false;

        LowExtremeToAdjacentRatio.Name = "Low Bid / Adjacent Bid Ratio";
        LowExtremeToAdjacentRatio.DrawStyle = DRAWSTYLE_IGNORE;
        LowExtremeToAdjacentRatio.DrawZeros = false;

        HighExtremeToAdjacentRatio.Name = "High Ask / Adjacent Ask Ratio";
        HighExtremeToAdjacentRatio.DrawStyle = DRAWSTYLE_IGNORE;
        HighExtremeToAdjacentRatio.DrawZeros = false;

        LowExtremeToAverageRatio.Name = "Low Bid / Average Bid Ratio";
        LowExtremeToAverageRatio.DrawStyle = DRAWSTYLE_IGNORE;
        LowExtremeToAverageRatio.DrawZeros = false;

        HighExtremeToAverageRatio.Name = "High Ask / Average Ask Ratio";
        HighExtremeToAverageRatio.DrawStyle = DRAWSTYLE_IGNORE;
        HighExtremeToAverageRatio.DrawZeros = false;

        ChartCompatibility.Name =
            "YMU/YM Chart Compatibility (1 = Valid, -1 = Blocked)";
        ChartCompatibility.DrawStyle = DRAWSTYLE_IGNORE;
        ChartCompatibility.DrawZeros = false;

        MaximumExtremeToAdjacentRatioInput.Name =
            "Maximum Extreme-to-Adjacent Aggressive Volume Ratio";
        MaximumExtremeToAdjacentRatioInput.SetFloat(0.25f);
        MaximumExtremeToAdjacentRatioInput.SetFloatLimits(0.0f, 10.0f);

        MaximumExtremeToAverageRatioInput.Name =
            "Maximum Extreme-to-Bar-Average Aggressive Volume Ratio";
        MaximumExtremeToAverageRatioInput.SetFloat(0.35f);
        MaximumExtremeToAverageRatioInput.SetFloatLimits(0.0f, 10.0f);

        MinimumAdjacentAggressiveVolumeInput.Name =
            "Minimum Adjacent Aggressive Volume (Contracts)";
        MinimumAdjacentAggressiveVolumeInput.SetInt(10);
        MinimumAdjacentAggressiveVolumeInput.SetIntLimits(0, 1000000000);

        MaximumExtremeAggressiveVolumeInput.Name =
            "Maximum Extreme Aggressive Volume in Contracts (0 = Disabled)";
        MaximumExtremeAggressiveVolumeInput.SetInt(0);
        MaximumExtremeAggressiveVolumeInput.SetIntLimits(0, 1000000000);

        RequireFinishedAuctionInput.Name =
            "Require Finished Auction at Extreme";
        RequireFinishedAuctionInput.SetYesNo(0);

        RequireRejectionInput.Name = "Require Close Rejection from Extreme";
        RequireRejectionInput.SetYesNo(1);

        MinimumRejectionPercentInput.Name =
            "Minimum Close Rejection from Extreme (Percent of Bar Range)";
        MinimumRejectionPercentInput.SetFloat(20.0f);
        MinimumRejectionPercentInput.SetFloatLimits(0.0f, 100.0f);

        MinimumBarRangeTicksInput.Name =
            "Minimum Bar Range in YMU Points (1 Point = 1 Tick)";
        MinimumBarRangeTicksInput.SetInt(2);
        MinimumBarRangeTicksInput.SetIntLimits(0, 100000);

        ClosedBarsOnlyInput.Name = "Signal on Closed Bars Only";
        ClosedBarsOnlyInput.SetYesNo(1);

        ArrowOffsetTicksInput.Name = "Arrow Offset in YMU Points";
        ArrowOffsetTicksInput.SetInt(4);
        ArrowOffsetTicksInput.SetIntLimits(0, 1000);

        AlertSoundNumberInput.Name = "Alert Sound Number (0 = Disabled)";
        AlertSoundNumberInput.SetInt(0);
        AlertSoundNumberInput.SetIntLimits(0, 150);

        RestrictToYMSymbolInput.Name =
            "Restrict Study to E-mini Dow YM/YMU Symbols";
        RestrictToYMSymbolInput.SetYesNo(1);

        RequireOnePointTickInput.Name =
            "Require YM 1-Point Tick Size";
        RequireOnePointTickInput.SetYesNo(1);

        return;
    }

    ClearSubgraphsAtIndex(sc, 0, 6);

    const bool SymbolIsValid =
        !RestrictToYMSymbolInput.GetYesNo() || IsYMEminiDowSymbol(sc.Symbol);
    const bool TickSizeIsValid =
        !RequireOnePointTickInput.GetYesNo()
        || IsYMOnePointTickSize(sc.TickSize);

    ChartCompatibility[sc.Index] =
        SymbolIsValid && TickSizeIsValid ? 1.0f : -1.0f;

    if (!SymbolIsValid || !TickSizeIsValid)
        return;

    if (ClosedBarsOnlyInput.GetYesNo()
        && sc.GetBarHasClosedStatus() == BHCS_BAR_HAS_NOT_CLOSED)
    {
        return;
    }

    if (sc.VolumeAtPriceForBars == NULL || sc.TickSize <= 0.0f)
        return;

    const int BarIndex = sc.Index;
    const int VAPCount = sc.VolumeAtPriceForBars->GetSizeAtBarIndex(BarIndex);

    if (VAPCount < 2)
        return;

    double TotalBidVolume = 0.0;
    double TotalAskVolume = 0.0;

    const s_VolumeAtPriceV2* Element = NULL;
    for (int VAPIndex = 0; VAPIndex < VAPCount; ++VAPIndex)
    {
        if (!GetVAPElement(sc, BarIndex, VAPIndex, Element))
            return;

        TotalBidVolume += Element->BidVolume;
        TotalAskVolume += Element->AskVolume;
    }

    const s_VolumeAtPriceV2* LowestElement = NULL;
    const s_VolumeAtPriceV2* SecondLowestElement = NULL;
    const s_VolumeAtPriceV2* HighestElement = NULL;
    const s_VolumeAtPriceV2* SecondHighestElement = NULL;

    if (!GetVAPElement(sc, BarIndex, 0, LowestElement)
        || !GetVAPElement(sc, BarIndex, 1, SecondLowestElement)
        || !GetVAPElement(sc, BarIndex, VAPCount - 1, HighestElement)
        || !GetVAPElement(sc, BarIndex, VAPCount - 2, SecondHighestElement))
    {
        return;
    }

    const double AverageBidPerLevel = TotalBidVolume / VAPCount;
    const double AverageAskPerLevel = TotalAskVolume / VAPCount;

    // At the low, aggressive sellers transact at the Bid.
    const double LowExtremeAggressiveVolume = LowestElement->BidVolume;
    const double LowAdjacentAggressiveVolume = SecondLowestElement->BidVolume;

    // At the high, aggressive buyers transact at the Ask.
    const double HighExtremeAggressiveVolume = HighestElement->AskVolume;
    const double HighAdjacentAggressiveVolume = SecondHighestElement->AskVolume;

    const double LowAdjacentRatio = SafeRatio(
        LowExtremeAggressiveVolume,
        LowAdjacentAggressiveVolume);

    const double HighAdjacentRatio = SafeRatio(
        HighExtremeAggressiveVolume,
        HighAdjacentAggressiveVolume);

    const double LowAverageRatio = SafeRatio(
        LowExtremeAggressiveVolume,
        AverageBidPerLevel);

    const double HighAverageRatio = SafeRatio(
        HighExtremeAggressiveVolume,
        AverageAskPerLevel);

    LowExtremeToAdjacentRatio[BarIndex] = static_cast<float>(LowAdjacentRatio);
    HighExtremeToAdjacentRatio[BarIndex] = static_cast<float>(HighAdjacentRatio);
    LowExtremeToAverageRatio[BarIndex] = static_cast<float>(LowAverageRatio);
    HighExtremeToAverageRatio[BarIndex] = static_cast<float>(HighAverageRatio);

    const double BarRange = sc.High[BarIndex] - sc.Low[BarIndex];
    const double BarRangeTicks = BarRange / sc.TickSize;

    if (BarRangeTicks < MinimumBarRangeTicksInput.GetInt())
        return;

    const double CloseLocation = BarRange > 0.0
        ? Clamp((sc.Close[BarIndex] - sc.Low[BarIndex]) / BarRange, 0.0, 1.0)
        : 0.5;

    const bool RequireRejection = RequireRejectionInput.GetYesNo() != 0;
    const double MinimumRejectionFraction =
        MinimumRejectionPercentInput.GetFloat() / 100.0;

    const bool BullishRejectionOK =
        !RequireRejection || CloseLocation >= MinimumRejectionFraction;

    const bool BearishRejectionOK =
        !RequireRejection || CloseLocation <= 1.0 - MinimumRejectionFraction;

    const double MaximumAdjacentRatio =
        MaximumExtremeToAdjacentRatioInput.GetFloat();
    const double MaximumAverageRatio =
        MaximumExtremeToAverageRatioInput.GetFloat();
    const double MinimumAdjacentVolume =
        static_cast<double>(MinimumAdjacentAggressiveVolumeInput.GetInt());
    const double MaximumExtremeVolume =
        static_cast<double>(MaximumExtremeAggressiveVolumeInput.GetInt());

    const bool BullishAdjacentVolumeOK =
        LowAdjacentAggressiveVolume >= MinimumAdjacentVolume;
    const bool BearishAdjacentVolumeOK =
        HighAdjacentAggressiveVolume >= MinimumAdjacentVolume;

    const bool BullishFixedMaximumOK =
        MaximumExtremeVolume <= 0.0
        || LowExtremeAggressiveVolume <= MaximumExtremeVolume;

    const bool BearishFixedMaximumOK =
        MaximumExtremeVolume <= 0.0
        || HighExtremeAggressiveVolume <= MaximumExtremeVolume;

    const bool RequireFinishedAuction = RequireFinishedAuctionInput.GetYesNo() != 0;

    // A commonly used finished-auction convention is zero opposite-side volume
    // at the extreme: zero Ask at the low and zero Bid at the high.
    const bool BullishFinishedAuctionOK =
        !RequireFinishedAuction || LowestElement->AskVolume == 0;

    const bool BearishFinishedAuctionOK =
        !RequireFinishedAuction || HighestElement->BidVolume == 0;

    const bool BullishSignal =
        BullishAdjacentVolumeOK
        && LowAdjacentRatio <= MaximumAdjacentRatio
        && LowAverageRatio <= MaximumAverageRatio
        && BullishFixedMaximumOK
        && BullishFinishedAuctionOK
        && BullishRejectionOK;

    const bool BearishSignal =
        BearishAdjacentVolumeOK
        && HighAdjacentRatio <= MaximumAdjacentRatio
        && HighAverageRatio <= MaximumAverageRatio
        && BearishFixedMaximumOK
        && BearishFinishedAuctionOK
        && BearishRejectionOK;

    const float ArrowOffset =
        static_cast<float>(ArrowOffsetTicksInput.GetInt()) * sc.TickSize;

    if (BullishSignal)
        BullishExhaustion[BarIndex] = sc.Low[BarIndex] - ArrowOffset;

    if (BearishSignal)
        BearishExhaustion[BarIndex] = sc.High[BarIndex] + ArrowOffset;

    const int AlertNumber = AlertSoundNumberInput.GetInt();
    if (AlertNumber > 0 && BarIndex >= sc.ArraySize - 2)
    {
        if (BullishSignal)
            sc.SetAlert(AlertNumber, "YMU/YM bullish exhaustion candidate");
        else if (BearishSignal)
            sc.SetAlert(AlertNumber, "YMU/YM bearish exhaustion candidate");
    }
}
