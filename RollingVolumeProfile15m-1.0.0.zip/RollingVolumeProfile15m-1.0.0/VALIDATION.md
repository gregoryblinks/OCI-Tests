# Validation

Release: 1.0.0, 19 October 2026.

## Automated checks

- Complete add-on compiled against the published Bookmap Core API 7.4.0.10 with Java 17 bytecode. The adapter was additionally compile-checked against API 7.6.0.20.
- Calculation engine: 743,955 assertions, including randomized comparison with an independent dense reference calculation, exact window-boundary expiry, quiet-window expiry, aggressor volume conservation, POC ties, value-area ties and price gaps, binning, negative prices, empty profiles, detached snapshots, replay resets and arithmetic boundary cases.
- Bookmap callback integration: 39 assertions against a mock `Layer1ApiProvider`, using actual API classes. Covers aggressor mapping, depth updates excluded, execution-chain flags, API tick coordinates, quiet 900-second expiry, warm-up status, replay rewind, skipped-clock resets, provider-clock skew, isolated instruments, reconnect resets and listener/clock cleanup.
- Renderer: headless image generation covering empty data, coincident levels, missing/invalid ranges, small panels, off-screen levels, negative/fractional prices, frozen levels and POC price alignment. A synthetic display preview was visually inspected.

The callback tests exercise the adapter with a mock provider; they do not emulate Bookmap's rendering pipeline or a real Rithmic connection. Assertion counts are checks within deterministic tests, rather than independent market observations.

## Runtime checks still requiring Bookmap

The add-on has not been loaded in the Bookmap desktop application here. Installation, its exact settings-panel presentation, graphics alignment while navigating the heatmap, signing acceptance and live Rithmic delivery remain unverified.

For an initial replay check:

1. Enable the add-on before replay starts; verify that the right-hand profile and labelled level lines appear on YM.
2. Let replay deliver at least 15 minutes of data and confirm that warm-up changes to WINDOW READY.
3. Pause replay and confirm that volume does not age out in wall-clock time. Resume and verify that it does age out with replay time.
4. Freeze levels and confirm that the purple references stay fixed while the live profile continues to develop.
5. Rewind replay or reconnect the feed and confirm that the add-on clears its old state and restarts warm-up.

The supplied image `synthetic-preview.png` illustrates the renderer using generated test trades. It is not a Bookmap screenshot or evidence of live-feed validation.
