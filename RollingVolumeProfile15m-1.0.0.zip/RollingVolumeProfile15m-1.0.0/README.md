# Rolling Volume Profile for Bookmap

Version 1.0.0 — 19 October 2026

A custom Bookmap indicator for a continuously trailing 15-minute executed-volume profile, with aggressor buy/sell colours and clear POC, VAH and VAL labels. The default setup is intended for YM through Rithmic.

## Install

1. Extract this ZIP to a permanent folder.
2. In Bookmap, open **Settings → Configure add-ons → Add**.
3. Select `addon/RollingVolumeProfile15m-1.0.0.jar`.
4. Choose **Rolling Volume Profile — 15 minute**, enable it, and open your subscribed YM instrument.
5. Allow 15 minutes of incoming data for a complete observed window. The panel shows its warm-up progress.

The histogram overlays the right edge of the heatmap, with current levels extending across the chart. It is a screen-space overlay, rather than a separate Bookmap column. Its width is adjustable in the add-on settings.

This build targets Java 17 and was compiled against Bookmap API `7.4.0.10`; the adapter was also compile-checked against `7.6.0.20`. Your Bookmap build and its Java runtime must support these requirements. No Bookmap GUI installation or live Rithmic connection was available for an end-to-end test; see `VALIDATION.md`.

### Paid live-data signing

The supplied JAR is unsigned. Bookmap can block unsigned custom add-ons on paid real-time exchange data. The entry point includes `@UnrestrictedData`, but this annotation does not replace Bookmap validation/signing.

If Bookmap blocks it on your live Rithmic instrument, send the final JAR and its description to **support@bookmap.com** for their validation/signing process. Load the signed JAR they return. Rebuilding or modifying the JAR invalidates that signature. No request has been sent on your behalf.

Official guidance: https://github.com/BookmapAPI/ai-skills/blob/main/references/live-data-and-signing.md

## Display and controls

| Item | Behaviour |
| --- | --- |
| Green | Executed volume classified by Bookmap as an aggressive buy |
| Red | Executed volume classified by Bookmap as an aggressive sell |
| Gray | Executed volume with no aggressor information supplied |
| Gold POC | Price row with the greatest total executed volume |
| Cyan VAH / VAL | Upper and lower boundaries of the contiguous value area |
| Purple frozen levels | Reference POC / VAH / VAL captured with the freeze button |
| Historical trails | Developing levels sampled at most once per data-clock second, retaining 60 minutes |

The settings panel lets you change the trailing window (1–120 minutes), price bin (1–100 instrument ticks), value area (1–100%), overlay width (220–600 pixels), aggressor colours, and historical trails. Defaults are **15 minutes, 1 tick, 70%, 300 pixels**, with colours and trails enabled.

**Freeze current POC / VAH / VAL** captures reference levels. The live histogram and levels continue updating. **Clear frozen levels** removes the references. Frozen levels and trail history are kept in memory for the current run; calculation settings are saved through Bookmap's settings interface.

Changing the window, bin size or value-area percentage clears the calculation and starts a fresh warm-up. Display-only changes preserve the calculation. Removing and re-enabling the add-on also starts a fresh window.

## Calculation

- The active interval is **(current Bookmap time − 900 seconds, current Bookmap time]** with the default settings. A trade expires when it becomes exactly 900 seconds old. This is a sliding window, with no reset on quarter-hour boundaries.
- Only `onTrade` executions count. MBO order additions, changes, cancellations and displayed depth never contribute to volume. MBO availability does not require any separate setup in this add-on.
- Bookmap supplies the aggressor side. `isBidAggressor = true` is an initiating buy; `false` is an initiating sell. A missing `TradeInfo` is retained as unknown. Execution-chain flags do not cause fills to be discarded or aggregated a second time.
- POC and value area use **buy + sell + unknown volume**, regardless of colour settings. Size is the API's raw trade size; for YM this is contract volume. This release does not implement size-multiplier conversion for other asset classes.
- Price bins use Bookmap's integer tick coordinates, anchored at tick zero. Actual displayed price is tick coordinate multiplied by the instrument's `pips`. For bins larger than one tick, POC is the bin's lower tick; VAL is the lowest included tick and VAH is the highest included tick.
- POC ties select the row closest to the midpoint of the occupied price range, then the lower row.
- Value area begins with POC. Compare the immediately adjacent upper and lower row volumes and include the larger one. If they tie, include both together. Empty intervening rows count as zero. Stop when the included volume is at least `ceil(total volume × 70%)`. Thus the actual fraction can exceed 70%. This explicit tie rule can differ from other platforms' implementations.
- Histogram widths are scaled to the largest currently visible row. Zooming changes the display, while the underlying volume and levels remain based on the complete trailing window.

## Timing, history and reconnects

Bookmap's provider/event clock drives expiry, including quiet periods. The add-on requests 100 ms clock events and redraws about five times per wall-clock second. Pausing replay therefore pauses calculation time. Replay speed changes do not intentionally substitute the computer's wall clock for replay time.

The Core API trade callback supplies no dedicated exchange timestamp. Trades use `provider.getCurrentTime()`, with monotonic clamping for documented clock-read skew. The engine uses nanosecond timestamps, but this does **not** claim exchange-level nanosecond accuracy or timestamps reconstructed from MBO order messages.

Already-loaded chart history is **not imported**. The profile contains executions delivered after attachment, including executions delivered while replay runs. For a fully populated replay window at a chosen moment, enable the add-on and start replay at least 15 minutes before that moment. Trails are sampled developing levels, rather than a record of every intrasecond change.

A detected backward clock sequence, a Bookmap skipped-clock notification, a disconnect or reconnect clears the profile, frozen levels and trails. This prevents mixing timelines or presenting a reconnect gap as a complete observed window. The add-on cannot identify losses that the provider does not report. **WINDOW READY** means that a full window of Bookmap clock time has elapsed since the latest reset; it does not certify feed completeness.

The rolling window runs across session boundaries. For example, at the cash open it may include pre-open trades. There is no automatic RTH reset.

## Build from source

The `source/` folder contains the complete Java sources, tests and build files. No API or compiler JAR is embedded in the add-on or distributed in this bundle.

With Python 3 and JDK 17+ on your PATH:

```sh
cd source
python3 build.py
```

On Windows, `py build.py` is an alternative. The script downloads the public Bookmap API dependency, runs all three test runners, and creates `build/libs/RollingVolumeProfile15m-1.0.0.jar` plus a SHA-256 sidecar. To build without downloading the API, supply your installed Bookmap `lib` folder:

```sh
python3 build.py --bookmap-lib "/path/to/Bookmap/lib"
```

An optional `--ecj /path/to/ecj.jar` accepts an existing Eclipse compiler when only a Java 17+ runtime is available. A Gradle build is also supplied for systems with Gradle installed: `gradle clean check jar`. No Gradle wrapper is included.

Entry point: `com.rollingprofile.bookmap.RollingProfileAddon`.

Official API examples: https://github.com/BookmapAPI/DemoStrategies
