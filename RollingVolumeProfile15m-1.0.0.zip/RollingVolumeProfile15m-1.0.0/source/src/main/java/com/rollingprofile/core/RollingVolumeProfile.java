package com.rollingprofile.core;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

/**
 * Exact executed-volume profile over the trailing interval (now - window, now].
 *
 * <p>Trade timestamps must arrive in nondecreasing order. Advancing the clock
 * removes expired trades even when no new trades arrive. A backward clock
 * movement clears all old data, which makes replay rewinds safe. A trade older
 * than the current clock is rejected rather than moving the clock backward.
 * Call {@link #advanceTime(long)} explicitly when handling a replay rewind.</p>
 *
 * <p>Rows use an instrument's integer tick coordinates and are anchored at tick
 * zero. Negative prices therefore use mathematical floor division. All volume,
 * including UNKNOWN aggressor volume, contributes to POC and value area.
 * Public operations are synchronized so renderers may request snapshots while
 * a feed thread supplies trades.</p>
 */
public final class RollingVolumeProfile {
    public static final long NO_TIME = Long.MIN_VALUE;

    public enum Side { BUY, SELL, UNKNOWN }

    public final long windowNanos;
    public final int binTicks;
    public final double valueAreaFraction;

    private final NavigableMap<Long, MutableLevel> rows = new TreeMap<Long, MutableLevel>();
    private final Deque<Trade> trades = new ArrayDeque<Trade>();
    private final BigDecimal decimalValueAreaFraction;
    private boolean hasClock;
    private long currentTime;
    private long totalVolume;
    private long buyVolume;
    private long sellVolume;
    private long unknownVolume;

    public RollingVolumeProfile(long windowNanos, int binTicks, double valueAreaFraction) {
        if (windowNanos <= 0) {
            throw new IllegalArgumentException("windowNanos must be positive");
        }
        if (binTicks <= 0) {
            throw new IllegalArgumentException("binTicks must be positive");
        }
        if (!(valueAreaFraction > 0.0 && valueAreaFraction <= 1.0)) {
            throw new IllegalArgumentException("valueAreaFraction must be in (0, 1]");
        }
        this.windowNanos = windowNanos;
        this.binTicks = binTicks;
        this.valueAreaFraction = valueAreaFraction;
        this.decimalValueAreaFraction = BigDecimal.valueOf(valueAreaFraction);
    }

    /**
     * Adds an executed trade, advancing time first. Size is positive contract
     * volume; null Side is treated as UNKNOWN. Zero and negative sizes are
     * rejected. Arithmetic overflow throws before adding any part of a trade.
     */
    public synchronized void addTrade(long timeNanos, int priceTicks, long size, Side side) {
        if (size <= 0) {
            throw new IllegalArgumentException("trade size must be positive");
        }
        if (hasClock && timeNanos < currentTime) {
            throw new IllegalArgumentException("trade timestamp precedes current clock");
        }
        advanceTime(timeNanos);
        long newTotal = Math.addExact(totalVolume, size);
        Side effectiveSide = side == null ? Side.UNKNOWN : side;
        long rowId = Math.floorDiv((long) priceTicks, (long) binTicks);
        MutableLevel row = rows.get(rowId);
        if (row == null) {
            row = new MutableLevel();
            rows.put(rowId, row);
        }
        if (effectiveSide == Side.BUY) {
            row.buyVolume += size;
            buyVolume += size;
        } else if (effectiveSide == Side.SELL) {
            row.sellVolume += size;
            sellVolume += size;
        } else {
            row.unknownVolume += size;
            unknownVolume += size;
        }
        row.totalVolume += size;
        totalVolume = newTotal;
        trades.addLast(new Trade(timeNanos, rowId, size, effectiveSide));
    }

    /**
     * Advances the data/replay clock. Equal timestamps are allowed. A backward
     * timestamp resets the profile, then starts a new clock at that timestamp.
     */
    public synchronized void advanceTime(long timeNanos) {
        if (hasClock && timeNanos < currentTime) {
            reset();
        }
        hasClock = true;
        currentTime = timeNanos;
        while (!trades.isEmpty() && isExpired(trades.peekFirst().timeNanos, timeNanos)) {
            Trade trade = trades.removeFirst();
            MutableLevel row = rows.get(trade.rowId);
            if (trade.side == Side.BUY) {
                row.buyVolume -= trade.size;
                buyVolume -= trade.size;
            } else if (trade.side == Side.SELL) {
                row.sellVolume -= trade.size;
                sellVolume -= trade.size;
            } else {
                row.unknownVolume -= trade.size;
                unknownVolume -= trade.size;
            }
            row.totalVolume -= trade.size;
            totalVolume -= trade.size;
            if (row.totalVolume == 0) {
                rows.remove(trade.rowId);
            }
        }
    }

    public synchronized void reset() {
        rows.clear();
        trades.clear();
        totalVolume = 0;
        buyVolume = 0;
        sellVolume = 0;
        unknownVolume = 0;
        hasClock = false;
        currentTime = 0;
    }

    /**
     * Returns detached, immutable data. Only occupied rows are materialized.
     * Empty rows between VAL and VAH still belong to the contiguous value area.
     *
     * <p>POC ties go to the row closest to the midpoint of the occupied price
     * range, then to the lower row. Value area starts with POC and compares the
     * immediately adjacent lower and upper row volumes. The larger neighbor is
     * included first. An equal-volume tie includes both available neighbors
     * together, even when one alone would reach the target. Expansion stops as
     * soon as the target is reached; if POC alone reaches it, no neighbor is
     * included. Missing rows have zero volume. This definition can overshoot
     * the requested fraction, and deliberately avoids a directional tie bias.</p>
     */
    public synchronized Snapshot snapshot() {
        List<Level> levels = new ArrayList<Level>(rows.size());
        long pocRowId = 0;
        long pocVolume = -1;
        long midpointSum = rows.isEmpty() ? 0 : rows.firstKey() + rows.lastKey();
        long bestMidpointDistance = Long.MAX_VALUE;
        for (Map.Entry<Long, MutableLevel> entry : rows.entrySet()) {
            long rowId = entry.getKey();
            MutableLevel row = entry.getValue();
            levels.add(new Level(rowLowerTicks(rowId), row.buyVolume, row.sellVolume,
                    row.unknownVolume, row.totalVolume));
            long midpointDistance = Math.abs(2 * rowId - midpointSum);
            if (row.totalVolume > pocVolume || (row.totalVolume == pocVolume
                    && midpointDistance < bestMidpointDistance)) {
                pocRowId = rowId;
                pocVolume = row.totalVolume;
                bestMidpointDistance = midpointDistance;
            }
        }
        if (rows.isEmpty()) {
            return new Snapshot(windowNanos, binTicks, valueAreaFraction, hasClock,
                    currentTime, levels, 0, 0, 0, 0, null, null, null,
                    0, 0, NO_TIME, NO_TIME, 0, 0);
        }
        long target = decimalValueAreaFraction.multiply(BigDecimal.valueOf(totalVolume))
                .setScale(0, RoundingMode.CEILING).longValueExact();
        ValueArea area = calculateValueArea(pocRowId, pocVolume, target);
        long firstTime = trades.peekFirst().timeNanos;
        long lastTime = trades.peekLast().timeNanos;
        return new Snapshot(windowNanos, binTicks, valueAreaFraction, hasClock,
                currentTime, levels, totalVolume, buyVolume, sellVolume, unknownVolume,
                rowLowerTicks(pocRowId), rowUpperTicks(area.upperRow),
                rowLowerTicks(area.lowerRow), area.volume, target,
                firstTime, lastTime, saturatedElapsed(currentTime, firstTime), trades.size());
    }

    private ValueArea calculateValueArea(long pocRow, long pocVolume, long target) {
        long lower = pocRow;
        long upper = pocRow;
        long volume = pocVolume;
        long minimum = rows.firstKey();
        long maximum = rows.lastKey();
        while (volume < target) {
            boolean hasLower = lower > minimum;
            boolean hasUpper = upper < maximum;
            long lowerVolume = hasLower ? volumeAt(lower - 1) : -1;
            long upperVolume = hasUpper ? volumeAt(upper + 1) : -1;

            // Skip a run of empty rows with exactly the same result as moving
            // one row at a time. With two available sides, zero-volume ties
            // advance both boundaries by the same number of rows.
            if (lowerVolume == 0 && upperVolume == 0) {
                long lowerDistance = lower - rows.lowerKey(lower);
                long upperDistance = rows.higherKey(upper) - upper;
                long skip = Math.min(lowerDistance, upperDistance) - 1;
                lower -= skip;
                upper += skip;
                continue;
            }
            if (lowerVolume == 0 && !hasUpper) {
                lower = rows.lowerKey(lower);
                volume += volumeAt(lower);
            } else if (upperVolume == 0 && !hasLower) {
                upper = rows.higherKey(upper);
                volume += volumeAt(upper);
            } else if (lowerVolume > upperVolume) {
                lower--;
                volume += lowerVolume;
            } else if (upperVolume > lowerVolume) {
                upper++;
                volume += upperVolume;
            } else {
                // Both neighbors are available because -1 is only used for a
                // missing side, and a nonempty outside row remains if < target.
                lower--;
                upper++;
                volume += lowerVolume + upperVolume;
            }
        }
        return new ValueArea(lower, upper, volume);
    }

    private long volumeAt(long rowId) {
        MutableLevel row = rows.get(rowId);
        return row == null ? 0 : row.totalVolume;
    }

    private int rowLowerTicks(long rowId) {
        return clampInt(rowId * binTicks);
    }

    private int rowUpperTicks(long rowId) {
        return clampInt(rowId * binTicks + binTicks - 1L);
    }

    private static int clampInt(long ticks) {
        return (int) Math.max(Integer.MIN_VALUE, Math.min(Integer.MAX_VALUE, ticks));
    }

    private boolean isExpired(long tradeTime, long now) {
        long elapsed = now - tradeTime;
        // A negative difference here is an overflow, not a future trade, since
        // trade order is validated before storage.
        return elapsed < 0 || elapsed >= windowNanos;
    }

    private static long saturatedElapsed(long now, long then) {
        long elapsed = now - then;
        return elapsed < 0 ? Long.MAX_VALUE : elapsed;
    }

    private static final class MutableLevel {
        long buyVolume;
        long sellVolume;
        long unknownVolume;
        long totalVolume;
    }

    private static final class Trade {
        final long timeNanos;
        final long rowId;
        final long size;
        final Side side;

        Trade(long timeNanos, long rowId, long size, Side side) {
            this.timeNanos = timeNanos;
            this.rowId = rowId;
            this.size = size;
            this.side = side;
        }
    }

    private static final class ValueArea {
        final long lowerRow;
        final long upperRow;
        final long volume;

        ValueArea(long lowerRow, long upperRow, long volume) {
            this.lowerRow = lowerRow;
            this.upperRow = upperRow;
            this.volume = volume;
        }
    }

    public static final class Level {
        /** Lowest tick in the row; extreme integer-edge bins are clipped. */
        public final int priceTicks;
        public final long buyVolume;
        public final long sellVolume;
        public final long unknownVolume;
        public final long totalVolume;

        private Level(int priceTicks, long buyVolume, long sellVolume,
                      long unknownVolume, long totalVolume) {
            this.priceTicks = priceTicks;
            this.buyVolume = buyVolume;
            this.sellVolume = sellVolume;
            this.unknownVolume = unknownVolume;
            this.totalVolume = totalVolume;
        }
    }

    public static final class Snapshot {
        public final long windowNanos;
        public final int binTicks;
        public final double valueAreaFraction;
        public final boolean hasClock;
        public final long currentTimeNanos;
        /** Occupied rows, sorted ascending by price. */
        public final List<Level> levels;
        public final long totalVolume;
        public final long buyVolume;
        public final long sellVolume;
        public final long unknownVolume;
        /** POC is the lowest tick of its row; null when empty. */
        public final Integer pocTicks;
        /** Highest tick of the uppermost included value-area row. */
        public final Integer vahTicks;
        /** Lowest tick of the lowermost included value-area row. */
        public final Integer valTicks;
        public final long valueAreaVolume;
        public final long valueAreaTargetVolume;
        /** Oldest active trade, or NO_TIME when empty. */
        public final long firstEventTime;
        /** Newest active trade, or NO_TIME when empty. */
        public final long lastEventTime;
        /** Age of the oldest active trade, not a completeness guarantee. */
        public final long coveredSpanNanos;
        public final int tradeCount;

        private Snapshot(long windowNanos, int binTicks, double valueAreaFraction,
                         boolean hasClock, long currentTimeNanos, List<Level> levels,
                         long totalVolume, long buyVolume, long sellVolume,
                         long unknownVolume, Integer pocTicks, Integer vahTicks,
                         Integer valTicks, long valueAreaVolume, long valueAreaTargetVolume,
                         long firstEventTime, long lastEventTime,
                         long coveredSpanNanos, int tradeCount) {
            this.windowNanos = windowNanos;
            this.binTicks = binTicks;
            this.valueAreaFraction = valueAreaFraction;
            this.hasClock = hasClock;
            this.currentTimeNanos = currentTimeNanos;
            this.levels = Collections.unmodifiableList(levels);
            this.totalVolume = totalVolume;
            this.buyVolume = buyVolume;
            this.sellVolume = sellVolume;
            this.unknownVolume = unknownVolume;
            this.pocTicks = pocTicks;
            this.vahTicks = vahTicks;
            this.valTicks = valTicks;
            this.valueAreaVolume = valueAreaVolume;
            this.valueAreaTargetVolume = valueAreaTargetVolume;
            this.firstEventTime = firstEventTime;
            this.lastEventTime = lastEventTime;
            this.coveredSpanNanos = coveredSpanNanos;
            this.tradeCount = tradeCount;
        }

        public boolean hasData() {
            return totalVolume != 0;
        }
    }
}
