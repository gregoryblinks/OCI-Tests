package com.rollingprofile.core;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import com.rollingprofile.core.RollingVolumeProfile.Level;
import com.rollingprofile.core.RollingVolumeProfile.Side;
import com.rollingprofile.core.RollingVolumeProfile.Snapshot;

/** Dependency-free test runner: java ...RollingVolumeProfileTest. */
public final class RollingVolumeProfileTest {
    private static int assertions;

    public static void main(String[] args) {
        exactFifteenMinuteBoundaryAndQuietExpiry();
        aggressorConservationAndSnapshotIsolation();
        expiringVolumeCanMovePocWithoutNewTrades();
        pocAndValueAreaTies();
        sparseAndNegativePriceRows();
        clockRewindsAndInvalidTrades();
        largeVolumesAndIntegerEdgePrices();
        randomizedReferenceComparison();
        System.out.println("RollingVolumeProfile: " + assertions + " assertions passed");
    }

    private static void exactFifteenMinuteBoundaryAndQuietExpiry() {
        long window = 900_000_000_000L;
        RollingVolumeProfile profile = new RollingVolumeProfile(window, 1, .70);
        profile.addTrade(0, 42000, 10, Side.BUY);
        profile.addTrade(1, 42001, 7, Side.SELL);
        profile.advanceTime(window - 1);
        equal(17, profile.snapshot().totalVolume, "window boundary minus 1 keeps both trades");
        profile.advanceTime(window);
        Snapshot snapshot = profile.snapshot();
        equal(7, snapshot.totalVolume, "trade exactly 900 seconds old expires");
        equal(1, snapshot.firstEventTime, "left interval endpoint is exclusive");
        equal(window - 1, snapshot.coveredSpanNanos, "active span follows oldest trade");
        profile.advanceTime(window + 1);
        check(!profile.snapshot().hasData(), "quiet clock empties profile without new trades");
        check(profile.snapshot().pocTicks == null, "empty POC is absent");
        equal(RollingVolumeProfile.NO_TIME, profile.snapshot().firstEventTime,
                "empty event time is explicit");
    }

    private static void aggressorConservationAndSnapshotIsolation() {
        RollingVolumeProfile profile = new RollingVolumeProfile(100, 1, .70);
        profile.addTrade(0, 10, 9, Side.BUY);
        profile.addTrade(1, 10, 4, Side.SELL);
        profile.addTrade(2, 11, 3, Side.UNKNOWN);
        profile.addTrade(3, 11, 2, null);
        Snapshot snapshot = profile.snapshot();
        equal(18, snapshot.totalVolume, "total executed volume");
        equal(9, snapshot.buyVolume, "buy aggressor volume");
        equal(4, snapshot.sellVolume, "sell aggressor volume");
        equal(5, snapshot.unknownVolume, "unknown side retained rather than discarded");
        equal(18, snapshot.buyVolume + snapshot.sellVolume + snapshot.unknownVolume,
                "side totals conserve volume");
        equal(13, snapshot.levels.get(0).totalVolume, "sides aggregate into same row");
        equal(13, snapshot.valueAreaTargetVolume, "70 percent target rounds upward");
        expect(UnsupportedOperationException.class, new Runnable() {
            public void run() { snapshot.levels.clear(); }
        }, "snapshot level list is immutable");
        profile.advanceTime(103);
        equal(18, snapshot.totalVolume, "previous snapshot remains detached after expiry");
        equal(13, snapshot.levels.get(0).totalVolume, "old row remains detached after expiry");
        equal(0, profile.snapshot().totalVolume, "all expired volume removed");
    }

    private static void expiringVolumeCanMovePocWithoutNewTrades() {
        RollingVolumeProfile profile = new RollingVolumeProfile(900, 1, .70);
        profile.addTrade(0, 100, 20, Side.SELL);
        profile.addTrade(100, 110, 15, Side.BUY);
        equal(100, profile.snapshot().pocTicks, "initial POC at larger old cluster");
        profile.advanceTime(900);
        equal(110, profile.snapshot().pocTicks, "expiry alone moves POC");
        equal(15, profile.snapshot().totalVolume, "newer cluster is unchanged");
        equal(0, profile.snapshot().sellVolume, "expiry removes correct aggressor side");
    }

    private static void pocAndValueAreaTies() {
        RollingVolumeProfile profile = new RollingVolumeProfile(100, 1, .70);
        profile.addTrade(0, 100, 1, Side.BUY);
        profile.addTrade(0, 101, 5, Side.BUY);
        profile.addTrade(0, 102, 5, Side.BUY);
        profile.addTrade(0, 103, 1, Side.BUY);
        equal(101, profile.snapshot().pocTicks, "midpoint POC tie picks lower row");
        profile.addTrade(0, 104, 1, Side.BUY);
        equal(102, profile.snapshot().pocTicks, "POC tie picks closest row to occupied midpoint");

        RollingVolumeProfile tiedNeighbors = new RollingVolumeProfile(100, 1, .70);
        tiedNeighbors.addTrade(0, 99, 4, Side.BUY);
        tiedNeighbors.addTrade(0, 100, 10, Side.BUY);
        tiedNeighbors.addTrade(0, 101, 4, Side.BUY);
        Snapshot tie = tiedNeighbors.snapshot();
        equal(99, tie.valTicks, "equal neighbors include lower");
        equal(101, tie.vahTicks, "equal neighbors include upper at same expansion step");
        equal(18, tie.valueAreaVolume, "symmetric tie may exceed exact target");

        RollingVolumeProfile pocOnly = new RollingVolumeProfile(100, 1, .50);
        pocOnly.addTrade(0, 99, 4, Side.BUY);
        pocOnly.addTrade(0, 100, 10, Side.BUY);
        pocOnly.addTrade(0, 101, 4, Side.BUY);
        equal(100, pocOnly.snapshot().valTicks, "POC reaching target includes no extra lower row");
        equal(100, pocOnly.snapshot().vahTicks, "POC reaching target includes no extra upper row");
    }

    private static void sparseAndNegativePriceRows() {
        RollingVolumeProfile profile = new RollingVolumeProfile(100, 1, 1);
        profile.addTrade(0, Integer.MIN_VALUE, 1, Side.UNKNOWN);
        profile.addTrade(0, 0, 3, Side.UNKNOWN);
        profile.addTrade(0, Integer.MAX_VALUE, 1, Side.UNKNOWN);
        Snapshot snapshot = profile.snapshot();
        equal(Integer.MIN_VALUE, snapshot.valTicks, "sparse full-range value area lower bound");
        equal(Integer.MAX_VALUE, snapshot.vahTicks, "sparse full-range value area upper bound");
        equal(3, snapshot.levels.size(), "empty grid rows are not allocated");

        RollingVolumeProfile negative = new RollingVolumeProfile(100, 5, 1);
        negative.addTrade(0, -1, 3, Side.SELL);
        negative.addTrade(0, -5, 4, Side.SELL);
        negative.addTrade(0, 0, 2, Side.BUY);
        Snapshot negativeSnapshot = negative.snapshot();
        equal(-5, negativeSnapshot.pocTicks, "negative bin uses floor rather than truncation");
        equal(7, negativeSnapshot.levels.get(0).totalVolume, "negative trades share floor bin");
        equal(-5, negativeSnapshot.valTicks, "VAL is lower row tick");
        equal(4, negativeSnapshot.vahTicks, "VAH is highest tick in highest row");
    }

    private static void clockRewindsAndInvalidTrades() {
        final RollingVolumeProfile profile = new RollingVolumeProfile(100, 1, .70);
        profile.addTrade(1000, 10, 7, Side.BUY);
        expect(IllegalArgumentException.class, new Runnable() {
            public void run() { profile.addTrade(999, 11, 1, Side.BUY); }
        }, "out-of-order trade rejected");
        equal(7, profile.snapshot().totalVolume, "invalid order does not mutate profile");
        profile.advanceTime(500);
        check(!profile.snapshot().hasData(), "replay rewind clears old data");
        equal(500, profile.snapshot().currentTimeNanos, "replay clock starts at new time");
        profile.addTrade(500, 20, 2, Side.SELL);
        equal(20, profile.snapshot().pocTicks, "replay accepts new timeline trades");
        expect(IllegalArgumentException.class, new Runnable() {
            public void run() { profile.addTrade(501, 10, 0, Side.BUY); }
        }, "zero volume rejected");
        expect(IllegalArgumentException.class, new Runnable() {
            public void run() { profile.addTrade(501, 10, -1, Side.BUY); }
        }, "negative volume rejected");
        profile.reset();
        check(!profile.snapshot().hasClock, "explicit reset clears clock");
        check(!profile.snapshot().hasData(), "explicit reset clears volume");
        expect(IllegalArgumentException.class, new Runnable() {
            public void run() { new RollingVolumeProfile(0, 1, .7); }
        }, "zero window rejected");
        expect(IllegalArgumentException.class, new Runnable() {
            public void run() { new RollingVolumeProfile(100, 0, .7); }
        }, "zero bin width rejected");
        expect(IllegalArgumentException.class, new Runnable() {
            public void run() { new RollingVolumeProfile(100, 1, Double.NaN); }
        }, "NaN value area rejected");
        expect(IllegalArgumentException.class, new Runnable() {
            public void run() { new RollingVolumeProfile(100, 1, 1.1); }
        }, "value area above 100 percent rejected");
    }

    private static void largeVolumesAndIntegerEdgePrices() {
        final RollingVolumeProfile profile = new RollingVolumeProfile(100, 1, .70);
        profile.addTrade(0, 0, Long.MAX_VALUE, Side.UNKNOWN);
        long exactTarget = new BigDecimal("0.7").multiply(BigDecimal.valueOf(Long.MAX_VALUE))
                .setScale(0, RoundingMode.CEILING).longValueExact();
        equal(exactTarget, profile.snapshot().valueAreaTargetVolume,
                "target is exact above double integer precision");
        expect(ArithmeticException.class, new Runnable() {
            public void run() { profile.addTrade(0, 1, 1, Side.BUY); }
        }, "overflow fails explicitly");
        equal(Long.MAX_VALUE, profile.snapshot().totalVolume, "overflow cannot wrap total");
        equal(1, profile.snapshot().levels.size(), "overflow adds no partial new row");
        profile.advanceTime(100);
        equal(0, profile.snapshot().totalVolume, "maximum volume expires exactly");

        RollingVolumeProfile edge = new RollingVolumeProfile(10, 3, 1);
        edge.addTrade(Long.MIN_VALUE, Integer.MIN_VALUE, 2, Side.SELL);
        edge.addTrade(Long.MIN_VALUE, Integer.MAX_VALUE, 1, Side.BUY);
        equal(Integer.MIN_VALUE, edge.snapshot().valTicks, "extreme negative bin clamps lower edge");
        equal(Integer.MAX_VALUE, edge.snapshot().vahTicks, "extreme positive bin clamps upper edge");
        edge.advanceTime(Long.MAX_VALUE);
        equal(0, edge.snapshot().totalVolume, "elapsed-time overflow still expires old events");
    }

    /**
     * Compare with a deliberately simple dense-grid, event-list implementation.
     * This catches sparse-zero skipping, ties, expiry and side accounting against
     * a separately calculated result across many windows and grid sizes.
     */
    private static void randomizedReferenceComparison() {
        Random random = new Random(32150900L);
        for (int trial = 0; trial < 100; trial++) {
            int bin = 1 + random.nextInt(5);
            double fraction = new double[] {.5, .7, 1.0}[random.nextInt(3)];
            RollingVolumeProfile profile = new RollingVolumeProfile(35, bin, fraction);
            List<ReferenceTrade> events = new ArrayList<ReferenceTrade>();
            long time = 0;
            for (int i = 0; i < 150; i++) {
                time += random.nextInt(7);
                if (random.nextInt(4) == 0) {
                    profile.advanceTime(time);
                } else {
                    int ticks = random.nextInt(121) - 60;
                    int size = 1 + random.nextInt(25);
                    Side side = Side.values()[random.nextInt(3)];
                    profile.addTrade(time, ticks, size, side);
                    events.add(new ReferenceTrade(time, Math.floorDiv(ticks, bin), size, side));
                }
                compareReference(profile.snapshot(), events, time, 35, bin, fraction);
            }
        }
    }

    private static void compareReference(Snapshot actual, List<ReferenceTrade> events,
                                         long now, long window, int bin, double fraction) {
        TreeMap<Integer, long[]> rows = new TreeMap<Integer, long[]>();
        long total = 0, buy = 0, sell = 0, unknown = 0;
        int count = 0;
        for (ReferenceTrade event : events) {
            if (event.time <= now - window) continue;
            long[] row = rows.get(event.row);
            if (row == null) {
                row = new long[4];
                rows.put(event.row, row);
            }
            row[event.side.ordinal()] += event.size;
            row[3] += event.size;
            total += event.size;
            if (event.side == Side.BUY) buy += event.size;
            if (event.side == Side.SELL) sell += event.size;
            if (event.side == Side.UNKNOWN) unknown += event.size;
            count++;
        }
        equal(total, actual.totalVolume, "random reference total");
        equal(buy, actual.buyVolume, "random reference buy");
        equal(sell, actual.sellVolume, "random reference sell");
        equal(unknown, actual.unknownVolume, "random reference unknown");
        equal(count, actual.tradeCount, "random reference active trades");
        equal(rows.size(), actual.levels.size(), "random reference rows");
        if (rows.isEmpty()) {
            check(actual.pocTicks == null, "random empty POC");
            return;
        }
        int poc = rows.firstKey();
        int midpointSum = rows.firstKey() + rows.lastKey();
        for (Map.Entry<Integer, long[]> row : rows.entrySet()) {
            long volume = row.getValue()[3];
            long maxVolume = rows.get(poc)[3];
            if (volume > maxVolume || (volume == maxVolume
                    && Math.abs(2 * row.getKey() - midpointSum) < Math.abs(2 * poc - midpointSum))) {
                poc = row.getKey();
            }
        }
        long target = BigDecimal.valueOf(fraction).multiply(BigDecimal.valueOf(total))
                .setScale(0, RoundingMode.CEILING).longValueExact();
        int lower = poc, upper = poc;
        long included = rows.get(poc)[3];
        while (included < target) {
            long below = lower > rows.firstKey() ? denseVolume(rows, lower - 1) : -1;
            long above = upper < rows.lastKey() ? denseVolume(rows, upper + 1) : -1;
            if (below > above) {
                lower--;
                included += below;
            } else if (above > below) {
                upper++;
                included += above;
            } else {
                lower--;
                upper++;
                included += below + above;
            }
        }
        equal(poc * bin, actual.pocTicks, "random reference POC");
        equal(lower * bin, actual.valTicks, "random reference VAL");
        equal(upper * bin + bin - 1, actual.vahTicks, "random reference VAH");
        equal(included, actual.valueAreaVolume, "random reference area volume");
        int index = 0;
        for (Map.Entry<Integer, long[]> row : rows.entrySet()) {
            Level level = actual.levels.get(index++);
            equal(row.getKey() * bin, level.priceTicks, "random row price");
            equal(row.getValue()[0], level.buyVolume, "random row buy");
            equal(row.getValue()[1], level.sellVolume, "random row sell");
            equal(row.getValue()[2], level.unknownVolume, "random row unknown");
            equal(row.getValue()[3], level.totalVolume, "random row total");
        }
    }

    private static long denseVolume(TreeMap<Integer, long[]> rows, int price) {
        return rows.containsKey(price) ? rows.get(price)[3] : 0;
    }

    private static final class ReferenceTrade {
        final long time;
        final int row;
        final long size;
        final Side side;

        ReferenceTrade(long time, int row, long size, Side side) {
            this.time = time;
            this.row = row;
            this.size = size;
            this.side = side;
        }
    }

    private static void expect(Class<? extends Throwable> type, Runnable action, String message) {
        try {
            action.run();
        } catch (Throwable error) {
            check(type.isInstance(error), message + ": got " + error);
            return;
        }
        throw new AssertionError(message + ": exception not thrown");
    }

    private static void equal(long expected, long actual, String message) {
        check(expected == actual, message + " (expected " + expected + ", got " + actual + ")");
    }

    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }
}
