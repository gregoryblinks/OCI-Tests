package com.rollingprofile.bookmap;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.rollingprofile.core.RollingVolumeProfile;
import com.rollingprofile.core.RollingVolumeProfile.Snapshot;

import velox.api.layer1.Layer1ApiProvider;
import velox.api.layer1.data.InstrumentInfo;
import velox.api.layer1.data.TradeInfo;
import velox.api.layer1.messages.CurrentTimeUserMessage;
import velox.api.layer1.messages.Layer1ApiRequestCurrentTimeEvents;
import velox.api.layer1.messages.UserMessageLayersChainCreatedTargeted;

/** Tests real adapter callbacks against a mock Bookmap provider, without a GUI. */
public final class RollingProfileAddonTest {
    private static final String YM = "YMZ6@RITHMIC";
    private static int assertions;

    public static void main(String[] args) throws Exception {
        executedTradesAndAggressorsOnly();
        providerClockExpiresQuietWindow();
        replayRewindAndExplicitDataGap();
        clockReadSkewPreservesValidVolume();
        fractionalTickInstrumentUsesApiTickCoordinates();
        connectionGapsRestartCoverage();
        lifecycleRemovesListenersAndStopsUpdates();
        System.out.println("RollingProfileAddon: " + assertions + " assertions passed");
    }

    private static void executedTradesAndAggressorsOnly() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.trade(YM, 42000, 4, new TradeInfo(false, false));
            harness.trade(YM, 42001, 3, null);
            // Execution-chain flags do not authorize discarding ordinary fills.
            harness.trade(YM, 42001, 2, new TradeInfo(false, true, false, false));
            harness.addon.onDepth(YM, true, 42000, 1_000_000);
            harness.addon.onDepth(YM, false, 42001, 1_000_000);
            harness.addon.onDepth(YM, true, 42000, 0);
            Snapshot snapshot = harness.snapshot(YM);
            equal(19, snapshot.totalVolume, "only executed trades contribute volume");
            equal(12, snapshot.buyVolume, "Bookmap bid aggressor maps to initiating buy side");
            equal(4, snapshot.sellVolume, "Bookmap ask aggressor maps to initiating sell side");
            equal(3, snapshot.unknownVolume, "missing aggressor is retained as unknown");
            equal(42000, snapshot.pocTicks, "YM API tick coordinate is unscaled");
            equal(4, snapshot.tradeCount, "fills counted once, independent of execution-chain flags");
            harness.trade("UNSUBSCRIBED", 42000, 100, new TradeInfo(false, true));
            harness.trade(YM, Double.NaN, 100, new TradeInfo(false, true));
            harness.trade(YM, Double.POSITIVE_INFINITY, 100, new TradeInfo(false, true));
            harness.trade(YM, 42000.1, 100, new TradeInfo(false, true));
            harness.trade(YM, 42000, 0, new TradeInfo(false, true));
            harness.trade(YM, 42000, -1, new TradeInfo(false, true));
            equal(19, harness.snapshot(YM).totalVolume, "invalid or unrelated prints do not affect volume");
        }
    }

    private static void providerClockExpiresQuietWindow() throws Exception {
        try (Harness harness = new Harness()) {
            long window = TimeUnit.MINUTES.toNanos(15);
            harness.pulse(0);
            harness.trade(YM, 42000, 20, new TradeInfo(false, false));
            harness.pulse(TimeUnit.SECONDS.toNanos(100));
            harness.trade(YM, 42010, 15, new TradeInfo(false, true));
            harness.pulse(window - 1);
            equal(35, harness.snapshot(YM).totalVolume, "pre-boundary quiet pulse retains window");
            check(harness.status(YM).startsWith("WARM-UP"), "coverage stays partial before 900 seconds");
            harness.pulse(window);
            equal(15, harness.snapshot(YM).totalVolume, "pulse expires exactly 900-second-old trade");
            equal(42010, harness.snapshot(YM).pocTicks, "quiet expiry changes POC without new buying");
            check(harness.status(YM).startsWith("WINDOW READY"), "full observed interval marks ready");
            harness.pulse(window + TimeUnit.SECONDS.toNanos(100));
            check(!harness.snapshot(YM).hasData(), "quiet profile eventually becomes empty");
        }
    }

    private static void replayRewindAndExplicitDataGap() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(TimeUnit.SECONDS.toNanos(1000));
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.pulse(TimeUnit.SECONDS.toNanos(1100));
            harness.pulse(TimeUnit.SECONDS.toNanos(200));
            equal(0, harness.snapshot(YM).totalVolume, "backward pulse clears old replay timeline");
            harness.trade(YM, 41900, 7, new TradeInfo(false, false));
            equal(7, harness.snapshot(YM).totalVolume, "rewound timeline accepts new trades");
            check(harness.status(YM).startsWith("WARM-UP 0/900s"), "rewind restarts observed coverage");
            harness.pulse(TimeUnit.SECONDS.toNanos(250), true);
            equal(0, harness.snapshot(YM).totalVolume, "skipped-event flag clears uncertain volume");
            check(harness.status(YM).startsWith("WARM-UP 0/900s"), "skipped events restart coverage");
            harness.trade(YM, 41910, 5, new TradeInfo(false, true));
            equal(5, harness.snapshot(YM).totalVolume, "new gap generation receives trades once");
        }
    }

    private static void clockReadSkewPreservesValidVolume() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.pulse(TimeUnit.SECONDS.toNanos(1));
            // CurrentTime events and getCurrentTime can disagree slightly.
            // API documentation also allows getCurrentTime to read next-event
            // time for slow consumers. Neither should erase a valid profile.
            harness.provider.now = TimeUnit.MILLISECONDS.toNanos(950);
            harness.trade(YM, 42001, 7, new TradeInfo(false, false));
            equal(17, harness.snapshot(YM).totalVolume, "future pulse versus provider read cannot clear data");
            harness.provider.now = TimeUnit.SECONDS.toNanos(2);
            harness.trade(YM, 42002, 3, new TradeInfo(false, true));
            harness.pulse(TimeUnit.MILLISECONDS.toNanos(1100));
            equal(20, harness.snapshot(YM).totalVolume, "ordered pulse behind future provider read preserves volume");
            equal(TimeUnit.SECONDS.toNanos(2), harness.snapshot(YM).currentTimeNanos,
                    "per-instrument clock remains monotonic absent authoritative rewind");
            harness.pulse(TimeUnit.MILLISECONDS.toNanos(1050));
            equal(0, harness.snapshot(YM).totalVolume, "backward pulse sequence still triggers replay reset");
        }
    }

    private static void fractionalTickInstrumentUsesApiTickCoordinates() throws Exception {
        try (Harness harness = new Harness()) {
            String alias = "ESZ6@RITHMIC";
            harness.addon.onInstrumentAdded(alias, instrument("ES", .25));
            harness.pulse(0);
            harness.trade(alias, 240000, 6, new TradeInfo(false, true));
            Snapshot snapshot = harness.snapshot(alias);
            equal(240000, snapshot.pocTicks, "API price is already a tick coordinate; never divide by pips");
            equal(6, snapshot.totalVolume, "fractional tick size does not alter contract volume");
            equal(0, harness.snapshot(YM).totalVolume, "instrument profiles are isolated");
            harness.addon.onInstrumentRemoved(alias);
            harness.trade(alias, 240001, 10, new TradeInfo(false, true));
            check(!harness.states().containsKey(alias), "removed instrument cannot receive new profile state");
        }
    }

    private static void connectionGapsRestartCoverage() throws Exception {
        try (Harness harness = new Harness()) {
            harness.pulse(0);
            harness.trade(YM, 42000, 10, new TradeInfo(false, true));
            harness.addon.onConnectionLost(null, "test gap");
            equal(0, harness.snapshot(YM).totalVolume, "disconnect clears incomplete window");
            check(harness.status(YM).startsWith("DISCONNECTED"), "disconnect status is explicit");
            harness.trade(YM, 42001, 15, new TradeInfo(false, true));
            equal(0, harness.snapshot(YM).totalVolume, "trades ignored while disconnected");
            harness.pulse(TimeUnit.SECONDS.toNanos(600));
            harness.addon.onConnectionRestored();
            harness.pulse(TimeUnit.SECONDS.toNanos(1000));
            harness.trade(YM, 42100, 3, new TradeInfo(false, false));
            equal(3, harness.snapshot(YM).totalVolume, "reconnected data has no pre-gap volume");
            check(harness.status(YM).startsWith("WARM-UP 0/900s"), "reconnect starts a fresh observed window");
        }
    }

    private static void lifecycleRemovesListenersAndStopsUpdates() throws Exception {
        Harness harness = new Harness();
        harness.pulse(0);
        harness.trade(YM, 42000, 10, new TradeInfo(false, true));
        check(harness.provider.addedListeners > 0, "constructor registers API listeners");
        check(harness.provider.clockRequests == 1, "activation requests provider clock events once");
        harness.addon.onUserMessage(new UserMessageLayersChainCreatedTargeted(RollingProfileAddon.class, true));
        equal(1, harness.provider.clockRequests, "duplicate activation cannot register duplicate clock stream");
        harness.close();
        equal(harness.provider.addedListeners, harness.provider.removedListeners,
                "finish removes every registered listener");
        equal(1, harness.provider.clockRemovals, "finish unregisters clock event request");
        check(harness.states().isEmpty(), "finish releases per-instrument state");
        harness.trade(YM, 42000, 100, new TradeInfo(false, true));
        check(harness.states().isEmpty(), "late callbacks after finish do not recreate state");
    }

    private static InstrumentInfo instrument(String symbol, double pips) {
        return new InstrumentInfo(symbol, "CBOT", "FUTURE", pips, 5,
                symbol + " integration test", true, 1);
    }

    private static final class Harness implements AutoCloseable {
        final MockProvider provider = new MockProvider();
        final RollingProfileAddon addon = new RollingProfileAddon(provider.proxy());

        Harness() {
            addon.onInstrumentAdded(YM, instrument("YM", 1));
            addon.onUserMessage(new UserMessageLayersChainCreatedTargeted(RollingProfileAddon.class, true));
        }

        void pulse(long now) { pulse(now, false); }

        void pulse(long now, boolean skipped) {
            provider.now = now;
            addon.onUserMessage(new CurrentTimeUserMessage(now, skipped));
        }

        void trade(String alias, double ticks, int size, TradeInfo info) {
            addon.onTrade(alias, ticks, size, info);
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> states() throws Exception {
            return (Map<String, Object>) field(addon, "instruments");
        }

        Snapshot snapshot(String alias) throws Exception {
            Object state = states().get(alias);
            synchronized (state) {
                return ((RollingVolumeProfile) field(state, "profile")).snapshot();
            }
        }

        String status(String alias) throws Exception {
            Object state = states().get(alias);
            synchronized (state) {
                Method frame = state.getClass().getDeclaredMethod("frame", boolean.class);
                frame.setAccessible(true);
                Object result = frame.invoke(state, (Boolean) field(addon, "connected"));
                return (String) field(result, "status");
            }
        }

        @Override public void close() { addon.finish(); }
    }

    private static final class MockProvider implements InvocationHandler {
        long now;
        int addedListeners;
        int removedListeners;
        int clockRequests;
        int clockRemovals;
        final List<Object> messages = new ArrayList<Object>();

        Layer1ApiProvider proxy() {
            return (Layer1ApiProvider) Proxy.newProxyInstance(Layer1ApiProvider.class.getClassLoader(),
                    new Class<?>[] {Layer1ApiProvider.class}, this);
        }

        @Override public Object invoke(Object proxy, Method method, Object[] args) {
            String name = method.getName();
            if (name.equals("getCurrentTime")) return now;
            if (name.equals("getSource")) return "Mock Rithmic";
            if (name.equals("hashCode")) return System.identityHashCode(proxy);
            if (name.equals("equals")) return proxy == args[0];
            if (name.equals("toString")) return "Mock Bookmap Layer1 provider";
            if (name.startsWith("add") && name.toLowerCase().contains("listener")) addedListeners++;
            if (name.startsWith("remove") && name.toLowerCase().contains("listener")) removedListeners++;
            if (name.equals("sendUserMessage")) {
                Object message = args[0];
                messages.add(message);
                if (message instanceof Layer1ApiRequestCurrentTimeEvents) {
                    if (((Layer1ApiRequestCurrentTimeEvents) message).isAdd) clockRequests++;
                    else clockRemovals++;
                }
            }
            Class<?> result = method.getReturnType();
            if (result == boolean.class) return false;
            if (result == int.class) return 0;
            if (result == long.class) return 0L;
            if (result == double.class) return 0.0;
            if (result == float.class) return 0f;
            if (result == short.class) return (short) 0;
            if (result == byte.class) return (byte) 0;
            if (result == char.class) return (char) 0;
            return null;
        }
    }

    private static Object field(Object object, String name) throws Exception {
        Field field = object.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.get(object);
    }

    private static void equal(long expected, long actual, String message) {
        check(expected == actual, message + " (expected " + expected + ", got " + actual + ")");
    }

    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }
}
