package com.rollingprofile.view;

import com.rollingprofile.core.RollingVolumeProfile;
import com.rollingprofile.core.RollingVolumeProfile.Side;
import com.rollingprofile.core.RollingVolumeProfile.Snapshot;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Random;
import javax.imageio.ImageIO;

/** Dependency-free rendering checks, run with java -Djava.awt.headless=true. */
public final class ProfileRendererTest {
    public static void main(String[] args) throws Exception {
        RollingVolumeProfile profile = new RollingVolumeProfile(900_000_000_000L, 1, 0.70);
        Snapshot empty = profile.snapshot();
        checkImage(ProfileRenderer.render(empty, 320, 640, 43900, 44100, 1, "Warming up", true, null), 320, 640);
        checkImage(ProfileRenderer.render(null, 0, -1, 0, 0, 1, null, true, null), 1, 1);
        checkImage(ProfileRenderer.render(empty, 10, 10, 2, 1, 1, "No range", true, null), 10, 10);
        checkImage(ProfileRenderer.render(empty, 320, 80, Double.NaN, 100, 1, "Invalid range", true, null), 320, 80);
        check("11000.00".equals(ProfileRenderer.price(44000, 0.25)), "Quarter tick precision");
        check("44000".equals(ProfileRenderer.price(44000, 1.0)), "YM integer precision");
        check("-1.25".equals(ProfileRenderer.price(-5, 0.25)), "Negative price precision");
        check("44t".equals(ProfileRenderer.price(44, 0)), "Missing tick size should show ticks");
        profile.addTrade(1, 44000, 10, Side.BUY);
        // All three levels coincide. This must render one combined live label.
        Snapshot one = profile.snapshot();
        checkImage(ProfileRenderer.render(one, 300, 90, 43999, 44001, 1, "Synthetic demo", true, one), 300, 90);

        profile.reset();
        Random random = new Random(72815L);
        for (int i = 0; i < 12000; i++) {
            int ticks = 44000 + (int) Math.round(random.nextGaussian() * 13);
            Side side = i % 13 == 0 ? Side.UNKNOWN : (ticks > 44000 || random.nextBoolean() ? Side.BUY : Side.SELL);
            profile.addTrade(i * 70_000_000L, ticks, 1 + random.nextInt(5), side);
        }
        Snapshot synthetic = profile.snapshot();
        BufferedImage preview = ProfileRenderer.render(synthetic, 340, 760,
                43945, 44055, 1, "SYNTHETIC DEMO | full 15m sample", true, null);
        checkImage(preview, 340, 760);
        // Check the gold line at its exact transform, away from the label.
        int pocY = (int) Math.round((44055 - synthetic.pocTicks) / 110.0 * 759);
        boolean alignedGold = false;
        for (int dy = -1; dy <= 1; dy++) {
            Color pocColor = new Color(preview.getRGB(330, pocY + dy), true);
            alignedGold |= pocColor.getRed() > 220 && pocColor.getGreen() > 165 && pocColor.getBlue() < 150;
        }
        check(alignedGold, "POC line should align with the visible price scale within antialiasing tolerance");
        checkImage(ProfileRenderer.render(synthetic, 300, 700, 50000, 50100, 1,
                "All levels off-screen", false, null), 300, 700);
        checkImage(ProfileRenderer.render(synthetic, 300, 700, -1e10, 1e10, 0.25,
                "Synthetic compressed scale", true, one), 300, 700);
        File destination = new File("build/preview.png");
        File parent = destination.getParentFile();
        if (!parent.isDirectory() && !parent.mkdirs()) {
            throw new IllegalStateException("Cannot create " + parent);
        }
        ImageIO.write(preview, "png", destination);
        System.out.println("ProfileRendererTest: passed; synthetic preview: " + destination.getAbsolutePath());
    }

    private static void checkImage(BufferedImage image, int width, int height) {
        check(image != null && image.getWidth() == width && image.getHeight() == height,
                "Image dimensions");
    }

    private static void check(boolean condition, String description) {
        if (!condition) {
            throw new AssertionError(description);
        }
    }
}
