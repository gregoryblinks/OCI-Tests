# Academic OFI v4.0 - MBO receipt diagnostics

No model, training, predictions or trading commands. This is a patch to the
previous history-preserving OFI add-on. It subscribes to Bookmap's per-order
MBO callback; it does not generate simulated market data or substitute trades
or aggregated depth for the MBO feed. Tests in this package are offline only.

## Install in your existing setup

1. Disable/stop the current OFI Python add-on so the old process is no longer
   writing to the archive. Do not run two copies for the same instrument.
2. Replace `C:\BookmapScripts\academic_ofi.py` with this package's
   `academic_ofi.py`. Keep that exact filename, not `academic_ofi (1).py` or
   `academic_ofi.py.txt`. Do not delete the history folder.
3. Keep just these two lines in Bookmap's Python editor:

   ```python
   import runpy
   runpy.run_path(r"C:\BookmapScripts\academic_ofi.py", run_name="__main__")
   ```

   Change the path only if your actual script is elsewhere. Do not paste the
   full large script into the editor that previously had a folding error.
4. Use the same Build operation that worked for your existing add-on, and
   enable the rebuilt add-on for your Rithmic ES chart. Start with one instrument.
5. Confirm the startup message contains `v4.0-mbo-diagnostics`. A different
   version means you are still running a different file or an old process.

No extra pip packages are required. Bookmap provides its `bookmap` module.
Run the loader inside Bookmap's Python API, not by double-clicking it.

## What counts as evidence

Bookmap capability metadata, a subscription acknowledgement, and a delivered
MBO payload are THREE DIFFERENT things. This patch reports them separately.

- `supported=YES`: the instrument's `supported_features['mbo']` flag is True.
  Missing or unrecognised values are UNKNOWN, never silently treated as YES.
- `ACK=YES`: the response callback acknowledged this MBO subscription request.
  This alone does not prove any data arrived or that the snapshot is complete.
  Some Python API builds may lack the documented acknowledgement hook; that
  is reported as HOOK_UNAVAILABLE and does not disable the actual MBO callback.
- `MBO CALLBACK RECEIVED`: emitted once, only after the actual handler receives
  a recognised MBO event with a nonempty string order ID and appropriate payload.
  It includes the event type, order ID, integer price and size for inspection.
- `received=YES`: at least one such payload has arrived in this activation.
  It remains YES afterwards; use `receipt` and `last_age` to assess freshness.

No code path sets receipt confirmation just because the connection supports MBO.

## Where to see counts

Every approximately 5 seconds, the Python console and Bookmap message log get
an `MBO DIAG` line, prefixed by the actual instrument alias. Reporting uses
Bookmap interval callbacks, so callback backlog can delay a report.

Fields:

| Field | Meaning |
| --- | --- |
| `total` | All MBO callbacks received during this instrument activation, including the initial snapshot and malformed events |
| `BID_NEW`, `ASK_NEW`, `REPLACE`, `CANCEL`, `OTHER` | Counts by event type since activation; these sum to `total` |
| `events/s` | Count divided by the measured sample interval, normally about one second; the exact count and elapsed duration follow in parentheses |
| `after5s` | Callbacks received after the first five seconds since activation, NOT a guaranteed count of post-snapshot/live events |
| `last_age` | Seconds since the most recent callback reached Python; NEVER means none have arrived |
| `applied` | Events successfully applied to the reconstructed local book; deliberately separate from receipt count |
| `book` | VALID, EMPTY, NO_BID, NO_ASK, LOCKED or CROSSED |
| `TRACKING` / `FROZEN_AFTER_ERROR` | Whether the local book is still being updated or was stopped by a processing error |
| `bid`, `ask` | Actual reconstructed prices and queue sizes, converted using Bookmap's instrument multipliers |
| `spread_ticks` | Ask price level minus bid price level; zero means locked, negative means crossed |
| `orders` | Current unique order IDs in the reconstructed book, with bid/ask counts; not all IDs ever seen |
| `invalid_after_warmup` | Applied events producing an invalid top of book after OFI startup |
| `invalid_for` | Duration of the current uninterrupted invalid-book episode |
| `errors` | Caught event-processing errors; the error text and OFI state are also displayed |
| `OFI` | WARMUP, ACTIVE, WAIT_VALID_BBO or STOPPED_ERROR |
| `bridges` | Estimated transitions across invalid observations, inherited from v3 and now explicitly marked |
| `delayed` | The supplied `isDelayed` capability flag, or UNKNOWN; not a measurement of feed latency |

Counters run before book validation and archive-error checks. Even after an
OFI processing failure, new incoming callbacks increase `total`. If receipt
counts rise while `applied` stops, the feed is reaching the script but the
local OFI/book processing has stopped. If both rise and the book is CROSSED,
MBO is arriving but the reconstruction is currently unusable for exact OFI.

`receipt=NO_RECENT_MBO_CALLBACKS` means no recognised payload was received in
the last five seconds. It is NOT a disconnect detector: a quiet market, a
closed session, buffering, replay or a broken connection can all produce silence.

## Chart diagnostics

Three additional bottom-panel lines are registered:

- `MBO - Events per second (received)`
- `MBO - Last event age (seconds)`
- `MBO - Book valid (1 yes, 0 no)`

They are enabled by default for troubleshooting. Their different units can
stretch the shared chart scale. Turn off `Show MBO diagnostic lines` afterwards;
that only hides these plots and does not stop OFI or MBO counters.

`MBO diagnostics in message log (every 5s)` controls console/message summaries.
Turning it off does not erase history or stop the periodic archived summaries.
All OFI lines and the cumulative-OFI setting remain available.

## What this can and cannot confirm about "live"

The official Python API documents an initial snapshot followed by real-time
MBO events. Its documented MBO callback has no exchange timestamp, snapshot-end
flag, sequence number or explicit live/replay provenance field. Therefore:

1. Delivered per-order callbacks are directly observed and counted.
2. Continuing counts and a small last-event age show ongoing callback delivery.
3. These measurements ALONE cannot establish whether the source is live,
   delayed, replayed, buffered or complete. `live_source=UNVERIFIED` is deliberate.

Use Bookmap's live Rithmic connection, not replay, for this version. Compare
the report's instrument and bid/ask with the active chart. No five-minute wait
is required to establish receipt. The OFI 1/3/5-minute lookbacks are unrelated
to confirming the data subscription. `last_age` is local callback freshness,
NOT exchange-to-application latency.

## History preservation and bridge caveat

The archive path, schema and instrument identity calculation are unchanged:

`%USERPROFILE%\Bookmap_OFI_History`

There are no automatic delete/reset statements. Existing recorded OFI stays
in the same per-instrument SQLite file, including across app restarts. Periodic
JSON counter snapshots are appended as `MBO_DIAGNOSTIC` records. The live counters
start at zero on a fresh instrument activation and have a distinct session ID;
previous archived snapshots and OFI totals remain intact. They are not a
full raw-MBO event journal. Diagnostic snapshots may be unavailable after a
disk failure even though the console and receipt counters keep updating.

The mathematical CKS four-term event formula is unchanged. V3's bridging of
the last valid BBO to the next valid BBO is retained, but now marked
`ESTIMATED_BRIDGE` in the archive and on the associated OFI record. Such an
endpoint comparison is NOT generally equal to the sum of all intermediate
OFI events; the missing path cannot be recovered from endpoints. The patch
never claims an invalid book is healthy or invents missing order messages.

During invalid observations the last valid comparison state and history are
retained, but no new valid OFI contribution can be computed. Receipt counters
and book reconstruction continue unless a hard processing error occurs.
OFI Data status is -1 for an unusable current book or a stopped calculation,
0 during startup or while a lookback contains a detected invalid episode,
and 1 after all lookbacks contain a continuous valid-book segment. Status 1
is not a guarantee of exchange-feed completeness. The patch resets only the
quality/warmup indicator after a bridge, not saved history.

Old v3 archive rows are not rewritten to add these newer quality annotations.
Prior bridges in old data may therefore be unmarked. There is no attempt to
reconstruct or retroactively validate old feed data.

Rolling windows continue to age out older events; those events stay in the
archive and cumulative total. Plotting old chart points on a recreated
indicator is separate and not implemented by this patch.

Writes are asynchronous and normally committed in batches about once a second.
Forced termination, power failure, disk failure or a full writer queue can
lose uncommitted tail records. Orderly shutdown flushes. A disk/history error
stops OFI accumulation rather than pretending the records were safely saved.

## Verification

Run from this folder with a normal Python interpreter:

```text
python -m unittest -v test_core test_diagnostics
```

These are 106 offline tests, including the existing formula/book/rolling/archive
regressions, modified expectations for v3 bridging, callback confirmation,
capability-vs-receipt separation, acknowledgement handling, counters after
errors, exact sampled rates, invalid-book reasons, per-instrument isolation,
settings, plots and persisted diagnostic summaries. The package includes the
actual run log. No live Bookmap or Rithmic session was available for testing.

An additional offline upgrade check created a SQLite history file with the
uploaded v3 implementation, opened it with v4, checked that totals were
restored and every old row was unchanged, and ran SQLite integrity_check.
See `upgrade_test.txt`. This is a compatibility check, not a test on your files.

## Official API references checked

- https://github.com/BookmapAPI/python-api/blob/master/README.md
  Sections: start_addon, subscribe_to_mbo, add_mbo_handler,
  add_response_data_handler, add_on_interval_handler, register_indicator,
  add_point, send_user_message, prices and sizes.
- https://bookmap.com/en/partner/rithmic

No functionality in this package independently contacts Rithmic or the exchange.
