"""Simulated callbacks only: these tests do NOT contact Bookmap or Rithmic."""
import ast
import json
import math
import sqlite3
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

import academic_ofi as ofi
import test_core as core


class StatisticsTests(unittest.TestCase):
    def test_capabilities_absent_are_unknown(self):
        s = ofi.MBOStatistics(0)
        self.assertEqual(s.mbo_supported, 'UNKNOWN')
        self.assertEqual(s.delayed_reported, 'UNKNOWN')
        self.assertFalse(s.payloads)
        self.assertEqual(s.receipt_state(0), 'NO_CALLBACKS')

    def test_capabilities_do_not_prove_receipt(self):
        s = ofi.MBOStatistics(0, {'mbo': True, 'isDelayed': False})
        self.assertEqual(s.mbo_supported, 'YES')
        self.assertEqual(s.delayed_reported, 'NO')
        self.assertEqual(s.total, 0)
        self.assertEqual(s.receipt_state(99), 'NO_CALLBACKS')

    def test_string_feature_flag_not_treated_as_verified(self):
        s = ofi.MBOStatistics(0, {'mbo': 'false', 'isDelayed': 'true'})
        self.assertEqual(s.mbo_supported, 'UNKNOWN')
        self.assertEqual(s.delayed_reported, 'UNKNOWN')

    def test_exact_counts_by_event_type_and_first_proof_once(self):
        s = ofi.MBOStatistics(0)
        self.assertTrue(s.record(.1, 'BID_NEW', 'b', 100, 10))
        self.assertFalse(s.record(.2, 'ASK_NEW', 'a', 101, 10))
        s.record(.3, 'REPLACE', 'b', 100, 11)
        s.record(.4, 'CANCEL', 'a', 0, 0)
        self.assertEqual(s.total, 4)
        self.assertEqual(s.payloads, 4)
        self.assertEqual(s.counts, {'BID_NEW': 1, 'ASK_NEW': 1, 'REPLACE': 1, 'CANCEL': 1, 'OTHER': 0})
        self.assertEqual(s.receipt_state(.5), 'MBO_RECEIVED_STARTUP')

    def test_malformed_callbacks_are_counted_but_not_proof(self):
        s = ofi.MBOStatistics(0)
        self.assertFalse(s.record(.1, 'SOMETHING', 'x', 100, 10))
        self.assertFalse(s.record(.2, 'BID_NEW', '', 100, 10))
        self.assertFalse(s.record(.3, 'ASK_NEW', 'a', 'not-price', 10))
        self.assertFalse(s.record(.4, 'BID_NEW', 'x', 100, 0))
        self.assertEqual(s.total, 4)
        self.assertEqual(s.bad_payloads, 4)
        self.assertEqual(s.receipt_state(1), 'NO_VALID_MBO_PAYLOAD')

    def test_cancel_payload_price_size_can_be_ignored(self):
        s = ofi.MBOStatistics(0)
        self.assertTrue(s.record(.1, 'CANCEL', 'valid-id', None, None))
        self.assertEqual(s.payloads, 1)

    def test_rate_uses_measured_elapsed_not_assumed_one_second(self):
        s = ofi.MBOStatistics(0)
        for i in range(30):
            s.record(.2, 'BID_NEW', str(i), 100, 1)
        self.assertTrue(s.sample(2.5))
        self.assertEqual(s.rate, 12)
        self.assertEqual(s.sample_seconds, 2.5)
        self.assertEqual(s.sample_count, 30)
        self.assertEqual(s.type_rates['BID_NEW'], 12)
        self.assertFalse(s.sample(2.5, force=True))
        self.assertTrue(s.sample(3.5))
        self.assertEqual(s.rate, 0)
        self.assertEqual(s.total, 30)

    def test_stale_age_is_not_zero_and_rate_decays(self):
        s = ofi.MBOStatistics(0)
        self.assertIsNone(s.age(2))
        s.record(10, 'BID_NEW', 'b', 100, 1)
        self.assertEqual(s.receipt_state(10), 'RECENT_MBO_CALLBACKS')
        self.assertEqual(s.receipt_state(16), 'NO_RECENT_MBO_CALLBACKS')
        self.assertEqual(s.age(16), 6)
        s.sample(16)
        s.sample(17)
        self.assertEqual(s.rate, 0)

    def test_post_five_second_counts_are_time_based_not_snapshot_completion(self):
        s = ofi.MBOStatistics(0)
        s.record(4, 'BID_NEW', 'b', 100, 1)
        s.record(5, 'ASK_NEW', 'a', 101, 1)
        s.record(6, 'REPLACE', 'a', 101, 2)
        s.record(7, 'CANCEL', 'a', 0, 0)
        self.assertEqual(s.after_5s, 3)
        self.assertEqual(s.updates_after_5s, 2)

    def test_invalid_reason_and_duration_count_even_before_warmup(self):
        s = ofi.MBOStatistics(0)
        s.book_applied(1, 'NO_ASK', True)
        s.book_applied(2, 'LOCKED', False)
        self.assertEqual(s.invalid_since, 1)
        self.assertEqual(s.invalid_applied, 2)
        self.assertEqual(s.invalid_after_warmup, 1)
        s.book_applied(3, 'VALID', False)
        self.assertIsNone(s.invalid_since)
        self.assertEqual(s.applied, 3)

    def test_callback_sample_is_bounded(self):
        s = ofi.MBOStatistics(0)
        s.record(.1, 'BID_NEW', 'x' * 10000, 100, 1)
        self.assertEqual(len(s.last_event['order_id']), 96)


class TopStateTests(unittest.TestCase):
    def test_all_causes_are_distinguished_with_real_quotes_retained(self):
        b = ofi.MBOBook()
        self.assertEqual(b.top_state(), ('EMPTY', None, None))
        b.apply('BID_NEW', 'b', 100, 10)
        self.assertEqual(b.top_state(), ('NO_ASK', (100, 10), None))
        b.apply('ASK_NEW', 'a', 100, 12)
        self.assertEqual(b.top_state(), ('LOCKED', (100, 10), (100, 12)))
        b.apply('REPLACE', 'a', 99, 12)
        self.assertEqual(b.top_state()[0], 'CROSSED')
        b.apply('REPLACE', 'a', 101, 12)
        self.assertEqual(b.top_state()[0], 'VALID')
        b.apply('CANCEL', 'b', 0, 0)
        self.assertEqual(b.top_state(), ('NO_BID', None, (101, 12)))

    def test_endpoint_ofi_is_not_generally_additive(self):
        # Documents why a retained v3 bridge must NOT be called exact missing flow.
        a, b, c = (100, 10, 103, 8), (101, 20, 103, 8), (100, 30, 103, 8)
        path_sum = ofi.academic_ofi_event(a, b) + ofi.academic_ofi_event(b, c)
        self.assertNotEqual(path_sum, ofi.academic_ofi_event(a, c))


class DiagnosticsAdapterTests(unittest.TestCase):
    # Reuse setup helpers, not inherited test methods (no inflated test counts).
    setUp = core.AdapterTests.setUp
    tearDown = core.AdapterTests.tearDown
    subscribe = core.AdapterTests.subscribe
    ready = core.AdapterTests.ready

    def test_receipt_proof_generated_by_actual_handler_only_once(self):
        self.subscribe()
        self.assertFalse(any('MBO CALLBACK RECEIVED' in n for n in self.fake.notices))
        ofi.handle_mbo_event(None, 'TEST', 'BID_NEW', 'b', 100, 10)
        ofi.handle_mbo_event(None, 'TEST', 'ASK_NEW', 'a', 102, 12)
        self.assertEqual(sum('MBO CALLBACK RECEIVED' in n for n in self.fake.notices), 1)
        s = ofi._states['TEST']
        self.assertEqual(s.stats.total, 2)
        self.assertEqual(s.stats.applied, 2)

    def test_ack_alone_does_not_prove_mbo(self):
        self.subscribe()
        s = ofi._states['TEST']
        req = s.stats.request_id
        ofi.handle_data_response(None, req)
        self.assertIsNotNone(s.stats.ack_at)
        d = ofi._diagnostic_snapshot('TEST', s, 0)
        self.assertTrue(d['ack_received'])
        self.assertFalse(d['mbo_payload_received'])
        self.assertEqual(d['receipt_state'], 'NO_CALLBACKS')

    def test_late_ack_for_old_subscription_is_ignored(self):
        self.subscribe()
        old = ofi._states['TEST']
        old_req = old.stats.request_id
        self.clock.return_value = 1
        self.subscribe()
        new = ofi._states['TEST']
        ofi.handle_data_response(None, old_req)
        self.assertIsNone(new.stats.ack_at)
        self.assertIsNot(old, new)

    def test_counters_keep_running_after_reconstruction_failure(self):
        s = self.ready()
        self.clock.return_value = 7
        ofi.handle_mbo_event(None, 'TEST', 'CANCEL', 'missing', 0, 0)
        self.assertTrue(s.failed)
        total, applied, recorded = s.stats.total, s.stats.applied, s.history.total
        self.clock.return_value = 8
        ofi.handle_mbo_event(None, 'TEST', 'BID_NEW', 'later', 100, 5)
        self.assertEqual(s.stats.total, total + 1)
        self.assertEqual(s.stats.applied, applied)
        self.assertEqual(s.history.total, recorded)
        self.assertEqual(s.stats.processing_errors, 1)
        d = ofi._diagnostic_snapshot('TEST', s, 8)
        self.assertTrue(d['mbo_payload_received'])
        self.assertEqual(d['book_tracking'], 'FROZEN_AFTER_ERROR')
        self.assertFalse(d['book_usable'])
        self.assertEqual(d['ofi_mode'], 'STOPPED_ERROR')

    def test_counters_keep_running_after_archive_failure(self):
        s = self.ready()
        self.clock.return_value = 7
        with patch.object(s.history.archive, 'error', 'Disk error for test'):
            ofi.handle_mbo_event(None, 'TEST', 'REPLACE', 'b', 100, 12)
            self.assertTrue(s.failed)
            before = s.stats.total
            self.clock.return_value = 11
            ofi.handle_mbo_event(None, 'TEST', 'REPLACE', 'b', 100, 13)
            ofi.on_interval(None, 'TEST')
            self.assertEqual(s.stats.total, before + 1)
            self.assertTrue(any('MBO DIAG' in n and 'STOPPED_ERROR' in n for n in self.fake.notices))
            self.assertEqual(s.history.total, 5)

    def test_invalid_book_does_not_reset_counts_or_history(self):
        s = self.ready()
        self.clock.return_value = 7
        ofi.handle_mbo_event(None, 'TEST', 'BID_NEW', 'cross', 103, 50)
        d = ofi._diagnostic_snapshot('TEST', s, 9)
        self.assertEqual(d['callbacks_total_including_snapshot'], 4)
        self.assertEqual(d['reconstructed_book'], 'CROSSED')
        self.assertEqual(d['spread_ticks'], -1)
        self.assertEqual(d['current_invalid_seconds'], 2)
        self.assertEqual(d['ofi_mode'], 'WAIT_VALID_BBO')
        self.assertEqual(s.history.total, 5)
        self.assertIsNone(s.failed)

    def test_bbo_prices_and_sizes_and_active_orders_are_reported(self):
        s = self.ready()
        d = ofi._diagnostic_snapshot('TEST', s, 6)
        self.assertEqual(d['bid']['price'], 25)
        self.assertEqual(d['bid']['size'], 15)
        self.assertEqual(d['ask']['price'], 25.5)
        self.assertEqual(d['spread_ticks'], 2)
        self.assertEqual(d['active_order_ids'], 3)
        self.assertEqual((d['bid_order_ids'], d['ask_order_ids']), (2, 1))
        self.assertEqual(d['source_live_vs_replay'], 'NOT_VERIFIED_BY_CALLBACK')
        self.assertEqual(d['snapshot_complete'], 'NOT_EXPOSED_BY_CALLBACK')

    def test_no_event_report_and_plot_age_never_are_not_fake_zero(self):
        self.subscribe()
        s = ofi._states['TEST']
        self.clock.return_value = 10
        ofi.on_interval(None, 'TEST')
        d = ofi._diagnostic_snapshot('TEST', s, 10)
        self.assertEqual(d['callbacks_total_including_snapshot'], 0)
        self.assertIsNone(d['last_event_age_seconds'])
        self.assertFalse(d['mbo_payload_received'])
        ages = [v for a, i, v in self.fake.points if i == s.indicators[ofi.MBO_AGE_KEY]]
        self.assertTrue(math.isnan(ages[-1]))
        self.assertTrue(any('received=NO' in n and 'last_age=NEVER' in n for n in self.fake.notices))

    def test_message_is_throttled_and_archived_as_json(self):
        s = self.ready()
        # Ready emits report at 5.1 only. No per-event message spam.
        reports = [n for n in self.fake.notices if 'MBO DIAG' in n]
        self.assertEqual(len(reports), 1)
        self.clock.return_value = 7
        ofi.on_interval(None, 'TEST')
        self.assertEqual(sum('MBO DIAG' in n for n in self.fake.notices), 1)
        self.clock.return_value = 10.2
        ofi.on_interval(None, 'TEST')
        self.assertEqual(sum('MBO DIAG' in n for n in self.fake.notices), 2)
        s.history.archive.flush()
        with closing(sqlite3.connect(str(s.history.archive.path))) as conn:
            notes = conn.execute("SELECT note FROM records WHERE kind='MBO_DIAGNOSTIC' ORDER BY seq").fetchall()
        self.assertEqual(len(notes), 2)
        d = json.loads(notes[-1][0])
        self.assertEqual(d['callbacks_total_including_snapshot'], 3)
        self.assertEqual(d['alias'], 'TEST')

    def test_message_and_plot_settings_do_not_stop_recording(self):
        s = self.ready()
        ofi.on_settings_change(None, 'TEST', ofi.MBO_LOG_SETTING, 'BOOLEAN', 'false')
        ofi.on_settings_change(None, 'TEST', ofi.MBO_PLOTS_SETTING, 'BOOLEAN', 'false')
        before = sum('MBO DIAG' in n for n in self.fake.notices)
        self.clock.return_value = 11
        ofi.handle_mbo_event(None, 'TEST', 'REPLACE', 'b', 100, 11)
        ofi.on_interval(None, 'TEST')
        self.assertEqual(sum('MBO DIAG' in n for n in self.fake.notices), before)
        self.assertEqual(s.stats.total, 4)
        points = [v for a, i, v in self.fake.points if i == s.indicators[ofi.MBO_RATE_KEY]]
        self.assertTrue(math.isnan(points[-1]))
        self.assertEqual(s.history.total, 6)

    def test_last_counter_report_on_unsubscribe_and_fresh_counter_session(self):
        s = self.ready()
        original = s.stats.session_id
        self.clock.return_value = 7
        ofi.handle_unsubscribe_instrument(None, 'TEST')
        self.clock.return_value = 8
        self.subscribe()
        new = ofi._states['TEST']
        self.assertNotEqual(new.stats.session_id, original)
        self.assertEqual(new.stats.total, 0)
        self.assertEqual(new.history.total, 5)
        self.assertIs(new.history, s.history)
        s.history.archive.flush()
        with closing(sqlite3.connect(str(s.history.archive.path))) as conn:
            notes = conn.execute("SELECT note FROM records WHERE kind='MBO_DIAGNOSTIC' ORDER BY seq").fetchall()
        self.assertEqual(json.loads(notes[-1][0])['callbacks_total_including_snapshot'], 3)

    def test_counters_and_pending_requests_are_per_instrument(self):
        self.subscribe('A')
        self.subscribe('B')
        ofi.handle_mbo_event(None, 'A', 'BID_NEW', 'same', 100, 10)
        self.assertEqual(ofi._states['A'].stats.total, 1)
        self.assertEqual(ofi._states['B'].stats.total, 0)
        self.assertNotEqual(ofi._states['A'].stats.request_id, ofi._states['B'].stats.request_id)

    def test_subscription_exception_is_not_success(self):
        def raises(*args):
            raise RuntimeError('Simulated subscribe error')
        self.fake.subscribe_to_mbo = raises
        self.subscribe()
        s = ofi._states['TEST']
        self.assertFalse(s.stats.request_sent)
        self.assertIsNotNone(s.stats.request_error)
        self.assertFalse(s.stats.payloads)
        self.clock.return_value = 5
        ofi.on_interval(None, 'TEST')
        self.assertTrue(any('MBO DIAG' in n for n in self.fake.notices))

    def test_ack_hook_available_under_both_documented_names(self):
        for name in ('add_response_data_handler', 'on_response_data_handler'):
            with self.subTest(name=name):
                called = []
                with patch.object(self.fake, name, lambda *args: called.append(args), create=True):
                    self.assertTrue(ofi._register_data_response_handler('ADDON'))
                self.assertEqual(called, [('ADDON', ofi.handle_data_response)])

    def test_missing_ack_hook_does_not_block_subscription(self):
        self.assertFalse(ofi._register_data_response_handler(None))
        self.subscribe()
        self.assertEqual(len(self.fake.subscriptions), 1)
        ofi.handle_mbo_event(None, 'TEST', 'BID_NEW', 'b', 100, 10)
        self.assertEqual(ofi._states['TEST'].stats.payloads, 1)

    def test_new_diagnostic_lines_are_registered_and_plot(self):
        s = self.ready()
        for key in (ofi.MBO_RATE_KEY, ofi.MBO_AGE_KEY, ofi.MBO_VALID_KEY):
            self.assertIn(key, s.indicators)
            self.assertTrue(any(i == s.indicators[key] for a, i, v in self.fake.points))
        self.assertIn(('TEST', s.indicators[ofi.MBO_VALID_KEY], 1.0), self.fake.points)

    def test_invalid_quote_produces_zero_validity_line_not_positive(self):
        s = self.ready()
        self.clock.return_value = 7
        ofi.handle_mbo_event(None, 'TEST', 'CANCEL', 'a', 0, 0)
        ofi.on_interval(None, 'TEST')
        self.assertIn(('TEST', s.indicators[ofi.MBO_VALID_KEY], 0.0), self.fake.points)

    def test_malformed_id_stops_book_but_counts_callback(self):
        self.subscribe()
        ofi.handle_mbo_event(None, 'TEST', 'BID_NEW', '', 100, 1)
        s = ofi._states['TEST']
        self.assertEqual(s.stats.total, 1)
        self.assertEqual(s.stats.payloads, 0)
        self.assertEqual(s.stats.bad_payloads, 1)
        self.assertTrue(s.failed)


if __name__ == '__main__':
    unittest.main(verbosity=2)
