"""Offline tests. Run: python -m unittest -v test_academic_ofi.py

No Bookmap installation or market connection is required for these tests.
The adapter tests use a stub; they are NOT a live Bookmap/Rithmic integration test.
"""
import ast
import math
import random
import unittest
from pathlib import Path
from unittest.mock import patch

import academic_ofi as ofi


class FormulaTests(unittest.TestCase):
    def setUp(self):
        self.old = (100, 10, 102, 12)

    def test_unchanged_book(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, self.old), 0)

    def test_bid_add(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 15, 102, 12)), 5)

    def test_bid_size_reduction(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 7, 102, 12)), -3)

    def test_ask_add(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 102, 20)), -8)

    def test_ask_size_reduction(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 102, 8)), 4)

    def test_bid_price_improves(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (101, 3, 102, 12)), 3)

    def test_bid_price_worsens(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (99, 999, 102, 12)), -10)

    def test_ask_price_improves(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 101, 7)), -7)

    def test_ask_price_worsens(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (100, 10, 103, 999)), 12)

    def test_both_sides_change(self):
        self.assertEqual(ofi.academic_ofi_event(self.old, (101, 5, 103, 90)), 17)

    def test_randomized_against_piecewise_definition(self):
        rng = random.Random(7)
        for _ in range(10000):
            old = (100, rng.randrange(1, 100), 105, rng.randrange(1, 100))
            new = (100 + rng.randrange(-1, 2), rng.randrange(1, 100),
                   105 + rng.randrange(-1, 2), rng.randrange(1, 100))
            bid = new[1] if new[0] > old[0] else (-old[1] if new[0] < old[0] else new[1] - old[1])
            ask = -new[3] if new[2] < old[2] else (old[3] if new[2] > old[2] else old[3] - new[3])
            self.assertEqual(ofi.academic_ofi_event(old, new), bid + ask)


class BookTests(unittest.TestCase):
    def setUp(self):
        self.book = ofi.MBOBook()
        self.book.apply("BID_NEW", "b1", 100, 10)
        self.book.apply("ASK_NEW", "a1", 102, 12)

    def test_aggregates_multiple_orders(self):
        self.book.apply("BID_NEW", "b2", 100, 4)
        self.assertEqual(self.book.bbo(), (100, 14, 102, 12))

    def test_deeper_events_have_no_l1_effect(self):
        old = self.book.bbo()
        self.book.apply("ASK_NEW", "deep", 200, 10000)
        self.assertEqual(ofi.academic_ofi_event(old, self.book.bbo()), 0)

    def test_replace_price_and_size_atomic(self):
        old = self.book.bbo()
        self.book.apply("REPLACE", "b1", 101, 4)
        self.assertEqual(self.book.bbo(), (101, 4, 102, 12))
        self.assertEqual(ofi.academic_ofi_event(old, self.book.bbo()), 4)

    def test_zero_size_replace_removes_order(self):
        self.book.apply("BID_NEW", "b2", 99, 100)
        self.book.apply("REPLACE", "b1", 100, 0)
        self.assertEqual(self.book.bbo(), (99, 100, 102, 12))
        self.assertNotIn("b1", self.book.orders)

    def test_cancel_uses_stored_payload(self):
        self.book.apply("BID_NEW", "b2", 99, 7)
        old = self.book.bbo()
        self.book.apply("CANCEL", "b1", 0, 0)
        self.assertEqual(ofi.academic_ofi_event(old, self.book.bbo()), -10)

    def test_unknown_replace_rejected(self):
        with self.assertRaises(ofi.BookIntegrityError):
            self.book.apply("REPLACE", "missing", 100, 5)

    def test_unknown_cancel_rejected(self):
        with self.assertRaises(ofi.BookIntegrityError):
            self.book.apply("CANCEL", "missing", 0, 0)

    def test_duplicate_new_rejected(self):
        with self.assertRaises(ofi.BookIntegrityError):
            self.book.apply("BID_NEW", "b1", 100, 1)
        self.assertEqual(self.book.bbo(), (100, 10, 102, 12))

    def test_invalid_size_rejected_without_book_change(self):
        with self.assertRaises(ofi.BookIntegrityError):
            self.book.apply("REPLACE", "b1", 100, -4)
        self.assertEqual(self.book.bbo(), (100, 10, 102, 12))

    def test_empty_and_locked_books_invalid(self):
        self.book.apply("CANCEL", "b1", 0, 0)
        self.assertIsNone(self.book.bbo())
        self.book.apply("BID_NEW", "b2", 102, 5)
        self.assertIsNone(self.book.bbo())

    def test_heap_compaction(self):
        for index in range(3000):
            self.book.apply("ASK_NEW", "deep", 200 + index, 1)
            self.book.apply("CANCEL", "deep", 0, 0)
        self.assertLessEqual(len(self.book.heaps[False]), 1028)
        self.assertEqual(self.book.bbo(), (100, 10, 102, 12))

    def test_randomized_book_matches_reaggregation(self):
        rng = random.Random(11)
        for index in range(4000):
            action = rng.randrange(3)
            if action == 0 or not self.book.orders:
                side = bool(rng.randrange(2))
                price = rng.randrange(90, 101) if side else rng.randrange(102, 113)
                self.book.apply("BID_NEW" if side else "ASK_NEW", str(index), price, rng.randrange(1, 50))
            else:
                key = rng.choice(list(self.book.orders))
                side = self.book.orders[key][0]
                price = rng.randrange(90, 101) if side else rng.randrange(102, 113)
                self.book.apply("REPLACE" if action == 1 else "CANCEL", key, price, rng.randrange(1, 50))
            expected = {True: {}, False: {}}
            for side, price, size in self.book.orders.values():
                expected[side][price] = expected[side].get(price, 0) + size
            self.assertEqual(self.book.levels, expected)
            if expected[True] and expected[False]:
                b, a = max(expected[True]), min(expected[False])
                self.assertEqual(self.book.bbo(), (b, expected[True][b], a, expected[False][a]))


class RollingTests(unittest.TestCase):
    def test_empty_is_zero(self):
        self.assertEqual(ofi.RollingOFI().values(0), {60: 0, 180: 0, 300: 0})

    def test_exact_horizon_boundaries(self):
        r = ofi.RollingOFI()
        r.add(10.0, 5)
        self.assertEqual(r.values(69.999)[60], 5)
        self.assertEqual(r.values(70.0)[60], 0)
        self.assertEqual(r.values(190.0)[180], 0)
        self.assertEqual(r.values(310.0)[300], 0)

    def test_same_timestamp_multiple_events(self):
        r = ofi.RollingOFI()
        r.add(1.0, 10)
        r.add(1.0, -3)
        self.assertEqual(r.values(1.0)[60], 7)

    def test_no_events_still_expires_flow(self):
        r = ofi.RollingOFI()
        r.add(1, 17)
        self.assertEqual(r.values(1000), {60: 0, 180: 0, 300: 0})
        r.add(1001, -2)
        self.assertEqual(r.values(1001), {60: -2, 180: -2, 300: -2})

    def test_non_monotonic_time_rejected(self):
        r = ofi.RollingOFI()
        r.add(10, 1)
        with self.assertRaises(ValueError):
            r.add(9, 2)

    def test_nan_time_rejected(self):
        with self.assertRaises(ValueError):
            ofi.RollingOFI().values(math.nan)

    def test_randomized_against_direct_event_sums_and_compaction(self):
        rng = random.Random(91)
        r = ofi.RollingOFI()
        r.COMPACT_THRESHOLD = 32
        history, now = [], 0.0
        for index in range(12000):
            now += rng.random() * 0.5
            delta = rng.randrange(-100, 101)
            r.add(now, delta)
            history.append((now, delta))
            if index % 37 == 0:
                actual = r.values(now)
                for h in ofi.WINDOWS_SECONDS:
                    self.assertEqual(actual[h], sum(d for ts, d in history if ts > now - h))
        r.values(now + 1000)
        self.assertLess(len(r.timestamps), 32)


class StateTests(unittest.TestCase):
    def ready_state(self, multiplier=1):
        s = ofi.InstrumentState(multiplier, 0)
        s.consume(0.1, "BID_NEW", "b", 100, 10)
        s.consume(0.2, "ASK_NEW", "a", 102, 12)
        self.assertFalse(s.start_if_ready(0.2))
        self.assertTrue(s.start_if_ready(5.3))
        return s

    def test_startup_events_not_counted(self):
        s = self.ready_state()
        self.assertEqual(s.displayed_values(5.3), {60: 0.0, 180: 0.0, 300: 0.0})

    def test_incremental_flow(self):
        s = self.ready_state()
        s.consume(6, "BID_NEW", "b2", 100, 5)
        s.consume(7, "REPLACE", "a", 102, 8)
        self.assertEqual(s.displayed_values(8)[60], 9)

    def test_size_multiplier_conversion(self):
        s = self.ready_state(10)
        s.consume(6, "BID_NEW", "b2", 100, 5)
        self.assertEqual(s.displayed_values(6)[60], 0.5)

    def test_partial_windows_can_be_hidden(self):
        s = self.ready_state()
        s.show_partial = False
        self.assertTrue(math.isnan(s.displayed_values(10)[60]))
        vals = s.displayed_values(66)
        self.assertEqual(vals[60], 0)
        self.assertTrue(math.isnan(vals[180]))

    def test_invalid_book_discards_history(self):
        s = self.ready_state()
        s.consume(6, "BID_NEW", "b2", 100, 5)
        message = s.consume(7, "CANCEL", "a", 0, 0)
        self.assertIsNotNone(message)
        self.assertIsNone(s.started_at)
        self.assertTrue(math.isnan(s.displayed_values(7)[60]))

    def test_reset_keeps_book_but_clears_flow(self):
        s = self.ready_state()
        s.consume(6, "BID_NEW", "b2", 100, 5)
        s.reset_flow(7)
        self.assertEqual(s.book.bbo(), (100, 15, 102, 12))
        self.assertTrue(s.start_if_ready(12.1))
        self.assertEqual(s.displayed_values(12.1)[60], 0)

    def test_first_interval_is_required_before_start_guard(self):
        s = ofi.InstrumentState(1, 0)
        s.consume(0, "BID_NEW", "b", 100, 10)
        s.consume(0, "ASK_NEW", "a", 102, 12)
        self.assertFalse(s.start_if_ready(100))
        self.assertFalse(s.start_if_ready(104))
        self.assertTrue(s.start_if_ready(105))


class FakeAPI:
    def __init__(self):
        self.registered, self.points, self.notices, self.subscriptions = [], [], [], []
    def register_indicator(self, addon, alias, request_id, name, graph, **kwargs):
        self.registered.append((alias, request_id, name))
    def add_boolean_settings_parameter(self, *args, **kwargs):
        pass
    def add_number_settings_parameter(self, *args, **kwargs):
        pass
    def add_label_to_settings(self, *args):
        pass
    def subscribe_to_mbo(self, addon, alias, request_id):
        self.subscriptions.append((alias, request_id))
    def send_user_message(self, addon, alias, text):
        self.notices.append(text)
    def add_point(self, addon, alias, indicator_id, value):
        self.points.append((alias, indicator_id, value))


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.fake = FakeAPI()
        self.api_patch = patch.object(ofi, "bm", self.fake)
        self.clock_patch = patch.object(ofi.time, "monotonic", return_value=0)
        self.print_patch = patch("builtins.print")
        self.api_patch.start()
        self.clock = self.clock_patch.start()
        self.print_patch.start()
        ofi._states.clear()
        ofi._pending_indicators.clear()

    def tearDown(self):
        self.api_patch.stop()
        self.clock_patch.stop()
        self.print_patch.stop()
        ofi._states.clear()
        ofi._pending_indicators.clear()

    def subscribe(self, alias="TEST", mbo=True):
        ofi.handle_subscribe_instrument(None, alias, alias, False, 0.25, 1, 50, {"mbo": mbo})
        for name, request_id, label in reversed(self.fake.registered):
            ofi.handle_indicator_response(None, request_id, request_id + 1000)

    def test_full_callback_smoke(self):
        self.subscribe()
        ofi.handle_mbo_event(None, "TEST", "BID_NEW", "b", 100, 10)
        ofi.handle_mbo_event(None, "TEST", "ASK_NEW", "a", 102, 12)
        ofi.on_interval(None, "TEST")
        self.clock.return_value = 5.1
        ofi.on_interval(None, "TEST")
        self.clock.return_value = 6
        ofi.handle_mbo_event(None, "TEST", "BID_NEW", "b2", 100, 5)
        ofi.on_interval(None, "TEST")
        state = ofi._states["TEST"]
        self.assertIn(("TEST", state.indicators[60], 5.0), self.fake.points)
        self.assertIn(("TEST", state.indicators[0], 0.0), self.fake.points)
        self.clock.return_value = 70
        ofi.on_interval(None, "TEST")
        self.assertIn(("TEST", state.indicators[60], 0.0), self.fake.points)
        ofi.handle_unsubscribe_instrument(None, "TEST")
        self.assertNotIn("TEST", ofi._states)

    def test_unsupported_mbo_does_not_subscribe(self):
        self.subscribe(mbo=False)
        self.assertTrue(ofi._states["TEST"].failed)
        self.assertEqual(self.fake.subscriptions, [])

    def test_missing_order_stops_instead_of_guessing(self):
        self.subscribe()
        ofi.handle_mbo_event(None, "TEST", "CANCEL", "missing", 0, 0)
        self.assertTrue(ofi._states["TEST"].failed)
        ofi.handle_mbo_event(None, "TEST", "BID_NEW", "b", 100, 10)
        self.assertEqual(ofi._states["TEST"].book.orders, {})

    def test_aliases_are_isolated(self):
        self.subscribe("A")
        self.subscribe("B")
        ofi.handle_mbo_event(None, "A", "BID_NEW", "same-id", 100, 10)
        self.assertEqual(ofi._states["B"].book.orders, {})
        self.assertEqual(len(ofi._states["A"].book.orders), 1)

    def test_wire_nan_is_a_float_with_java_spelling(self):
        self.assertIsInstance(ofi.NAN, float)
        self.assertTrue(math.isnan(ofi.NAN))
        self.assertEqual(str(ofi.NAN), "NaN")

    def test_settings_handler_singular_client_name(self):
        called = []
        self.fake.add_on_setting_change_handler = lambda *args: called.append(args)
        ofi._register_settings_handler("addon")
        self.assertEqual(called, [("addon", ofi.on_settings_change)])

    def test_settings_handler_plural_documentation_name(self):
        called = []
        self.fake.add_on_settings_change_handler = lambda *args: called.append(args)
        ofi._register_settings_handler("addon")
        self.assertEqual(called, [("addon", ofi.on_settings_change)])

    def test_no_trading_calls_exist(self):
        tree = ast.parse(Path(ofi.__file__).read_text())
        forbidden = {"send_order", "cancel_order", "move_order", "resize_order"}
        methods = {n.func.attr for n in ast.walk(tree)
                   if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
        self.assertFalse(methods.intersection(forbidden))


if __name__ == "__main__":
    unittest.main(verbosity=2)
