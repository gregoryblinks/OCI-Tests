"""Academic L1 OFI for Bookmap's Python API and an MBO-capable feed.

Cont, Kukanov & Stoikov, "The Price Impact of Order Book Events", section 2.1:
https://arxiv.org/html/1011.6402
Bookmap API reference: https://github.com/BookmapAPI/python-api

Read-only: no trading methods, models, external services or file writes.
Raw OFI over the LAST 60/180/300 seconds, NOT forecasts or trade-volume delta.
Every MBO update is processed; only chart rendering is throttled.
Window timestamps are local monotonic callback-receipt times, not exchange time.

IMPORTANT: The Python callbacks documented by Bookmap do not identify the end
of the initial MBO snapshot. A first-interval + 5-second startup guard is used;
it is a heuristic, NOT a feed-level snapshot-completion guarantee. Reset after
the initial book is fully loaded if needed. Disable/re-enable this add-on after
ANY disconnect/reconnect to obtain a fresh book. See README.md for limitations.
"""

import heapq
import itertools
import math
import time
from array import array
from bisect import bisect_right
from typing import Dict, Optional, Tuple

# EDIT THESE ONLY WHILE THE ADD-ON IS STOPPED.
WINDOWS_SECONDS = (60, 180, 300)
STARTUP_GUARD_SECONDS = 5.0
PLOT_EVERY_SECONDS = 0.25
SHOW_PARTIAL_WINDOWS_DEFAULT = True

RESET_SETTING = "Reset OFI counter (increase to reset)"
PARTIAL_SETTING = "Show partial windows during startup"
BBO = Tuple[int, int, int, int]  # bid price, bid size, ask price, ask size
class _WireNaN(float):
    """A float NaN whose string form is accepted by Java's Double parser.

    Bookmap's Python client serializes indicator values using str(value).
    Python normally writes "nan"; the Java spelling is "NaN".
    """
    def __new__(cls):
        return super().__new__(cls, "nan")

    def __str__(self):
        return "NaN"


NAN = _WireNaN()
bm = None  # Imported by main(), so the calculation can be unit-tested offline.


def academic_ofi_event(previous: BBO, current: BBO) -> int:
    """Exact CKS event contribution, in integer Bookmap size units.

    The four conditions are INDEPENDENT. Equality activates both terms
    on that side, which gives the change in queue size at unchanged price.
    """
    old_bid, old_bid_size, old_ask, old_ask_size = previous
    bid, bid_size, ask, ask_size = current
    return (
        (bid_size if bid >= old_bid else 0)
        - (old_bid_size if bid <= old_bid else 0)
        - (ask_size if ask <= old_ask else 0)
        + (old_ask_size if ask >= old_ask else 0)
    )


class BookIntegrityError(ValueError):
    """The local MBO book cannot safely be continued without resubscribing."""


class MBOBook:
    """Individual orders plus aggregate price-level queues.

    Lazy heaps make best-price lookup inexpensive. Heap compaction prevents
    stale price entries from accumulating indefinitely. A REPLACE is atomic:
    its old and new legs are BOTH applied before the BBO is read.
    """

    def __init__(self):
        self.orders = {}  # order_id -> (is_bid, integer_price, integer_size)
        self.levels = {True: {}, False: {}}
        self.heaps = {True: [], False: []}

    def _change_level(self, is_bid: bool, price: int, delta: int) -> None:
        levels = self.levels[is_bid]
        heap = self.heaps[is_bid]
        old_size = levels.get(price, 0)
        new_size = old_size + delta
        if new_size < 0:
            raise BookIntegrityError("Negative aggregate queue size")
        if new_size:
            levels[price] = new_size
            if old_size == 0:
                heapq.heappush(heap, -price if is_bid else price)
        else:
            levels.pop(price, None)
        if len(heap) > 2 * len(levels) + 1024:
            heap[:] = [-p if is_bid else p for p in levels]
            heapq.heapify(heap)

    def apply(self, event_type: str, order_id: str,
              price: int, size: int) -> None:
        if event_type in ("BID_NEW", "ASK_NEW"):
            if order_id in self.orders:
                raise BookIntegrityError("Duplicate NEW order ID: %s" % order_id)
            if not isinstance(price, int) or not isinstance(size, int) or size <= 0:
                raise BookIntegrityError("NEW requires an integer price and positive size")
            is_bid = event_type == "BID_NEW"
            self.orders[order_id] = (is_bid, price, size)
            self._change_level(is_bid, price, size)
        elif event_type in ("REPLACE", "CANCEL"):
            old_order = self.orders.get(order_id)
            if old_order is None:
                raise BookIntegrityError("%s for unknown order ID: %s" %
                                         (event_type, order_id))
            if event_type == "REPLACE" and (
                not isinstance(price, int) or not isinstance(size, int) or size < 0
            ):
                raise BookIntegrityError("REPLACE requires an integer price and nonnegative size")
            is_bid, old_price, old_size = old_order
            self._change_level(is_bid, old_price, -old_size)
            if event_type == "REPLACE" and size > 0:
                self.orders[order_id] = (is_bid, price, size)
                self._change_level(is_bid, price, size)
            else:
                # CANCEL payload price/size are deliberately ignored.
                del self.orders[order_id]
        else:
            raise BookIntegrityError("Unsupported MBO event: %r" % event_type)

    def _best(self, is_bid: bool):
        heap, levels = self.heaps[is_bid], self.levels[is_bid]
        while heap:
            price = -heap[0] if is_bid else heap[0]
            if price in levels:
                return price, levels[price]
            heapq.heappop(heap)
        return None

    def bbo(self) -> Optional[BBO]:
        bid, ask = self._best(True), self._best(False)
        if bid is None or ask is None:
            return None
        if bid[0] >= ask[0]:
            # Do not interpret a locked/crossed reconstructed book as valid OFI.
            return None
        return bid[0], bid[1], ask[0], ask[1]


class RollingOFI:
    """Exact trailing sums on (now - horizon, now], without time bucketing.

    Compact arrays store timestamps and cumulative integer OFI. Three rolling
    sums share one history. Non-BBO events and zero contributions use no history.
    Expired prefixes are periodically removed; there is no session-long log.
    """

    COMPACT_THRESHOLD = 65536

    def __init__(self, windows=WINDOWS_SECONDS):
        if not windows or any(w <= 0 for w in windows):
            raise ValueError("OFI windows must be positive")
        self.windows = tuple(windows)
        self.timestamps = array("d")
        self.prefixes = array("q")
        self.total = 0
        self.base_total = 0
        self.head = 0
        self.last_time = -math.inf
        self._since_trim = 0

    def _check_time(self, now: float) -> None:
        if not math.isfinite(now) or now < self.last_time:
            raise ValueError("RollingOFI requires finite, nondecreasing timestamps")
        self.last_time = now

    def add(self, now: float, contribution: int) -> None:
        self._check_time(now)
        if not contribution:
            return
        self.total += contribution
        self.timestamps.append(now)
        self.prefixes.append(self.total)
        self._since_trim += 1
        if self._since_trim >= self.COMPACT_THRESHOLD:
            self._trim(now)
            self._since_trim = 0

    def values(self, now: float) -> Dict[int, int]:
        self._check_time(now)
        result = {}
        for horizon in self.windows:
            boundary = bisect_right(self.timestamps, now - horizon, lo=self.head)
            before = self.prefixes[boundary - 1] if boundary > self.head else self.base_total
            result[horizon] = self.total - before
        self._trim(now)
        return result

    def _trim(self, now: float) -> None:
        new_head = bisect_right(self.timestamps, now - max(self.windows), lo=self.head)
        if new_head > self.head:
            self.base_total = self.prefixes[new_head - 1]
            self.head = new_head
        if self.head >= self.COMPACT_THRESHOLD and self.head * 2 >= len(self.timestamps):
            del self.timestamps[:self.head]
            del self.prefixes[:self.head]
            self.head = 0


class InstrumentState:
    def __init__(self, size_multiplier: float, now: float):
        if not math.isfinite(size_multiplier) or size_multiplier <= 0:
            raise ValueError("Instrument size_multiplier must be finite and positive")
        self.size_multiplier = size_multiplier
        self.book = MBOBook()
        self.rolling = RollingOFI()
        self.indicators = {}
        self.previous = None
        self.first_event_at = None
        self.first_interval_at = None
        self.started_at = None
        self.not_before = now
        self.last_plot = -math.inf
        self.failed = None
        self.show_partial = SHOW_PARTIAL_WINDOWS_DEFAULT
        self.reset_counter = 0
        self.created_at = now
        self.no_data_reported = False

    def reset_flow(self, now: float) -> None:
        """Keep the book, discard OFI history, and restart the startup guard."""
        self.rolling = RollingOFI()
        self.previous = None
        self.started_at = None
        self.not_before = now

    def consume(self, now: float, event_type: str, order_id: str,
                price: int, size: int) -> Optional[str]:
        if self.failed:
            return None
        self.book.apply(event_type, order_id, price, size)
        if self.first_event_at is None:
            self.first_event_at = now
        current = self.book.bbo()
        if self.started_at is None:
            return None  # Initial snapshot / guard: build the book but count no flow.
        if current is None:
            self.reset_flow(now)
            return "Book became empty, locked or crossed; OFI history cleared and startup guard restarted."
        contribution = academic_ofi_event(self.previous, current)
        self.rolling.add(now, contribution)
        self.previous = current
        return None

    def start_if_ready(self, now: float) -> bool:
        if self.first_interval_at is None:
            self.first_interval_at = now
        if self.failed or self.started_at is not None or self.first_event_at is None:
            return False
        guard_start = max(self.first_event_at, self.first_interval_at, self.not_before)
        current = self.book.bbo()
        if now - guard_start < STARTUP_GUARD_SECONDS or current is None:
            return False
        self.rolling = RollingOFI()
        self.previous = current
        self.started_at = now
        return True

    def displayed_values(self, now: float) -> Dict[int, float]:
        if self.failed or self.started_at is None:
            return {h: NAN for h in WINDOWS_SECONDS}
        raw = self.rolling.values(now)
        return {
            h: (float(raw[h]) / self.size_multiplier
                if self.show_partial or now - self.started_at >= h else NAN)
            for h in WINDOWS_SECONDS
        }


_states = {}
_pending_indicators = {}
_request_ids = itertools.count(1)


def _notice(addon, alias: str, message: str) -> None:
    text = "Academic OFI [%s]: %s" % (alias, message)
    print(text, flush=True)
    bm.send_user_message(addon, alias, text)


def handle_subscribe_instrument(addon, alias, full_name, is_crypto, pips,
                                size_multiplier, instrument_multiplier,
                                supported_features=None):
    try:
        state = InstrumentState(float(size_multiplier), time.monotonic())
    except (ValueError, TypeError) as exc:
        _notice(addon, alias, "Cannot start: %s" % exc)
        return
    _states[alias] = state
    specifications = (
        (60, "Academic OFI - 1m", (0, 200, 255), "SOLID"),
        (180, "Academic OFI - 3m", (255, 180, 0), "SOLID"),
        (300, "Academic OFI - 5m", (215, 120, 255), "SOLID"),
        (0, "Academic OFI - Zero", (140, 140, 140), "SHORT_DASH"),
    )
    for horizon, name, color, style in specifications:
        request_id = next(_request_ids)
        _pending_indicators[request_id] = (alias, state, horizon)
        bm.register_indicator(addon, alias, request_id, name, "BOTTOM",
                              color=color, line_style=style, initial_value=NAN)
    bm.add_boolean_settings_parameter(addon, alias, PARTIAL_SETTING,
                                       SHOW_PARTIAL_WINDOWS_DEFAULT, reload_if_change=False)
    bm.add_number_settings_parameter(addon, alias, RESET_SETTING, 0, 0, 1000000, 1,
                                     reload_if_change=False)
    bm.add_label_to_settings(
        addon, alias,
        "Raw L1 OFI; 1/3/5m LOOKBACKS, not forecasts. Restart after any feed reconnect."
    )
    if supported_features and supported_features.get("mbo") is False:
        state.failed = "This instrument/connection reports no MBO support."
        _notice(addon, alias, state.failed + " Check your Rithmic connection and MBO entitlement.")
        return
    # Subscribe ONLY to MBO: no MBP double-counting and no added trade volume.
    bm.subscribe_to_mbo(addon, alias, next(_request_ids))
    _notice(addon, alias, "Building MBO book. Initial flow is ignored during the startup guard.")


def handle_unsubscribe_instrument(addon, alias):
    state = _states.pop(alias, None)
    for request_id, record in list(_pending_indicators.items()):
        if record[0] == alias and record[1] is state:
            del _pending_indicators[request_id]


def handle_indicator_response(addon, request_id, indicator_id):
    record = _pending_indicators.pop(request_id, None)
    if record is not None:
        alias, state, horizon = record
        if _states.get(alias) is state:
            state.indicators[horizon] = indicator_id


def handle_mbo_event(addon, alias, event_type, order_id, price_level, size_level):
    state = _states.get(alias)
    if state is None or state.failed:
        return
    try:
        message = state.consume(time.monotonic(), event_type, order_id, price_level, size_level)
        if message:
            _notice(addon, alias, message)
    except (BookIntegrityError, OverflowError, ValueError, TypeError) as exc:
        # Never silently guess a missing order's side or continue with a corrupt book.
        state.failed = str(exc)
        _notice(addon, alias, "STOPPED: %s. Disable/re-enable the add-on to rebuild the book." % exc)


def on_interval(addon, alias):
    state = _states.get(alias)
    if state is None:
        return
    now = time.monotonic()
    if state.start_if_ready(now):
        _notice(addon, alias, "OFI collection started. Values are partial until each lookback fills.")
    if (state.first_event_at is None and not state.failed and
            not state.no_data_reported and now - state.created_at >= 15):
        state.no_data_reported = True
        _notice(addon, alias, "No MBO events received. Check live feed, instrument and MBO support.")
    if now - state.last_plot < PLOT_EVERY_SECONDS:
        return
    state.last_plot = now
    values = state.displayed_values(now)
    for horizon, indicator_id in state.indicators.items():
        bm.add_point(addon, alias, indicator_id, 0.0 if horizon == 0 else values[horizon])


def on_settings_change(addon, alias, setting_name, field_type, new_value):
    state = _states.get(alias)
    if state is None:
        return
    if setting_name == PARTIAL_SETTING:
        state.show_partial = (
            new_value.lower() == "true" if isinstance(new_value, str) else bool(new_value)
        )
    elif setting_name == RESET_SETTING:
        try:
            counter = int(float(new_value))
        except (TypeError, ValueError, OverflowError):
            _notice(addon, alias, "Reset counter must be a whole number.")
            return
        if counter != state.reset_counter:
            state.reset_counter = counter
            if state.failed:
                _notice(addon, alias, "A counter reset cannot repair the book. Disable/re-enable the add-on.")
            else:
                state.reset_flow(time.monotonic())
                _notice(addon, alias, "OFI history reset; restarting the startup guard.")


def _register_settings_handler(addon):
    # The README uses "settings"; the published client source uses "setting".
    register = getattr(bm, "add_on_settings_change_handler", None)
    if register is None:
        register = getattr(bm, "add_on_setting_change_handler", None)
    if register is None:
        raise RuntimeError("This Bookmap Python API version has no settings-change handler")
    register(addon, on_settings_change)


def main():
    global bm
    try:
        import bookmap as bm
    except ImportError as exc:
        raise SystemExit(
            "Run this script INSIDE Bookmap's Python API add-on, not by double-clicking it. "
            "See README.md. The Bookmap runtime supplies the bookmap module."
        ) from exc
    addon = bm.create_addon()
    bm.add_mbo_handler(addon, handle_mbo_event)
    bm.add_on_interval_handler(addon, on_interval)
    bm.add_indicator_response_handler(addon, handle_indicator_response)
    _register_settings_handler(addon)
    bm.start_addon(addon, handle_subscribe_instrument, handle_unsubscribe_instrument)
    bm.wait_until_addon_is_turned_off(addon)


if __name__ == "__main__":
    main()
