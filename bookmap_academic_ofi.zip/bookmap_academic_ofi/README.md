# Academic OFI for Bookmap / Rithmic MBO

## What this is

A read-only Python add-on implementing the Level-1 order flow imbalance (OFI)
event equation from Cont, Kukanov and Stoikov, *The Price Impact of Order Book
Events*, section 2.1. No model, training, fitted coefficients, predictions,
trading orders, external service calls or market-data exports are included.

The three lines are trailing raw sums:

| Indicator | Meaning | Default color |
| --- | --- | --- |
| Academic OFI - 1m | OFI over the last 60 seconds | Cyan |
| Academic OFI - 3m | OFI over the last 180 seconds | Orange |
| Academic OFI - 5m | OFI over the last 300 seconds | Purple |
| Academic OFI - Zero | Zero reference | Gray dashed |

These are LOOKBACKS, not forecasts. Positive means positive signed book-flow
pressure; negative means negative pressure. It does not mean price must move
in the same direction. The result is in instrument quantity units, not ticks,
percentages or probabilities. It is not normalized to -1/+1 or -100/+100.

## Files

- `academic_ofi.py`: the complete script to run in Bookmap.
- `test_academic_ofi.py`: offline calculation and stubbed-adapter tests.
- `test_results.txt`: output of the local test run.
- `README.md`: this guide.

## Installation

1. In Bookmap, install **Python API** through **Settings -> Manage plugins ->
   Bookmap Add-ons (L1)**. Restart Bookmap after installation. Use the Python
   interpreter/runtime supported by your installed Python API version; complete
   its interpreter setup if prompted. The script itself uses Python 3.7+
   language features and the standard library, plus Bookmap's runtime module.
2. Connect your Rithmic feed and open one MBO-capable instrument. Initially
   enable this indicator on just one instrument to simplify verification.
3. Open **Settings -> Configure add-ons**, select/enable **Python API**, and open
   its Python script editor. Bookmap versions can differ in the editor's exact
   button labels.
4. Open `academic_ofi.py` in a text editor, copy its ENTIRE contents, and paste
   those contents into the Python API editor, replacing the example script.
   Save and start/enable the script using that editor's controls.
5. Display Bookmap's lower indicator panel. The three OFI lines and zero line
   are registered there. Check the Python output / Bookmap message log for
   `OFI collection started` or a specific error message.

You do not need a special Bookmap installation-folder location for the source.
Do not load the `.py` file through the Java `.jar` file picker, rename it to
`.jar`, or double-click it to run it as an ordinary standalone Python program.

### Optional: keep the code in a separate file

Instead of pasting all the code, save it at a permanent location and put a
loader in Bookmap's Python editor. For example, on Windows, create
`C:\BookmapScripts` and save `academic_ofi.py` there, then use:

```python
import runpy
runpy.run_path(r"C:\BookmapScripts\academic_ofi.py", run_name="__main__")
```

That path is an EXAMPLE, not a Bookmap-required folder. Change it to the actual
absolute path where you saved the file. Paths on macOS/Linux must be changed
accordingly. Do not rename the script `bookmap.py`, which could shadow the API.

## Startup and settings

Initial MBO events reconstruct an existing book; they must not be counted as
new order flow. This version builds the book without accumulating OFI until
a first interval callback has occurred and a five-second startup guard has
elapsed, with a valid two-sided book available.

**The guard is a heuristic, not a snapshot-completion guarantee.** The documented
Python MBO callback does not provide a snapshot-end flag. After a slow startup,
let the book finish loading, then increase **Reset OFI counter (increase to
reset)** from 0 to 1, or to the next number. This clears the OFI history and
restarts the guard while retaining the reconstructed book.

**Show partial windows during startup** is enabled by default. After collection
starts, a 1-minute line initially contains only the available history; the same
applies to the 3- and 5-minute lines. They become full windows after 60, 180 and
300 seconds, respectively. Disable that setting to leave each line blank until
its full window has accumulated. Different lookbacks can initially have the
same value when all observed flow is inside all three windows.

Settings can be changed without a script reload. To change the hard-coded
windows or guard duration, edit the configuration near the top of the script
while stopped and restart it. Indicator names currently assume 60/180/300
seconds; update their names as well when changing the windows.

## Exact calculation

For consecutive best-bid/ask observations, the code evaluates all four terms:

```text
e =  I(new_bid >= old_bid) * new_bid_size
   - I(new_bid <= old_bid) * old_bid_size
   - I(new_ask <= old_ask) * new_ask_size
   + I(new_ask >= old_ask) * old_ask_size
```

At unchanged prices, adding 5 at the best bid contributes +5. Removing 4 at the
best ask contributes +4. Adding 8 at the best ask contributes -8. A bid price
improvement contributes the NEW best-bid quantity; a bid deterioration removes
the OLD best-bid quantity. The corresponding ask signs are reversed.

The add-on processes individual BID_NEW, ASK_NEW, REPLACE and CANCEL events,
maintains aggregated price-level queues, and evaluates OFI after each complete
MBO event. A REPLACE removes the old order and inserts its replacement before
comparing best quotes. Deep-book changes contribute zero unless they change
the best quotes. There is no separate trade-volume term: execution-related
queue changes are already reflected in the book. Counting trades again would
change the indicator.

Every incoming event is processed. Chart drawing is throttled to approximately
0.25-0.3 seconds, depending on Bookmap's interval callbacks. The three rolling
sums share timestamp/prefix arrays and use exact `(now - horizon, now]`
boundaries. There is no 1-second or 100-millisecond feature downsampling.

## Operational limitations

- **Live receipt-time implementation:** timestamps come from Python's monotonic
  clock when callbacks are handled, not from exchange timestamps. Feed/bridge
  delay or a processing backlog can therefore shift the clock-time windows.
  This script is not suitable for historical research, accelerated replay or
  claiming exchange-timestamp accuracy. It does not backfill earlier chart data.
- **After ANY feed disconnect/reconnect:** disable and re-enable the add-on to
  request a fresh MBO snapshot. The reset counter alone cannot rebuild a book
  that missed messages. Not all silent feed gaps can be detected by this code.
- **Integrity protection:** duplicate NEW IDs, unknown REPLACE/CANCEL IDs and
  invalid sizes stop calculation instead of guessing missing data. Read the log,
  reconnect as necessary and re-enable the add-on. If these recur, the feed
  semantics need investigation; do not silently ignore the errors.
- **Invalid quotes:** if an active reconstructed book becomes empty, locked or
  crossed, this implementation clears OFI history and repeats the startup guard.
  A new valid baseline is required, so this can create chart gaps. Frequent gaps
  need investigation of feed sequencing rather than interpretation as neutral
  flow. A visible zero reference alone does not prove the feed is healthy.
- **No trading advice or signal guarantee:** OFI describes order-book events;
  it is not a calibrated return forecast or an automatic entry/exit rule.

## Live-data permission check

Bookmap's current custom-add-on guide states that custom add-ons require
verification/signing to run on paid exchange data, including CME. That guide
specifically describes the Java/JAR signing workflow. The Python API page does
not clearly resolve how this applies to user Python scripts on Rithmic.

This package is NOT signed or approved by Bookmap. Account-level availability
has not been verified. If Bookmap blocks activation with a permissions/signing
message, ask Bookmap support whether your Python API setup is permitted for
that instrument and which approval route applies. A `.py` file is not a signed
`.jar`; do not assume the code bypasses data-access restrictions.

## Troubleshooting

**No module named bookmap:** run through Bookmap's Python API editor and its
configured runtime. Do not install an unrelated similarly named package from
PyPI as a substitute.

**Only the zero line appears:** inspect the log for no-MBO, startup, invalid-book
or integrity messages. Ensure the feed is live and MBO-capable. If partial
windows are disabled, the other lines remain blank until their windows fill.

**Permission/signing error:** see the permission check above. This is distinct
from an OFI equation or Python syntax issue.

**Second instrument causes problems:** first validate on one instrument. The
calculation state is separated by instrument, but this does not certify the
installed Python API's own multi-instrument behavior.

## Verification performed

45 local automated tests passed, including explicit price/quantity sign cases,
10,000 randomized formula comparisons, randomized order reconstruction,
12,000 rolling-history events with brute-force comparisons, expiry/compaction,
startup/reset behavior, and callback tests using a stub API. Syntax compilation
also passed. The wire-format NaN spelling and both published spellings of the
settings-change handler are covered.

**Not performed:** execution inside Bookmap, a real Rithmic session, account
permission verification, or sustained live-feed load testing. A successful
local test run is not a claim of live integration certification.

To rerun the offline tests from this folder:

```text
python -m unittest -v test_academic_ofi.py
```

## Primary references checked on 2026-10-02

- Academic equation, section 2.1: https://arxiv.org/html/1011.6402
- Bookmap Python API documentation: https://github.com/BookmapAPI/python-api
- Published Python client implementation:
  https://github.com/BookmapAPI/python-api/blob/master/client-rpc/src/bookmap/bookmap.py
- Installation / Python API limitations:
  https://bookmap.com/knowledgebase/docs/Addons-Python-API
- Bookmap custom add-on activation and signing guidance:
  https://bookmap.com/knowledgebase/docs/KB-Bookmap-Vibe-Coding-Starter-Guide

The implementation is original; it uses the published academic equation and
Bookmap's documented API. Bookmap and Rithmic are third-party products; this
package is not endorsed by either company.
